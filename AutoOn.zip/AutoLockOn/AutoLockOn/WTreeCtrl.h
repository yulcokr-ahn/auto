#pragma once


// CWTreeCtrl

class CWTreeCtrl : public CTreeCtrl
{
	DECLARE_DYNAMIC(CWTreeCtrl)

public:
	CWTreeCtrl();
	virtual ~CWTreeCtrl();
	BOOL SetTransparentColor(COLORREF rgb, BOOL bTrans, BYTE transparency);

	int		m_nSkinMode;
	int		m_nTansparent;
	int		m_nXPos;
	int		m_nYPos;
	int		m_nAutoRun;
	int		m_nAutoQuit;

	// ��Ƽ����Ʈ(MBCS) �� �����ڵ�(CString)
	CString ConvertMBCSToUnicode(const char* pszMultiByte);
	CStringA ConvertUnicodeToMBCS(const CStringW& strUnicode);


protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
protected:
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	/*
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnNcPaint();
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult);
*/
	//}}AFX_MSG
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()
};


