#if !defined(AFX_COLORSHOW_H__1D3163CC_97BE_45EE_828D_8C5D97A75ACC__INCLUDED_)
#define AFX_COLORSHOW_H__1D3163CC_97BE_45EE_828D_8C5D97A75ACC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColorShow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CColorShow window

class CColorShow : public CStatic
{
// Construction
public:
        CColorShow();

int nModeType; // = MODE_DEMO;

// Attributes
public:

// Operations
public:
   void RecomputeImage();
   void SetSize(int n);
   void AdjustPos(int dx, int dy);
   void Copy();
   void Show();
   void StartPick(CPoint pt);
   CRect MakeSelection();
   CRect MapSelection(const CRect & r);
// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CColorShow)
        //}}AFX_VIRTUAL

// Implementation
public:
        virtual ~CColorShow();

        // Generated message map functions
protected:
//2010.09.12
bool m_bTracking;


        int dx;
        int dy;
        HCURSOR dropper;
        CBitmap bmp;
        CPoint where;
        COLORREF color;
        BOOL select;
        CPoint previous;
        CPoint anchor;
        CRect selection;
        CSize GetSize();
        void PrepareDC(CDC & dc);
        void DrawSelection(CDC & dc);
        //{{AFX_MSG(CColorShow)
        afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
        afx_msg void OnMouseMove(UINT nFlags, CPoint point);
        afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
        afx_msg void OnPaint();
        //}}AFX_MSG

        DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#include "msg.h"

#define UWM_POINT_HWND_MSG _T("UWM_POINT_HWND-{9ED38EEB-3069-48b0-B770-E13BDAE8A1D3}")
#define UWM_POINT_DEMO_MSG _T("UWM_POINT_DEMO-{9ED38EEB-3069-48b0-B770-E13BDAE8A1D3}")
#define UWM_POINT_MAIN_MSG _T("UWM_POINT_MAIN-{9ED38EEB-3069-48b0-B770-E13BDAE8A1D3}")


#endif // !defined(AFX_COLORSHOW_H__1D3163CC_97BE_45EE_828D_8C5D97A75ACC__INCLUDED_)
