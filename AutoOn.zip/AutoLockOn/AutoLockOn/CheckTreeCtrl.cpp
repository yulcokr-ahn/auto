//#######################################################################################
//## CheckTreeCtrl.cpp : implementation file
//#######################################################################################
#include "stdafx.h"
#include "CheckTreeCtrl.h"
#include "CheckComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//#######################################################################################
CCheckTreeCtrl::CCheckTreeCtrl() : CTreeCtrl()
{
	//## INITIALIZE
	m_pwndParentCombo = NULL;
	m_hPrevSelected = NULL;
	m_bUpdateNeeded = FALSE;
	m_bExclusive = FALSE;
}

//## ====================================================================================
CCheckTreeCtrl::~CCheckTreeCtrl()
{
}

//#######################################################################################
BEGIN_MESSAGE_MAP(CCheckTreeCtrl, CTreeCtrl)
	ON_WM_LBUTTONDOWN()
	//ON_WM_LBUTTONUP()
	ON_WM_PAINT()
END_MESSAGE_MAP()

//#######################################################################################
void CCheckTreeCtrl::Populate()
{
	//## ASSERT
	if (!m_hWnd) return;

	//## GET Data
	CCheckTreeData* pTreeData = ((CCheckComboBox*)m_pwndParentCombo)->GetData();
	BOOL bImageList = (GetImageList(TVSIL_NORMAL) != NULL);

	//## INSERT ROOT
	//## ADD rest of the items
	HTREEITEM hParents[TREE_MAX_LEVELS];
	HTREEITEM hFirst = NULL;
	hParents[ROOT_LEVEL] = TVI_ROOT;

	long nLevel; BOOL bIsLeaf;
	for(long i=1; i<pTreeData->GetSize(); i++){
		nLevel = pTreeData->ElementAt(i).nLevel;
		bIsLeaf = pTreeData->ElementAt(i).bIsLeaf;
		if (bImageList)
		{
			if(nLevel == ROOT_LEVEL)
				hParents[ nLevel ] = InsertItem( pTreeData->ElementAt(i).strCaption, (bIsLeaf) ? IMG_ITEM : IMG_CLOSE, (bIsLeaf) ? IMG_ITEM : IMG_CLOSE, TVI_ROOT);
			else
				hParents[ nLevel ] = InsertItem( pTreeData->ElementAt(i).strCaption, (bIsLeaf) ? IMG_ITEM : IMG_CLOSE, (bIsLeaf) ? IMG_ITEM : IMG_CLOSE, hParents[nLevel-1] );
		}
		else
		{
			if(nLevel == ROOT_LEVEL)
				hParents[ nLevel ] = InsertItem( pTreeData->ElementAt(i).strCaption, TVI_ROOT );
			else
				hParents[ nLevel ] = InsertItem( pTreeData->ElementAt(i).strCaption, hParents[nLevel-1] );
		}

		if(!hFirst)
			hFirst = hParents[ nLevel ];
		SetItemData(hParents[ nLevel ], pTreeData->ElementAt(i).nID);
	}
}


void CCheckTreeCtrl::AddString(LPCTSTR lpszString, int nID)
{
	if (!m_hWnd) return;

	BOOL bImageList = (GetImageList(TVSIL_NORMAL) != NULL);
	HTREEITEM hItem, hParent = GetRootItem();
	if(!hParent)
		return;

	if (bImageList)
		hItem = InsertItem(lpszString, IMG_ITEM, IMG_ITEM, hParent);
	else
		hItem = InsertItem(lpszString, hParent);
	SetItemData(hItem, nID);
}


void CCheckTreeCtrl::OnLButtonDown(UINT nFlags, CPoint point)
{
	BOOL bChanged = FALSE;
	HTREEITEM hItem = HitTest(point, &nFlags);
	if(hItem == NULL)
		return;
	if(ItemHasChildren(hItem))
		return;

	if(m_bExclusive)
	{
		if(m_hPrevSelected)
			if(m_hPrevSelected != hItem)
				SetCheck(m_hPrevSelected, FALSE);
	}

	BOOL bCheck = GetCheck(hItem);
	SetCheck(hItem, !bCheck);

	if(!bCheck)
		m_hPrevSelected = hItem;
	else
		m_hPrevSelected = NULL;

	//## UPDATE Needed
	m_bUpdateNeeded = TRUE;

	//## UPDATE to state
	UpdateToState();
	m_pwndParentCombo->SendMessage(WM_COMMAND, MAKELONG(GetWindowLong(this->m_hWnd, GWL_ID), CBN_SELCHANGE), (LPARAM)this->m_hWnd);

	if(m_bExclusive)
	{
		if(m_pwndParentCombo)
			((CCheckComboBox *)m_pwndParentCombo)->Drop(FALSE);
	}
}

#if 0
//##	 ====================================================================================
void CCheckTreeCtrl::OnLButtonUp(UINT nFlags, CPoint point)
{
	//## CALL Parent
	CTreeCtrl::OnLButtonDown(nFlags, point);

	//## UPDATE Needed
	m_bUpdateNeeded = TRUE;

	//## UPDATE to state
	UpdateToState();
}
#endif

//## ====================================================================================
void CCheckTreeCtrl::OnPaint()
{
	//## CALL Parent
	CTreeCtrl::OnPaint();

	//## UPDATE to state
	if (m_bUpdateNeeded){
		m_bUpdateNeeded = FALSE;
		UpdateToState();
	}
}


void CCheckTreeCtrl::CheckChange(HTREEITEM hItem)
{
	long nIndex;
	BOOL bChecked;

	//## GET Data
	CCheckTreeData* pTreeData = ((CCheckComboBox*)m_pwndParentCombo)->GetData();
	if (!pTreeData) return;
	if (!pTreeData->GetSize()) return;

	while(hItem){
		//## GET ItemData = Index
		nIndex = GetItemData(hItem);

		//## UPDATE Image if needed
		if ((nIndex >= 0) && (!pTreeData->GetNode(nIndex)->bIsLeaf))
			UpdateItemImage(hItem);

		//## GET Checked. Modification => update & exit
		bChecked = GetCheck(hItem);

		if(bChecked && ItemHasChildren(hItem))
			SetCheck(hItem, FALSE);

		if ((nIndex >= 0) && (pTreeData->GetNode(nIndex)->bChecked != bChecked)){
			pTreeData->GetNode(nIndex)->bChecked = bChecked;
			pTreeData->UpdateChecks(nIndex);
		}
	
		//## GO ON
		hItem = GetNextItem(hItem, TVGN_NEXT);
	}
}

//#######################################################################################
void CCheckTreeCtrl::UpdateToState()
{
	//## ASSERT
	if (!m_pwndParentCombo) return;

	//## SCAN TREE
	HTREEITEM hItem = GetRootItem();
	CheckChange(GetNextItem(hItem, TVGN_CHILD));
	// 2nd Root
	hItem = GetNextItem(hItem, TVGN_NEXT);
	CheckChange(GetNextItem(hItem, TVGN_CHILD));

	UpdateFromState();
	UpdateParentWnd();
	Invalidate();
}

//#######################################################################################
BOOL CCheckTreeCtrl::GetItemExpanded(HTREEITEM hItem)
{
	//## ASSERT
	if (!hItem) return FALSE;

	//## RETURN Expanded
	return ((GetItemState(hItem, TVIS_EXPANDED) & TVIS_EXPANDED) != 0L);
}

//## ====================================================================================
void CCheckTreeCtrl::UpdateItemImage(HTREEITEM hItem)
{
	//## ASSERT
	if (!hItem) return;

	//## DECLARE
	BOOL bExpanded;
	int nImage, nSelectedImage;

	//## GET Expanded + Image
	bExpanded = GetItemExpanded(hItem);
	GetItemImage(hItem, nImage, nSelectedImage);

	//## UPDTE Image if necessary
	if (bExpanded && (nImage == IMG_CLOSE))
		SetItemImage(hItem, IMG_OPEN, IMG_OPEN);
	if (!bExpanded && (nImage == IMG_OPEN))
		SetItemImage(hItem, IMG_CLOSE, IMG_CLOSE);
}
//#######################################################################################
void CCheckTreeCtrl::UpdateFromState()
{
	//## ASSERT
	if (!m_pwndParentCombo) return;

	//## GET Data
	CCheckTreeData* pTreeData = ((CCheckComboBox*)m_pwndParentCombo)->GetData();
	if (pTreeData->GetSize() <= 0) return;

	//## GET Root & RootIndex
	HTREEITEM hItem = GetRootItem();
	long nIndex = GetItemData(hItem);

	//## SELECT
	HTREEITEM hItemToSelect = GetNextItem(TVI_ROOT, TVGN_CARET);
	if (!hItemToSelect) hItemToSelect = hItem;
	SelectItem( hItemToSelect );
	//## RECURSIVE
	RecursiveUpdateFromState(hItem);

	// 2nd Root
	hItem = GetNextItem(hItem, TVGN_NEXT);
	//## RECURSIVE
	RecursiveUpdateFromState(hItem);
}

//## ====================================================================================
void CCheckTreeCtrl::RecursiveUpdateFromState(HTREEITEM hParentItem)
{
	//## ASSERT
	if (!ItemHasChildren(hParentItem)) return;

	//## GET Data
	CCheckTreeData* pTreeData = ((CCheckComboBox*)m_pwndParentCombo)->GetData();

	//## SCAN
	long nIndex = 0L;
	HTREEITEM hItem = GetChildItem(hParentItem);
	while(hItem){
		//## GET ItemData = Index
		nIndex = GetItemData(hItem);

		//## SET Check
		SetCheck( hItem, pTreeData->GetNode(nIndex)->bChecked );
		if(pTreeData->GetNode(nIndex)->bChecked)
			m_hPrevSelected = hItem;

		//## RECURSIVE
		RecursiveUpdateFromState(hItem);

		//## GO ON
		hItem = GetNextItem(hItem, TVGN_NEXT);
	}	
}


//## ====================================================================================
void CCheckTreeCtrl::UpdateParentWnd()
{
	//## ASSERT
	if (!m_pwndParentCombo) return;

	//## GET Data
	CCheckTreeData* pTreeData = ((CCheckComboBox*)m_pwndParentCombo)->GetData();
	if (!pTreeData) return;

	//## SET Caption
	m_pwndParentCombo->SetWindowText( pTreeData->GetCheckedTexts() );
}
//#######################################################################################


void CCheckTreeCtrl::ExpandRoot()
{
	//## EXPAND Root
	HTREEITEM hItem1 = GetRootItem();
	HTREEITEM hItem2 = GetNextItem(hItem1, TVGN_NEXT);
	Expand(hItem1, TVE_EXPAND);
	Expand(hItem2, TVE_EXPAND);
	EnsureVisible(hItem1);
}
