// ColorSwatch.cpp : implementation file
//

#include "stdafx.h"
#include "ColorSwatch.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorSwatch

CColorSwatch::CColorSwatch()
{
}

CColorSwatch::~CColorSwatch()
{
}


BEGIN_MESSAGE_MAP(CColorSwatch, CStatic)
        //{{AFX_MSG_MAP(CColorSwatch)
        ON_WM_PAINT()
        ON_WM_ERASEBKGND()
        //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorSwatch message handlers

void CColorSwatch::OnPaint() 
   {
    CPaintDC dc(this); // device context for painting

    CRect r;
    GetClientRect(&r);
    dc.FillSolidRect(&r, color);

    // Do not call CStatic::OnPaint() for painting messages
}

BOOL CColorSwatch::OnEraseBkgnd(CDC* pDC) 
   {
    // Do nothing
    return TRUE;
   }
