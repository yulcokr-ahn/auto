//#######################################################################################
//## CheckComboBox.h : header file
//## [Magerusan G. Cosmin] 20-apr-2002
//#######################################################################################
#if !defined(__CHECKCOMBOCTRL_H__)
#define __CHECKCOMBOCTRL_H__
//#######################################################################################
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//## ====================================================================================
#include "CheckTreeCtrl.h"
#include "CheckTreeData.h"
//## ====================================================================================
#define DROP_BUTTON_WIDTH 16
#define DROPDOWN_HEIGHT 300
#define TOOLTIP_MAX_WIDTH 350
#define TOOLTIP_MAX_CHARACTERS 50*20
#define DROPPED_WIDTH_NOT_SET -1
//#######################################################################################

#define IDC_CHECK_TREE	0x3E8

#define WM_CHANGECHECK	WM_USER + 2000

static CWnd* m_pwndParent;

class AFX_EXT_CLASS CCheckComboBox : public CButton
{
//## CONSTRUCTOR
public:
	CCheckComboBox();
	virtual ~CCheckComboBox();
	DECLARE_DYNAMIC(CCheckComboBox)

//## STATE
private:
	CCheckTreeCtrl*	m_pwndTree;
	CCheckTreeData	m_Data;
	CImageList		m_imgList;
	static WNDPROC	m_parentWndProc;
	static CWnd*	m_pwndXPX_ACTIVEDropDown;
	static CCheckComboBox* m_pwndXPX_ACTIVECheckComboBox;
	static CRect	m_rcParentRect;
	CToolTipCtrl	m_ToolTip;
	long			m_nDroppedWidth;
	CBitmap			m_Bitmap;
	BOOL			m_bExclusive;

//## OVERRIDE
protected:
	virtual LRESULT WindowProc( UINT message, WPARAM wParam, LPARAM lParam );
	virtual BOOL PreTranslateMessage( MSG* pMsg );
	virtual void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );

//## MESSAGES
protected:
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSelchangeCheckTree();
	afx_msg UINT OnGetDlgCode();

	static LRESULT CALLBACK ParentWindowProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);
	static BOOL IsMsgOK(HWND hWnd, UINT nMsg,/* WPARAM wParam,*/ LPARAM lParam);
	DECLARE_MESSAGE_MAP()

//## INTERCEPT Methods
private:
	void InterceptParentWndProc();
	void UnInterceptParentWndProc();

//## PROPERTIES
public:
	CCheckTreeData* GetData(){ return &m_Data; };

//## DROP Methods
private:
	void CreateDropWnd();
	void ShowDropWnd();
	void PlaceDropWnd();
	BOOL IsDropped();
	static void HideXPX_ACTIVEDropDown();

//## TREE Methods
public:
	void AddString(LPCTSTR lpszString, long nID, long nLevel);
	void InsertString(LPCTSTR lpszString, long nID, long = ROOT_LEVEL + 1);
	void CheckAll(BOOL bCheck);
	void Drop(BOOL bDrop);
	void Reset();
	void Refresh();

//## GET/SET Methods
public:
	int			GetCount();
	BOOL		GetCheck(long nID);
	CString		GetCheckedIDs();
	CString		GetCheckedTexts();
	CString		GetIDString(int nID);
	CImageList* GetImageList();
	long		GetDroppedWidth();

	void		SetCheck(long nID, BOOL bCheck);
	void		SetImageList(CImageList *pimgList);
	void		SetDroppedWidth(long nWidth);
	void		SetBitmap(CString strBitmap);
	void		SetExclusiveMode(BOOL bExclusive);


//## TOOLTIP & CAPTION Methods
private:
	void InitToolTip();
	void SetToolTipText(CString strText, BOOL bActivate = TRUE);
	void SetToolTipText(int nId, BOOL bActivate = TRUE);
	void UpdateCaption();
};
//#######################################################################################
#endif // !defined(__CHECKCOMBOCTRL_H__)
//#######################################################################################
