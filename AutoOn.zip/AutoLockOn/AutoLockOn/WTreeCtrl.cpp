﻿// WTreeCtrl.cpp : 구현 파일입니다.
//

#include "stdafx.h"
#include "AutoLockOn.h"
#include "WTreeCtrl.h"

#include <gdiplus.h>
using namespace Gdiplus;


//////////////////////////////////////////////////////////////////////////////////////////////////
#define TREE_TEXT_COLOR		RGB(0,0,0)
#define TREE_NORAM_BACK		RGB(255,255,255)
#define TREE_NORAM_LINE		RGB(255,255,255)
#define TREE_HILITE_BACK	RGB(240,240,240)
#define TREE_HILITE_LINE	RGB(189,189,189)

// CWTreeCtrl
typedef BOOL (WINAPI *lpfnSetLayeredWindowAttributes)	(HWND hWnd, COLORREF cr, BYTE bAlpha, DWORD dwFlags);
static lpfnSetLayeredWindowAttributes g_pSetLayeredWindowAttributes = NULL;
static CPoint g_pointScreen = CPoint(0, 0);
static UINT WM_WorldClock_INIT = ::RegisterWindowMessage(_T("WM_WorldClock_INIT"));


IMPLEMENT_DYNAMIC(CWTreeCtrl, CTreeCtrl)

CWTreeCtrl::CWTreeCtrl()
{
		m_nTansparent = 100;

}

CWTreeCtrl::~CWTreeCtrl()
{
}


BEGIN_MESSAGE_MAP(CWTreeCtrl, CTreeCtrl)

	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnCustomDraw)
	ON_WM_CTLCOLOR_REFLECT()
END_MESSAGE_MAP()



///////////////////////////////////////////////////////////////////////////////
BOOL CWTreeCtrl::SetTransparentColor(COLORREF rgb, BOOL bTrans, BYTE transparency)
{
	if (!g_pSetLayeredWindowAttributes)
		return FALSE;
	if (bTrans)
	{
		SetWindowLong(m_hWnd, GWL_EXSTYLE, GetWindowLong(m_hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
		g_pSetLayeredWindowAttributes(m_hWnd, rgb, transparency, LWA_COLORKEY|LWA_ALPHA);
	}
	else
	{
		SetWindowLong(m_hWnd, GWL_EXSTYLE, GetWindowLong(m_hWnd, GWL_EXSTYLE) & ~WS_EX_LAYERED);
		::RedrawWindow(m_hWnd, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN);
	}
	return TRUE;
}

int CWTreeCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
/*
	ULONG_PTR m_gdiplusToken;
	Gdiplus::GdiplusStartupInput gdiplusStartupInput;
	Gdiplus::GdiplusStartup(&m_gdiplusToken, &gdiplusStartupInput, NULL);

	HMODULE hUser32 = GetModuleHandle(_T("USER32.DLL"));
	g_pSetLayeredWindowAttributes = (lpfnSetLayeredWindowAttributes) GetProcAddress(hUser32, "SetLayeredWindowAttributes");
	SetTransparentColor(RGB(255,0,255), TRUE, 255-m_nTansparent);
*/	



	return 0;
}

HBRUSH CWTreeCtrl::CtlColor(CDC* pDC, UINT nCtlColor)
{
	pDC->SetBkMode(TRANSPARENT);             // 배경 투명하게
	pDC->SetTextColor(RGB(255, 255, 255));   // 글자색 (선택 가능)
	return (HBRUSH)::GetStockObject(HOLLOW_BRUSH); // 배경 브러시: 없음
}
void CWTreeCtrl::OnPaint() 
{
	/*
	CWindowDC dc(this);					

	CRect rc, rcTemp;
	GetWindowRect(&rc);
	ScreenToClient(&rc);
	OffsetRect(&rc, -rc.left, -rc.top);

	Default();					

	DWORD dwStyle = GetStyle();
	BOOL bHorz = (dwStyle & WS_HSCROLL);
	BOOL bVert = (dwStyle & WS_VSCROLL);
*/

}
void CWTreeCtrl::OnDestroy() 
{
	CTreeCtrl::OnDestroy();
}

BOOL CWTreeCtrl::OnEraseBkgnd(CDC* pDC) 
{
	/*
	// fill background with transparent color
	CRect rect;
	GetWindowRect(&rect);
	ScreenToClient(&rect);
	CBrush brush(RGB(255,0,255));
	pDC->FillRect(&rect, &brush);
*/
//	return CTreeCtrl::OnEraseBkgnd(pDC);
	return TRUE;
}
/*
void CWTreeCtrl::OnSize(UINT nType, int cx, int cy)
{
	CTreeCtrl::OnSize(nType, cx, cy);

	// 둥근 사각형 Region 적용 (반지름 15)
	CRgn rgn;
	rgn.CreateRoundRectRgn(0, 0, cx, cy, 15, 15);
	SetWindowRgn(rgn, TRUE);
}
*/
/*
void CWTreeCtrl::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMTVCUSTOMDRAW pDraw = (LPNMTVCUSTOMDRAW)pNMHDR;

	switch (pDraw->nmcd.dwDrawStage)
	{
	case CDDS_PREPAINT:
		*pResult = CDRF_NOTIFYITEMDRAW;
		return;
	case CDDS_ITEMPREPAINT:
	
		HTREEITEM hItem = (HTREEITEM)pDraw->nmcd.dwItemSpec;

		CString txt;
		txt.Format(_T("%s") , GetItemText(hItem) );
		int nLen = MultiByteToWideChar(CP_ACP, 0, txt, -1, NULL, 0);
std:wstring wstr(nLen, L'\0');
		MultiByteToWideChar(CP_ACP, 0, txt, -1, &wstr[0], nLen);

		CRect rc;
		GetItemRect(hItem, &rc, TRUE);
		UINT uState = GetItemState(hItem, TVIS_SELECTED);
		HDC hdc = pDraw->nmcd.hdc;

		// GDI+ 객체 생성
		SetBkMode(hdc, TRANSPARENT); // GDI용
		Graphics graphics(hdc);

		SolidBrush bgBrush(Color(50, 50, 240, 50)); // 연한 회색
		graphics.SetTextRenderingHint(TextRenderingHintAntiAlias);

		// 선택 항목이면 연회색 배경 그리기
		Pen borderPen(Color(255, 189, 189, 189), 1);
		if (uState & TVIS_SELECTED) {
			graphics.FillRectangle(&bgBrush, rc.left, rc.top, rc.Width(), rc.Height());
			graphics.DrawRectangle(&borderPen, rc.left, rc.top, rc.Width() - 1, rc.Height() - 1);
		}

		// '굴림체'로 폰트 생성
		Gdiplus::FontFamily fontFamily(L"굴림체");  // 한글 폰트 '굴림체'
		Gdiplus::Font font(&fontFamily, 14, FontStyleRegular, UnitPixel);

		SolidBrush textBrush(Color(255, 0, 0, 0)); // 검정 텍스트
		// 텍스트 위치 설정
		RectF layoutRect((REAL)rc.left, (REAL)(rc.top + 2), (REAL)rc.Width(), (REAL)rc.Height());
		// 텍스트 출력
		graphics.FillRectangle(&bgBrush, layoutRect.X, layoutRect.Y , layoutRect.Width , layoutRect.Height  );
		graphics.DrawString(wstr.c_str() , -1, &font, layoutRect, NULL, &textBrush);
		*pResult = CDRF_SKIPDEFAULT;
		return;
	}
	*pResult = 0;
}
*/


void CWTreeCtrl::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	*pResult = 0;
	NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMHDR;
	*pResult = CDRF_DODEFAULT;

	if (pTVCD->nmcd.dwDrawStage == CDDS_PREPAINT) {
		*pResult = CDRF_NOTIFYITEMDRAW;
	}
	else if (pTVCD->nmcd.dwDrawStage == CDDS_ITEMPREPAINT) {
		*pResult = CDRF_NOTIFYPOSTPAINT;
	}
	else if (pTVCD->nmcd.dwDrawStage == CDDS_ITEMPOSTPAINT) {
		HTREEITEM hItem = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

		CString txt;
		txt.Format(_T("%s") , GetItemText(hItem) );
		int nLen = MultiByteToWideChar(CP_ACP, 0, txt, -1, NULL, 0);
		std:wstring wstr(nLen, L'\0');
		MultiByteToWideChar(CP_ACP, 0, txt, -1, &wstr[0], nLen);

		CRect rc;
		GetItemRect(hItem, &rc, TRUE);
		UINT uState = GetItemState(hItem, TVIS_SELECTED);
		HDC hdc = pTVCD->nmcd.hdc;

		// GDI+ 객체 생성
		SetBkMode(hdc, TRANSPARENT); // GDI용
		Graphics graphics(hdc);

		SolidBrush bgBrush(Color(255, 240, 240, 240)); // 연한 회색
		graphics.SetTextRenderingHint(TextRenderingHintAntiAlias);

		// 선택 항목이면 연회색 배경 그리기
		Pen borderPen(Color(255, 189, 189, 189), 1);
		if (uState & TVIS_SELECTED) {
			graphics.FillRectangle(&bgBrush, rc.left, rc.top, rc.Width(), rc.Height());
			graphics.DrawRectangle(&borderPen, rc.left, rc.top, rc.Width() - 1, rc.Height() - 1);
		}

		// '굴림체'로 폰트 생성
		Gdiplus::FontFamily fontFamily(L"굴림체");  // 한글 폰트 '굴림체'
		Gdiplus::Font font(&fontFamily, 14, FontStyleRegular, UnitPixel);

		SolidBrush textBrush(Color(255, 0, 0, 0)); // 검정 텍스트
		// 텍스트 위치 설정
		RectF layoutRect((REAL)rc.left, (REAL)(rc.top + 2), (REAL)rc.Width(), (REAL)rc.Height());
		// 텍스트 출력
		graphics.FillRectangle(&bgBrush, layoutRect.X, layoutRect.Y , layoutRect.Width , layoutRect.Height  );
		graphics.DrawString(wstr.c_str() , -1, &font, layoutRect, NULL, &textBrush);
//		*pResult = CDRF_SKIPDEFAULT;
	}
	else {
		*pResult = CDRF_SKIPDEFAULT;
	}
}

// CWTreeCtrl 메시지 처리기입니다.


