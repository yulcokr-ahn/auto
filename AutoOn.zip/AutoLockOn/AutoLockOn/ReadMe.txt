/** 
 * @file ColorMap.cpp
 * @brief CColorMap Ŭ������ ���� ����
 * @author ������
 * @date 2005.11.28
 * ���� ���� 
 * 
 */

#include "StdAfx.h"
#include "SharedInfoDll/SharedInfo.h"
#include ".\colormap.h"
#include "ColorMapDef.h"

#define		COLORMAPFILE			"ColorMap.txt"
#define		USERCOLORMAPFILE		"UserColorMap.txt"

#define		DEFAULTINFO_START		"INFO"
#define		DEFAULTINFO_END			"INFO_END"
#define		COLORMAP_START			"COLORMAP"
#define		COLORMAP_END			"COLORMAP_END"
#define		COLORMAP_START_LENGTH	8



CColorInfoMap CColorMap::m_curColorMap;
//////////////////////////////////////////////////////////////////
// CColorSelList
//////////////////////////////////////////////////////////////////

CColorSelList::CColorSelList(void)
{
	m_strName = "";
	m_bUserDefine = FALSE;
}

CColorSelList::~CColorSelList(void)
{
	CColorInfo *pInfo = NULL;

	for(int i=0; i < m_arrColorInfo.GetCount(); i++)
	{
		pInfo = m_arrColorInfo.GetAt(i);
		if(pInfo != NULL)
		{
			delete pInfo;
		}
	}
}

//////////////////////////////////////////////////////////////////
// CColorMap
//////////////////////////////////////////////////////////////////

#define MODE_RUN 1 

CColorMap::CColorMap(void)
{
}

CColorMap::~CColorMap(void)
{
}



CColorInfo *CColorMap::GetColorInfo(WORD wID)
{
	CColorInfo *pInfo = NULL;

	if(!m_curColorMap.Lookup(wID,pInfo))
	{
		pInfo = new CColorInfo();
		pInfo->SetID(wID);
		pInfo->SetColor(RGB(245,245,233));
		m_curColorMap.SetAt(wID,pInfo);
	}
	return pInfo;
}

void CColorMap::SetColor(WORD wID, COLORREF m_color)
{
	CColorInfo *pInfo = NULL;
	
	if(m_curColorMap.Lookup(wID,pInfo))
	{
		pInfo->SetColor(m_color);
	}
	else 
	{
		pInfo = new CColorInfo();
		pInfo->SetID(wID);
		pInfo->SetColor(m_color);
		m_curColorMap.SetAt(wID, pInfo);	
	}
}

COLORREF CColorMap::GetColor(WORD wID)
{
	CColorInfo *pInfo = NULL;
	if(!m_curColorMap.Lookup(wID,pInfo))
	{
		return RGB(245,245,233);
	}
	return pInfo->GetColor();
}

void CColorMap::SetColorMap(CColorSelList *pSource)
{
	CColorInfo *pInfo = NULL;

	for(int i=0; i < pSource->m_arrColorInfo.GetCount(); i++)
	{
		pInfo = pSource->m_arrColorInfo.GetAt(i);
		if(pInfo != NULL)
		{
			CColorInfo *pSourceInfo = NULL;
			if(m_curColorMap.Lookup(pInfo->GetID(), pSourceInfo))
			{
				pSourceInfo->SetColor(pInfo->GetColor());
			} 
			else
			{
				pSourceInfo = new CColorInfo();
				pSourceInfo->SetID(pInfo->GetID());
				pSourceInfo->SetColor(pInfo->GetColor());
				pSourceInfo->SetName(pInfo->GetName());
				pSourceInfo->SetKind(pInfo->GetKind());
				m_curColorMap.SetAt(pSourceInfo->GetID(), pSourceInfo);
			}
		}
	}

	//2010.09.01 ������ skin link test 
	SetColorMapPtr(&m_curColorMap);
	//2010.09.03 ������ skin link test
	Notify_COLOR_CHANGE(pSource);
}

void CColorMap::ClearMap()
{
	POSITION pos = m_curColorMap.GetStartPosition();

	WORD wKey;
	CColorInfo *pInfo = NULL;

	while(pos)
	{
		m_curColorMap.GetNextAssoc(pos,wKey,pInfo);
		if(pInfo != NULL)
		{
			delete pInfo;
		}
	}
	m_curColorMap.RemoveAll();
}

void CColorMap::DivideString(CString strSource, CStringArray &arrResult, char dDivision)
{
	CString strData;
    strSource.TrimRight();
	if(strSource.GetLength() <= 0)
	{
		return;
	}

	int oldPos = 0;
	int pos = strSource.Find(dDivision,oldPos);

	while(pos >= 0)
	{	
		strData = strSource.Mid(oldPos,pos - oldPos);
		arrResult.Add(strData);
		oldPos = pos+1;
		pos = strSource.Find(dDivision,oldPos);
	}
	strData = strSource.Mid(oldPos,strSource.GetLength() - oldPos);
	arrResult.Add(strData);
}

COLORREF CColorMap::StrToRGB(CString str)
{
	short k = -1; 
	short val[3];
	CString s[3];
	BOOL bSep = FALSE;
	memset(val, 0, sizeof(short)*3);
	for (int i = 0; i < str.GetLength(); i++) {
		if (isdigit(str[i])) {
			if (bSep) k++;
			bSep = FALSE;
			s[k] += str[i];
		}
		else {
			bSep = TRUE;
			if (k == 2) break;
		}
	}
	COLORREF color = RGB(atoi(s[0]), atoi(s[1]), atoi(s[2]));
	return color;
}

CString CColorMap::RGBToStr(COLORREF rgb)
{
	CString str;
	str.Format("RGB(%s,%s,%s)", rgb & 0xff, (rgb >> 8) & 0xff, (rgb >> 16) & 0xff);
	return str;
}

// �ӽ�
// test start
// ������� �ð��� �帣�� �� �Լ��� �����Ѵ�.
WORD CColorMap::IsDeletedColor(WORD wID)
{
	WORD wRet = wID;
	switch(wID)
	{
		case CL_INPUT_TITLE_BACK :			// 50:�Է�Ÿ��Ʋ���:RGB(245,245,233)
		case CL_INPUT_BUSI :				// 6:�Էº�����:RGB(245,245,245)
			{
				wRet = CL_INPUT_BACK;
				break;
			}
		case CL_EQUAL_TEXT :				// 25:���ձ۲�:RGB(0,0,0)
		case CL_BTN_TEXT :					// 27:��ư�۲�:RGB(0,0,0)
		case CL_COMMENT_SP_TEXT :			// 89:�ּ�����ȭ�۲�(Bold):RGB(0,0,0)
		case CL_TAB_FOCUS_TEXT :			// 31:Ȱ���Ǳ۲�:RGB(0,0,0)
		case CL_HEAD_TEXT :					// 91:����۲�:RGB(0,0,0)
		case CL_TITLE_TEXT :				// 92:Ÿ��Ʋ�۲�(Bold):RGB(0,0,0)
		case CL_COMMENT_1DEP_TITLE_TEXT :	// 111:�ּ� 1depth Ÿ��Ʋ �ؽ�Ʈ(Bold):RGB(0,0,0)
			{
				wRet = CL_TEXT;
				break;
			}
		case CL_COMMENT_TEXT :				// 88:�ּ��⺻�۲�:RGB(85,85,85)
			{
				wRet = CL_GRID_TEXT;
				break;
			}
		case CL_INPUT_GRID_HEAD_LINE :		// 79:�Է±׸��� �������:RGB(219,219,183)
		case CL_INPUT_GRID_HEAD_LINE2 :		// 80:�Է±׸��� �������2:RGB(219,219,183)
			{
				wRet = CL_INPUT_BORDER;
				break;
			}
		case CL_GRID_OUTPUT_LINE2 :			// 12:��±׸���Ÿ��Ʋ����2:RGB(64,144,222)
			{
				wRet = CL_GRID_HEAD_LINE;
				break;
			}
		case CL_COMMENT_IMP_TEXT :			// 90:�ּ������۲�(Bold):RGB(252,0,1)
		case CL_MSG_ERROR_TEXT :			// 110:�޽��� ���� �ؽ�Ʈ:RGB(252,0,1)
			{
				wRet = CL_UP_TEXT;
				break;
			}
		case CL_MSG_RIGHT_LINE :			// 17:�޽������ϴܶ���:RGB(231,231,231)
			{
				wRet = CL_MSG_LEFT_LINE;
				break;
			}
		case CL_TAB_TEXT :					// 32:��Ȱ���Ǳ۲�:RGB(68,68,68)
		case CL_DEACT_BTN_TEXT :			// 94:��Ȱ����ư�۲�:RGB(153,153,153)
		case CL_PROCESS_BTN_FUNC_BACK :		// 114:ȭ��ó����ư ���Ű ���:RGB(145,145,145)
			{
				wRet = CL_MSG_TEXT;
				break;
			}
		case CL_BTN_CLICK :					// 21:��ưŬ����:RGB(128,0,0)
		case CL_BTN_FOCUS_BACK :			// 20:��ưȰ��ȭ/Ŭ����:RGB(128,0,0)
			{
				wRet = CL_BTN_BACK;
				break;
			}
		case CL_BLANK_BACK :				// 52:����ó�����:RGB(248,248,248)
		case CL_MSG_BACK :					// 15:�޽�������:RGB(235,235,235)
			{
				wRet = CL_COMMENT_BACK;
				break;
			}
		case CL_OUTPUT_TITLE_BACK :			// 51:���Ÿ��Ʋ���:RGB(230,239,247)
			{
				wRet = CL_OUTPUT_BACK;
				break;
			}
		case CL_GRID_BACK :					// 9:��±׸������:RGB(255,255,255)
			{
				wRet = CL_INPUT_GRID_BACK;
				break;
			}
		case CL_INPUT_GRID_BLOCK :			// 36:�Է� �׸��� ����:RGB(231,231,204)
		case CL_INPUT_GRID_HEAD_IMP_BLOCK :	//39:�Է� �׸��� ��� �߿����:RGB(231,231,204)
			{
				wRet = CL_INPUT_GRID_IMP_BLOCK;
				break;
			}
		case CL_GRID_BACK2 :				// 33:��±׸������2:RGB(241,247,251)
			{
				wRet = CL_OUTPUT_GRID_BLOCK;
				break;
			}
		case CL_GRID_BOLD_HEAD_BACK :		// 11:��±׸�������߿���:RGB(182,218,252)
			{
				wRet = CL_OUTPUT_GRID_IMP_BLOCK;
				break;
			}
		case CL_BUY_BTN_BACK :				// 98:�ż���ư���:RGB(231,25,25)
			{
				wRet = CL_BUY_TITLE_BACK;
				break;
			}
		case CL_SELL_BTN_BACK :				// 99:�ŵ���ư���:RGB(64,157,253)
			{
				wRet = CL_SELL_TITLE_BACK;
				break;
			}
		case CL_AMEND_BTN_BACK :			// 100:������ư���:RGB(66,171,45)
			{
				wRet = CL_AMEND_TITLE_BACK;
				break;
			}
		case CL_CANCEL_BTN_BACK :			// 101:��ҹ�ư���:RGB(168,69,168)
			{
				wRet = CL_CANCEL_TITLE_BACK;
				break;
			}
		case CL_UP_BACK :					// 23:��¹���:RGB(255,209,209)
			{
				wRet = CL_PRICE_UP_BACK5;
				break;
			}
		case CL_DOWN_BACK :					// 24:�϶�����:RGB(198,225,255)
			{
				wRet = CL_PRICE_DOWN_BACK5;
				break;
			}
		case CL_TR_TAB_BACK :				// 102:TRȭ�� �� ��� ����:RBG(212,231,246)
			{
				wRet = CL_TR_TAB_DEACT_BACK;
				break;
			}
		case CL_ORDER_TEXT :				// 93:�ֹ���ư�۲�:RGB(255,255,255)
			{
				wRet = CL_OUTPUT_2DEP_TAB_BACK;
				break;
			}
		case CL_GRID_LINE :					// 10:��±׸������:RGB(223,223,223)
			{
				wRet = CL_INPUT_GRID_LINE;
				break;
			}
		case CL_INPUT_2DEP_TAB_LINE :		// 84:�Է� 2depth Ȱ���Ƕ���:RGB(204,204,157)
			{
				wRet = CL_INPUT_1DEP_TAB_LINE;
				break;
			}
		case CL_TAB_LINE :					// 81:TRȭ�� �Ƕ���:RGB(0,113,209)
			{
				wRet = CL_TR_TAB_ACT_BORDER_LINE;
				break;
			}
		case CL_DEACT_BTN_SHADOW_TEXT :		// 112:��Ȱ�� ��ư �׸��� �ؽ�Ʈ:RGB(255,255,255)
			{
				wRet = CL_TEXT_WHITE;
				break;
			}
	}
	return wRet;
}
// test end

// ������ ���� File�� �д´�.
// bIsDlg : TRUE�� Dlg���� open, FALSE�� MainFrm���� ȣ��
/*
BOOL CColorMap::LoadColorMapFile(CArray <CColorSelList *, CColorSelList *> *arrColorMapList,
								 CComboBox *ctlColorMapList, BOOL bIsDlg)
{
	CStdioFile clsFile;

	arrColorMapList->RemoveAll();
	
	// File�� Open�Ѵ�.
	CString strPath = GetDataFolder()+ COLORMAPFILE;
	if(!clsFile.Open(strPath,CFile::modeRead))
	{
		return FALSE;
	}

	CString strData;
	CStringArray strDataArray;

	// �������� ������ �д´�.
	if(clsFile.ReadString(strData))
	{
		DivideString(strData,strDataArray,':');
		if(strDataArray.GetCount() <= 0)
		{
			clsFile.Close();
			return FALSE;
		}

		int iTitleCnt = (int)(strDataArray.GetCount());
		for(int i=0; i < iTitleCnt; i++)
		{
			// ������ Set�� �����.
			CColorSelList *pColorMapList = new CColorSelList();
			pColorMapList->m_strName =  strDataArray.GetAt(i);
			arrColorMapList->Add(pColorMapList);

			if(bIsDlg)
			{
				int iIndex = ctlColorMapList->AddString(pColorMapList->m_strName);
				ctlColorMapList->SetItemDataPtr(iIndex,pColorMapList);
			}
		}

		// ���� ������ �д´�.
		int col = 0;
		int wKind = 0;
		while(clsFile.ReadString(strData))
		{
			strDataArray.RemoveAll();
			DivideString(strData,strDataArray,':');

			// ���� �з��� ���
			if((strDataArray.GetCount() == 2) && (strDataArray.GetAt(0) == "KIND"))
			{
				wKind = atoi(strDataArray.GetAt(1));
				continue;
			}

			if((strDataArray.GetCount() != (iTitleCnt+2)) || (strDataArray.GetCount() < 2))
			{
				clsFile.Close();
				return FALSE;
			}
			
			CString strID = strDataArray.GetAt(0);
			CString strName = strDataArray.GetAt(1);
			WORD wID = atoi(strID);
        
			CColorInfo *pInfo = NULL;
			for(i=0; i < iTitleCnt;i++)
			{
				CColorSelList *pList = arrColorMapList->GetAt(i);
				pInfo = new CColorInfo();
				pInfo->SetID(wID);
				pInfo->SetName(strName);
				pInfo->SetKind(wKind);
				pInfo->SetColor(CColorMap::StrToRGB(strDataArray.GetAt(i+2)));
				pList->m_arrColorInfo.SetAtGrow(col,pInfo);
			}
			col++;
		}
	}
	else 
	{
		clsFile.Close();
		return FALSE;
	}

	strDataArray.RemoveAll();

	clsFile.Close();
	return TRUE;
}
*/

BOOL CColorMap::LoadDefaultInfo(CStdioFile & file, CColorSelList * pDefaultList)
{
	ASSERT(pDefaultList);
	ASSERT(pDefaultList->m_arrColorInfo.GetCount() == 0);

	CString strLine;
	int iID, iKind;
	CString strColorName;
	CColorInfo * pColorInfo;

	while (file.ReadString(strLine))
	{
		strLine.Trim();

		if (strLine.IsEmpty())
			continue;

		// Comment...
		if (strLine[0] == '!')
			continue;

		// ������ �⺻ ���� ��...
		if (strLine == DEFAULTINFO_END) 
			break;

		iID = atoi(strLine.Left(4));
		iKind = atoi(strLine.Right(1));
		strColorName = strLine.Mid(5, strLine.GetLength() - 4 - 2);

		pColorInfo = new CColorInfo;
		pColorInfo->SetID(iID);
		pColorInfo->SetKind(iKind);
		pColorInfo->SetName(strColorName);
		// ������ �ִ´�.
		pDefaultList->m_arrColorInfo.Add(pColorInfo);
	}

	int nCnt = pDefaultList->m_arrColorInfo.GetCount();

	return (pDefaultList->m_arrColorInfo.GetCount() > 0);
}

CColorInfo * CColorMap::FindDefaultInfo(CColorSelList * pDefaultList, int iID)
{
	CColorInfo * pColorInfo = NULL;

	for (int i = 0; i < pDefaultList->m_arrColorInfo.GetCount(); i++)
	{
		pColorInfo = pDefaultList->m_arrColorInfo.GetAt(i);

		if (pColorInfo->GetID() == iID)
			return pColorInfo;
	}

	return NULL;
}

BOOL CColorMap::LoadColorInfo(CStdioFile & file, CColorSelList * pDefaultList, CColorSelList * pNewList)
{
	ASSERT(pDefaultList);
	ASSERT(pDefaultList->m_arrColorInfo.GetCount() > 0);

	ASSERT(pNewList);
	ASSERT(pNewList->m_strName.IsEmpty() == FALSE);
	ASSERT(pNewList->m_arrColorInfo.GetCount() == 0);

	CString strLine;
	int iID, iRValue, iGValue, iBValue;
	CColorInfo * pColorInfo, * pDefaultInfo;

	while (file.ReadString(strLine))
	{
		strLine.Trim();

		if (strLine.IsEmpty())
			continue;

		// Comment...
		if (strLine[0] == '!')
			continue;

		// ���� ���� ��...
		if (strLine == COLORMAP_END)
			break;

		ASSERT(strLine.GetLength() == (4 + 1 + 1 + 3 + 1 + 3 + 1 + 3 + 1));

		iID = atoi(strLine.Left(4));
		iRValue = atoi(strLine.Mid(6, 3));
		iGValue = atoi(strLine.Mid(10, 3));
		iBValue = atoi(strLine.Mid(14, 3));

		// kskim "INFO" �� �ִ��� ã�´�.
		pDefaultInfo = FindDefaultInfo(pDefaultList, iID);

		// �ش� ID�� �⺻������ �ִ� ��쿡�� ����...
		if (pDefaultInfo)
		{
			int n = pNewList->m_arrColorInfo.GetCount(); // 0

			pColorInfo = new CColorInfo;
			pColorInfo->SetID(pDefaultInfo->GetID());
			pColorInfo->SetKind(pDefaultInfo->GetKind());
			pColorInfo->SetName(pDefaultInfo->GetName());

			// kskim �÷����� ���⼭ �ִ´�.
			pColorInfo->SetColor(RGB(iRValue, iGValue, iBValue));
			// ����Ʈ�� �ִ´�
			pNewList->m_arrColorInfo.Add(pColorInfo);
		}
	}

	return TRUE;
}

BOOL CColorMap::LoadDefaultColorMapFile(CColorSelListArray & arrColorMapList, CComboBox * pColorMapListCombo)
{
	arrColorMapList.RemoveAll();
	
	CString strFilePath = GetDataFolder() + COLORMAPFILE;
	CStdioFile file;

	if (!file.Open(strFilePath, CFile::modeRead))
		return FALSE;

	CString strLine;
	CColorSelList aDefaultList;

	while (file.ReadString(strLine))
	{
		strLine.Trim();

		if (strLine.IsEmpty())
			continue;

		// Comment...
		if (strLine[0] == '!')
			continue;

		// ������ �⺻ ���� "kskim INFO"
		if (strLine == DEFAULTINFO_START)
		{					//kskim INFO �� �о���δ� 
			if (!LoadDefaultInfo(file, &aDefaultList))
			{
				file.Close();
				return FALSE;
			}
		}

		// ���� ����
		if (strLine.Left(COLORMAP_START_LENGTH) == COLORMAP_START) //"COLORMAP" 
		{	// pNewList ����
			CColorSelList * pNewList = new CColorSelList;// ����Ʈ

			// ����Ʈ�� ��°��� INFO���� COLORMAP �� �׸��
			
			// �ڡڡ�COLORMAP:Blue / COLORMAP:Blue (LCD) / COLORMAP:����� / COLORMAP:Purple / COLORMAP:Purple (LCD) ... 
			pNewList->m_strName = strLine.Mid(COLORMAP_START_LENGTH + 1); // ����Ʈ(�̸�)->Array(ColorInfo)
			pNewList->m_bUserDefine = FALSE;
			// ���׸��� �����Ѵ�
			if (!LoadColorInfo(file, &aDefaultList, pNewList))
			{
				delete pNewList;
				file.Close();
				return FALSE;
			}

			arrColorMapList.Add(pNewList);

			if (pColorMapListCombo)
			{
				int iIndex = pColorMapListCombo->AddString(pNewList->m_strName);
				pColorMapListCombo->SetItemDataPtr(iIndex, pNewList);
			}
		}
	}

	file.Close();

	return (arrColorMapList.GetCount() > 0);
}

BOOL CColorMap::LoadUserColorMapFile(CColorSelListArray & arrColorMapList, CComboBox * pColorMapListCombo)
{
	ASSERT(arrColorMapList.GetCount() > 0);

	if (arrColorMapList.GetCount() == 0)
		return FALSE;

	CString strFilePath = GetUserFolder() + USERCOLORMAPFILE;
	CStdioFile file;

	if (!file.Open(strFilePath, CFile::modeRead))
	{
		// ��������� ������ ������ ��� ������ �ƴ�...
		return TRUE;
	}

	CString strLine;
	CColorSelList * pDefaultList = arrColorMapList.GetAt(0);

	while (file.ReadString(strLine))
	{
		strLine.Trim();

		if (strLine.IsEmpty())
			continue;

		// Comment...
		if (strLine[0] == '!')
			continue;

		// ���� ����
		if (strLine.Left(COLORMAP_START_LENGTH) == COLORMAP_START)
		{
			CColorSelList * pNewList = new CColorSelList;

			pNewList->m_strName = strLine.Mid(COLORMAP_START_LENGTH + 1);
			pNewList->m_bUserDefine = TRUE;

			if (!LoadColorInfo(file, pDefaultList, pNewList))
			{
				delete pNewList;
				file.Close();
				return FALSE;
			}

			arrColorMapList.Add(pNewList);

			if (pColorMapListCombo)
			{
				int iIndex = pColorMapListCombo->AddString(pNewList->m_strName);
				pColorMapListCombo->SetItemDataPtr(iIndex, pNewList);
			}
		}
	}

	file.Close();

	return TRUE;
}

BOOL CColorMap::LoadColorMapFile(CColorSelListArray & arrColorMapList, CComboBox * pColorMapListCombo)
{
	if (!LoadDefaultColorMapFile(arrColorMapList, pColorMapListCombo))
		return FALSE;

	if (!LoadUserColorMapFile(arrColorMapList, pColorMapListCombo))
		return FALSE;

	return TRUE;
}

// ksi 20100714
BOOL CColorMap::LoadColorMapFileSkin(CColorSelListArray & arrColorMapList)
{
	if (!LoadDefaultColorMapFileSkin(arrColorMapList))
		return FALSE;

	if (!LoadUserColorMapFileSkin(arrColorMapList))
		return FALSE;

	return TRUE;
}

// ������ ������ ������ ���Ͽ� �����Ѵ�
// ��, ����� ���Ƿ� ������ �����Ǹ� �����Ѵ�
BOOL CColorMap::SaveColorMapFile(CColorSelListArray & arrColorMapList)
{
	if (arrColorMapList.GetCount() == 0)
		return FALSE;

	CString strFilePath = GetUserFolder() + USERCOLORMAPFILE;
	CString strBackupFilePath = strFilePath + ".bak";
	CStdioFile file;

	::MoveFile(strFilePath, strBackupFilePath);

	if (!file.Open(strFilePath, CFile::modeWrite | CFile::modeCreate | CFile::shareDenyNone))
		return FALSE;

	char szBuffer[512];
	CColorSelList * pList;

	for (int iListIndex = 0; iListIndex < arrColorMapList.GetCount(); iListIndex++)
	{
		pList = arrColorMapList.GetAt(iListIndex);

		// ����� ���� �����Ǹ� ����...
		if (!pList->m_bUserDefine)
			continue;

		wsprintf(szBuffer, "%s:%s\r\n\r\n", COLORMAP_START, pList->m_strName);
		file.WriteString(szBuffer);

		CColorInfo * pColorInfo;
		COLORREF clColor;

		for (int iColorIndex = 0; iColorIndex < pList->m_arrColorInfo.GetCount(); iColorIndex++)
		{
			pColorInfo = pList->m_arrColorInfo.GetAt(iColorIndex);

			clColor = pColorInfo->GetColor();

			wsprintf(szBuffer, "%03d:(%03d,%03d,%03d)\r\n", pColorInfo->GetID(), GetRValue(clColor), GetGValue(clColor), GetBValue(clColor));
			file.WriteString(szBuffer);
		}

		wsprintf(szBuffer, "\r\n%s\r\n\r\n", COLORMAP_END);
		file.WriteString(szBuffer);
	}

	file.Close();

	::DeleteFile(strBackupFilePath);

	return TRUE;
}

// ksi 20100714
BOOL CColorMap::LoadDefaultColorMapFileSkin(CColorSelListArray & arrColorMapList)
{
	arrColorMapList.RemoveAll();
	
	CString strFilePath = GetDataFolder() + COLORMAPFILE;
	CStdioFile file;

	if (!file.Open(strFilePath, CFile::modeRead))
		return FALSE;

	CString strLine;
	CColorSelList aDefaultList;

	while (file.ReadString(strLine))
	{
		strLine.Trim();

		if (strLine.IsEmpty())
			continue;

		// Comment...
		if (strLine[0] == '!')
			continue;

		// ������ �⺻ ���� "kskim INFO"
		if (strLine == DEFAULTINFO_START)
		{					//kskim INFO �� �о���δ� 
			if (!LoadDefaultInfo(file, &aDefaultList))
			{
				file.Close();
				return FALSE;
			}
		}

		// ���� ����
		if (strLine.Left(COLORMAP_START_LENGTH) == COLORMAP_START) //"COLORMAP" 
		{	// pNewList ����
			CColorSelList * pNewList = new CColorSelList;// ����Ʈ

			// ����Ʈ�� ��°��� INFO���� COLORMAP �� �׸��
			
			// �ڡڡ�COLORMAP:Blue / COLORMAP:Blue (LCD) / COLORMAP:����� / COLORMAP:Purple / COLORMAP:Purple (LCD) ... 
			pNewList->m_strName = strLine.Mid(COLORMAP_START_LENGTH + 1); // ����Ʈ(�̸�)->Array(ColorInfo)
			pNewList->m_bUserDefine = FALSE;
			// ���׸��� �����Ѵ�
			if (!LoadColorInfo(file, &aDefaultList, pNewList))
			{
				delete pNewList;
				file.Close();
				return FALSE;
			}

			arrColorMapList.Add(pNewList);
		}
	}

	file.Close();

	return (arrColorMapList.GetCount() > 0);
}

// ksi 20100714
BOOL CColorMap::LoadUserColorMapFileSkin(CColorSelListArray & arrColorMapList)
{
	ASSERT(arrColorMapList.GetCount() > 0);

	if (arrColorMapList.GetCount() == 0)
		return FALSE;

	CString strFilePath = GetUserFolder() + USERCOLORMAPFILE;
	CStdioFile file;

	if (!file.Open(strFilePath, CFile::modeRead))
	{
		// ��������� ������ ������ ��� ������ �ƴ�...
		return TRUE;
	}

	CString strLine;
	CColorSelList * pDefaultList = arrColorMapList.GetAt(0);

	while (file.ReadString(strLine))
	{
		strLine.Trim();

		if (strLine.IsEmpty())
			continue;

		// Comment...
		if (strLine[0] == '!')
			continue;

		// ���� ����
		if (strLine.Left(COLORMAP_START_LENGTH) == COLORMAP_START)
		{
			CColorSelList * pNewList = new CColorSelList;

			pNewList->m_strName = strLine.Mid(COLORMAP_START_LENGTH + 1);
			pNewList->m_bUserDefine = TRUE;

			if (!LoadColorInfo(file, pDefaultList, pNewList))
			{
				delete pNewList;
				file.Close();
				return FALSE;
			}

			arrColorMapList.Add(pNewList);
		}
	}

	file.Close();

	return TRUE;
}
