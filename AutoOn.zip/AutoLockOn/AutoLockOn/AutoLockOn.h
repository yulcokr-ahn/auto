// AutoLockOn.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


class CDemoApp : public CWinApp
{
public:




	CDemoApp();
	CString m_szRootDir, m_szMainDir;
	CString m_szTemp;



public:
	virtual BOOL InitInstance();



	DECLARE_MESSAGE_MAP()
};

extern CDemoApp theApp;