#if !defined(AFX_PICKER_H__67968BF9_4A25_4480_8A43_FD3683666AF1__INCLUDED_)
#define AFX_PICKER_H__67968BF9_4A25_4480_8A43_FD3683666AF1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Picker.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPicker window

class CPicker : public CStatic
{
// Construction
public:
        CPicker();
int nModeType; // = MODE_DEMO;
// Attributes
public:

// Operations
public:

// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CPicker)
        //}}AFX_VIRTUAL

// Implementation
public:
        virtual ~CPicker();

        // Generated message map functions
protected:
        //{{AFX_MSG(CPicker)
        afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
        //}}AFX_MSG

        DECLARE_MESSAGE_MAP()
};


/****************************************************************************
*                             
* Inputs:
*       WPARAM: TRUE for pickup, FALSE for drop
*       LPARAM: (WPARAM)MAKELONG(x, y)
* Result: LRESULT
*       Logically void, 0, always
* Effect: 
*       Notifies the parent that the cursor has been picked out
****************************************************************************/

#include "msg.h"
#define UWM_PICKER_HWND_MSG _T("UWM_PICKER_HWND-{9ED38EEB-3069-48b0-B770-E13BDAE8A1D3}")
#define UWM_PICKER_DEMO_MSG _T("UWM_PICKER_DEMO-{9ED38EEB-3069-48b0-B770-E13BDAE8A1D3}")
#define UWM_PICKER_MAIN_MSG _T("UWM_PICKER_MAIN-{9ED38EEB-3069-48b0-B770-E13BDAE8A1D3}")
#define MODE_DEMO 1
#define MODE_MAIN 2

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICKER_H__67968BF9_4A25_4480_8A43_FD3683666AF1__INCLUDED_)
