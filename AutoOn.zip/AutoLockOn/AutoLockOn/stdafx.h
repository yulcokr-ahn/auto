// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifndef _SECURE_ATL
#define _SECURE_ATL 1
#endif

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN            // Exclude rarely-used stuff from Windows headers
#endif

#include "targetver.h"

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS      // some CString constructors will be explicit

// turns off MFC's hiding of some common and often safely ignored warning messages
#define _AFX_ALL_WARNINGS

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h>           // MFC support for Internet Explorer 4 Common Controls
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>                     // MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT







//2010.09.02 ������
#pragma warning(disable:4786)
#include <map>
#include <vector>
using namespace std;

#define		ISkinChartMapping_FileDefault "Data\\ChartMappingColorTable.cfg"
#define		ISkinColor_default_File	      "Data\\DefaultColorTable.cfg"
#define     ISKIN_TEST_MapFile            "Data\\ChartMappingTEST.cfg"



typedef struct {
	CString		m_szName;
	CString		m_szColorTable;
	CString		m_szBKImage;
	CString		m_szBKColor;
	CString		m_szTreeIconImage;
	CString		m_szVScreenImageIndex;
	CString		m_szSubColorTableInfo;
} ST_SKININFO;

typedef CArray<ST_SKININFO, ST_SKININFO> ARRAY_ST_SKININFO;
typedef CList<ST_SKININFO*, ST_SKININFO*>  LIST_ST_SKININFO;


typedef struct _tabUserColorTable
{
	int nListControlRowID;
	int nListControl_SearchRowID;
	CString szName;
	COLORREF rgb;
	int nDEMOID;  //sscanf(key1, "%d,%[^,]", &nID_RGB, sIndexName ); //
	int nMAINID;
} STUSERCOLORTABLE;

typedef CArray<STUSERCOLORTABLE, STUSERCOLORTABLE>	ARR_COLOR_TABLE;




#if defined _M_IX86
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_IA64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='ia64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif



