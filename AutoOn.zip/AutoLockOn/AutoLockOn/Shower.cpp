// Shower.cpp : implementation file
//

#include "stdafx.h"
#include "Shower.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShower

CShower::CShower()
   {
    selection.SetRectEmpty();
   }

CShower::~CShower()
{
}


BEGIN_MESSAGE_MAP(CShower, CWnd)
        //{{AFX_MSG_MAP(CShower)
        ON_WM_CREATE()
        ON_WM_PAINT()
        ON_WM_TIMER()
        //}}AFX_MSG_MAP
END_MESSAGE_MAP()

#define IDT_TIMER 1

/////////////////////////////////////////////////////////////////////////////
// CShower message handlers

/****************************************************************************
*                              CShower::OnCreate
* Inputs:
*       LPCREATESTRUCT lpCreateStruct: Creation parameters
* Result: int
*       -1 if error
*       0 if success
* Effect: 
*       Uses the Create parameter to initialize the selection
*       Sets a timer to kill the window after a half-second
****************************************************************************/

int CShower::OnCreate(LPCREATESTRUCT lpCreateStruct) 
   {
    if (CWnd::OnCreate(lpCreateStruct) == -1)
       return -1;
        
    if(lpCreateStruct->lpCreateParams == NULL)
       { /* failed */
        ASSERT(FALSE); // should not happen
        selection.SetRectEmpty();
       } /* failed */
    else
       { /* has selection */
        selection = *(CRect *)lpCreateStruct->lpCreateParams;
       } /* has selection */
        
    SetTimer(IDT_TIMER, 5000, NULL);
    return 0;
}

/****************************************************************************
*                           CShower::PostNcDestroy
* Result: void
*       
* Effect: 
*       Deletes the object. 
****************************************************************************/

void CShower::PostNcDestroy() 
   {
    delete this;
        
    CWnd::PostNcDestroy();
   }

/****************************************************************************
*                              CShower::OnPaint
* Result: void
*       
* Effect: 
*       Draws the highlighting boxes
****************************************************************************/

void CShower::OnPaint() 
   {
    CPaintDC dc(this); // device context for painting
        
    int save = dc.SaveDC();
    CPen pen(PS_DOT, 1, RGB(0,0,0)); 
    dc.SelectObject(&pen);

    CRect r;
    GetClientRect(&r);
    dc.SelectStockObject(HOLLOW_BRUSH);
    dc.Rectangle(&r);

    if(!selection.IsRectEmpty())
       { /* draw subselection */
        dc.Rectangle(&selection);
       } /* draw subselection */

    dc.RestoreDC(save);

    // Do not call CWnd::OnPaint() for painting messages
   }

/****************************************************************************
*                              CShower::OnTimer
* Inputs:
*       UINT nIDEvent: ignored, there is only one timer event
* Result: void
*       
* Effect: 
*       Posts a message to close the window.
****************************************************************************/

void CShower::OnTimer(UINT nIDEvent) 
   {
    PostMessage(WM_CLOSE);

    CWnd::OnTimer(nIDEvent);
   }
