// Picker.cpp : implementation file
//

#include "stdafx.h"
#include "Picker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

DECLARE_MESSAGE(UWM_PICKER_DEMO)
DECLARE_MESSAGE(UWM_PICKER_MAIN)
/////////////////////////////////////////////////////////////////////////////
// CPicker

CPicker::CPicker()
{
nModeType = MODE_MAIN;
}

CPicker::~CPicker()
{
}


BEGIN_MESSAGE_MAP(CPicker, CStatic)
        //{{AFX_MSG_MAP(CPicker)
        ON_WM_LBUTTONDOWN()
        //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPicker message handlers

void CPicker::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if(nModeType == MODE_DEMO)
	{
		GetParent()->SendMessage(UWM_PICKER_DEMO, (WPARAM)TRUE, (LPARAM)MAKELONG(point.x, point.y));
	}
	else
	{
		GetParent()->SendMessage(UWM_PICKER_MAIN, (WPARAM)TRUE, (LPARAM)MAKELONG(point.x, point.y));

	}
//CStatic::OnLButtonDown(nFlags, point);
}
