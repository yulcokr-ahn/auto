#if !defined(AFX_SHOWER_H__64A7DA54_BAF7_4ABA_8F54_59CBA70D4083__INCLUDED_)
#define AFX_SHOWER_H__64A7DA54_BAF7_4ABA_8F54_59CBA70D4083__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Shower.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CShower window

class CShower : public CWnd
{
// Construction
public:
        CShower();

// Attributes
public:

// Operations
public:

// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CShower)
        protected:
        virtual void PostNcDestroy();
        //}}AFX_VIRTUAL

// Implementation
public:
        virtual ~CShower();

        // Generated message map functions
protected:
        CRect selection;
        //{{AFX_MSG(CShower)
        afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
        afx_msg void OnPaint();
        afx_msg void OnTimer(UINT nIDEvent);
        //}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHOWER_H__64A7DA54_BAF7_4ABA_8F54_59CBA70D4083__INCLUDED_)
