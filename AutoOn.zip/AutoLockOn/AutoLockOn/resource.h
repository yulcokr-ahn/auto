//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AutoLockOn.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DIALOGBAR                   103
#define IDR_MAINFRAME                   128
#define IDC_PICKER_DEMO                 129
#define IDC_PICKER_MAIN                 130
#define IDC_CURSOR1                     133
#define IDB_BITMAP1                     134
#define IDB_COPY                        135
#define IDB_DOWN                        136
#define IDB_UPRIGHT                     137
#define IDB_DOWNLEFT                    138
#define IDB_DOWNRIGHT                   139
#define IDB_LEFT                        140
#define IDB_RIGHT                       141
#define IDB_SHOW                        142
#define IDB_UP                          143
#define IDB_UPLEFT                      144
#define IDB_BITMAP_MULTI_BOXES          147
#define IDB_BITMAP_BOX                  149
#define IDB_BITMAP2                     150
#define IDB_BITMAP_MULTI                150
#define IDC_DATE                        1002
#define IDC_COMBO                       1003
#define IDC_LIST_DEMO3                  1003
#define IDC_RADIO1_DEMO                 1007
#define IDC_RADIO2_DEMO                 1008
#define IDC_RADIO3_DEMO                 1009
#define IDC_RADIO4                      1017
#define IDC_RADIO5                      1018
#define IDC_RADIO6                      1019
#define IDC_RADIO1_MAIN                 1207
#define IDC_RADIO2_MAIN                 1208
#define IDC_RADIO3_MAIN                 1209
#define IDC_RADIO3_MAIN2                1211
#define IDC_EDT_HSV_H                   2029
#define IDC_EDT_HSV_S                   2039
#define IDC_EDT_HSV_V                   2049
#define IDC_EDT_RGB_B_DEMO              2059
#define IDC_EDT_RGB_G_DEMO              2069
#define IDC_EDT_RGB_R_DEMO              2079
#define IDC_EDT_RGB_B_MAIN              2080
#define IDC_EDT_RGB_G_MAIN              2081
#define IDC_EDT_RGB_R_MAIN              2082
#define IDC_EDITHEX_DEMO                2087
#define IDC_EDITHEX_MAIN                2089
#define IDD_AutoLockOn_DIALOG           2100
#define IDC_LIST_DEMO                   2101
#define IDC_LIST_SEARCH_DEMO            2102
#define IDC_EDIT                        2103
#define IDC_R                           2105
#define IDC_BOX_DEMO                    2106
#define IDC_BOX_MAIN                    2107
#define IDC_B                           2108
#define IDC_SIZEVALUE                   2109
#define IDC_SPINSIZE                    2110
#define IDC_IMAGE_DEMO                  2112
#define IDC_IMAGE_MAIN                  2113
#define IDC_COLORPICKER_DEMO            2114
#define IDC_COLORPICKER_MAIN            2116
#define IDC_COLORWELL_DEMO              2118
#define IDC_COLORWELL_MAIN              2120
#define IDC_COLORSLIDER_DEMO            2122
#define IDC_COLORSLIDER_MAIN            2124
#define IDC_RGB_DEMO                    2141
#define IDC_RGB_MAIN                    2142
#define IDC_HWND_TXT                    2143
#define IDC_LIST_MAIN                   2200
#define IDC_LIST_SEARCH_MAIN            2201
#define IDC_FRAME_DEMO                  2304
#define IDC_FRAME_MAIN                  2305
#define IDC_BUTTON1                     5010
#define IDC_BUTTON_SAVE_MAP             5010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        151
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         5011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
