﻿// DemoDlg.h : header file
//
#pragma once
#include "listctrlex.h"
#include "afxdtctl.h"
#include "afxwin.h"
#include "dlgcolor.h"


#include "ColorShow.h"
#include "ColorSwatch.h"
#include "ImageButton.h"
#include "Picker.h"

#include "GTColorSelectorWnd.h"
#include "GTColorWellWnd.h"
#include "GTColorSliderWnd.h"
#include "resource.h"

//2025.04.04
#include <gdiplus.h>
using namespace Gdiplus;


struct INFO_treeItem {
	COLORREF color;
	BOOL     isChecked;
	CString  sName;
	int      nPacketCnt;
};

class CBezierOverlayWnd : public CWnd
{
public:
	CToolTipCtrl m_ToolTip; //2025.04.21
	void UpdateToolTips();
	
	BOOL m_SINGLE_LINE_MODE;
	std::vector<CRect>   m_vSBox;
	std::vector<CRect>   m_vEBox;
	std::vector<std::pair<CPoint, CPoint>> m_Links;	

	bool IsPointInBezierCurve(CPoint point);


	CBezierOverlayWnd();
	BOOL Create(CWnd* pParent);
	void AddLink(const CPoint& from, const CPoint& to);
	void ClearLinks();
private:
	bool m_bSelected;  // 곡선 선택 여부
	bool m_isMouseDown; // 마우스 다운 상태
protected:
		virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	afx_msg void OnPaint();
		afx_msg void OnMouseMove(UINT nFlags, CPoint point);
		afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg); //2025.04.21
	DECLARE_MESSAGE_MAP()
};

class CDemoDlg : public CDialog
{
public:
	void PrintDesktopIconsUIAutomation(); // 아이콘 이름과 위치를 출력하는 UIAutomation 방식
	void DrawSingleLine_Node(HWND hWnd1, HWND hWnd2);
	void FindChildWindows(CTreeCtrl& tree, HTREEITEM hParent, HWND hWnd);
	void InitTreeWithWindows(CTreeCtrl& tree, HWND parent) ;
	CColorShow      c_Image_MAIN;
		CEdit	m_edtHex_MAIN;
	CPicker c_Picker_MAIN;
	HCURSOR picker;
	HICON m_hIcon;

	BOOL m_reChkDraw_SingleLogic;
	int  m_sumSingle;

	BOOL m_reChkDraw_MultLogic;
	int m_sumMult;

		BOOL m_On_Picke;

	CDemoDlg(CWnd* pParent = nullptr);
	enum { IDD = IDD_AutoLockOn_DIALOG };
protected:
	virtual void DoDataExchange(CDataExchange* pDX) override;
	virtual BOOL OnInitDialog() override;
	DECLARE_MESSAGE_MAP()
private:
	CWnd* m_pParentWnd;
	CWnd* m_pChildWnd;
	afx_msg void OnClick(NMHDR* pNMHDR, LRESULT* pResult);

private:
	CTreeCtrl m_Tree;
	CImageList m_ImageList;

	std::vector<CPoint>  m_IconPositions;
	
	std::vector<CRect>   m_vSBox;
	std::vector<CRect>   m_vEBox;
	std::vector<CString> m_IconNameItem;
	int m_Mode_isDeskTopIcon;

	void DrawMultLine_BezierLinks(HWND hWCur);
	void InitTreeCtrl();

private:

	// 멤버 변수
	int m_RadioID;
	DWORD m_dError;
	HWND m_hOverW;
	HWND m_hTargetWnd;
	DWORD m_CurrentProcessId;
	float m_fAlpha;
	HWND m_hwndSingle;
	DWORD m_dwOriginalStyle;
	// 작업 표시줄 관련 핸들
	HWND m_hTray;
	HWND m_hStart;
	HWND m_hTryNotifyWindow;
	HWND m_hToolbar;
	HWND m_hBarWindow;
	HWND m_hTabControl;
	HWND m_hQuickLaunch;
	HWND m_hClock;
	HWND m_hDesk;
protected:
	BOOL IsExcludedProcess(DWORD processId);
	BOOL IsExcludedWindowClass(HWND hWnd);
	void InitializeTaskbarHandles();
	BOOL isCheckHandles(HWND hWCur);
	void HandleMainRadioClick(bool bIsDesktopIcon);
	void SetCheck_tree(bool bChk);

	// 상수
	static const WCHAR* EXCLUDED_PROCESS_NAMES[];
	static const WCHAR* EXCLUDED_CLASS_NAMES[];

	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedRadio1() { m_RadioID = 1; }
	afx_msg void OnBnClickedRadio2() { m_RadioID = 2; }
	afx_msg void OnBnClickedRadio3() { m_RadioID = 3; }
	afx_msg void OnBnClickedRadio4() { m_RadioID = 4; }
	afx_msg void OnBnClickedRadio5() { m_RadioID = 5; }
	afx_msg void OnBnClickedRadio6() { m_RadioID = 6; }
	afx_msg void OnBnClickedRadio7() { m_RadioID = 7; }
	afx_msg void OnBnClickedRadio8();
	afx_msg void OnBnClickedRadio9() { m_RadioID = 9; }
	afx_msg void OnBnClickedShow();
	afx_msg void OnBnClickedHide();
	afx_msg void OnCancel() override;

	afx_msg LRESULT OnPoint_MAIN(WPARAM, LPARAM);
	afx_msg LRESULT OnPicker_MAIN(WPARAM, LPARAM);
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);

	afx_msg void OnWindowPosChanged(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnNcMouseMove(UINT nHitTest, CPoint point);
		afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
public:
	afx_msg void OnBnClickedRadio2Main();
	afx_msg void OnBnClickedRadio1Main();
	afx_msg void OnBnClickedRadio3Main();
	afx_msg void OnBnClickedRadio3Main2();
};
