// STgridCellIssue.h: interface for the CSTgridCellIssue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STgridCELLISSUE_H__06C99A47_7C9D_4BCF_BD9A_F1ECEDAB9434__INCLUDED_)
#define AFX_STgridCELLISSUE_H__06C99A47_7C9D_4BCF_BD9A_F1ECEDAB9434__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "STgridCell.h"

class AFX_EXT_CLASS CSTgridCellIssue : public CSTgridCellStd  
{
	friend class CSTgridCtrl;
	DECLARE_DYNCREATE(CSTgridCellIssue)
public:
	CSTgridCellIssue();
	virtual ~CSTgridCellIssue();

	BOOL IsShowToolTip() { return m_bShowToolTip; }
	void SetShowToolTip(BOOL bShowToolTip) { m_bShowToolTip = bShowToolTip; }
	CString GetIssueCode() { return m_strIssueCode; }
	void SetIssueCode(CString strIssueCode) { m_strIssueCode = strIssueCode; }
	
protected:
	CString m_strIssueCode;
	BOOL	m_bShowToolTip;

    virtual void OnMouseOver();
};

#endif // !defined(AFX_STgridCELLISSUE_H__06C99A47_7C9D_4BCF_BD9A_F1ECEDAB9434__INCLUDED_)
