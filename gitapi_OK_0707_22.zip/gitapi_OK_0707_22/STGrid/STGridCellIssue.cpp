// STgridCellIssue.cpp: implementation of the CSTgridCellIssue class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "STgridCtrl.h"
#include "STgridCellIssue.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CSTgridCellIssue, CSTgridCellStd)

CSTgridCellIssue::CSTgridCellIssue()
{
	m_strIssueCode.Empty();
	m_bShowToolTip = FALSE;
}

CSTgridCellIssue::~CSTgridCellIssue()
{

}

void CSTgridCellIssue::OnMouseOver()
{

}

