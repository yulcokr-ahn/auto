// STgridCellSign.cpp: implementation of the CSTgridCellSign class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "STgridCellSign.h"
#include <math.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define SIGN_UPDOWN		0			//���
#define SIGN_CONCLE		1			//ü��
#define SIGN_CANDLE		2			//ĵ��

IMPLEMENT_DYNCREATE(CSTgridCellSign, CSTgridCellStd)

CSTgridCellSign::CSTgridCellSign() : CSTgridCellStd()
{
	m_nSignType = SIGN_UPDOWN;
    m_bShowSign = TRUE;
    m_chDiffGb = -1;

	m_lClose = m_lOpen = m_lHigh = m_lLow = m_lPreClose = 0;
}

CSTgridCellSign::~CSTgridCellSign()
{

}

BOOL CSTgridCellSign::Draw(CDC* pDC, int nRow, int nCol, CRect rect,  BOOL bEraseBkgnd /*=TRUE*/)
{
	if(m_nSignType == SIGN_CONCLE)
	{
		return DrawConcle(pDC, nRow, nCol, rect, bEraseBkgnd);
	}
	else if(m_nSignType == SIGN_CANDLE)
	{
		return DrawCandle(pDC, nRow, nCol, rect, bEraseBkgnd);
	}

	COLORREF OldTextColor = pDC->GetTextColor();
	COLORREF clrSignColor;

	CPoint P[7];
	int nPolyCount = 3;
	int X;
	int Y;
	X = rect.left;
	Y = rect.top+2;
	
	switch (m_chDiffGb) 
	{
	case '1':	// ����
		{
			clrSignColor = RGB(255, 0, 0);
			nPolyCount = 7;
			P[0] = CPoint(X+7, Y+2);
			P[1] = CPoint(X+3, Y+6);
			P[2] = CPoint(X+6, Y+6);
			P[3] = CPoint(X+6, Y+10);
			P[4] = CPoint(X+8, Y+10);
			P[5] = CPoint(X+8, Y+6);
			P[6] = CPoint(X+11, Y+6);
		}
		break;
	case '+':	// ���
	case '2':
	case 'R':
		{
			clrSignColor = RGB(255, 0, 0);
			P[0] = CPoint(X+7, Y+2);
			P[1] = CPoint(X+4, Y+9);
			P[2] = CPoint(X+10,Y+9);
		}
		break;
	case '-':	// �϶�
	case '5':
	case 'G':
		{
			clrSignColor = RGB(0, 0, 255);
			P[0] = CPoint(X+4, Y+2);
			P[1] = CPoint(X+7, Y+9);
			P[2] = CPoint(X+10,Y+2);
		}
		break;
	case '4':	// ����
		{
			clrSignColor = RGB(0, 0, 255);
			nPolyCount = 7;
			P[0] = CPoint(X+6, Y+2);
			P[1] = CPoint(X+6, Y+6);
			P[2] = CPoint(X+3, Y+6);
			P[3] = CPoint(X+7, Y+10);
			P[4] = CPoint(X+11,Y+6);
			P[5] = CPoint(X+8, Y+6);
			P[6] = CPoint(X+8, Y+2);
		}
		break;
	default:	// ����
		SetTextClr(OldTextColor);
		return CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);
		//clrSignColor = OldTextColor;
	}

	SetTextClr(clrSignColor);

	if (!m_bShowSign)
		return CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);

    BOOL bResult = CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);

	CPen  pen(PS_SOLID, 1, clrSignColor);
	CBrush	brush(clrSignColor);

	CPen* OldPen = pDC->SelectObject(&pen);
	CBrush* OldBrush = pDC->SelectObject(&brush);
	pDC->Polygon(P, nPolyCount);
	pDC->SelectObject(OldPen);
	pDC->SelectObject(OldBrush);

	return bResult;
}

BOOL CSTgridCellSign::DrawConcle(CDC* pDC, int nRow, int nCol, CRect rect,  BOOL bEraseBkgnd /*=TRUE*/)
{
	COLORREF OldTextColor = pDC->GetTextColor();
	COLORREF clrSignColor;

	CRect ElRect = rect;
	ElRect.left += ((rect.Width()) / 2) - 3;
	ElRect.top += ((rect.Height()) / 2) - 3;
	ElRect.right = ElRect.left + 7;
	ElRect.bottom = ElRect.top + 7;

	//ElRect.DeflateRect(6, 4, 6, 4);
	switch (m_chDiffGb) 
	{
	case '1':
		clrSignColor = RGB(255, 0, 0);
		break;
	case '2':
		clrSignColor = RGB(0, 0, 255);
		break;
	default:	// ����
		SetTextClr(OldTextColor);
		return CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);
		//clrSignColor = OldTextColor;
	}

	if (!m_bShowSign)
		return CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);

    BOOL bResult = CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);

	CPen  pen(PS_SOLID, 1, clrSignColor);
	CBrush	brush(clrSignColor);

	CPen* OldPen = pDC->SelectObject(&pen);
	CBrush* OldBrush = pDC->SelectObject(&brush);
	pDC->Ellipse(ElRect);
	pDC->SelectObject(OldPen);
	pDC->SelectObject(OldBrush);

	return bResult;
}

/*
BOOL CSTgridCellSign::DrawCandle(CDC* pDC, int nRow, int nCol, CRect rect,  BOOL bEraseBkgnd)
{
	COLORREF OldTextColor = pDC->GetTextColor();
	COLORREF clrSignColor;

	CRect rcBody = rect;
	CRect rcHiLo = rect;

	rcBody.DeflateRect(4, 0, 4, 0);
	rcHiLo.DeflateRect(9, 0, 9, 0);

	float fMiddleLn = (float)rcBody.Height() / 2 + rcBody.top;
	float fOpen = (float)(m_lOpen - m_lPreClose) / m_lPreClose;
	float fHigh = (float)(m_lHigh - m_lPreClose) / m_lPreClose;
	float fLow  = (float)(m_lLow  - m_lPreClose) / m_lPreClose;
	float fClose = (float)(m_lClose - m_lPreClose) / m_lPreClose;

	float fPTemp;
	if(m_lClose > m_lOpen)
	{
		clrSignColor = 0x0000ff;
		fPTemp = fMiddleLn * fClose;
		if(fClose < 0)
			rcBody.top = (int)(fMiddleLn - fPTemp);
		else
			rcBody.top = (int)(fMiddleLn + fPTemp);

		fPTemp = fMiddleLn * fOpen;
		if(fOpen < 0)
			rcBody.bottom = (int)(fMiddleLn - fPTemp);
		else
			rcBody.bottom = (int)(fMiddleLn + fPTemp);
	}
	else
	{
		clrSignColor = 0xff0000;
		fPTemp = fMiddleLn * fOpen;
		if(fOpen < 0)
			rcBody.top = (int)(fMiddleLn - fPTemp);
		else
			rcBody.top = (int)(fMiddleLn + fPTemp);

		fPTemp = fMiddleLn * fClose;
		if(fClose < 0)
			rcBody.bottom = (int)(fMiddleLn - fPTemp);
		else
			rcBody.bottom = (int)(fMiddleLn + fPTemp);
	}

	fPTemp = fMiddleLn * fHigh;
	if(fHigh < 0)
		rcHiLo.top = (int)(fMiddleLn - fPTemp);
	else
		rcHiLo.top = (int)(fMiddleLn + fPTemp);

	fPTemp = fMiddleLn * fLow;
	if(fLow < 0)
		rcHiLo.bottom = (int)(fMiddleLn - fPTemp);
	else
		rcHiLo.bottom = (int)(fMiddleLn + fPTemp);

	if (!m_bShowSign || (m_lOpen == 0 || m_lHigh == 0 || m_lLow == 0 || m_lClose == 0))
		return CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);

	SetTextClr(clrSignColor);
    BOOL bResult = CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);

	CPen  pen(PS_SOLID, 1, clrSignColor);
	CBrush	brush(clrSignColor);

	CPen* OldPen = pDC->SelectObject(&pen);
	CBrush* OldBrush = pDC->SelectObject(&brush);
	pDC->Rectangle(rcHiLo);
	pDC->Rectangle(rcBody);
	pDC->SelectObject(OldPen);
	pDC->SelectObject(OldBrush);

	return bResult;
}*/

BOOL CSTgridCellSign::DrawCandle(CDC* pDC, int nRow, int nCol, CRect rect,  BOOL bEraseBkgnd)
{
	COLORREF OldTextColor = pDC->GetTextColor();
	COLORREF clrSignColor;

	CRect rcBody = rect;
	CRect rcHiLo = rect;

	rcBody.DeflateRect(4, 0, 4, 0);
	rcHiLo.DeflateRect(9, 0, 9, 0);

	float fTop = (float)rcBody.top;
	float fBottom = (float)rcBody.bottom;
	float fHeight = (float)rect.Height();
	fHeight = fHeight / (float)0.3;
	float fMiddleLn = (fTop + fBottom) / 2;

	//float fMiddleLn = (float)rcBody.Height() / 2 + rcBody.top;
	float fOpen = (float)(m_lOpen - m_lPreClose) / m_lPreClose;
	float fHigh = (float)(m_lHigh - m_lPreClose) / m_lPreClose;
	float fLow  = (float)(m_lLow  - m_lPreClose) / m_lPreClose;
	float fClose = (float)(m_lClose - m_lPreClose) / m_lPreClose;

	float fPTemp;
	
	//���� ����
	fPTemp = fHeight * fHigh;
	fPTemp = (float)GetFloorCeil((double)fPTemp);
	rcHiLo.top = (int)(fMiddleLn - fPTemp);

	fPTemp = fHeight * fLow;
	fPTemp = (float)GetFloorCeil((double)fPTemp);
	rcHiLo.bottom = (int)(fMiddleLn - fPTemp);

	//�ð� ����
	if(m_lClose >= m_lOpen)
	{
		clrSignColor = 0x0000ff;
		fPTemp = fHeight * fClose;
		fPTemp = (float)GetFloorCeil((double)fPTemp);
		rcBody.top = (int)(fMiddleLn - fPTemp);

		fPTemp = fHeight * fOpen;
		fPTemp = (float)GetFloorCeil((double)fPTemp);
		rcBody.bottom = (int)(fMiddleLn - fPTemp);

		//����
		if(fHigh > fClose && rcHiLo.top == rcBody.top)
			rcHiLo.top--;
		if(fLow < fOpen && rcHiLo.bottom == rcBody.bottom)
			rcHiLo.bottom++;
	}
	else
	{
		clrSignColor = 0xff0000;
		fPTemp = fHeight * fOpen;
		fPTemp = (float)GetFloorCeil((double)fPTemp);
		rcBody.top = (int)(fMiddleLn - fPTemp);
	
		fPTemp = fHeight * fClose;
		fPTemp = (float)GetFloorCeil((double)fPTemp);
		rcBody.bottom = (int)(fMiddleLn - fPTemp);

		//����
		if(fHigh > fOpen && rcHiLo.top == rcBody.top)
			rcHiLo.top--;
		if(fLow < fClose && rcHiLo.bottom == rcBody.bottom)
			rcHiLo.bottom++;
	}
	if(rcBody.top == rcBody.bottom)
		rcBody.bottom++;

	if (!m_bShowSign || (m_lOpen == 0 || m_lHigh == 0 || m_lLow == 0 || m_lClose == 0))
		return CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);

	SetTextClr(clrSignColor);
    BOOL bResult = CSTgridCellStd::Draw(pDC, nRow, nCol, rect,  bEraseBkgnd);

	CPen  pen(PS_SOLID, 1, clrSignColor);
	CBrush	brush(clrSignColor);

	CPen* OldPen = pDC->SelectObject(&pen);
	CBrush* OldBrush = pDC->SelectObject(&brush);

	int x = rect.left + ((rect.Width()) / 2);
	pDC->MoveTo(x, rcHiLo.top);
	pDC->LineTo(x, rcHiLo.bottom);
	//pDC->Rectangle(rcHiLo);
	pDC->Rectangle(rcBody);
	pDC->SelectObject(OldPen);
	pDC->SelectObject(OldBrush);

	return bResult;
}

double CSTgridCellSign::GetFloorCeil(double dValue)
{
	int nData = (int)dValue;
	double dRemaind = dValue - (double)nData;
	if(dRemaind >= 0.5)
		dValue = ceil(dValue);
	else
		dValue = floor(dValue);
	return dValue;
}