// STgridCellBase.cpp : implementation file
//
// MFC STgrid Control - Main STgrid cell base class
//
// Provides the implementation for the base cell type of the
// STgrid control. No data is stored (except for state) but default
// implementations of drawing, printingetc provided. MUST be derived
// from to be used.
//
// Written by Chris Maunder <cmaunder@mail.com>
// Copyright (c) 1998-2002. All Rights Reserved.
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed unmodified by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name and all copyright 
// notices remains intact. 
//
// An email letting me know how you are using it would be nice as well. 
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability for any damage/loss of business that
// this product may cause.
//
// For use with CSTgridCtrl v2.22+
//
// History:
// Ken Bertelson - 12 Apr 2000 - Split CSTgridCell into CSTgridCell and CSTgridCellBase
// C Maunder     - 19 May 2000 - Fixed sort arrow drawing (Ivan Ilinov)
// C Maunder     - 29 Aug 2000 - operator= checks for NULL font before setting (Martin Richter)
// C Maunder     - 15 Oct 2000 - GetTextExtent fixed (Martin Richter)
// C Maunder     -  1 Jan 2001 - Added ValidateEdit
//
// NOTES: Each STgrid cell should take care of it's own drawing, though the Draw()
//        method takes an "erase background" paramter that is called if the STgrid
//        decides to draw the entire STgrid background in on hit. Certain ambient
//        properties such as the default font to use, and hints on how to draw
//        fixed cells should be fetched from the parent STgrid. The STgrid trusts the
//        cells will behave in a certain way, and the cells trust the STgrid will
//        supply accurate information.
//        
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "STgridCtrl.h"
#include "STgridCellBase.h"
#include "STgridcellsign.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CSTgridCellBase, CObject)

/////////////////////////////////////////////////////////////////////////////
// STgridCellBase

CSTgridCellBase::CSTgridCellBase()
{
    Reset();
}

CSTgridCellBase::~CSTgridCellBase()
{
}

/////////////////////////////////////////////////////////////////////////////
// STgridCellBase Operations

void CSTgridCellBase::Reset()
{
	m_Hide=false;
    m_nState  = 0;
	m_MergeRange.Set();
	m_IsMergeWithOthers=false;
	m_MergeCellID.row=-1;
	m_MergeCellID.col=-1;


}
//Used for merge cells,remove const
//by Huang Wei

void CSTgridCellBase::operator=( CSTgridCellBase& cell)
{
	if (this == &cell) return;

    SetSTgrid(cell.GetSTgrid());    // do first in case of dependencies


    Set_BAR(cell.Get_BAR());
    SetText(cell.GetText());

    SetImage(cell.GetImage());
    SetData(cell.GetData());
    SetState(cell.GetState());
    SetFormat(cell.GetFormat());
    SetTextClr(cell.GetTextClr());
    SetBackClr(cell.GetBackClr());
    SetFont(cell.IsDefaultFont()? NULL : cell.GetFont());
    SetMargin(cell.GetMargin());
	SetMergeCellID(cell.GetMergeCellID());
	SetMergeRange(cell.GetMergeRange());
	Show(cell.IsShow());
}

/////////////////////////////////////////////////////////////////////////////
// CSTgridCellBase Attributes

// Returns a pointer to a cell that holds default values for this particular type of cell
CSTgridCellBase* CSTgridCellBase::GetDefaultCell() const
{
    if (GetSTgrid())
        return GetSTgrid()->GetDefaultCell(IsFixedRow(), IsFixedCol());
    return NULL;
}


/////////////////////////////////////////////////////////////////////////////
// CSTgridCellBase Operations

// EFW - Various changes to make it draw cells better when using alternate
// color schemes.  Also removed printing references as that's now done
// by PrintCell() and fixed the sort marker so that it doesn't draw out
// of bounds.
BOOL CSTgridCellBase::Draw(CDC* pDC, int nRow, int nCol, CRect rect,  BOOL bEraseBkgnd /*=TRUE*/)
{
	if(	m_Hide && !IsMerged())	{	return TRUE;	}
	CRect rcOrg = rect;
    CSTgridCtrl* pSTgrid = GetSTgrid();
    ASSERT(pSTgrid);
    if (!pSTgrid || !pDC)        return FALSE;
    if( rect.Width() <= 0 || rect.Height() <= 0)  return FALSE;    // prevents imagelist item from drawing even  return FALSE;                             //  though cell is hidden
    int nSavedDC = pDC->SaveDC();
    pDC->SetBkMode(TRANSPARENT);    // Get the default cell implementation for this kind of cell. We use it if this cell has anything marked as "default"
    CSTgridDefaultCell *pDefaultCell = (CSTgridDefaultCell*) GetDefaultCell();
    if (!pDefaultCell)      return FALSE;
    COLORREF TextClr, TextBkClr;
    TextClr = (GetTextClr() == CLR_DEFAULT)? pDefaultCell->GetTextClr() : GetTextClr();
    if (GetBackClr() == CLR_DEFAULT)
    {
		TextBkClr = pDefaultCell->GetBackClr();

	if (!IsFixed())
	{
		if (pSTgrid->IsAlternateDraw())
			{
				if ((nRow-pSTgrid->GetFixedRowCount()) % (pSTgrid->GetAlternateRowCount()*2) >= pSTgrid->GetAlternateRowCount())
				{
					bEraseBkgnd = TRUE;
					TextBkClr = pSTgrid->GetAlternateColor();
				}
				else if (nRow >= pSTgrid->GetFixedRowCount())
				{
					bEraseBkgnd = TRUE;
					TextBkClr = pSTgrid->GetDefaultCell(FALSE, FALSE)->GetBackClr();
				}
			}
		}
    }
	else
    {
        bEraseBkgnd = TRUE;
		TextBkClr = GetBackClr();
    }

    if (!(GetState() & GVIS_NOSELECT) && IsFocused() || IsDropHighlighted() )
    {
        //if(GetState() & GVIS_SELECTED)
        {
            TextBkClr = pSTgrid->GetSelBkColor();
            bEraseBkgnd = TRUE;
        }

        if (bEraseBkgnd)
        {
            TRY 
            {
                CBrush brush(TextBkClr);   //>>> pDC->FillRect(rect, &brush);
            } 
            CATCH(CResourceException, e)
            {
            }
            END_CATCH
        }

        if(pSTgrid->GetSTgridLines() != GVL_NONE)
        {
        }

        if (!pSTgrid->IsRowFocusFrame() && pSTgrid->GetFrameFocusCell())
        {
            TRY 
            {
	            CPen pen(PS_SOLID, 1, RGB(0,0,0));
				CPen *pPen = pDC->SelectObject(&pen);
                pDC->DrawFocusRect(rect);
				pDC->SelectObject(pPen);
            }
            CATCH(CResourceException, e)
            {
            }
            END_CATCH
        }
        pDC->SetTextColor(TextClr);

        if(pSTgrid->GetSTgridLines() == GVL_NONE)
        {
            rect.right--;
            rect.bottom--;
        }
    }
    else if ((!(GetState() & GVIS_NOSELECT) && GetState() & GVIS_SELECTED))
    {
//		Line_BF(pDC,rect.left, rect.top   ,rect.right, rect.bottom, RGB(0,50,0));
//		CRect Temprect(rect);
//		Temprect.DeflateRect(1,1);
        pDC->FillSolidRect(rect, pSTgrid->GetSelBkColor());//::GetSysColor(COLOR_HIGHLIGHT));
        pDC->SetTextColor(TextClr);//::GetSysColor(COLOR_HIGHLIGHTTEXT));
    }
    else
    {
        if (bEraseBkgnd)
        {
            CBrush brush(TextBkClr);   //>>>   pDC->FillRect(rect, &brush);
        }
        pDC->SetTextColor(TextClr);
    }

    if (IsFixed() && pSTgrid->GetSTgridLines() != GVL_NONE)
    {
        CSTCellID FocusCell = pSTgrid->GetFocusCell();
        {
			CSTgridCtrl *pSTgrid = GetSTgrid();
			CPen lightpen(PS_SOLID, 1, pSTgrid->m_crSTgridLineColour);
			CPen *pOldPen = pDC->GetCurrentPen();

			pDC->SelectObject(&lightpen);
            pDC->MoveTo(rect.right, rect.top);
            pDC->LineTo(rect.right, rect.bottom);
			pDC->LineTo(rect.left-1, rect.bottom);

            pDC->SelectObject(pOldPen);
            rect.DeflateRect(1,1);
        }
    }

#if !defined(_WIN32_WCE_NO_PRINTING) && !defined(STgridCONTROL_NO_PRINTING)
    if (!pDC->m_bPrinting)
#endif
    {
        CFont *pFont = GetFontObject();
		ASSERT(pFont);
        if (pFont)  pDC->SelectObject(pFont);
    }

    rect.DeflateRect(GetMargin(), 0);

    if (pSTgrid->GetImageList() && GetImage() >= 0)
    {
        IMAGEINFO Info;
        if (pSTgrid->GetImageList()->GetImageInfo(GetImage(), &Info))
        {
            int nImageWidth = Info.rcImage.right-Info.rcImage.left+1;
            int nImageHeight = Info.rcImage.bottom-Info.rcImage.top+1;

            if( nImageWidth + rect.left <= rect.right + (int)(2*GetMargin())
                && nImageHeight + rect.top <= rect.bottom + (int)(2*GetMargin())  )
            {
                pSTgrid->GetImageList()->Draw(pDC, GetImage(), rect.TopLeft(), ILD_NORMAL);
            }

        }
    }

    if( Get_BAR())//----------------- Bar DrawPrint---------------------
    {
			if (bEraseBkgnd)
			{
				if(GetState() & GVIS_SELECTED)
				{
					TextBkClr= pSTgrid->GetSelBkColor();
					Line_BF(pDC,rect.left, rect.top   ,rect.right, rect.bottom, TextBkClr);  // ���� ����
				}
			}

		    _STOCK_DATA *pItemBAR = Get_BAR();
			#define			CellSize   0.1                                          // ���� 0.1% ������ ����� ���� 1%�� = 5���� (0.2%)
			#define			CellMin  -15                                          // �� �ŷ��� �ּ� �����
			double			CellMax = 15;                                          // �� �ŷ��� �ְ� �����

			double			STgridMin = (0 - CellMin) / CellSize;
			double			STgridCellCount = 1 / CellSize;                                      // 1%�� �� ����
			double			LavelDifferSum= CellMax - CellMin;								// ����� ��

			int iYesterday =             pItemBAR->iValue_4; //��������--------------(10)
         double dwPer      =   ((double) pItemBAR->iValue_5 - iYesterday) / iYesterday * 100;
			int iClose     =(int) ((((double) pItemBAR->iValue_5 - iYesterday) / iYesterday) * 100 / CellSize); //���簡----------------(11)
			int iOpen      =(int) ((((double) pItemBAR->iValue_6 - iYesterday) / iYesterday) * 100 / CellSize); //�ð�------------------(13)
			int iHight     =(int) ((((double) pItemBAR->iValue_7 - iYesterday) / iYesterday) * 100 / CellSize); //����------------------(14)
			int iLow       =(int) ((((double) pItemBAR->iValue_8 - iYesterday) / iYesterday) * 100 / CellSize); //����------------------(15)

            pItemBAR->iValue_18 =(int) ((double)(iClose) + STgridMin);																							// ���簡
            pItemBAR->iValue_19 =(int) ((double)(iOpen)  + STgridMin); 
            pItemBAR->iValue_20 =(int) ((double)(iHight) + STgridMin);  
            pItemBAR->iValue_21 =(int) ((double)(iLow)   + STgridMin); 

			int rClose = pItemBAR->iValue_18;    //���簡
			int rOpen  = pItemBAR->iValue_19;    //�ð�
			int rHight = pItemBAR->iValue_20;    //����
			int rLow   = pItemBAR->iValue_21;    //����

			if( rClose < 0 ) rClose = 0;
			if( rOpen  < 0 ) rOpen  = 0;
			if( rHight < 0 ) rHight = 0;
			if( rLow   < 0 ) rLow   = 0;
        
			double nCellScaleX = rect.Width()/((LavelDifferSum / CellSize));

			int xPos = rect.left; 
			int yTop = rect.top+2; 
			int yBottom = rect.bottom-2; 

			int pClose  = xPos + int(rClose * nCellScaleX);
			int pOpen   = xPos + int(rOpen * nCellScaleX);
			int pLow    = xPos + int(rLow * nCellScaleX);
			int pHight  = xPos + int(rHight  * nCellScaleX);

			int nR3     = xPos + int(((int)(  3/CellSize) + STgridMin)  * nCellScaleX);
			int nL3     = xPos + int(((int)( -3/CellSize) + STgridMin)  * nCellScaleX);
			int nR6     = xPos + int(((int)(  6/CellSize) + STgridMin)  * nCellScaleX);
			int nL6     = xPos + int(((int)( -6/CellSize) + STgridMin)  * nCellScaleX);
			int nR9     = xPos + int(((int)(  9/CellSize) + STgridMin)  * nCellScaleX);
			int nL9     = xPos + int(((int)( -9/CellSize) + STgridMin)  * nCellScaleX);
			int nR12    = xPos + int(((int)( 12/CellSize) + STgridMin)  * nCellScaleX);
			int nL12    = xPos + int(((int)(-12/CellSize) + STgridMin)  * nCellScaleX);
			int nR15    = xPos + int(((int)( 15/CellSize) + STgridMin)  * nCellScaleX);
			int nL15    = xPos + int(((int)(-15/CellSize) + STgridMin)  * nCellScaleX);

			int nCenter = rect.left+((int)rect.Width()/2);

			Line_BF(pDC,nR15    , rect.top+7     ,nR15+1    , rect.bottom-7, RGB(185,155,100)); //--- �߽�+15
			Line_BF(pDC,nR12    , rect.top+7     ,nR12+1    , rect.bottom-7, RGB(175,145,90)); //--- �߽�+12
			Line_BF(pDC,nR9     , rect.top+7     ,nR9+1     , rect.bottom-7, RGB(165,135,80)); //--- �߽�+9
			Line_BF(pDC,nR6     , rect.top+7     ,nR6+1     , rect.bottom-7, RGB(155,125,70)); //--- �߽�+6
			Line_BF(pDC,nR3     , rect.top+7     ,nR3+1     , rect.bottom-7, RGB(145,115,60)); //--- �߽�+3
			Line_BF(pDC,nCenter , rect.top       ,nCenter+1 , rect.bottom  , RGB(30,30,30)); //RGB(145,145,145));//--- �߽�
			Line_BF(pDC,nL3     , rect.top+7     ,nL3+1     , rect.bottom-7, RGB(60,115,145)); //--- �߽�-3
			Line_BF(pDC,nL6     , rect.top+7     ,nL6+1     , rect.bottom-7, RGB(70,125,155)); //--- �߽�-6
			Line_BF(pDC,nL9     , rect.top+7     ,nL9+1     , rect.bottom-7, RGB(80,135,165)); //--- �߽�-9
			Line_BF(pDC,nL12    , rect.top+7     ,nL12+1    , rect.bottom-7, RGB(90,145,175)); //--- �߽�-12
			Line_BF(pDC,nL15    , rect.top+7     ,nL15+1    , rect.bottom-7, RGB(100,155,185)); //--- �߽�-15

			int nHeight_Bar = (rect.Height()/2)-2;
			unsigned long c;
			if( rClose >= rOpen )
  			{
						c = RGB(225,100,100); // ���� ���� �Ʒ� (+)
			}
  			else
  			{
						c = RGB(100,225,225); //RGB(75,75,225);;// ���� ���� ��(-)
			}

            CPen penLight(PS_SOLID, 1, c);
            CPen *pOldPen = (CPen*) pDC->SelectObject(&penLight);
            pDC->MoveTo( pLow, yTop+nHeight_Bar);
            pDC->LineTo( pHight, yTop+nHeight_Bar );
            pDC->SelectObject(pOldPen);
 		    Line_BF(pDC,pOpen, yTop    ,pClose, yBottom, c); // ���� ���� �Ʒ�   g_colorNormal  g_colorBLUE
    }

    if (pSTgrid->GetSortColumn() == nCol && nRow == 0 && !pSTgrid->m_bFooterDrawing)
    {
        CSize size = pDC->GetTextExtent(_T("M"));
        int nOffset = 2;

        size.cy -= (nOffset * 2);
        if (size.cy >= rect.Height())      size.cy = rect.Height() - (nOffset * 2);
        size.cx = size.cy;      // Make the dimensions square
        BOOL bVertical = (GetFont()->lfEscapement == 900);
        if (size.cx + rect.left < rect.right + (int)(2*GetMargin()))
        {
            int nTriangleBase = rect.bottom - nOffset - size.cy;    // Triangle bottom right
            int nTriangleLeft;
            if (bVertical)
                nTriangleLeft = (rect.right + rect.left - size.cx)/2; // Triangle middle
            else
                nTriangleLeft = rect.right - size.cx;               // Triangle RHS

            CPen penShadow(PS_SOLID, 0, ::GetSysColor(COLOR_3DSHADOW));
            CPen penLight(PS_SOLID, 0, ::GetSysColor(COLOR_3DHILIGHT));
            if (pSTgrid->GetSortAscending())
            {
                // Draw triangle pointing upwards
                CPen *pOldPen = (CPen*) pDC->SelectObject(&penLight);
                pDC->MoveTo( nTriangleLeft + 1, nTriangleBase + size.cy + 1);
                pDC->LineTo( nTriangleLeft + (size.cx / 2) + 1, nTriangleBase + 1 );
                pDC->LineTo( nTriangleLeft + size.cx + 1, nTriangleBase + size.cy + 1);
                pDC->LineTo( nTriangleLeft + 1, nTriangleBase + size.cy + 1);

                pDC->SelectObject(&penShadow);
                pDC->MoveTo( nTriangleLeft, nTriangleBase + size.cy );
                pDC->LineTo( nTriangleLeft + (size.cx / 2), nTriangleBase );
                pDC->LineTo( nTriangleLeft + size.cx, nTriangleBase + size.cy );
                pDC->LineTo( nTriangleLeft, nTriangleBase + size.cy );
                pDC->SelectObject(pOldPen);
            }
            else
            {
                // Draw triangle pointing downwards
                CPen *pOldPen = (CPen*) pDC->SelectObject(&penLight);
                pDC->MoveTo( nTriangleLeft + 1, nTriangleBase + 1 );
                pDC->LineTo( nTriangleLeft + (size.cx / 2) + 1, nTriangleBase + size.cy + 1 );
                pDC->LineTo( nTriangleLeft + size.cx + 1, nTriangleBase + 1 );
                pDC->LineTo( nTriangleLeft + 1, nTriangleBase + 1 );
    
                pDC->SelectObject(&penShadow);
                pDC->MoveTo( nTriangleLeft, nTriangleBase );
                pDC->LineTo( nTriangleLeft + (size.cx / 2), nTriangleBase + size.cy );
                pDC->LineTo( nTriangleLeft + size.cx, nTriangleBase );
                pDC->LineTo( nTriangleLeft, nTriangleBase );
                pDC->SelectObject(pOldPen);
            }
            
            if (!bVertical)   rect.right -= size.cy;
        }
    }

    GetTextRect(rect);
	rect.top++;

	CString strText = GetText();
	
	if (pSTgrid->GetCell(nRow, nCol)->IsKindOf(RUNTIME_CLASS(CSTgridCellSign)))		strText.Remove('-');

	if(nCol==3)  //2009.1025 
	{
		strText.Replace("-","");
//		Line_BF(pDC,rect.left-1, rect.top-1   ,rect.right+1, rect.bottom+1, RGB(90,73,132));
//		Line_BF(pDC,rect.left, rect.top   ,rect.right, rect.bottom, RGB(93,68,138));
	}

	if (strText.Find("\n") > 0)
	{
		CStringArray arrText;
		int nPos;
		while ((nPos = strText.Find("\n")) > 0)
		{
			if (strText.Left(nPos) == "") break;
			arrText.Add(strText.Left(nPos));
			strText = strText.Mid(nPos+1);
		}

		if (strText != "")
			arrText.Add(strText);

		int nTextHeight = rect.Height()/arrText.GetSize();
		for (int i = 0; i < arrText.GetSize(); i++)
		{
			CRect rcText(rect);
			rcText.top = rcText.top + (i*nTextHeight);
			rcText.bottom = rcText.top + nTextHeight;
			DrawText(pDC->m_hDC, arrText.GetAt(i), -1, rcText, GetFormat() | DT_NOPREFIX);
		}
	}
	else
		DrawText(pDC->m_hDC, strText, -1, rect, GetFormat() | DT_NOPREFIX);

    pDC->RestoreDC(nSavedDC);

    return TRUE;
}

void CSTgridCellBase::Line_BF(CDC* pDC,int xLeft, int yTop,int xRight, int yBottom, unsigned long c)
{
		CRect blockRect(xLeft, yTop ,xRight,yBottom);
		CBrush brush(c);
		CBrush* pOldBrush=pDC->SelectObject(&brush);
		pDC->FillRect(blockRect,&brush);
		pDC->SelectObject(pOldBrush);
		brush.DeleteObject();
}

void CSTgridCellBase::OnMouseEnter()
{
    TRACE0("Mouse entered cell\n");
}

void CSTgridCellBase::OnMouseOver()
{
    //TRACE0("Mouse over cell\n");
}

// Not Yet Implemented
void CSTgridCellBase::OnMouseLeave()
{
//    TRACE0("Mouse left cell\n");
}

void CSTgridCellBase::OnClick( CPoint PointCellRelative)
{
    UNUSED_ALWAYS(PointCellRelative);
//    TRACE2("Mouse Left btn up in cell at x=%i y=%i\n", PointCellRelative.x, PointCellRelative.y);
}

void CSTgridCellBase::OnClickDown( CPoint PointCellRelative)
{
    UNUSED_ALWAYS(PointCellRelative);
 //   TRACE2("Mouse Left btn down in cell at x=%i y=%i\n", PointCellRelative.x, PointCellRelative.y);
}

void CSTgridCellBase::OnRClick( CPoint PointCellRelative)
{
    UNUSED_ALWAYS(PointCellRelative);
//    TRACE2("Mouse right-clicked in cell at x=%i y=%i\n", PointCellRelative.x, PointCellRelative.y);
}

void CSTgridCellBase::OnDblClick( CPoint PointCellRelative)
{
    UNUSED_ALWAYS(PointCellRelative);
//    TRACE2("Mouse double-clicked in cell at x=%i y=%i\n", PointCellRelative.x, PointCellRelative.y);
}

// Return TRUE if you set the cursor
BOOL CSTgridCellBase::OnSetCursor()
{
#ifndef _WIN32_WCE_NO_CURSOR
    SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));
#endif
    return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CSTgridCellBase editing

void CSTgridCellBase::OnEndEdit() 
{
	ASSERT( FALSE); 
}

BOOL CSTgridCellBase::ValidateEdit(LPCTSTR str)
{
    UNUSED_ALWAYS(str);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CSTgridCellBase Sizing

BOOL CSTgridCellBase::GetTextRect( LPRECT pRect)  // i/o:  i=dims of cell rect; o=dims of text rect
{
    if (GetImage() >= 0)
    {
        IMAGEINFO Info;

        CSTgridCtrl* pSTgrid = GetSTgrid();
        CImageList* pImageList = pSTgrid->GetImageList();
        
        if (pImageList && pImageList->GetImageInfo( GetImage(), &Info))
        {
            int nImageWidth = Info.rcImage.right-Info.rcImage.left+1;
            pRect->left += nImageWidth + GetMargin();
        }
    }

    return TRUE;
}

// By default this uses the selected font (which is a bigger font)
CSize CSTgridCellBase::GetTextExtent(LPCTSTR szText, CDC* pDC /*= NULL*/)
{
    CSTgridCtrl* pSTgrid = GetSTgrid();
    ASSERT(pSTgrid);

    BOOL bReleaseDC = FALSE;
    if (pDC == NULL || szText == NULL)
    {
        if (szText)
			pDC = pSTgrid->GetDC();
        if (pDC == NULL || szText == NULL) 
        {
            CSTgridDefaultCell* pDefCell = (CSTgridDefaultCell*) GetDefaultCell();
            ASSERT(pDefCell);
            return CSize(pDefCell->GetWidth(), pDefCell->GetHeight());
        }
        bReleaseDC = TRUE;
    }

    CFont *pOldFont = NULL,
          *pFont = GetFontObject();
    if (pFont)
        pOldFont = pDC->SelectObject(pFont);

    CSize size;
    int nFormat = GetFormat();

    // If the cell is a multiline cell, then use the width of the cell
    // to get the height
    if ((nFormat & DT_WORDBREAK) && !(nFormat & DT_SINGLELINE))
    {
        CString str = szText;
        int nMaxWidth = 0;
        while (TRUE)
        {
            int nPos = str.Find(_T('\n'));
            CString TempStr = (nPos < 0)? str : str.Left(nPos);
            int nTempWidth = pDC->GetTextExtent(TempStr).cx;
            if (nTempWidth > nMaxWidth)
                nMaxWidth = nTempWidth;

            if (nPos < 0)
                break;
            str = str.Mid(nPos + 1);    // Bug fix by Thomas Steinborn
        }
        
        CRect rect;
        rect.SetRect(0,0, nMaxWidth+1, 0);
        pDC->DrawText(szText, -1, rect, nFormat | DT_CALCRECT);
        size = rect.Size();
    }
    else
        size = pDC->GetTextExtent(szText, _tcslen(szText));

    TEXTMETRIC tm;
    pDC->GetTextMetrics(&tm);
    size.cx += (tm.tmOverhang);

    if (pOldFont)
        pDC->SelectObject(pOldFont);
    
    size += CSize(4*GetMargin(), 2*GetMargin());

    // Kludge for vertical text
    LOGFONT *pLF = GetFont();
    if (pLF->lfEscapement == 900 || pLF->lfEscapement == -900)
    {
        int nTemp = size.cx;
        size.cx = size.cy;
        size.cy = nTemp;
        size += CSize(0, 4*GetMargin());
    }
    
    if (bReleaseDC)
        pSTgrid->ReleaseDC(pDC);

    return size;
}

CSize CSTgridCellBase::GetCellExtent(CDC* pDC)
{
    CSize size = GetTextExtent(GetText(), pDC);
    CSize ImageSize(0,0);

    int nImage = GetImage();
    if (nImage >= 0) 
    {
        CSTgridCtrl* pSTgrid = GetSTgrid();
        ASSERT(pSTgrid);

        if (pSTgrid->GetImageList()) 
        {
            IMAGEINFO Info;
            if (pSTgrid->GetImageList()->GetImageInfo(nImage, &Info))
                ImageSize = CSize(Info.rcImage.right-Info.rcImage.left+1, 
                                  Info.rcImage.bottom-Info.rcImage.top+1);
        }
    }
    
    return CSize(size.cx + ImageSize.cx, max(size.cy, ImageSize.cy));
}

// EFW - Added to print cells so that STgrids that use different colors are
// printed correctly.
BOOL CSTgridCellBase::PrintCell(CDC* pDC, int /*nRow*/, int /*nCol*/, CRect rect)
{
	//Used for merge cells
	//by Huang Wei
	if(	m_Hide && !IsMerged())
	{
		return TRUE;
	}

#if defined(_WIN32_WCE_NO_PRINTING) || defined(STgridCONTROL_NO_PRINTING)
    return FALSE;
#else
    COLORREF crFG, crBG;
    STGV_ITEM Item;

    CSTgridCtrl* pSTgrid = GetSTgrid();
    if (!pSTgrid || !pDC)
        return FALSE;

    if( rect.Width() <= 0
        || rect.Height() <= 0)  // prevents imagelist item from drawing even
        return FALSE;           //  though cell is hidden

    int nSavedDC = pDC->SaveDC();

    pDC->SetBkMode(TRANSPARENT);
	//Used for merge cells
	//by Huang Wei
	rect.InflateRect(1,1);
	pDC->Rectangle(rect);
	rect.DeflateRect(1,1);

    if (pSTgrid->GetShadedPrintOut())
    {
        // Get the default cell implementation for this kind of cell. We use it if this cell
        // has anything marked as "default"
        CSTgridDefaultCell *pDefaultCell = (CSTgridDefaultCell*) GetDefaultCell();
        if (!pDefaultCell)
            return FALSE;

        // Use custom color if it doesn't match the default color and the
        // default STgrid background color.  If not, leave it alone.
        if(IsFixed() && !pSTgrid->IsPortfolio())
            crBG = (GetBackClr() != CLR_DEFAULT) ? GetBackClr() : pDefaultCell->GetBackClr();
        else
            crBG = (GetBackClr() != CLR_DEFAULT && GetBackClr() != pDefaultCell->GetBackClr()) ?
                GetBackClr() : CLR_DEFAULT;

        // Use custom color if the background is different or if it doesn't
        // match the default color and the default STgrid text color.  
        if(IsFixed() && !pSTgrid->IsPortfolio())
            crFG = (GetBackClr() != CLR_DEFAULT) ? GetTextClr() : pDefaultCell->GetTextClr();
        else
            crFG = (GetBackClr() != CLR_DEFAULT) ? GetTextClr() : pDefaultCell->GetTextClr();

        // If not printing on a color printer, adjust the foreground color
        // to a gray scale if the background color isn't used so that all
        // colors will be visible.  If not, some colors turn to solid black
        // or white when printed and may not show up.  This may be caused by
        // coarse dithering by the printer driver too (see image note below).
        if(pDC->GetDeviceCaps(NUMCOLORS) == 2 && crBG == CLR_DEFAULT)
            crFG = RGB(GetRValue(crFG) * 0.30, GetGValue(crFG) * 0.59,
                GetBValue(crFG) * 0.11);

        // Only erase the background if the color is not the default
        // STgrid background color.
        if(crBG != CLR_DEFAULT)
        {
            CBrush brush(crBG);
            rect.right++; rect.bottom++;
            pDC->FillRect(rect, &brush);
            rect.right--; rect.bottom--;
        }
    }
    else
    {
        crBG = CLR_DEFAULT;
        crFG = RGB(0, 0, 0);
    }

    pDC->SetTextColor(crFG);

    CFont *pFont = GetFontObject();
    if (pFont)
        pDC->SelectObject(pFont);

    /*
    // ***************************************************
    // Disabled - if you need this functionality then you'll need to rewrite.
    // Create the appropriate font and select into DC.
    CFont Font;
    // Bold the fixed cells if not shading the print out.  Use italic
    // font it it is enabled.
    const LOGFONT* plfFont = GetFont();
    if(IsFixed() && !pSTgrid->GetShadedPrintOut())
    {
        Font.CreateFont(plfFont->lfHeight, 0, 0, 0, FW_BOLD, plfFont->lfItalic, 0, 0,
            ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
#ifndef _WIN32_WCE
            PROOF_QUALITY,
#else
            DEFAULT_QUALITY,
#endif
            VARIABLE_PITCH | FF_SWISS, plfFont->lfFaceName);
    }
    else
        Font.CreateFontIndirect(plfFont);

    pDC->SelectObject(&Font);
    // ***************************************************
    */

    // Draw lines only when wanted on fixed cells.  Normal cell STgrid lines
    // are handled in OnPrint.
    if(pSTgrid->GetSTgridLines() != GVL_NONE && IsFixed())
    {
        CPen lightpen(PS_SOLID, 1, ::GetSysColor(COLOR_3DHIGHLIGHT)),
			darkpen(PS_SOLID,  1, ::GetSysColor(COLOR_3DDKSHADOW)),
            *pOldPen = pDC->GetCurrentPen();

        pDC->SelectObject(&lightpen);
        pDC->MoveTo(rect.right, rect.top);
        pDC->LineTo(rect.left, rect.top);
        pDC->LineTo(rect.left, rect.bottom);

        pDC->SelectObject(&darkpen);
        pDC->MoveTo(rect.right, rect.top);
        pDC->LineTo(rect.right, rect.bottom);
        pDC->LineTo(rect.left, rect.bottom);

        rect.DeflateRect(1,1);
        pDC->SelectObject(pOldPen);
    }
	else
	{
//		pDC->Rectangle(rect);

	}

    rect.DeflateRect(GetMargin(), 0);

    if(pSTgrid->GetImageList() && GetImage() >= 0)
    {
        // NOTE: If your printed images look like fuxABxy garbage, check the
        //       settings on your printer driver.  If it's using coarse
        //       dithering and/or vector graphics, they may print wrong.
        //       Changing to fine dithering and raster graphics makes them
        //       print properly.  My HP 4L had that problem.

        IMAGEINFO Info;
        if(pSTgrid->GetImageList()->GetImageInfo(GetImage(), &Info))
        {
            int nImageWidth = Info.rcImage.right-Info.rcImage.left;
            pSTgrid->GetImageList()->Draw(pDC, GetImage(), rect.TopLeft(), ILD_NORMAL);
            rect.left += nImageWidth+GetMargin();
        }
    }

    // Draw without clipping so as not to lose text when printed for real
	// DT_NOCLIP removed 01.01.01. Slower, but who cares - we are printing!

    DrawText(pDC->m_hDC, GetText(), -1, rect,
        GetFormat() | /*DT_NOCLIP | */ DT_NOPREFIX);

    pDC->RestoreDC(nSavedDC);

    return TRUE;
#endif
}

/*****************************************************************************
Callable by derived classes, only
*****************************************************************************/
LRESULT CSTgridCellBase::SendMessageToParent(int nRow, int nCol, int nMessage)
{
    CSTgridCtrl* pSTgrid = GetSTgrid();
    if( pSTgrid)
        return pSTgrid->SendMessageToParent(nRow, nCol, nMessage);
    else
        return 0;
}
//Used for merge cells
//by Huang Wei
void CSTgridCellBase::Show(bool IsShow)
{
	m_Hide=!IsShow;
}
//Used for merge cells
//by Huang Wei
void CSTgridCellBase::SetMergeRange(CSTCellRange range)
{
	m_MergeRange=range;
}
//Used for merge cells
//by Huang Wei
CSTCellRange CSTgridCellBase::GetMergeRange()
{
	return m_MergeRange;
}
//Used for merge cells
//by Huang Wei
bool CSTgridCellBase::IsMerged()
{
	return m_MergeRange.Count()>1;
}
//Used for merge cells
//by Huang Wei
void CSTgridCellBase::SetMergeCellID(CSTCellID cell)
{
	m_MergeCellID=cell;
	if(cell.row!=-1)
		m_IsMergeWithOthers=true;
	else
		m_IsMergeWithOthers=false;

}
//Used for merge cells
//by Huang Wei
CSTCellID CSTgridCellBase::GetMergeCellID()
{
	return m_MergeCellID;
}
//Used for merge cells
//by Huang Wei
bool CSTgridCellBase::IsMergeWithOthers()
{
	return m_IsMergeWithOthers;
}
//Used for merge cells
//by Huang Wei
bool CSTgridCellBase::IsShow()
{
	return !m_Hide;
}
//Used for merge cells
//by Huang Wei
void CSTgridCellBase::UnMerge()
{
	m_Hide=false;
	m_MergeRange.Set();
	m_IsMergeWithOthers=false;
	m_MergeCellID.row=-1;
	m_MergeCellID.col=-1;
}
