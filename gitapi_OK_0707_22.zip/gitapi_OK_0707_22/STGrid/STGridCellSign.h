// STgridCellSign.h: interface for the CSTgridCellSign class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STgridCELLSIGN_H__E15A2A3F_E13B_4CDE_907D_BD2D85CE8A7C__INCLUDED_)
#define AFX_STgridCELLSIGN_H__E15A2A3F_E13B_4CDE_907D_BD2D85CE8A7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "STgridCell.h"

class AFX_EXT_CLASS CSTgridCellSign : public CSTgridCellStd  
{
  friend class CSTgridCtrl;
  DECLARE_DYNCREATE(CSTgridCellSign)
public:
	CSTgridCellSign();
	virtual ~CSTgridCellSign();

public:
	double GetFloorCeil(double dValue);
	BOOL IsShowSign() { return m_bShowSign = m_bShowSign; }
	void SetShowSign(BOOL bShowSign) { m_bShowSign = bShowSign; }
	char GetDiffGb() { return m_chDiffGb; }
	void SetDiffGb(char chDiffGb) { m_chDiffGb = chDiffGb; }
	void SetSignType(int nSignType) { m_nSignType = nSignType; }
	void SetPrice(long lOpen, long lHigh, long lLow, long lClose, long lPreClose)
	{m_lOpen = lOpen; m_lHigh = lHigh; m_lLow = lLow; m_lClose = lClose; m_lPreClose = lPreClose;}

protected:
    virtual BOOL Draw(CDC* pDC, int nRow, int nCol, CRect rect, BOOL bEraseBkgnd = TRUE);
	BOOL DrawConcle(CDC* pDC, int nRow, int nCol, CRect rect, BOOL bEraseBkgnd);
	BOOL DrawCandle(CDC* pDC, int nRow, int nCol, CRect rect, BOOL bEraseBkgnd);

protected:
	long	m_lClose, m_lOpen, m_lHigh, m_lLow, m_lPreClose;	//ĵ���� �׸������� �ð�����/��������
	int		m_nSignType;
    BOOL	m_bShowSign;
    char	m_chDiffGb;

};

#endif // !defined(AFX_STgridCELLSIGN_H__E15A2A3F_E13B_4CDE_907D_BD2D85CE8A7C__INCLUDED_)
