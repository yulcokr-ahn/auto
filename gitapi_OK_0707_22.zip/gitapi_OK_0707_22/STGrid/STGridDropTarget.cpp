// STgridDropTarget.cpp : implementation file
//
// MFC STgrid Control - Drag/Drop target implementation
//
// CSTgridDropTarget is an OLE drop target for CSTgridCtrl. All it does
// is handle the drag and drop windows messages and pass them
// directly onto the STgrid control.
//
// Written by Chris Maunder <cmaunder@mail.com>
// Copyright (c) 1998-2002. All Rights Reserved.
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed unmodified by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name and all copyright 
// notices remains intact. 
//
// An email letting me know how you are using it would be nice as well. 
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability for any damage/loss of business that
// this product may cause.
//
// For use with CSTgridCtrl v2.10+
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "STgridCtrl.h"

#ifndef STgridCONTROL_NO_DRAGDROP
#include "STgridDropTarget.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSTgridDropTarget

CSTgridDropTarget::CSTgridDropTarget()
{
    m_pSTgridCtrl = NULL;
    m_bRegistered = FALSE;
}

CSTgridDropTarget::~CSTgridDropTarget()
{
}

// Overloaded Register() function performs the normal COleDropTarget::Register
// but also serves to connect this COleDropTarget with the parent STgrid control,
// where all drop messages will ultimately be forwarded.
BOOL CSTgridDropTarget::Register(CSTgridCtrl *pSTgridCtrl)
{
    if (m_bRegistered)
        return FALSE;

    // Stop re-entry problems
    static BOOL bInProcedure = FALSE;
    if (bInProcedure)
        return FALSE;
    bInProcedure = TRUE;

    ASSERT(pSTgridCtrl->IsKindOf(RUNTIME_CLASS(CSTgridCtrl)));
    ASSERT(pSTgridCtrl);

    if (!pSTgridCtrl || !pSTgridCtrl->IsKindOf(RUNTIME_CLASS(CSTgridCtrl)))
    {
        bInProcedure = FALSE;
        return FALSE;
    }

    m_pSTgridCtrl = pSTgridCtrl;

    m_bRegistered = COleDropTarget::Register(pSTgridCtrl);

    bInProcedure = FALSE;
    return m_bRegistered;
}

void CSTgridDropTarget::Revoke()
{
    m_bRegistered = FALSE;
    COleDropTarget::Revoke();
}

BEGIN_MESSAGE_MAP(CSTgridDropTarget, COleDropTarget)
    //{{AFX_MSG_MAP(CSTgridDropTarget)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSTgridDropTarget message handlers

DROPEFFECT CSTgridDropTarget::OnDragScroll(CWnd* pWnd, DWORD dwKeyState, CPoint /*point*/)
{
//    //TRACE("LOG_00  In CSTgridDropTarget::OnDragScroll\n");
    if (pWnd->GetSafeHwnd() == m_pSTgridCtrl->GetSafeHwnd())
    {
        if (dwKeyState & MK_CONTROL)
            return DROPEFFECT_COPY;
        else
            return DROPEFFECT_MOVE;
    } else
        return DROPEFFECT_NONE;
}

DROPEFFECT CSTgridDropTarget::OnDragEnter(CWnd* pWnd, COleDataObject* pDataObject, 
                                        DWORD dwKeyState, CPoint point)
{
    TRACE(_T("In CSTgridDropTarget::OnDragEnter\n"));
    ASSERT(m_pSTgridCtrl);

    if (pWnd->GetSafeHwnd() == m_pSTgridCtrl->GetSafeHwnd())
        return m_pSTgridCtrl->OnDragEnter(pDataObject, dwKeyState, point);
    else
        return DROPEFFECT_NONE;
}

void CSTgridDropTarget::OnDragLeave(CWnd* pWnd)
{
    TRACE(_T("In CSTgridDropTarget::OnDragLeave\n"));
    ASSERT(m_pSTgridCtrl);

    if (pWnd->GetSafeHwnd() == m_pSTgridCtrl->GetSafeHwnd())
        m_pSTgridCtrl->OnDragLeave();
}

DROPEFFECT CSTgridDropTarget::OnDragOver(CWnd* pWnd, COleDataObject* pDataObject, 
                                       DWORD dwKeyState, CPoint point)
{
//    //TRACE("LOG_00  In CSTgridDropTarget::OnDragOver\n");
    ASSERT(m_pSTgridCtrl);

    if (pWnd->GetSafeHwnd() == m_pSTgridCtrl->GetSafeHwnd())
        return m_pSTgridCtrl->OnDragOver(pDataObject, dwKeyState, point);
    else
        return DROPEFFECT_NONE;
}

BOOL CSTgridDropTarget::OnDrop(CWnd* pWnd, COleDataObject* pDataObject,
                             DROPEFFECT dropEffect, CPoint point)
{
    TRACE(_T("In CSTgridDropTarget::OnDrop\n"));
    ASSERT(m_pSTgridCtrl);

    if (pWnd->GetSafeHwnd() == m_pSTgridCtrl->GetSafeHwnd())
        return m_pSTgridCtrl->OnDrop(pDataObject, dropEffect, point);
    else
        return FALSE;
}

#endif // STgridCONTROL_NO_DRAGDROP