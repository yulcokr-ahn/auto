// STgrid.h : main header file for the STgrid DLL
//

#if !defined(AFX_STgrid_H__EB35A1E1_1001_4ED5_BEA5_B0BC78DFC178__INCLUDED_)
#define AFX_STgrid_H__EB35A1E1_1001_4ED5_BEA5_B0BC78DFC178__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSTgridApp
// See STgrid.cpp for the implementation of this class
//

class CSTgridApp : public CWinApp
{
public:
	CSTgridApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSTgridApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CSTgridApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STgrid_H__EB35A1E1_1001_4ED5_BEA5_B0BC78DFC178__INCLUDED_)
