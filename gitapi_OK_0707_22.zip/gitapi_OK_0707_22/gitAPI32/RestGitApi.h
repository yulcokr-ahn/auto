#pragma once

#include <cpprest/http_client.h>
#include <cpprest/filestream.h>
#include <cpprest/json.h>

using namespace std;
using namespace web;
using namespace web::http;
using namespace web::http::client;
using namespace utility;					// string_t ����
using namespace web::json;					// json::value
using namespace utility;                    // Common utilities like string conversions
using namespace concurrency::streams;       // Asynchronous streams
using namespace pplx;

struct GitDiffLine	{
	CString line;	bool isAddition;	bool isDeletion;
};

struct GitDiffLine2	{
	enum LineType { FileHeader, Index, OldFile, NewFile, HunkHeader, Added, Removed, Context };
	LineType type;	CString content;
};

//Tr Last Commit ���� 
struct TR_LASTcommit {
	utility::string_t path;
	utility::string_t name;
	utility::string_t id;
	utility::string_t last_commit_date;
	utility::string_t last_commit_message;
	utility::string_t parent_ids; //0708
};

struct TR_HISTORYcommit {
	utility::string_t path;
	utility::string_t name;
	utility::string_t id;
	utility::string_t short_id;
	utility::string_t created_at;
	std::vector<utility::string_t> parent_ids;
//		utility::string_t parent_ids; //0708
	utility::string_t title;
	utility::string_t message;
	utility::string_t author_name;
	utility::string_t author_email;
	utility::string_t authored_date;
	utility::string_t committer_name;
	utility::string_t committer_email;
	utility::string_t committed_date;
};
/*
const utility::string_t g_tHOST_URL           = U("http://127.0.0.1");
const utility::string_t g_tAPI_URL            = U("/api/v4/projects/");
const utility::string_t g_tPROJECTID          = U("root");
const utility::string_t g_tPROJECTPATH        = U("htsmts");
const utility::string_t g_BRANCH	          = U("main");
const utility::string_t g_tPRIVATE_TOKEN      = U("glpat-pxmd9xUzJc2x1KHzkxsA"); 
const utility::string_t g_tContent_Type       = U("application/json");
const utility::string_t g_tDOWNPATH           = U("../../../../Down/");
//p: TQZZ+FdoT9JCNVSHGk8rItIPfTPBwwidM16jfW8pJmA
*/
//0706 22:00
const utility::string_t g_tHOST_URL           = U("http://127.0.0.1");
const utility::string_t g_tAPI_URL            = U("/api/v4/projects/");
const utility::string_t g_tPROJECTID          = U("root");
const utility::string_t g_tPROJECTPATH        = U("htsmts");
const utility::string_t g_BRANCH	          = U("main");
const utility::string_t g_tPRIVATE_TOKEN      = U("glpat-gZ2bnkHzCprmMur-Exuu"); //); //"glpat-pxmd9xUzJc2x1KHzkxsA"); 
const utility::string_t g_tContent_Type       = U("application/json");
const utility::string_t g_tDOWNPATH           = U("../../../../Down/");
//p: pIVZ/O+oR9BaMkOavToqzbY5M/BWIo5sNsllKRX3Bmc
// 2x root glpat-gZ2bnkHzCprmMur-Exuu
//fedd glft-7wK3czRGuxC9whdgpyz8

extern json::value g_Outjson; // ���ٿ�

class CRestGitApi
{
public:
	CRestGitApi(void);
	~CRestGitApi(void);

	std::vector<GitDiffLine2> ParseGitDiffOutput(const CString& output);
	bool starts_with(const std::string& str, const std::string& prefix);
	void parse_file_paths(const std::string& line); 
	void parse_index_info(const std::string& line); 
	std::string parse_file(const std::string& line); 
	void parse_hunk_header(const std::string& line);
	void parse_git_diff_output(FILE* fp);
	CString DetermineGitAction(TCHAR statusCode);

	CString UrlEncode(CString str);
	void DownloadGitlabFile(const CString& projectPath, const CString filePath, const CString& branch, const CString& privateToken);
	void logHead(http_client & cli, http_request &rq);
	std::vector<CString> GitLab_GetRepositoryTree2(json::value &Outjson);
	std::string readFileContent(const std::string& filePath); 
	std::string base64_encode(const std::vector<unsigned char>& data); 
	std::string readBinaryFileBase64(const std::string& filePath); 
	void commitFileToGitLab(const std::string& branch,	const std::string& filePath, const std::string& commitMessage);

	json::value getcommitHistory(utility::string_t path, std::vector<TR_HISTORYcommit> &fi, json::value& commit);
	std::vector<TR_HISTORYcommit> ParseFullCommitList(const web::json::value& commitsJson, const utility::string_t& filePath);
	TR_HISTORYcommit ParseFullCommitJson(const json::value& jsonCommit, const utility::string_t& filePath = U(""));


	void GetDiffCompareGitLab(const utility::string_t& oldSha, const utility::string_t& newSha, std::vector<json::value>& oldDiffList , std::vector<json::value> & newDiffList); //0709
	void GetDiffFromGitLab(const utility::string_t& commitSha, std::vector<json::value>& outDiffList);
//old diff void GetDiffFromGitLab(const utility::string_t& commitSha, json::value &Outjson);

	json::value getcommitLast(TR_LASTcommit& fi, json::value& commit);
	std::vector<CString> get_commits_and_files(json::value &Outjson); //	pplx::task<void> get_commits_and_files(json::value &Outjson);
	void LogWideStringChunks(const std::wstring& wstr);
	task<void> HttpGetGitLabList();
	void TraceJson1(const json::value& jsonVal);
	void TraceJson2(const web::json::value& jsonVal);
	void TraceJson3(const char* callerName, const web::json::value& jsonVal);
	void TraceJson5(const char* context, const web::json::value& val, int indent = 0);

	bool DownloadFileFromGitLab(const CString& url, const CString& outputPath);
	void CompareGitLabCommitWithWorkingTree();
	void LaunchDiffTool(const CString& fileFromGitLab, const CString& fileFromWorking);
	bool CopyWorkingTreeFile(const CString& sourcePath, const CString& destPath);

};

