#pragma once

enum TP_DEF { TP_QUOTE=0, TP_ORDER=1 };
enum MAMA_CON_DEF { CON_TP_REAL=0, CON_TP_TEST };

// ����
enum LANG_DEF { LANG_KOR=0, LANG_ENG=1 };



// ���μ��� ��..
#define		APPNAME_MAIN		TEXT("Quasar.exe")
#define		APPNAME_BASKET		TEXT("Login.exe")

// NSD/Transport/Topic 
#define		NSD_ENV_REAL		TEXT("REAL")
#define		NSD_ENV_TEST		TEXT("TEST")

#define		NSD_COM_REQREP		TEXT("REQREP")
#define		NSD_COM_PUBSUB		TEXT("PUBSUB")

#define		NSD_IF_TCP			TEXT("TCP")

#define		TPORT_ORD			TEXT("ORD")
#define		TPORT_MKD			TEXT("MKD")

#define		TOPIC_OM			TEXT("OM")
#define		TOPIC_ACK			TEXT("ACK")
#define		TOPIC_EXACK			TEXT("EXACK")
#define		TOPIC_KRX			TEXT("KRX")
#define		TOPIC_QRY			TEXT("QRY")
#define		TOPIC_SNAP			TEXT("SNAP")


#define		PID_LINKDATA		0x10		// ���μ������� LinkData ��ȯ�� ���� ID (COPYDATASTRUCT ���� ���)

