#ifndef __PACKETDEF_SCREEN_H_
#define __PACKETDEF_SCREEN_H_

//##########����ũ�� �⺻���м�##########
// Main Screen ����
typedef struct{
	char year[6];	//���
	char identy;		//Q:�б� q:���б�� Y:���� y:��������
}RQ_ii018600, RQ_ii018630;

typedef struct{
	char itemcode[6];
	char trper[3];
	char fwper[3];
	char pbr[3];
	char pcfr[3];
	char ev2ebitda[3];
	char ev2sales[3];
	char ebitda2sales[3];
	char op2sales[3];
	char ni2sales[3];
	char roe[3];
	char sales2fixedasset[3];
	char dre2sales[3];
	char capex2sales[3];
	char nwc2sales[3];
	char inv2sales[3];
	char sales2asset[3];
	char salesgr[3];
	char ebitdagr[3];
	char ebitgr[3];
	char epsgr[3];
	char seccode[3];		//�����ڵ�
} RP_ii018600_SUB;

typedef struct{
	char length[4];
	char identy[2];
	char message[80];
	RP_ii018600_SUB sub[500];
} RP_ii018600;

//Main Screen Sector
//RQ_ii018630�� ����� ������
typedef struct{
//	char itemcode[3];
	char trper[3];
	char fwper[3];
	char pbr[3];
	char pcfr[3];
	char ev2ebitda[3];
	char ev2sales[3];
	char ebitda2sales[3];
	char op2sales[3];
	char ni2sales[3];
	char roe[3];
	char sales2fixedasset[3];
	char dre2sales[3];
	char capex2sales[3];
	char nwc2sales[3];
	char inv2sales[3];
	char sales2asset[3];
	char salesgr[3];
	char ebitdagr[3];
	char ebitgr[3];
	char epsgr[3];
	char seccode[3];		//�����ڵ�
} RP_ii018630_SUB;

typedef struct{
	char length[4];
	char identy[2];
	char message[80];
	RP_ii018630_SUB sub[500];
} RP_ii018630;

//Sub Screen
//�������
typedef struct{
	char code[6];
	char identy;
} RQ_COMMON_SEND;

//Sector����
typedef struct{
	char code[3];
	char identy;
} RQ_COMMON_SEND_SECTOR;

//RP�� ����/Sector �������λ��
// Valuation
typedef struct{
	char year[6];			//��,�б�
	char trpe_ratio[10];
	char fwpe_ratio[10];
	char pb_ratio[10];
	char pcf_ratio[10];
	char ev_editda[10];
	char ev_sales[10];
} RP_ii018610_SUB;

typedef struct{
	char length[4];
	char identy[2];
	char message[80];
	RP_ii018610_SUB sub[200];
} RP_ii018610, RP_ii018620;

// ���ͼ�
typedef struct{
	char year[6];			//��,�б�
	char ebitda_sales[10];
	char op_sales[10];
	char ni_sales[10];
	char roe[10];
} RP_ii028610_SUB;

typedef struct{
	char length[4];
	char identy[2];
	char message[80];
	RP_ii028610_SUB sub[200];
} RP_ii028610, RP_ii028620;

// Ȱ����
typedef struct{
	char year[6];			//��,�б�
	char sales_fixedasst[10];
	char gamga_sales[10];
	char capex_sales[10];
	char nwc_sales[10];
	char inv_sales[10];
	char sales_asst[10];
} RP_ii038610_SUB;

typedef struct{
	char length[4];
	char identy[2];
	char message[80];
	RP_ii038610_SUB sub[200];
} RP_ii038610, RP_ii038620;

// �����
typedef struct{
	char year[6];			//��,�б�
	char sales_growth[10];
	char ebitda_growth[10];
	char ebit_growth[10];
	char eps_growth[10];
} RP_ii048610_SUB;

typedef struct{
	char length[4];
	char identy[2];
	char message[80];
	RP_ii048610_SUB sub[200];
} RP_ii048610, RP_ii048620;

// ����/��� ����Ʈ ��ȸ
typedef struct{
	char identy;		//1:���� / 2:���
} RQ_ii058610;

typedef struct{
	char code[3];
	char name[20];
} RP_ii058610_SUB;

typedef struct{
	char length[4];
	char identy[2];
	char message[80];
	char identy_type;		//1:���� / 2:���
	char count[5];
	RP_ii058610_SUB sub[200];
} RP_ii058610;

//##########����ũ�� ������м�##########
typedef struct{
	char basic[2];
	char max[2];
} RQ_ii018700;

typedef struct{
	char itemcode[6];
	char eps[3];
} RP_ii018700_SUB;

typedef struct{
	char length[4];
	char identy[2];
	char message[80];
	RP_ii018700_SUB sub[500];
} RP_ii018700;

//ȭ�鿡 �ʿ��� ����ü
struct sCONDITION{
	float	fACTW1;
	float	fACTW2;
	float	fACTW3;
	float	fACTW4;
	float	fACTW5;
	float	fACTW6;
	float	fMOMW1;
	float	fMOMW2;
	float	fMOMW3;
	float	fMOMW4;
	float	fPROW1;
	float	fPROW3;
	float	fPROW2;
	float	fPROW4;
	float	fVALW1;
	float	fVALW2;
	float	fVALW3;
	float	fVALW4;
	float	fVALW5;
	float	fVALW6;
	int		iEPS;		//EPS�����(0:Trailing EPS 1:Foreward EPS)
	int		iPeriod;	//�Ⱓ(0:���� 1:�б�)
};

struct sRANK_OPERATION
{
	int nrank;
	char scode[6];
	char sname[21];
	char ssector[49];
	float fscore;
	float fvalue;
	float fprofit;
	float fXPX_ACTIVE;
	float fmoment;
	float ftotal;
};

//������м�
struct sITEMLIST
{
	char sCode[6];
	char sName[20];
	int  nrsi;
	int  n20ma;
	int  n120ma;
	int  ntrade;
	int  ndangorate;
	int  neps;
	int  nforeign;
	int  ntotal;
	int  nCheck;
};

#endif