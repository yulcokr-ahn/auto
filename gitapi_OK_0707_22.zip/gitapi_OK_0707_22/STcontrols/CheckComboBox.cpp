//#######################################################################################
//## CheckComboBox.cpp : implementation file
//#######################################################################################
#include "stdafx.h"
#include "CheckComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//## ====================================================================================
WNDPROC CCheckComboBox::m_parentWndProc = NULL;
CWnd* CCheckComboBox::m_pwndXPX_ACTIVEDropDown = NULL;
CCheckComboBox* CCheckComboBox::m_pwndXPX_ACTIVECheckComboBox = NULL;
CRect CCheckComboBox::m_rcParentRect = CRect(0, 0, 0, 0);

//#######################################################################################
IMPLEMENT_DYNAMIC(CCheckComboBox, CButton)

//## ====================================================================================
CCheckComboBox::CCheckComboBox()
{
	//## INITIALIZE
	m_pwndTree = NULL;
	m_parentWndProc = NULL;
	m_pwndXPX_ACTIVECheckComboBox = NULL;
	m_nDroppedWidth = DROPPED_WIDTH_NOT_SET;
	m_pwndParent = NULL;
	m_bExclusive = FALSE;
}

//## ====================================================================================
CCheckComboBox::~CCheckComboBox()
{
	//## HIDE XPX_ACTIVEDropDown
	HideXPX_ACTIVEDropDown();

	//## UNINTERCEPT
	UnInterceptParentWndProc();

	//## DESTROY Tree
	if (m_pwndTree){
		m_pwndTree->ShowWindow( SW_HIDE );
		delete m_pwndTree;
		m_pwndTree = NULL;
	}

	if((HBITMAP)m_Bitmap)
		m_Bitmap.DeleteObject();
}

//## ====================================================================================
void CCheckComboBox::OnDestroy() 
{
	//## CALL Parent
	CButton::OnDestroy();
	
	//## HIDE XPX_ACTIVEDropDown
	HideXPX_ACTIVEDropDown();

	//## UNINTERCEPT
	UnInterceptParentWndProc();
}

//#######################################################################################
BEGIN_MESSAGE_MAP(CCheckComboBox, CButton)
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_GETDLGCODE()
	ON_CBN_SELCHANGE(IDC_CHECK_TREE,	OnSelchangeCheckTree)
	ON_WM_KILLFOCUS()
END_MESSAGE_MAP()

//#######################################################################################
void CCheckComboBox::OnLButtonDown(UINT nFlags, CPoint point)
{
	//## CALL Parent
	CButton::OnLButtonDown(nFlags, point);

	//## SHOW Tree
	ShowDropWnd();
}

//## ====================================================================================
void CCheckComboBox::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	//## CALL Parent
	CButton::OnLButtonDown(nFlags, point);

	//## SHOW Tree
	ShowDropWnd();
}

//## ====================================================================================
LRESULT CCheckComboBox::WindowProc( UINT message, WPARAM wParam, LPARAM lParam )
{
	//## CATCH DropDown Keys
	switch (message){
		case WM_KEYDOWN:
		case WM_SYSKEYDOWN:
			switch ((int) wParam){
				case VK_F4:
					ShowDropWnd();
					return NULL;	//## INTERCEPT
				case VK_DOWN:
				case VK_UP:
					if (message == WM_SYSKEYDOWN)
						ShowDropWnd();
					return NULL;	//## INTERCEPT
				case VK_SPACE:
					return NULL;	//## INTERCEPT
			}
	}		

	//## CALL Parent
	return CButton::WindowProc(message, wParam, lParam);
}

//## ====================================================================================
BOOL CCheckComboBox::PreTranslateMessage(MSG* pMsg)
{
	//## INTERCEPT Keys => send them to tree
	if ((pMsg->message >= WM_KEYFIRST) && (pMsg->message <= WM_KEYLAST))
		if(m_pwndXPX_ACTIVEDropDown){
			m_pwndXPX_ACTIVEDropDown->SendMessage( pMsg->message, pMsg->wParam, pMsg->lParam);
			((CCheckTreeCtrl*)m_pwndXPX_ACTIVEDropDown)->UpdateToState();
			return FALSE;
		}

	//## PROCESS ToolTip
	InitToolTip();
	m_ToolTip.RelayEvent(pMsg);		
	return CButton::PreTranslateMessage(pMsg);
}

//#######################################################################################
void CCheckComboBox::DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct )
{
	//## GET CDC
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	//## FRAME
	CRect rcItem = lpDrawItemStruct->rcItem;

	// Cover up dark 3D shadow.
	pDC->FillSolidRect(&rcItem, RGB(255,255,255));
	pDC->Draw3dRect(rcItem, COLOR_BORDER, COLOR_BORDER);
	rcItem.DeflateRect(1,1);

	if (!IsWindowEnabled()) {
		pDC->Draw3dRect( rcItem, ::GetSysColor(COLOR_BTNHILIGHT), ::GetSysColor(COLOR_BTNHILIGHT) );
	}
	
	else {
		pDC->Draw3dRect( rcItem, ::GetSysColor(COLOR_BTNFACE), ::GetSysColor(COLOR_BTNFACE) );
	}

	rcItem.DeflateRect(1,1);

	//## GET Caption
	CString strText;
	GetWindowText(strText);

	//## DRAW Caption
	pDC->SetBkColor( (IsWindowEnabled()) ? GetSysColor(COLOR_WINDOW) : GetSysColor(COLOR_BTNFACE) );
	COLORREF crOldColor = SetTextColor(lpDrawItemStruct->hDC, RGB(0, 0, 0));
	DrawText(lpDrawItemStruct->hDC, strText, strText.GetLength(), &rcItem, DT_SINGLELINE | DT_VCENTER );
	SetTextColor(lpDrawItemStruct->hDC, crOldColor);

	if ((HBITMAP)m_Bitmap)
	{	//draw the bitmap
		rcItem.DeflateRect(1,1);
		rcItem.left = rcItem.right - ::GetSystemMetrics(SM_CXHTHUMB);
		pDC->DrawState(rcItem.TopLeft(), rcItem.Size(),
			&m_Bitmap,DSS_NORMAL,(CBrush*)NULL);
	}
}

//#######################################################################################
void CCheckComboBox::AddString(LPCTSTR lpszString, long nID, long nLevel)
{
	//## IF is the first item => add root
	if (m_Data.GetSize() == 0)
		m_Data.AddString(lpszString, INVALID_ID, ROOT_LEVEL);

	//## ADD
	m_Data.AddString(lpszString, nID, nLevel);
}

//#######################################################################################
void CCheckComboBox::InsertString(LPCTSTR lpszString, long nID, long nLevel)
{
	//## IF is the first item => add root
	//if (m_Data.GetSize() == 0)
	//	m_Data.AddString(lpszString, INVALID_ID, ROOT_LEVEL);

	//## ADD
	m_Data.AddString(lpszString, nID, nLevel);

	// insert node to tree
	if(!m_pwndTree)
		return;
	m_pwndTree->AddString(lpszString, nID);
}

// �ʱ�ȭ
void CCheckComboBox::Reset()
{
	m_Data.RemoveAll();
	if(!m_pwndTree)
		return;
	m_pwndTree->DeleteAllItems();
}

void CCheckComboBox::Refresh()
{
	if(!m_pwndTree)
		return;
	m_pwndTree->Populate();
}


//## ====================================================================================
void CCheckComboBox::CheckAll(BOOL bCheck)
{
	m_Data.CheckAll(bCheck);
	UpdateCaption();
}
//## ====================================================================================
void CCheckComboBox::SetCheck(long nID, BOOL bCheck)
{
	m_Data.SetCheck(nID, bCheck);
	UpdateCaption();
}
//## ====================================================================================
BOOL CCheckComboBox::GetCheck(long nID)
{
	return m_Data.GetCheck(nID);
}
//## ====================================================================================
int CCheckComboBox::GetCount()
{
	return m_Data.GetSize();
}
//## ====================================================================================
CString CCheckComboBox::GetCheckedIDs()
{
	return m_Data.GetCheckedIDs();
}

CString	CCheckComboBox::GetCheckedTexts()
{
	return m_Data.GetCheckedTexts();
}

CString CCheckComboBox::GetIDString(int nID)
{
	return m_Data.GetIDString(nID);
}

//## ====================================================================================
void CCheckComboBox::UpdateCaption()
{

//20140608
/*
	//## CAPTION
	CString str = m_Data.GetCheckedTexts();
	SetWindowText(str);

	//## ASSERT
	if (!::IsWindow(m_ToolTip.m_hWnd)) InitToolTip();
	if (!::IsWindow(m_ToolTip.m_hWnd)) return;

	//## TOOLTIP
	m_ToolTip.SetMaxTipWidth( TOOLTIP_MAX_WIDTH );
	if (str.GetLength() > TOOLTIP_MAX_CHARACTERS)
		str = str.Mid(0, (TOOLTIP_MAX_CHARACTERS-3)) + "...";
	SetToolTipText( str );
*/
}
//#######################################################################################
void CCheckComboBox::SetImageList(CImageList *pimgList)
{
	//## SET ImageList
	m_imgList.Create( pimgList );
}
//## ====================================================================================
CImageList* CCheckComboBox::GetImageList()
{
	//## ASSERT
	if ((HIMAGELIST)m_imgList) return &m_imgList;
	return NULL;
}
//#######################################################################################
void CCheckComboBox::ShowDropWnd()
{
	//## ASSERT
	if (!m_pwndTree) CreateDropWnd();
	if (!m_pwndTree) return;

	//## PLACE Tree
	PlaceDropWnd();

	//## DROP
	Drop( !IsDropped() );
}
//## ====================================================================================
void CCheckComboBox::CreateDropWnd()
{
	//## ASSERT
	if (m_pwndTree) return;

	//## CREATE Tree
	m_pwndTree = new CCheckTreeCtrl;

#if  _MSC_VER >= 1600 //Visual C++ 2010 (10.0)
	m_pwndTree->CreateEx(	WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_TOOLWINDOW,
		WS_CHILD | WS_BORDER | WS_CLIPSIBLINGS | WS_OVERLAPPED | TVS_HASBUTTONS | TVS_HASLINES | TVS_CHECKBOXES | TVS_DISABLEDRAGDROP |	TVS_SHOWSELALWAYS | TVS_FULLROWSELECT,
		CRect(0, 0, 0, 0),
		GetDesktopWindow(),
		IDC_CHECK_TREE);

#elif   _MSC_VER >= 1910

m_pwndTree->CreateEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_TOOLWINDOW,
	WS_CHILD | WS_BORDER | WS_CLIPSIBLINGS | WS_OVERLAPPED | TVS_HASBUTTONS | TVS_HASLINES | TVS_CHECKBOXES | TVS_DISABLEDRAGDROP | TVS_SHOWSELALWAYS | TVS_FULLROWSELECT,
	CRect(0, 0, 0, 0),
	GetDesktopWindow(),
	IDC_CHECK_TREE);

#elif _MSC_VER <= 1200

	m_pwndTree->CreateEx(	WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_TOOLWINDOW,
		WC_TREEVIEW,
		NULL,
		WS_CHILD | WS_BORDER |
		WS_CLIPSIBLINGS | WS_OVERLAPPED |
		TVS_HASBUTTONS | TVS_HASLINES | TVS_CHECKBOXES | TVS_DISABLEDRAGDROP |
		TVS_SHOWSELALWAYS | TVS_FULLROWSELECT,
		CRect(0, 0, 0, 0),
		GetDesktopWindow(),
		IDC_CHECK_TREE,
		NULL);

#endif







	//## MOVE on top
	m_pwndTree->SetWindowPos(&CWnd::wndTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);

	//## SET Parent
	m_pwndTree->SetParentCombo( this );

	//## ATTACH ImageList
	if (GetImageList())
		m_pwndTree->SetImageList( GetImageList(), TVSIL_NORMAL );

	//## POPULATE
	m_pwndTree->Populate();
	m_pwndTree->m_bExclusive = m_bExclusive;
}

//## ====================================================================================
void CCheckComboBox::PlaceDropWnd()
{
	//## ASSERT
	if (!m_pwndTree) CreateDropWnd();
	if (!m_pwndTree) return;

	//## GET ComboRect
	CRect rc;
	GetWindowRect(&rc);

	//## MOVE Tree
	m_pwndTree->MoveWindow(rc.left, rc.bottom, GetDroppedWidth(), DROPDOWN_HEIGHT);
}
//## ====================================================================================
BOOL CCheckComboBox::IsDropped()
{
	//## ASSERT
	if (!m_pwndTree) return FALSE;

	//## RETURN
	return ( m_pwndTree->IsWindowVisible() );
}

//## ====================================================================================
void CCheckComboBox::Drop(BOOL bDrop)
{
	//## ASSERT
	if (!m_pwndTree) return;

	//## DROP/UNDROP
	if (bDrop){
		//## ASSERT
		HideXPX_ACTIVEDropDown();

		//## INTERCEPT parent messages
		if (!m_parentWndProc) InterceptParentWndProc();

		//## STRANGE (I do not know why... but without an image list, the following lines are needed)
		if (!(HIMAGELIST)m_imgList){
			m_pwndTree->ShowWindow( SW_SHOW );
			m_pwndTree->UpdateFromState();
		}

		//## UPDATE
		m_pwndTree->UpdateFromState();
		m_pwndTree->ExpandRoot();

		//## SHOW Window
		m_pwndTree->ShowWindow( SW_SHOW );
		m_pwndTree->SetFocus();

		//## SET XPX_ACTIVE DropDown
		m_pwndXPX_ACTIVEDropDown = m_pwndTree;
		m_pwndXPX_ACTIVECheckComboBox = this;

		//## TOOLTIP
		SetToolTipText( "" );

		//## TO BE SURE (if our combo is in a FormView)
		if (this->GetParent())
			this->GetParent()->GetWindowRect( &m_rcParentRect );
	}else{
		//## ASSERT
		HideXPX_ACTIVEDropDown();

		//## HIDE Window
		m_pwndTree->ShowWindow( SW_HIDE );

		//## CAPTION
		UpdateCaption();
	}
	m_pwndParent = (CWnd*)GetParent();
}

//CWnd CheckComboBox::m_parentWnd = NULL;

//## ====================================================================================
void CCheckComboBox::HideXPX_ACTIVEDropDown()
{
	//## ASSERT
	if (!m_pwndXPX_ACTIVEDropDown) return;

	//## HIDE Window
	m_pwndXPX_ACTIVEDropDown->ShowWindow( SW_HIDE );
	m_pwndXPX_ACTIVEDropDown = NULL;

	//## CAPTION
	if (m_pwndXPX_ACTIVECheckComboBox){
		m_pwndXPX_ACTIVECheckComboBox->UpdateCaption();
		m_pwndXPX_ACTIVECheckComboBox = NULL;
	}

	if ( !m_parentWndProc )
		return;
	if ( m_pwndParent ){
		(WNDPROC)::SetWindowLong(m_pwndParent->GetSafeHwnd(), GWL_WNDPROC, (long)(WNDPROC)m_parentWndProc);
		m_parentWndProc = NULL;
	}
}

//#######################################################################################
void CCheckComboBox::InterceptParentWndProc()
{
	//## ASSERT
	if (m_parentWndProc) return;

	//## ASSERT
	CWnd *pwndParent = GetParent();
	if (!pwndParent) return;
	if (!pwndParent->GetSafeHwnd()) return;

	//## GET Parent WinProc & SET our function
	m_parentWndProc = (WNDPROC)::SetWindowLong(pwndParent->GetSafeHwnd(), GWL_WNDPROC, (long)(WNDPROC)ParentWindowProc);
}

//## ====================================================================================
void CCheckComboBox::UnInterceptParentWndProc()
{
	//## ASSERT
	if (!m_parentWndProc) return;

	//## ASSERT
	CWnd *pwndParent = GetParent();
	if (!pwndParent) return;
	if (!pwndParent->GetSafeHwnd()) return;

	//## SET Parent WinProc = UNINTERCEPT
	(WNDPROC)::SetWindowLong(pwndParent->GetSafeHwnd(), GWL_WNDPROC, (long)(WNDPROC)m_parentWndProc);
	m_parentWndProc = NULL;
}

//## ====================================================================================
LRESULT CALLBACK CCheckComboBox::ParentWindowProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	//## CHECK Message
	switch (nMsg){
		case WM_COMMAND:
		case WM_SYSCOMMAND:
		case WM_SYSKEYDOWN:
		case WM_LBUTTONDOWN:
		case WM_NCLBUTTONDOWN:
		case WM_WINDOWPOSCHANGING:
		case WM_WINDOWPOSCHANGED:
			//## FILTER Messages
			if (IsMsgOK(hWnd, nMsg,/* wParam,*/ lParam)) break;

			//## HIDE XPX_ACTIVE DropDown
			HideXPX_ACTIVEDropDown();
			break;
		case WM_PAINT:
			//## TO BE SURE (if our combo is in a FormView)
			if (m_pwndXPX_ACTIVECheckComboBox)
				if (m_pwndXPX_ACTIVECheckComboBox->GetParent()){
					CRect rcParent;
					m_pwndXPX_ACTIVECheckComboBox->GetParent()->GetWindowRect( &rcParent );
					if ((rcParent.top != m_rcParentRect.top) || (rcParent.left != m_rcParentRect.left))
						HideXPX_ACTIVEDropDown();
				}
			break;
	}

	//## CALL Parent
	if(!m_parentWndProc) return NULL;
	return CallWindowProc( m_parentWndProc, hWnd, nMsg, wParam, lParam );
}

//## ====================================================================================
BOOL CCheckComboBox::IsMsgOK(HWND hWnd, UINT nMsg, /*WPARAM wParam,*/ LPARAM lParam)
{
	//## ASSERT
	if (!hWnd) return FALSE;
	if (nMsg != WM_COMMAND) return FALSE;
	if (!m_pwndXPX_ACTIVEDropDown) return FALSE;
	if ((HWND)lParam != m_pwndXPX_ACTIVECheckComboBox->GetSafeHwnd()) return FALSE;

	//## GET DropDownRect
	CRect rc;
	m_pwndXPX_ACTIVECheckComboBox->GetWindowRect( rc );

	//## GET MousePos
	CPoint pt;
	::GetCursorPos( &pt );

	//## CHECK is in rect
	if (pt.x < rc.left) return FALSE;
	if (pt.x > rc.right) return FALSE;
	if (pt.y < rc.top) return FALSE;
	if (pt.y > rc.bottom) return FALSE;

	//## FINALLY
	return TRUE;
}

//## ====================================================================================
UINT CCheckComboBox::OnGetDlgCode()
{
	return (UINT) (DLGC_WANTARROWS | DLGC_WANTCHARS | CButton::OnGetDlgCode()) ;


}

//#######################################################################################
void CCheckComboBox::OnKillFocus(CWnd* pNewWnd) 
{
	//## CALL Parent
	CButton::OnKillFocus(pNewWnd);

	//## HIDE XPX_ACTIVE DropDown
	HideXPX_ACTIVEDropDown();
}

void CCheckComboBox::OnSelchangeCheckTree()
{
	m_pwndParent->SendMessage(WM_CHANGECHECK, (WPARAM)GetWindowLong(this->m_hWnd, GWL_ID), 0);
}


//#######################################################################################
void CCheckComboBox::InitToolTip()
{
	if (m_ToolTip.m_hWnd == NULL){
		try{
			m_ToolTip.Create(this);
			m_ToolTip.Activate(FALSE);
		}catch(...){};
	}
}

//## ====================================================================================
void CCheckComboBox::SetToolTipText(int nId, BOOL bActivate)
{
	//## LOAD String
	CString strText;
	strText.LoadString(nId);

	//## SET Tooltip
	if (strText.IsEmpty() == FALSE) SetToolTipText(strText, bActivate);
}

//## ====================================================================================
void CCheckComboBox::SetToolTipText(CString strText, BOOL bActivate)
{
	//## INITIALIZE ToolTip
	InitToolTip();

	//## IF there is no tooltip defined then add it
	if (m_ToolTip.GetToolCount() == 0)
	{
		CRect rectBtn; 
		GetClientRect(rectBtn);
		m_ToolTip.AddTool(this, (LPCTSTR)strText, rectBtn, 1);
	}

	//## SET text for tooltip
	m_ToolTip.UpdateTipText((LPCTSTR)strText, this, 1);
	m_ToolTip.Activate(bActivate);
}

//#######################################################################################
long CCheckComboBox::GetDroppedWidth()
{
	//## ASSERT
	if (m_nDroppedWidth != DROPPED_WIDTH_NOT_SET) return m_nDroppedWidth;
	if (!m_hWnd) return DROPPED_WIDTH_NOT_SET;

	//## GET ComboRect
	CRect rc;
	GetWindowRect(&rc);

	//## SET, RETURN DroppedWidth
	m_nDroppedWidth = rc.Width();
	return m_nDroppedWidth;
}

//## ====================================================================================
void CCheckComboBox::SetDroppedWidth(long nWidth)
{
	m_nDroppedWidth = nWidth;
}

//#######################################################################################
void CCheckComboBox::SetBitmap(CString strBitmap) 
{
	HBITMAP hBitmap;
	hBitmap = (HBITMAP)LoadImage(AfxGetInstanceHandle(), strBitmap, IMAGE_BITMAP, 0, 0, 
		LR_LOADFROMFILE | LR_CREATEDIBSECTION | LR_DEFAULTSIZE); 
	m_Bitmap.Attach(hBitmap);
}

void CCheckComboBox::SetExclusiveMode(BOOL bExclusive)
{
	m_bExclusive = bExclusive;
}

