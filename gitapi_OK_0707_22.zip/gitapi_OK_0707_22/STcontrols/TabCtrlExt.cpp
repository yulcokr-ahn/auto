// TabCtrlExt.cpp : implementation file
// 2001.9.cyber.sukim

#include "stdafx.h"
#include "TabCtrlExt.h"
#include "PropertySheetExt.h"
#include "Resource.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	OFF_HEIGHT		20
#define	ON_HEIGHT		21

#define	WM_TABCHANGE		(WM_USER + 101)

/////////////////////////////////////////////////////////////////////////////
// CTabCtrlExt

CTabCtrlExt::CTabCtrlExt()
{
	m_crSelTextColour   = RGB(255,255,255);
	m_crUnselTextColour = RGB(0,0,0);
	m_crSelTabColour	= COLOR_TAB_BKGND;// RGB(29,62,37);
	m_crUnselTabColour	= COLOR_TAB_BKGND;//RGB(234,240,236);
	m_crBkgColour		= COLOR_TAB_BKGND;//RGB(228,234,230);
	m_bSheetMode		= TRUE;

	LoadTabImages();
}

CTabCtrlExt::~CTabCtrlExt()
{
	m_SelFont.DeleteObject();
	m_UnselFont.DeleteObject();

	m_bmOffCenter.DeleteObject();
	m_bmOffLeft.DeleteObject();
	m_bmOffRight.DeleteObject();
	m_bmOnCenter.DeleteObject();
	m_bmOnLeft.DeleteObject();
	m_bmOnRight.DeleteObject();
}

BEGIN_MESSAGE_MAP(CTabCtrlExt, CTabCtrl)
	//{{AFX_MSG_MAP(CTabCtrlExt)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	ON_WM_ENABLE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTabCtrlExt message handlers

int CTabCtrlExt::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTabCtrl::OnCreate(lpCreateStruct) == -1) return -1;
	ModifyStyle(0, TCS_OWNERDRAWFIXED);
	return 0;
}

void CTabCtrlExt::PreSubclassWindow() 
{	
	CTabCtrl::PreSubclassWindow();
	ModifyStyle(0, TCS_OWNERDRAWFIXED);
	SetItemSize(CSize(0, 21));
}

void CTabCtrlExt::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{	
	CRect rect = lpDrawItemStruct->rcItem;
	CRect rcBorder = rect;
	int itemID = lpDrawItemStruct->itemID;
	int itemAction = lpDrawItemStruct->itemAction;
	int itemState = lpDrawItemStruct->itemState;

	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	if (!pDC) return;

	int nTabIndex = lpDrawItemStruct->itemID;
	if (nTabIndex < 0) return;
	BOOL bSelected = (nTabIndex == GetCurSel());

	// �Ϲ�
	CDC dcTab, dcTrans, dcTabMask;
	CBitmap bmTab,bmTrans, bmTabMask, *pOldBitmap;

	dcTab.CreateCompatibleDC(pDC);
	dcTrans.CreateCompatibleDC(pDC);
	dcTabMask.CreateCompatibleDC(pDC);

	bmTab.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
	bmTrans.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
	bmTabMask.CreateBitmap(rect.Width(), rect.Height(), 1, 1, NULL);

	pOldBitmap = dcTab.SelectObject(&bmTab);
	dcTrans.SelectObject(&bmTrans);
	dcTabMask.SelectObject(&bmTabMask);

	dcTab.BitBlt(0, 0, rect.Width(), rect.Height(), pDC, 0, 0, SRCCOPY);

	CString strCaption;
	TCITEM	tci;
	memset(&tci, 0, sizeof(TCITEM));
	tci.mask = TCIF_TEXT;
	tci.pszText = strCaption.GetBuffer(100);
	tci.cchTextMax = 99;
	
	GetItem(itemID, &tci);
	strCaption.ReleaseBuffer(100);

	int L, T, B, R;

	if (itemAction == ODA_DRAWENTIRE) //���� 
	{
		COLORREF clrIn = RGB(199,172,238); // RGB(255, 255, 255);
		COLORREF clrOut = COLOR_TAB_CONTROL_BUT;   //20180613       RGB(107,40,206)
		CRect rcTemp(rect);

		pDC->FillSolidRect(rcTemp, COLOR_DLG_BKGND);
		rcTemp.InflateRect(-1, -1);
		pDC->FillSolidRect(rcTemp, m_crSelTabColour);

		CPen penBorderIn, penBorderOut, *pOldPen;
		penBorderIn.CreatePen(PS_SOLID, 1, clrIn);
		penBorderOut.CreatePen(PS_SOLID, 1, clrOut);
		
		L = rect.left;
		T = rect.top;
		B = rect.bottom;
		R = rect.right;

		CPoint P[4];
		P[0]  = CPoint(L+1,  B);
		P[1]  = CPoint(L+1,  T+1);
		P[2]  = CPoint(R-1,  T+1);
		P[3]  = CPoint(R-1,  B);
		pOldPen = pDC->SelectObject(&penBorderIn);
		pDC->Polyline(P, 4);

		CPoint P1[6];
		P1[0]  = CPoint(L,    B);
		P1[1]  = CPoint(L,    T+2);
		P1[2]  = CPoint(L+2,  T);
		P1[3]  = CPoint(R-2,  T);
		P1[4]  = CPoint(R,    T+2);
		P1[5]  = CPoint(R,    B);
		pOldPen = pDC->SelectObject(&penBorderOut);
		pDC->Polyline(P1, 6);

		pDC->SelectObject(pOldPen);
		pDC->SetBkMode(TRANSPARENT);
		pDC->DrawText(strCaption.GetBuffer(0), -1, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}
	else if (itemAction == ODA_SELECT && itemState == ODS_SELECTED) //���� 
	{
		COLORREF clrIn = COLOR_TAB_CONTROL_BUT; //RGB(240, 189, 80);
		COLORREF clrOut = COLOR_BORDER;
		CRect rcTemp(rect);

		pDC->FillSolidRect(rcTemp, RGB(123,60,214)); // COLOR_DLG_BKGND);
		rcTemp.InflateRect(-1, -1);
		rcTemp.bottom++;
		pDC->FillSolidRect(rcTemp, m_crSelTabColour);

		CPen penBorderIn, penBorderOut, *pOldPen;
		penBorderIn.CreatePen(PS_SOLID, 1, clrIn);
		penBorderOut.CreatePen(PS_SOLID, 1, clrOut);
		
		L = rect.left;
		T = rect.top;
		B = rect.bottom;
		R = rect.right;

		CPoint P[4];
		P[0]  = CPoint(L+1,  B-1);
		P[1]  = CPoint(L+1,  T+1);
		P[2]  = CPoint(R-1,  T+1);
		P[3]  = CPoint(R-1,  B);
		pOldPen = pDC->SelectObject(&penBorderIn);
		pDC->Polyline(P, 4);

		P[0]  = CPoint(L+2,  B-1);
		P[1]  = CPoint(L+2,  T+2);
		P[2]  = CPoint(R-2,  T+2);
		P[3]  = CPoint(R-2,  B);
		pDC->Polyline(P, 4);

		CPoint P1[6];
		P1[0]  = CPoint(L,    B-1);
		P1[1]  = CPoint(L,    T+2);
		P1[2]  = CPoint(L+2,  T);
		P1[3]  = CPoint(R-2,  T);
		P1[4]  = CPoint(R,    T+2);
		P1[5]  = CPoint(R,    B-1);
		pOldPen = pDC->SelectObject(&penBorderOut);
		pDC->Polyline(P1, 6);

		if (itemID != 0)
			pDC->SetPixel(rect.left, rect.bottom-1, clrIn);

		CFont *pFont = GetFont();
		LOGFONT lf;
		pFont->GetLogFont(&lf);

		lf.lfWeight = FW_BOLD;

		CFont fontBold, *pOldFont;
		fontBold.CreateFontIndirect(&lf);

		pOldFont = pDC->SelectObject(&fontBold);
		pDC->SetBkMode(TRANSPARENT);
		rcTemp = rect;
		rcTemp.top++;
		pDC->DrawText(strCaption.GetBuffer(0), -1, &rcTemp, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

		pDC->SelectObject(pOldFont);
		pDC->SelectObject(pOldPen);
		fontBold.DeleteObject();
	}

	dcTrans.DeleteDC();
	dcTab.DeleteDC();
	dcTabMask.DeleteDC();
	bmTabMask.DeleteObject();
	bmTab.DeleteObject();
	bmTrans.DeleteObject();

}

/////////////////////////////////////////////////////////////////////////////
// CTabCtrlExt operations

void CTabCtrlExt::SetColours(COLORREF SelColour, COLORREF UnselColour, 
							COLORREF SelTabColour, COLORREF UnselTabColour,
							COLORREF BkgColour)
{
	m_crSelTextColour = SelColour;
	m_crUnselTextColour = UnselColour;
	m_crSelTabColour = SelTabColour;
	m_crUnselTabColour = UnselTabColour;
	m_crBkgColour = BkgColour;
	Invalidate();
}

void CTabCtrlExt::SetFonts(CFont* pSelFont, CFont* pUnselFont)
{
	ASSERT(pSelFont && pUnselFont);

	LOGFONT lFont;
	int nSelHeight, nUnselHeight;

	m_SelFont.DeleteObject();
	m_UnselFont.DeleteObject();

	pSelFont->GetLogFont(&lFont);
	m_SelFont.CreateFontIndirect(&lFont);
	nSelHeight = lFont.lfHeight;

	pUnselFont->GetLogFont(&lFont);
	m_UnselFont.CreateFontIndirect(&lFont);
	nUnselHeight = lFont.lfHeight;

	SetFont( (nSelHeight > nUnselHeight)? &m_SelFont : &m_UnselFont);
}


void CTabCtrlExt::SetFonts(int nSelWeight,   BOOL bSelItalic,   BOOL bSelUnderline,
						  int nUnselWeight, BOOL bUnselItalic, BOOL bUnselUnderline)
{
	// Free any memory currently used by the fonts.
	m_SelFont.DeleteObject();
	m_UnselFont.DeleteObject();

	// Get the current font
	LOGFONT lFont;
	CFont *pFont = GetFont();
	if (pFont)
		pFont->GetLogFont(&lFont);
	else {
		NONCLIENTMETRICS ncm;
		ncm.cbSize = sizeof(NONCLIENTMETRICS);
		VERIFY(SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, 0));
		lFont = ncm.lfMessageFont; 
	}

	// Create the "Selected" font
	lFont.lfWeight = nSelWeight;
	lFont.lfItalic = bSelItalic;
	lFont.lfUnderline = bSelUnderline;
	m_SelFont.CreateFontIndirect(&lFont);

	// Create the "Unselected" font
	lFont.lfWeight = nUnselWeight;
	lFont.lfItalic = bUnselItalic;
	lFont.lfUnderline = bUnselUnderline;
	m_UnselFont.CreateFontIndirect(&lFont);

	SetFont( (nSelWeight > nUnselWeight)? &m_SelFont : &m_UnselFont);
}

void CTabCtrlExt::SetControlMode(BOOL bSheetMode, COLORREF ParentColour)
{
	m_bSheetMode = bSheetMode;
	m_crParent = ParentColour;
};

BOOL CTabCtrlExt::OnEraseBkgnd(CDC* pDC)
{

	CRect rcItem;
	GetClientRect(&rcItem);
	CPropertySheetExt* pParent = (CPropertySheetExt *)GetParent();
	if(m_bSheetMode)
		m_crParent = pParent->GetColours();

	pDC->FillSolidRect(&rcItem, RGB(148,89,255)); //[�׸�1] [�׸�1]  <---->�� �� �� ���  //RGB(123,60,214)); //RGB(148,97,222)); //COLOR_DLG_BKGND);//m_crParent);
	return FALSE;
}


void CTabCtrlExt::SetTabColour(COLORREF crSelected)
{
	m_crSelTabColour = crSelected;
	Invalidate();
}

void CTabCtrlExt::SetBkColour(COLORREF crBkgnd)
{
	m_crSelTabColour = m_crBkgColour = crBkgnd =  RGB(167,119,255); //RGB(148,89,255); // RGB(123,60,214); //RGB(148,97,222); //20180613 pm ���� ��ü  ��� 
	Invalidate();
}

void CTabCtrlExt::LoadTabImages()
{
	m_bmOffLeft.LoadBitmap(IDB_OFFLEFT);
	m_bmOffCenter.LoadBitmap(IDB_OFFCENTER);
	m_bmOffRight.LoadBitmap(IDB_OFFRIGHT);
	m_bmOnLeft.LoadBitmap(IDB_ONLEFT);
	m_bmOnCenter.LoadBitmap(IDB_ONCENTER);
	m_bmOnRight.LoadBitmap(IDB_ONRIGHT);
}


void CTabCtrlExt::OnPaint()
{
	CPaintDC dc(this);

	int nTab = GetItemCount();
	int nSel = GetCurSel();

	if (!nTab) // no pages added
		return;

	//COLORREF clrOldSelTabColour = m_crSelTabColour;
	//if (!IsWindowEnabled())
	//	m_crSelTabColour = RGB(227, 227, 227);

	// prepare dc
	dc.SelectObject(GetFont());

	// draw the rest of the borde                                                                                                                                              r
	CRect rClient, rPage;
	GetClientRect(&rClient);
	rPage = rClient;
	AdjustRect(FALSE, rPage);
	rClient.top = rPage.top - 3;

	// paint the tabs first and then the borders

	DRAWITEMSTRUCT dis;
	dis.CtlType = ODT_TAB;
	dis.CtlID = GetDlgCtrlID();
	dis.hwndItem = GetSafeHwnd();
	dis.hDC = dc.GetSafeHdc();
	dis.itemAction = ODA_DRAWENTIRE;

	while (nTab--)
	{
		if (nTab != nSel)
		{
			dis.itemID = nTab;
			dis.itemState = 0;

			VERIFY(GetItemRect(nTab, &dis.rcItem));
			if (nTab == 0)
				dis.rcItem.left -= 2;

			dis.rcItem.top += 1;

			DrawItem(&dis);
		}
	}

	COLORREF clrIn = COLOR_TAB_CONTROL_BUT; //GB(240, 189, 80);
	COLORREF clrOut = COLOR_BORDER;
	//dc.Draw3dRect(rClient, GetSysColor(COLOR_3DHILIGHT), GetSysColor(COLOR_3DSHADOW));
	CPen penBorderIn, penBorderOut, *pOldPen;
	penBorderIn.CreatePen(PS_SOLID, 1, clrIn);// RGB(96, 117,144));
	penBorderOut.CreatePen(PS_SOLID, 1, clrOut);// RGB(96, 117,144));

	CBrush brBkgnd, *pOldBrush;
	brBkgnd.CreateSolidBrush(m_crSelTabColour);
	pOldBrush = dc.SelectObject(&brBkgnd);
	pOldPen = dc.SelectObject(&penBorderOut);
	rClient.top--;
	dc.Rectangle(rClient);

	pOldPen = dc.SelectObject(&penBorderIn);
	dc.MoveTo(rClient.left+1, rClient.top + 1);
	dc.LineTo(rClient.right-1, rClient.top + 1);

	dc.SelectObject(pOldBrush);
	dc.SelectObject(pOldPen);

	penBorderIn.DeleteObject();
	penBorderOut.DeleteObject();
	brBkgnd.DeleteObject();

	// now selected tab
	dis.itemAction = ODA_SELECT;
	dis.itemID = nSel;
	dis.itemState = ODS_SELECTED;

	VERIFY(GetItemRect(nSel, &dis.rcItem));
	if (nSel == 0)
		dis.rcItem.left -= 2;

	DrawItem(&dis);


}


void CTabCtrlExt::OnEnable(BOOL bEnable) 
{
	CTabCtrl::OnEnable(bEnable);
	
		
}
