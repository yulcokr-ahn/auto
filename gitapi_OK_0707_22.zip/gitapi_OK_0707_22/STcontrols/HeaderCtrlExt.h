#if !defined(AFX_HEADERCTRLEXT_H__706E3285_BEF6_11D5_A8B1_444553540000__INCLUDED_)
#define AFX_HEADERCTRLEXT_H__706E3285_BEF6_11D5_A8B1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HeaderCtrlExt.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlExt window

class AFX_EXT_CLASS CHeaderCtrlExt : public CHeaderCtrl
{
	DECLARE_DYNAMIC(CHeaderCtrlExt)

// Construction
public:
	CHeaderCtrlExt();

// Attributes
protected:
	BOOL		m_bClicked;
	CPoint		m_SelPoint;
	COLORREF	m_clrHilight;	// Hilight color
	COLORREF	m_clrShadow;	// shadow color
	COLORREF	m_clrFace;		// face color
	CFont		m_textfont;
	int			m_nHeight;

// Operations
public:
	void SetColours(COLORREF Colour);
	void SetHeight(int nHeight) { m_nHeight = nHeight; };

// Overrides
protected:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHeaderCtrlExt)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHeaderCtrlExt();

	// Generated message map functions
protected:
	//{{AFX_MSG(CHeaderCtrlExt)
	afx_msg	void	OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg	void	OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg	void	OnPaint();
	afx_msg BOOL	OnEraseBkgnd(CDC* pDC);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	afx_msg LRESULT OnLayout(WPARAM wparam, LPARAM lparam);

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HEADERCTRLEXT_H__706E3285_BEF6_11D5_A8B1_444553540000__INCLUDED_)
