#if !defined(AFX_HILIGHTTEXTWND_H__E45B4400_F24D_4AD0_8807_13810DBFEA92__INCLUDED_)
#define AFX_HILIGHTTEXTWND_H__E45B4400_F24D_4AD0_8807_13810DBFEA92__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HilightTextWnd.h : header file
//
#include "afxtempl.h"
#include <imm.h>
#include "..\include\hrefer.h"

class CHilightTextWnd;

class Colorize
{
public:
	BOOL m_bCaseSensitive;
	CStringList KeyWords;
	CStringList SmartWords;
	CStringList TabPlusWords;
	CStringList TabMinusWords;
	CStringList Operators;  //2003.8.29(��) �α� 
	CString m_strLine;
	CHilightTextWnd* m_pEditor;

	Colorize(CString &keywordsFile,BOOL caseSensitive);
	~Colorize();

	void SetSelColor(CString strSel, int nCurIndex, COLORREF crSel, BOOL bReplace = FALSE);
	void SetLineColors(CString &pString, CTypedPtrArray<CPtrArray, void*> &pColors); 
	BOOL IsWhiteSpace(char pTest);
	BOOL IsKeyWord(CString & pTest);
	BOOL IsSmartWord(CString & pTest);
	BOOL IsTabPlusWord(CString & pTest);
	BOOL IsTabMinusWord(CString & pTest);
	BOOL IsOperator(CString & pTest);   //2003.8.29(��) �α� 
	BOOL IsOperatorChar(char pTest);
	BOOL IsNumChar(char pTest);   //2003.9.1(��) �α� 
	void LoadKeyWords(CString &keywordsFile);
	
};

/////////////////////////////////////////////////////////////////////////////
// CHilightTextWnd window

class AFX_EXT_CLASS CHilightTextWnd : public CRichEditCtrl
{
protected:
	friend class CEdit;

// Construction
public:
	CHilightTextWnd(CWnd * parent, CRect & rect,
		int nID,CString &keywordsFile, BOOL caseSensitive);

// Attributes
private:
	BOOL m_bLoading;
	HIMC m_hIMC;
	BOOL m_bNewComp;
	BOOL m_bCompMode;
	BOOL m_bHanBegin;
	BOOL m_bSendMessage;
	COLORREF m_crBorder;
	int m_nLeftMargin;
	int m_nFirstVisibleLine;

	CWnd* m_pParent;

public:
	BOOL m_bCaseSensitive;
	CHARFORMAT GetCharFormat() { return m_cfText; }
	int GetStartChar() { return m_nStartChar; }
	COLORREF GetBorderColor() { return m_crBorder; }
	void SetBorderColor(COLORREF crBorder) { m_crBorder = crBorder; }
	int GetVisibleLineCount();

// Operations
private:
	CStringArray m_arrText;
	Colorize* m_pColorize;
	CHARFORMAT	m_cfText;
	int m_nStartChar;

	void ParseLine(int nLineIndex = -1);
	BOOL ValidateKey(UINT nChar);
public:	
	void DoCopy();
	void DoPaste();
	void ReLoadKeyWords(CString &keywordsFile);  //2003.9.25(��) Ű���� ��ε��Լ� 
	void SetText(LPCTSTR lpszString);
	void InsertText(LPCTSTR lpszString);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHilightTextWnd)
	public:
	virtual void SetWindowText(LPCTSTR lpszString);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHilightTextWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CHilightTextWnd)
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnNcPaint();
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HILIGHTTEXTWND_H__E45B4400_F24D_4AD0_8807_13810DBFEA92__INCLUDED_)
