// TreeDropTarget.h
// For OLE Drag and Drop between tree controls
// Designed and developed by Vinayak Tadas
// vinayakt@aditi.com
// 

#if !defined(AFX_TREEDROPTARGET_H__246241C3_897C_11D3_A59E_00A02411D21E__INCLUDED_)
#define AFX_TREEDROPTARGET_H__246241C3_897C_11D3_A59E_00A02411D21E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TreeDropTarget.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CListDropTarget
#include <afxole.h>


#define DNDLIST_DROP		WM_USER + 1000


typedef struct tagDROP_INFO
{
	CWnd* m_pSource;
	CWnd* m_pDest;
	DWORD m_DropEffect;
	short m_nSourceType;
}DROP_INFO;


class AFX_EXT_CLASS CListDropTarget :public COleDropTarget	
{
// Overrides
	public:
			virtual DROPEFFECT OnDragEnter( CWnd* pWnd, COleDataObject* pDataObject, 
			DWORD dwKeyState, CPoint point );
			virtual DROPEFFECT OnDragOver( CWnd* pWnd, COleDataObject* pDataObject, 
			DWORD dwKeyState, CPoint point );
			virtual void OnDragLeave( CWnd* pWnd );
			virtual BOOL OnDrop(CWnd* pWnd, COleDataObject* pDataObject,
			DROPEFFECT dropEffect, CPoint point);
// Members
	public:
		//Static variable to store the window handle of source tree control
		static HWND m_shWndListCtrl;
		static short m_nSourceType; // 1�̸� list , 2�̸� Tree�� �Ѵ�.
		static HWND m_shWndListCtrlParent;

	private:
		// Pointer to source tree control
		CWnd* m_pSourceListCtrl;
		// Pointer to destination tree  control
		CWnd* m_pDestListCtrl;

		DWORD m_DropEffect;

};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TREEDROPTARGET_H__246241C3_897C_11D3_A59E_00A02411D21E__INCLUDED_)
