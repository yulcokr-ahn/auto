// MyColorListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "MyColorListCtrl.h"
#include "InplaceEdit.h"
#include "..\include\hrefer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDC_IPEDIT			40095

/////////////////////////////////////////////////////////////////////////////
// CMyColorListCtrl

CMyColorListCtrl::CMyColorListCtrl()
{
	m_nEditable = 0;
	m_nEditColumn = 0;
	m_nEditColumn2 = -1;

	m_crRow1 = COLOR_LIST_ROW1;
	m_crRow2 = COLOR_LIST_ROW2;
	m_crCol = 0x00ff00;
	m_bProgressBar = FALSE;
	m_bProgressBar2 = FALSE;
	m_bInit = FALSE;
	m_bMouseMove = FALSE;
	m_nLinkIndex1 = -1;
	m_nLinkIndex2 = -1;
	m_bDestColEdited = FALSE;
	m_bIsSizing = FALSE;
	//m_bAutoResize = TRUE;
	m_bAutoResize = FALSE;
	m_bEnableToolTip = FALSE;
	m_nEditNextRow = 0;
	m_bAutoEditMove = FALSE;
	m_fAutoSize = TRUE;
	m_bColColor = FALSE;
	m_nColColorIdx = 0;
	m_crBorder = COLOR_BORDER;		// Border Line Color
	m_nColorCount = 5;

	InitBKSetting();
}

CMyColorListCtrl::~CMyColorListCtrl()
{
	
}

BEGIN_MESSAGE_MAP(CMyColorListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CMyColorListCtrl)
	ON_WM_DRAWITEM()
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
	ON_WM_NCPAINT()
	ON_COMMAND(ID_EXCEL_SAVE, OnExcelSave)
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_IPEDIT, OnEndLabelEdit)
	ON_WM_LBUTTONDOWN()
	ON_WM_MEASUREITEM_REFLECT()
	ON_WM_SIZE()
	ON_MESSAGE(LNM_RESIZE, OnResize)
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTW, 0, 0xFFFF, OnToolTipText)
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTA, 0, 0xFFFF, OnToolTipText)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyColorListCtrl message handlers

BOOL CMyColorListCtrl::PreCreateWindow(CREATESTRUCT& cs) 
{
/*	cs.style &= ~LVS_TYPEMASK;
	cs.style &= ~LVS_SHOWSELALWAYS;
	cs.style |= LVS_REPORT | LVS_OWNERDRAWFIXED;
	cs.style |= LVS_EDITLABELS;*/

	return CListCtrl::PreCreateWindow(cs);
}

void CMyColorListCtrl::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CListCtrl::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CMyColorListCtrl::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rcItem(lpDrawItemStruct->rcItem);
	int nItem = lpDrawItemStruct->itemID;
	CImageList* pImageList;
	LV_COLUMN lvc;

	// Save dc state
	int nSavedDC = pDC->SaveDC();
	
	// Get item image and state info
	LV_ITEM lvi;
	lvi.mask = LVIF_IMAGE | LVIF_STATE;
	lvi.iItem = nItem;
	lvi.iSubItem = 0;
	lvi.stateMask = 0xFFFF;		// get all state flags
	GetItem(&lvi);

	// Should the item be highlighted
	BOOL bHighlight =(
						(lvi.state & LVIS_DROPHILITED) || 
						(
							(lvi.state & LVIS_SELECTED)	&& 
							(
								(GetFocus() == this) || (GetStyle() & LVS_SHOWSELALWAYS)
							)
						)
					);

	// Get rectangles for drawing
	CRect rcBounds, rcLabel, rcIcon;
	GetItemRect(nItem, rcBounds, LVIR_BOUNDS);
	GetItemRect(nItem, rcLabel, LVIR_LABEL);
	GetItemRect(nItem, rcIcon, LVIR_ICON);
	CRect rcCol( rcBounds ); 

	CString sLabel = GetItemText( nItem, 0 );

	// Labels are offset by a certain amount  
	// This offset is related to the width of a space character
	int offset = pDC->GetTextExtent(_T(" "), 1 ).cx*2;

	CRect rcHighlight;
	CRect rcWnd;
	int nExt;
	switch( m_nHighlight )
	{
	case 0: 
		nExt = pDC->GetOutputTextExtent(sLabel).cx + offset;
		rcHighlight = rcLabel;
		if( rcLabel.left + nExt < rcLabel.right )
			rcHighlight.right = rcLabel.left + nExt;
		break;
	case 1:
		rcHighlight = rcBounds;
		rcHighlight.left = rcLabel.left;
		break;
	case 2:
		GetClientRect(&rcWnd);
		rcHighlight = rcBounds;
		rcHighlight.left = rcLabel.left;
		rcHighlight.right = rcWnd.right +200;		
		break;
	default:
		rcHighlight = rcLabel;
	}

	int nBKIndex = IsBKChangedRow(lvi.iItem);
	
	// Draw the background color
	if( bHighlight )
	{
		CRect rcClient, rcRow = rcItem;
		GetClientRect(&rcClient);
		rcRow.right = rcClient.right;

//		pDC->SetTextColor(RGB(0,0,0));//::GetSysColor(COLOR_HIGHLIGHTTEXT));
//		pDC->SetBkColor(RGB(222,236,210));//::GetSysColor(COLOR_HIGHLIGHT));

		pDC->FillRect(rcRow , &CBrush(COLOR_SEL_BK));//::GetSysColor(COLOR_HIGHLIGHT)));
	}
	else if(nBKIndex >= 0)
	{
		CRect rcClient, rcRow = rcItem;
		GetClientRect(&rcClient);
		rcRow.right = rcClient.right;

		pDC->FillRect(rcRow, &CBrush(m_BKColorList[nBKIndex].crBkColor));
	}
	else
	{
		CRect rcClient, rcRow = rcItem;
		GetClientRect(&rcClient);
		rcRow.right = rcClient.right;
		rcRow.top-=2;;
		rcRow.bottom+=2;

		div_t div_result;
		div_result = div(nItem, m_nColorCount*2);//10);
		pDC->FillRect(rcRow, &CBrush(div_result.rem < m_nColorCount ? m_crRow1 : m_crRow2));
	}

	GetItemRect(nItem, rcItem, LVIR_LABEL);
	rcItem.left -= 2;
	rcItem.top -= 2;
	rcItem.bottom += 2;
	lvc.mask = LVCF_FMT | LVCF_WIDTH;
	for(int i = 0; GetColumn(i, &lvc); i++)
	{
		rcItem.right = rcItem.left + lvc.cx;
		COLORREF crGridLine = COLOR_LIST_LINE;
		CPen pen(PS_SOLID, 1, crGridLine);
		CPen* pPen = pDC->SelectObject(&pen);
		pDC->MoveTo(rcItem.right, rcItem.top);
		pDC->LineTo(rcItem.right, rcItem.bottom);
		rcItem.left = rcItem.right;
	}

	if(m_bColColor)			//Ư�� Column�� ���󺯰�
	{
		CRect rcCol;
		GetSubItemRect(nItem, m_nColColorIdx, LVIR_BOUNDS, rcCol);
		pDC->FillRect(rcCol, &CBrush(m_crCol));
	}

	//draw stick graph
	if(m_bProgressBar)// && nItem == m_nStickIndex)
		DrawStick(pDC, nItem);
	if(m_bProgressBar2)
		DrawStick2(pDC, nItem);

	// Set clip region
	rcCol.right = rcCol.left + GetColumnWidth(0);
	CRgn rgn;
	rgn.CreateRectRgnIndirect(&rcCol);
	pDC->SelectClipRgn(&rgn);
	rgn.DeleteObject();

	// Draw state icon
	if (lvi.state & LVIS_STATEIMAGEMASK)
	{
		int nImage = ((lvi.state & LVIS_STATEIMAGEMASK)>>12) - 1;
		pImageList = GetImageList(LVSIL_STATE);
		if (pImageList)
		{
			pImageList->Draw(pDC, nImage,
				CPoint(rcCol.left, rcCol.top), ILD_TRANSPARENT);
		}
	}
	
	// Draw normal and overlay icon
	pImageList = GetImageList(LVSIL_SMALL);
	if (pImageList)
	{
		UINT nOvlImageMask=lvi.state & LVIS_OVERLAYMASK;
		pImageList->Draw(pDC, lvi.iImage, 
			CPoint(rcIcon.left, rcIcon.top),
			(bHighlight?ILD_BLEND50:0) | ILD_TRANSPARENT | nOvlImageMask );
	}
	
	// Draw item label - Column 0
	//rcLabel.left += offset/2;
	//rcLabel.right -= offset;
	rcLabel.left += 2;
	rcLabel.right -= 2;

	DWORD dwData = GetItemData(nItem);
	COLORREF crSaved = -1;

/*	if (dwData != 0)
		crSaved = pDC->SetTextColor((COLORREF)dwData);*/

	pDC->DrawText(sLabel,-1,rcLabel,DT_LEFT | DT_SINGLELINE | DT_NOPREFIX | DT_NOCLIP 
				| DT_VCENTER);

/*	if (crSaved != -1)
		pDC->SetTextColor(crSaved);*/

	// Draw labels for remaining columns
	lvc.mask = LVCF_FMT | LVCF_WIDTH;

	if( m_nHighlight == 0 )		// Highlight only first column
	{
		pDC->SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
		pDC->SetBkColor(::GetSysColor(COLOR_WINDOW));
	}
	
	rcBounds.right = rcHighlight.right > rcBounds.right ? rcHighlight.right :
							rcBounds.right;
	rgn.CreateRectRgnIndirect(&rcBounds);
	pDC->SelectClipRgn(&rgn);
				   
	for(int nColumn = 1; GetColumn(nColumn, &lvc); nColumn++)
	{
		rcCol.left = rcCol.right;
		rcCol.right += lvc.cx;

//20140927	
		sLabel = GetItemText(nItem, nColumn);	//if (sLabel.GetLength() == 0) continue;

		// Get the text justification
		UINT nJustify = DT_LEFT;
		switch(lvc.fmt & LVCFMT_JUSTIFYMASK)
		{
		case LVCFMT_RIGHT:
			nJustify = DT_RIGHT;
			break;
		case LVCFMT_CENTER:
			nJustify = DT_CENTER;
			break;
		default:
			break;
		}

		rcLabel = rcCol;
		//rcLabel.left += offset;
		//rcLabel.right -= offset;
		rcLabel.left += 2;
		rcLabel.right -= 2;

		lvi.mask = LVIF_STATE|LVIF_IMAGE;
		lvi.iSubItem = nColumn;
		lvi.stateMask = 0xFFFF;		// get all state flags
		GetItem(&lvi);

/*		if (lvi.state & LVIS_SYMBOL)
		{
			CPoint pt;
			pt.x = rcCol.left;
			pt.y = rcCol.top - (16 - rcCol.Height());
			m_List.Draw(pDC, lvi.iImage, pt, ILD_TRANSPARENT);
		}*/
		
		if(lvi.state & LVIS_COLOR_RED)
			pDC->SetTextColor(LIST_RGB_RED);
		else if(lvi.state & LVIS_COLOR_BLUE)
			pDC->SetTextColor(LIST_RGB_BLUE);
		else if(lvi.state & LVIS_COLOR_GREEN)
			pDC->SetTextColor(LIST_RGB_GREEN);
		else
			pDC->SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));

		pDC->SetBkColor(::GetSysColor(COLOR_WINDOW));

		pDC->DrawText(sLabel, -1, rcLabel, nJustify | DT_SINGLELINE | 
					DT_NOPREFIX | DT_VCENTER);

		pDC->DrawText(sLabel, -1, rcLabel, nJustify | DT_SINGLELINE | 
					DT_NOPREFIX | DT_VCENTER);
	}

	// Draw focus rectangle if item has focus
	//if (lvi.state & LVIS_FOCUSED && (GetFocus() == this))
	//	pDC->DrawFocusRect(rcHighlight);
	
	// Restore dc
	pDC->RestoreDC( nSavedDC );
}

void CMyColorListCtrl::DrawStick(CDC* pDC, int nRowIndex)
{
	CRect rcItem, rcFill;
	double fWidth, f1Tick, fCurWidth;
	long lColor;

	GetSubItemRect(nRowIndex, m_nStickIndex, LVIR_BOUNDS, rcItem);
	rcItem.DeflateRect(1,1,1,1);
	
	CString strTemp = GetItemText(nRowIndex, m_nStickDataIndex);
	double dPos = (double)atof(strTemp.GetBuffer(0)) * 100;
	if(dPos > 0)
	{
		rcFill.left = (rcItem.Width()/2) + rcItem.left;
		fWidth = rcItem.Width()/2;
		f1Tick = fWidth/m_dMaxVal;
		fCurWidth = f1Tick*dPos;
		fCurWidth = fWidth - fCurWidth;
		rcFill.right = (long)(rcItem.right - fCurWidth);
		if(dPos != 0 && rcFill.right == rcFill.left)
			rcFill.right += 1;
		lColor = LIST_RGB_RED;
	}
	else if(dPos < 0)
	{
		rcFill.right = rcItem.Width()/2 + rcItem.left;
		fWidth = rcItem.Width()/2;
		f1Tick = fWidth/m_dMaxVal;
		fCurWidth = f1Tick*dPos;
		fCurWidth = (fWidth - fCurWidth) * (-1);
		rcFill.left = (long)(rcItem.right + fCurWidth);
		if(dPos != 0 && rcFill.right == rcFill.left)
			rcFill.left -= 1;
		lColor = LIST_RGB_BLUE;
	}
	else return;
	rcFill.top = rcItem.top + 1;
	rcFill.bottom = rcItem.bottom - 1;

	//�׶��̼� ȿ��
	CRect grRect;
	grRect = rcFill;
	grRect.bottom = rcFill.top + 1;
	if(dPos > 0)
	{
		while(grRect.bottom <= rcFill.bottom)
		{
			pDC->FillRect(&grRect, &CBrush(lColor-=10));
			grRect.top++;
			grRect.bottom++;
		}
	}
	else
	{
		while(grRect.bottom <= rcFill.bottom)
		{
			pDC->FillRect(&grRect, &CBrush(lColor+=0x001000));
			grRect.top++;
			grRect.bottom++;
		}
	}
	//pDC->FillRect(&rcFill, &CBrush(lColor));
}

//�ι�° Stick
void CMyColorListCtrl::DrawStick2(CDC* pDC, int nRowIndex)
{
	CRect rcItem, rcFill;
	double fWidth, f1Tick, fCurWidth;
	long lColor = 0x000000;

	GetSubItemRect(nRowIndex, m_nStickIndex2, LVIR_BOUNDS, rcItem);
	rcItem.DeflateRect(1,1,1,1);
	
	CString strTemp = GetItemText(nRowIndex, m_nStickDataIndex2);
	double dPos = (double)atof(strTemp.GetBuffer(0)) * 100;
	if(dPos > 0)
	{
		rcFill.left = (rcItem.Width()/2) + rcItem.left;
		fWidth = rcItem.Width()/2;
		f1Tick = fWidth/m_dMaxVal2;
		fCurWidth = f1Tick*dPos;
		fCurWidth = fWidth - fCurWidth;
		rcFill.right = (long)(rcItem.right - fCurWidth);
		if(dPos != 0 && rcFill.right == rcFill.left)
			rcFill.right += 1;
		lColor = LIST_RGB_RED;
	}
	else if(dPos < 0)
	{
		rcFill.right = rcItem.Width()/2 + rcItem.left;
		fWidth = rcItem.Width()/2;
		f1Tick = fWidth/m_dMaxVal2;
		fCurWidth = f1Tick*dPos;
		fCurWidth = (fWidth - fCurWidth) * (-1);
		rcFill.left = (long)(rcItem.right + fCurWidth);
		if(dPos != 0 && rcFill.right == rcFill.left)
			rcFill.left -= 1;
		lColor = LIST_RGB_BLUE;
	}
	else return;
	rcFill.top = rcItem.top + 1;
	rcFill.bottom = rcItem.bottom - 1;

	//�׶��̼� ȿ��
	CRect grRect;
	grRect = rcFill;
	grRect.bottom = rcFill.top + 1;
	if(dPos > 0)
	{
		while(grRect.bottom <= rcFill.bottom)
		{
			pDC->FillRect(&grRect, &CBrush(lColor-=10));
			grRect.top++;
			grRect.bottom++;
		}
	}
	else
	{
		while(grRect.bottom <= rcFill.bottom)
		{
			pDC->FillRect(&grRect, &CBrush(lColor+=0x001000));
			grRect.top++;
			grRect.bottom++;
		}
	}
}

void CMyColorListCtrl::SetStickMax(double dMax)
{
	m_dMaxVal = dMax*100;
	m_dMaxVal += 10;
}

void CMyColorListCtrl::SetStickMax2(double dMax)
{
	m_dMaxVal2 = dMax*100;
	m_dMaxVal2 += 10;
}

void CMyColorListCtrl::OnPaint()
{
	// in full row select mode, we need to extend the clipping region
	// so we can paint a selection all the way to the right
	if (m_nHighlight == HIGHLIGHT_ROW &&
		(GetStyle() & LVS_TYPEMASK) == LVS_REPORT )
	{
		CRect rcBounds;
		GetItemRect(0, rcBounds, LVIR_BOUNDS);

		CRect rcClient;
		GetClientRect(&rcClient);
		if(rcBounds.right < rcClient.right)
		{
			CPaintDC dc(this);

			CRect rcClip;
			dc.GetClipBox(rcClip);

			rcClip.left = min(rcBounds.right-1, rcClip.left);
			rcClip.right = rcClient.right;

			InvalidateRect(rcClip, FALSE);
		}
	}

	if(!m_bInit)
	{
		m_bInit = TRUE;
		CRect rc;
		GetWindowRect( &rc );

		WINDOWPOS wp;
		wp.hwnd = m_hWnd;
		wp.cx = rc.Width();
		wp.cy = rc.Height();
		wp.flags = SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOZORDER;
		SendMessage( WM_WINDOWPOSCHANGED, 0, (LPARAM)&wp );
	}

	CListCtrl::OnPaint();
}

int CMyColorListCtrl::SetHighlightType(EHighlight hilite)
{
	int oldhilite = m_nHighlight;
	if( hilite <= HIGHLIGHT_ROW )
	{
		m_nHighlight = hilite;
		Invalidate();
	}
	return oldhilite;
}

int CMyColorListCtrl::HitTestEx(CPoint &point, int *col) const
{
	if(!m_nEditable)
		return -1;

	int colnum = 0;
	int row = HitTest( point, NULL );
	
	if( col ) *col = 0;

	// Make sure that the ListView is in LVS_REPORT
	if( (GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK) != LVS_REPORT )
		return row;

	// Get the top and bottom row visible
	row = GetTopIndex();
	int bottom = row + GetCountPerPage();
	if( bottom > GetItemCount() )
		bottom = GetItemCount();
	
	// Get the number of columns
	CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);
	int nColumnCount = pHeader->GetItemCount();

	// Loop through the visible rows
	for( ;row <=bottom;row++)
	{
		// Get bounding rect of item and check whether point falls in it.
		CRect rect;
		GetItemRect( row, &rect, LVIR_BOUNDS );
		if( rect.PtInRect(point) )
		{
			// Now find the column
			for( colnum = 0; colnum < nColumnCount; colnum++ )
			{
				int colwidth = GetColumnWidth(colnum);
				if( point.x >= rect.left 
					&& point.x <= (rect.left + colwidth ) )
				{
					if( col ) *col = colnum;
					return row;
				}
				rect.left += colwidth;
			}
		}
	}
	return -1;
}

CEdit* CMyColorListCtrl::EditSubLabel( int nItem, int nCol )
{
	// The returned pointer should not be saved

	// Make sure that the item is visible
	if(!m_nEditable)
		return NULL;

	if( !EnsureVisible( nItem, TRUE ) ) return NULL;

	// Make sure that nCol is valid
	CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);
	int nColumnCount = pHeader->GetItemCount();
	if( nCol >= nColumnCount || GetColumnWidth(nCol) < 5 )
		return NULL;

	// Get the column offset
	int offset = 0;
	for( int i = 0; i < nCol; i++ )
		offset += GetColumnWidth( i );

	CRect rect;
	GetItemRect( nItem, &rect, LVIR_BOUNDS );

	// Now scroll if we need to expose the column
	CRect rcClient;
	GetClientRect( &rcClient );
	if( offset + rect.left < 0 || offset + rect.left > rcClient.right )
	{
		CSize size;
		size.cx = offset + rect.left;
		size.cy = 0;
		Scroll( size );
		rect.left -= size.cx;
	}

	// Get Column alignment
	LV_COLUMN lvcol;
	lvcol.mask = LVCF_FMT;
	GetColumn( nCol, &lvcol );
	DWORD dwStyle ;
	if((lvcol.fmt&LVCFMT_JUSTIFYMASK) == LVCFMT_LEFT)
		dwStyle = ES_LEFT;
	else if((lvcol.fmt&LVCFMT_JUSTIFYMASK) == LVCFMT_RIGHT)
		dwStyle = ES_RIGHT;
	else dwStyle = ES_CENTER;

	rect.left += offset+4;
	rect.right = rect.left + GetColumnWidth( nCol ) - 3 ;
	if( rect.right > rcClient.right) rect.right = rcClient.right;

	dwStyle |= WS_BORDER|WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL;
	CEdit *pEdit = new CInPlaceEdit(nItem, nCol, GetItemText( nItem, nCol ));
	pEdit->Create(dwStyle, rect, this, IDC_IPEDIT);

	return pEdit;
}

void CMyColorListCtrl::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if( GetFocus() != this ) SetFocus();
	CListCtrl::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CMyColorListCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if( GetFocus() != this ) SetFocus();
	CListCtrl::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CMyColorListCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CListCtrl::OnSize(nType, cx, cy);
	//Column Resize
	if(!m_bAutoResize)
		return;

	if (GetItemCount() == 0 && GetCountPerPage() < 1)
		return;

	if (!m_bIsSizing)
	{
		m_bIsSizing = TRUE;
		PostMessage(LNM_RESIZE, (WPARAM)0, (LPARAM)MAKELONG(cx, cy));
	}
}

void CMyColorListCtrl::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos) 
{
	CListCtrl::OnWindowPosChanged(lpwndpos);
}

void CMyColorListCtrl::OnEndLabelEdit(NMHDR* pNMHDR, LRESULT* pResult)
{
	LV_DISPINFO *plvDispInfo = (LV_DISPINFO *)pNMHDR;
	LV_ITEM	*plvItem = &plvDispInfo->item;

	if(!m_nEditable)
	{
		*pResult = FALSE;
		return;
	}

	if (plvItem->pszText != NULL)
	{
		SetItemText(plvItem->iItem, plvItem->iSubItem, plvItem->pszText);
	}
	*pResult = FALSE;
}

void CMyColorListCtrl::OnLButtonDown(UINT nFlags, CPoint point)
{
	int index;
	CListCtrl::OnLButtonDown(nFlags, point);
	
	if(!m_nEditable)
		return;
	
	int colnum;
	if( ( index = HitTestEx( point, &colnum )) != -1 )
	{
		UINT flag = LVIS_FOCUSED;
		if( (GetItemState( index, flag ) & flag) == flag && colnum != 0)	//1�� Į���� ���� �����ϰ�..
		{
			// Add check for LVS_EDITLABELS
//			if( GetWindowLong(m_hWnd, GWL_STYLE) & LVS_EDITLABELS )
			m_nEditNextRow = index;
			if(!m_bDestColEdited)
			{
				if(m_nEditColumn <= colnum)
					EditSubLabel( index, colnum );
			}
			else
			{
				if(m_nEditColumn == colnum)
					EditSubLabel(index, colnum);
				else if(m_nEditColumn2 == colnum)
					EditSubLabel(index, colnum);
			}
		}
		else
			SetItemState( index, LVIS_SELECTED, LVIS_SELECTED);
			//SetItemState( index, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
	}
}

void CMyColorListCtrl::SetEditable(BOOL bEdit)
{
	if(bEdit)
		m_nEditable = 1;
	else
		m_nEditable = 0;
}

void CMyColorListCtrl::SetRowColor(COLORREF crRow1, COLORREF crRow2)
{
	if (crRow2 == NULL)
		crRow2 = crRow1;

	m_crRow1 = crRow1;
	m_crRow2 = crRow2;
}

/////////////resizing row height---<
void CMyColorListCtrl::MeasureItem ( LPMEASUREITEMSTRUCT lpMeasureItemStruct )
{
	LOGFONT lf;
	GetFont()->GetLogFont( &lf );

	if( lf.lfHeight < 0 )
		lpMeasureItemStruct->itemHeight = -lf.lfHeight; 
	else
		lpMeasureItemStruct->itemHeight = lf.lfHeight;
	lpMeasureItemStruct->itemHeight += 3;

	lpMeasureItemStruct->itemHeight = 17;
}
/////////////resizing row height--->

void CMyColorListCtrl::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	if(m_bMouseMove)
	{
		LVHITTESTINFO pHitTestInfo;
		pHitTestInfo.pt.x = point.x;
		pHitTestInfo.pt.y = point.y;
		pHitTestInfo.flags = LVHT_ONITEM;
		ListView_SubItemHitTest(m_hWnd, &pHitTestInfo);
		if(pHitTestInfo.iSubItem == m_nLinkIndex1 || pHitTestInfo.iSubItem == m_nLinkIndex2)
			SetCursor(AfxGetApp()->LoadCursor(IDC_HAND_CURSOR_EX));//LoadCursorFromFile(".\\resource\\cursor1.cur"));
		else
			SetCursor(LoadCursor(NULL, IDC_ARROW));
	}

	HWND hwnd = GetParent()->GetSafeHwnd();
	GetParent()->SendMessage(WM_MOUSEMOVE_LISTCTRL, point.x, point.y);

	CListCtrl::OnMouseMove(nFlags, point);
}

//Column Resize

void CMyColorListCtrl::ResizeColumn()
{
	int nNum, num;
	int cx = 0;

	POSITION pos = m_ColumnNo.GetHeadPosition();
	if (pos == NULL)
		return;

	while (pos)
	{
		num = m_ColumnNo.GetAt(pos);
		if (m_Columns[num].cx != 0)
			nNum = num;

		m_ColumnNo.GetNext(pos);
	}

	// ���� �̽����� nNum�� ������ �÷��̴�.
	pos = m_ColumnNo.GetHeadPosition();
	while (pos)
	{
		num = m_ColumnNo.GetAt(pos);

		if (num == nNum)
			break;

		cx += m_Columns[num].cx;
		::SendMessage(this->m_hWnd, LVM_SETCOLUMNWIDTH, (WPARAM)num, (LPARAM)MAKELONG(m_Columns[num].cx, 0));
		m_ColumnNo.GetNext(pos);
	}

	// Ŭ���̾�Ʈ�� ������ ���Ѵ�.
	CRect rtClient;
	GetClientRect(&rtClient);

	if (rtClient.Width() > cx)
		::SendMessage(this->m_hWnd, LVM_SETCOLUMNWIDTH, (WPARAM)nNum, (LPARAM)MAKELONG(rtClient.Width() - cx, 0));

	Scroll(CSize(0, 0));
	Invalidate(FALSE);
}

void CMyColorListCtrl::EnableAutoSize(BOOL fAuto)
{
	m_fAutoSize = fAuto;
}

LRESULT  CMyColorListCtrl::OnResize(WPARAM wParam, LPARAM lParam)
{
	if (LOWORD(lParam) == 0)
		return 0;

	if(!m_bAutoResize)
		return 0;

	ResizeColumn();
	m_bIsSizing = FALSE;
	return 0;
}

int CMyColorListCtrl::InsertColumn(int nCol, const LVCOLUMN *pColumn)
{
	int nRet = CListCtrl::InsertColumn(nCol, pColumn);

	if(!m_bAutoResize)
		return nRet;

	LVCOLUMN pCol;
	memcpy(&pCol, pColumn, sizeof(LVCOLUMN));

	// �ش� �÷��� �߰��Ѵ�.
	m_Columns[nCol] = pCol;
	m_ColumnNo.AddTail(nCol);

	ResizeColumn();

	return nRet;
}

void CMyColorListCtrl::ResetColumnSize(int nCol, int nWidth)
{
	m_Columns[nCol].cx = nWidth;
}

void CMyColorListCtrl::SetAutoResize(BOOL bResize)
{
	m_bAutoResize = bResize;
}

//ToolTip ����

void CMyColorListCtrl::SetEnableToolTips(int nTipIndex)
{
	m_nTipIndex = nTipIndex;
	EnableToolTips(TRUE);
} 

int CMyColorListCtrl::OnToolHitTest(CPoint point, TOOLINFO * pTI) const
{
	int row, col;
	RECT cellrect;
	row = CellRectFromPoint(point, &cellrect, &col );

	if ( row == -1 ) 
		return -1;

	if(col != 0)
		return -1;

	pTI->hwnd = m_hWnd;
	pTI->uId = (UINT)((row<<10)+(col&0x3ff)+1);
	pTI->lpszText = LPSTR_TEXTCALLBACK;

	pTI->rect = cellrect;

	return pTI->uId;
}

// CellRectFromPoint	- Determine the row, col and bounding rect of a cell
// Returns		- row index on success, -1 otherwise
// point		- point to be tested.
// cellrect		- to hold the bounding rect
// col			- to hold the column index
int CMyColorListCtrl::CellRectFromPoint(CPoint & point, RECT * cellrect, int * col) const
{
	int colnum;

	// Make sure that the ListView is in LVS_REPORT
	if( (GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK) != LVS_REPORT )
		return -1;

	// Get the top and bottom row visible
	int row = GetTopIndex();
	int bottom = row + GetCountPerPage();
	if(bottom > GetItemCount())
		bottom = GetItemCount();
	
	// Get the number of columns
	CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);
	int nColumnCount = pHeader->GetItemCount();

	// Loop through the visible rows
	for( ;row <=bottom;row++)
	{
		// Get bounding rect of item and check whether point falls in it.
		CRect rect;
		GetItemRect( row, &rect, LVIR_BOUNDS );
		if( rect.PtInRect(point) )
		{
			// Now find the column
			for( colnum = 0; colnum < nColumnCount; colnum++ )
			{
				int colwidth = GetColumnWidth(colnum);
				if( point.x >= rect.left 
					&& point.x <= (rect.left + colwidth ) )
				{
					RECT rectClient;
					GetClientRect( &rectClient );
					if( col ) *col = colnum;
					rect.right = rect.left + colwidth;

					// Make sure that the right extent does not exceed
					// the client area
					if( rect.right > rectClient.right ) 
						rect.right = rectClient.right;
					*cellrect = rect;
					return row;
				}
				rect.left += colwidth;
			}
		}
	}
	return -1;
}

BOOL CMyColorListCtrl::OnToolTipText( UINT id, NMHDR * pNMHDR, LRESULT * pResult )
{
	// need to handle both ANSI and UNICODE versions of the message
	TOOLTIPTEXTA* pTTTA = (TOOLTIPTEXTA*)pNMHDR;
	TOOLTIPTEXTW* pTTTW = (TOOLTIPTEXTW*)pNMHDR;
	CString strTipText;
	UINT nID = pNMHDR->idFrom;

	if( nID == 0 )	  	// Notification in NT from automatically
		return FALSE;   	// created tooltip

	int row = ((nID-1) >> 10) & 0x3fffff ;
	int col = (nID-1) & 0x3ff;
	
	if(col != 0)
		return FALSE;
	
	strTipText = GetItemText(row, m_nTipIndex);		//�������񿡼� �����ڵ� �����ش�

#ifndef _UNICODE
	if (pNMHDR->code == TTN_NEEDTEXTA)
		lstrcpyn(pTTTA->szText, strTipText, 80);
	else
		_mbstowcsz(pTTTW->szText, strTipText, 80);
#else
	if (pNMHDR->code == TTN_NEEDTEXTA)
		_wcstombsz(pTTTA->szText, strTipText, 80);
	else
		lstrcpyn(pTTTW->szText, strTipText, 80);
#endif
	*pResult = 0;

	return TRUE;    // message was handled
}

void CMyColorListCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_nEditable && m_bAutoEditMove)
	{
		if(nChar == VK_RETURN)
		{
			int nRowCnt = GetItemCount();
			m_nEditNextRow++;
			if(nRowCnt > m_nEditNextRow)
				EditSubLabel(m_nEditNextRow, m_nEditColumn);
			else
				SetFocus();
		}
	}
	CListCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CMyColorListCtrl::InitBKSetting() //2004.9.13 min
{
	m_nBKCount = 0;
	for(int i=0;i<100;i++)
	{
		m_BKColorList[i].nIndex = 0;
		m_BKColorList[i].crBkColor = LIST_RGB_RED;
	}
}

void CMyColorListCtrl::SetRowBKColor(int nIndex, COLORREF crBKColor) //2004.9.13 min
{
	if(m_nBKCount >= 100)
		return;

	m_BKColorList[m_nBKCount].nIndex = nIndex;
	m_BKColorList[m_nBKCount].crBkColor = crBKColor;
	m_nBKCount++;
}

int CMyColorListCtrl::IsBKChangedRow(int nIndex) //2004.9.13 min
{
	for(int i=0;i<m_nBKCount;i++)
	{
		if(m_BKColorList[i].nIndex == nIndex)
			return i;
	}
	return -1;
}




void CMyColorListCtrl::OnNcPaint() 
{
	// TODO: Add your message handler code here
	
	// Do not call CListCtrl::OnNcPaint() for painting messages
	Default();
	
	LONG lStyle = ::GetWindowLong(m_hWnd, GWL_STYLE);
	if(lStyle & WS_BORDER)
	{
		CWindowDC dc(this);
		CRect rcBounds;
		GetWindowRect(rcBounds);
		ScreenToClient(rcBounds);
		rcBounds.OffsetRect(-rcBounds.left, -rcBounds.top);
		//dc.DrawEdge(rcBounds, EDGE_SUNKEN, BF_RECT);
		dc.Draw3dRect(rcBounds, m_crBorder, m_crBorder);
	}
}

void CMyColorListCtrl::PreSubclassWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	ModifyStyle(LVS_SMALLICON | LVS_LIST | LVS_ICON , LVS_OWNERDRAWFIXED | LVS_REPORT);
	ModifyStyle(0, LVIS_FOCUSED);
	ModifyStyle(0, WS_BORDER);
	ModifyStyleEx(WS_EX_CLIENTEDGE, 0);

	CListCtrl::PreSubclassWindow();
}


void CMyColorListCtrl::SaveToCSV()
{
	CString strBuffer, strTemp, strFileName;
	CFile saveFile;
	char sTemp[1024];
	HDITEM hitem;

	hitem.mask = HDI_TEXT;
	hitem.cchTextMax = 256;
	hitem.pszText = sTemp;

	memset(sTemp, 0x00, sizeof(sTemp));
	
	srand((unsigned)time(NULL));
	CString strReg = AfxGetApp()->GetProfileString("PWR","UserPath");
	strFileName.Format("%s\\temp\\temp_%d.csv", strReg, rand());

	CHeaderCtrl* pHeaderCtrl = GetHeaderCtrl();
	
	int nColCount = pHeaderCtrl->GetItemCount();

	// �÷���
	for(int i = 0; i < nColCount; i++)
	{
		pHeaderCtrl->GetItem(i, &hitem);
		strTemp = hitem.pszText;
		strBuffer = strBuffer + strTemp + ",";
	}
	strBuffer += "\n";

	for(int nRow = 0; nRow < GetItemCount(); nRow++)
	{
		for(int nCol = 0; nCol < nColCount; nCol++)
		{
			strTemp = GetItemText(nRow, nCol);
			strTemp.Remove(',');
			strBuffer = strBuffer + strTemp + ",";
		}
		strBuffer = strBuffer + ",\n";
	}
	strBuffer = strBuffer + ",\n";

	// Excel���ϻ���
	if(!saveFile.Open(strFileName, CFile::modeCreate|CFile::modeWrite))
	{
		MessageBox("���ϻ����� �����߽��ϴ�","�ý��� ����ȭ");
		return;
	}
	saveFile.Write(strBuffer.GetBuffer(0), strBuffer.GetLength());
	saveFile.Close();

	ShellExecute(0, "open", "excel.exe", strFileName, NULL, SW_SHOWNORMAL);
}

void CMyColorListCtrl::OnExcelSave() 
{
	// TODO: Add your command handler code here
	SaveToCSV();	
}

void CMyColorListCtrl::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	// TODO: Add your message handler code here
	CMenu* pPopup=NULL;

	CMenu mnuPopup;
	mnuPopup.LoadMenu(IDR_EXCEL_POPUP);
	::GetCursorPos(&point);
	pPopup = mnuPopup.GetSubMenu(0);

	int nCmd = pPopup->TrackPopupMenu( TPM_RETURNCMD | TPM_LEFTALIGN|
	TPM_RIGHTBUTTON, point.x, point.y, this );

	if (nCmd)
		this->SendMessage(WM_COMMAND, nCmd);
}
