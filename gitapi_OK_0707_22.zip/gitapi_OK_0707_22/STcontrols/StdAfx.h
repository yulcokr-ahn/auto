// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__5F5EA5C7_CE0E_11D5_A8B3_444553540000__INCLUDED_ST_)
#define AFX_STDAFX_H__5F5EA5C7_CE0E_11D5_A8B3_444553540000__INCLUDED_ST_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions

#ifndef _AFX_NO_OLE_SUPPORT
#include <afxole.h>         // MFC OLE classes
#include <afxodlgs.h>       // MFC OLE dialog classes
#include <afxdisp.h>        // MFC Automation classes
#endif // _AFX_NO_OLE_SUPPORT


#ifndef _AFX_NO_DB_SUPPORT
#include <afxdb.h>			// MFC ODBC database classes
#endif // _AFX_NO_DB_SUPPORT

#ifndef _AFX_NO_DAO_SUPPORT
#include <afxdao.h>			// MFC DAO database classes
#endif // _AFX_NO_DAO_SUPPORT

#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxpriv.h>
#include <afxdlgs.h>
#include <afxtempl.h>

#include <io.h>
#include <direct.h>
#include <afxsock.h>


#ifdef _SKINMODE_BLOCK
	#define COLOR_SCREEN_SETTING_BG      RGB(38,38,38)
#elif _SKINMOD_Orchid
	#define COLOR_SCREEN_SETTING_BG      RGB(158,99,255)
#endif





//20150922
#include "../TR/hrefer.h"
enum {
	SB_HELP = 0,
		SB_DOCKING,
		SB_TRANSPARENT,
		SB_POPUP,
		SB_MINIMIZE,
		SB_MAXIMIZE,
		SB_CLOSE,
		SB_SYSMENU,
};
#define	COLOR_BTN_FACE		RGB(237, 210, 169)//RGB(212, 212, 212)










//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__5F5EA5C7_CE0E_11D5_A8B3_444553540000__INCLUDED_ST_)
