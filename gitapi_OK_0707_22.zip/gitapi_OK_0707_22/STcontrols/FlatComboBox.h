#if !defined(AFX_FLATCOMBOBOX_H__FF3BE907_6FEB_408D_8FF1_746320E732A4__INCLUDED_)
#define AFX_FLATCOMBOBOX_H__FF3BE907_6FEB_408D_8FF1_746320E732A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FlatComboBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFlatComboBox window

class AFX_EXT_CLASS CFlatComboBox : public CComboBox
{
	// Operations
public:
	CFlatComboBox();
	virtual ~CFlatComboBox();
	
public:
	void SetBtnFATS(COLORREF clrBtnFace) { m_clrBtnFace = clrBtnFace; }
	void SetBkColor(COLORREF clrBkColor);
	void BlinkComboBox();
	
	int			m_nFontSize;
	int			m_nFontSizeList;
	int			m_nDropDownCount;
	int			m_nItemHeight;
	BOOL		m_bSihwang;
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlatComboBox)
public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	virtual BOOL OnChildNotify(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pLResult);
	//}}AFX_VIRTUAL
	
	// Implementation
	
protected:
	CFont		m_Font;			// EditBox���� Font�� ������ ���� 
	CFont		m_FontList;		// DropList���� Font�� ������ ���� 
	
	int			m_nOffset;		// offset used during paint.
	BOOL		m_bLBtnDown;	// TRUE if left mouse button is pressed
	BOOL		m_bPainted;		// used during paint operations
	BOOL		m_bHasFocus;	// TRUE if control has focus
	BOOL		m_bAutoComp;	// Used by Autocompleting.
	COLORREF	m_clrBtnHilite;	// set to the system color COLOR_BTNHILIGHT
	COLORREF	m_clrBtnShadow;	// set to the system color COLOR_BTNSHADOW
	COLORREF	m_clrBtnFace;	// set to the system color COLOR_BTNFACE
	COLORREF	m_clrBorder;
	
	CRect		m_rcBtn;
	COLORREF	m_clrBkColor;
	COLORREF	m_clrTextColor;
	CBrush		m_BkBrush;
	
	HCURSOR		m_HandCursor;
	HCURSOR		m_NormalCursor;
	
	int m_nTimeOut;
	BOOL m_bBlink;
	
	// enum used to determine the state the combo box should be
	//
	enum STATE { normal = 1, raised = 2, pressed = 3 };
	
	void DrawButton(CDC *pDC, BYTE State, CRect BorderRect);
	void DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight);
	
	// Generated message map functions
protected:
	DECLARE_DYNAMIC(CFlatComboBox)
		//{{AFX_MSG(CFlatComboBox)
		afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDropDown();
	afx_msg void OnCloseup();
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
    afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg LRESULT OnMouseLeave(WPARAM wparam, LPARAM lparam);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLATCOMBOBOX_H__FF3BE907_6FEB_408D_8FF1_746320E732A4__INCLUDED_)
