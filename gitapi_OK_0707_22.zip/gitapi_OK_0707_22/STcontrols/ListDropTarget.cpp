// TreeDropTarget.cpp : implementation file
// For OLE Drag and Drop between tree controls
// Designed and developed by Vinayak Tadas
// vinayakt@aditi.com
// 

#include "stdafx.h"
#include "ListDroptarget.h"
//#include "DragDropTreeCtrl.h"

#include "DNDListCtrl.h"

#define RECT_BORDER	10

// �̰� ���������� ����� ���ε� 
// �� �� ����� ����� �ʿ�� ����.
HWND CListDropTarget::m_shWndListCtrl = NULL;
short CListDropTarget::m_nSourceType; // 1�̸� list , 2�̸� Tree�� �Ѵ�.
HWND CListDropTarget::m_shWndListCtrlParent;

/////////////////////////////////////////////////////////////////////////////
// CListDropTarget

/********************************************************************
OnDragEnter()
	Called when the user drags the object in Tree control.
********************************************************************/
DROPEFFECT CListDropTarget::OnDragEnter( CWnd* pWnd, COleDataObject* pDataObject, 	DWORD dwKeyState, CPoint point )
{
	pWnd->SetFocus();

	// shift key�� ������ Move�̰� 
	// �ƴϸ� Copy�̴�.
	DROPEFFECT dropeffectRet = DROPEFFECT_COPY;
	if ( (dwKeyState & MK_SHIFT) == MK_SHIFT)
		dropeffectRet = DROPEFFECT_MOVE;

	// ���� Control�ʱ�ȭ.
	CDNDListCtrl* pDNDListCtrl = (CDNDListCtrl*)pWnd;
	pDNDListCtrl->m_nPrevDropIndex	= -1;
	pDNDListCtrl->m_uPrevDropState = NULL;

	m_DropEffect = dropeffectRet;
	return dropeffectRet;
}

/********************************************************************
OnDragOver()
	Called when the user drags the object over Tree control.
********************************************************************/
DROPEFFECT CListDropTarget::OnDragOver( CWnd* pWnd, COleDataObject* pDataObject, DWORD dwKeyState, CPoint point )
{
	
	DROPEFFECT dropeffectRet = DROPEFFECT_COPY;	
	if ( (dwKeyState & MK_SHIFT) == MK_SHIFT)
		dropeffectRet = DROPEFFECT_MOVE;

	m_pDestListCtrl = (CWnd*)pWnd;

	// Control�� ������ Update�Ѵ�.
	CDNDListCtrl* pDNDListCtrl = (CDNDListCtrl*)pWnd;
	pDNDListCtrl->UpdateSelection( pDNDListCtrl->HitTest( point ) );


	// Scroll Tree control depending on mouse position
	CRect rectClient;
	pWnd->GetClientRect(&rectClient);
	pWnd->ClientToScreen(rectClient);
	pWnd->ClientToScreen(&point);
	int nScrollDir = -1;
	if ( point.y >= rectClient.bottom - RECT_BORDER)
		nScrollDir = SB_LINEDOWN;
	else
	if ( (point.y <= rectClient.top + RECT_BORDER) )
		nScrollDir = SB_LINEUP;

	
	if ( nScrollDir != -1 ) 
	{
		int nScrollPos = pWnd->GetScrollPos(SB_VERT);
		WPARAM wParam = MAKELONG(nScrollDir, nScrollPos);
		pWnd->SendMessage(WM_VSCROLL, wParam);
	}
	
	nScrollDir = -1;
	if ( point.x <= rectClient.left + RECT_BORDER )
		nScrollDir = SB_LINELEFT;
	else
	if ( point.x >= rectClient.right - RECT_BORDER)
		nScrollDir = SB_LINERIGHT;
	
	if ( nScrollDir != -1 ) 
	{
		int nScrollPos = pWnd->GetScrollPos(SB_VERT);
		WPARAM wParam = MAKELONG(nScrollDir, nScrollPos);
		pWnd->SendMessage(WM_HSCROLL, wParam);
	}

	
	m_DropEffect = dropeffectRet;
	return dropeffectRet;
	
	
}

/********************************************************************
OnDragLeave()
	Called when the user drags the object out of Tree control.
********************************************************************/
void CListDropTarget::OnDragLeave( CWnd* pWnd )
{
	// Remove Highlighting 
	// �����̸鼭 ���õ� Item�� ó�������� ���� �� �� ����.
	m_pDestListCtrl = pWnd;

	CDNDListCtrl* pDNDListCtrl = (CDNDListCtrl*)pWnd;
	pDNDListCtrl->RestorePrevDropItemState();
	pDNDListCtrl->m_nPrevDropIndex	= -1;
	pDNDListCtrl->m_uPrevDropState = NULL;
	
}

/********************************************************************
OnDrop()ss	q
	Called when the user drops the object in the  Tree control.
********************************************************************/
BOOL CListDropTarget::OnDrop(CWnd* pWnd, COleDataObject* pDataObject,
		DROPEFFECT dropEffect, CPoint point)
{
	//Get the selected item from Source and destination Tree controls 
	m_pSourceListCtrl = (CWnd* )CWnd::FromHandlePermanent(m_shWndListCtrl);

	// Dialog ���� Drag & Drop�� �Ͼ� ���ٴ� ���� �˷� �ش�.
	// ��� ó���� Dialog���� �ϵ��� �Ѵ�.
	DROP_INFO drop_info;
	drop_info.m_pSource		= m_pSourceListCtrl;
	drop_info.m_pDest		= m_pDestListCtrl;
	drop_info.m_DropEffect	= m_DropEffect;
	drop_info.m_nSourceType = m_nSourceType;

	::SendMessage( m_shWndListCtrlParent, DNDLIST_DROP,  (UINT)&drop_info, 0  );
	
	//Remove highlighting
	//m_pDestTreeCtrl->SendMessage(TVM_SELECTITEM, TVGN_DROPHILITE,0);

	return TRUE;
	
	
}

