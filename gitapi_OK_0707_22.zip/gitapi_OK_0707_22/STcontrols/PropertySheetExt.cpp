// PropertySheetEx.cpp : implementation file
// 2001.9.cyber.sukim

#include "stdafx.h"
#include "PropertySheetExt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	WM_TABCHANGE		(WM_USER + 101)

/////////////////////////////////////////////////////////////////////////////
// CPropertySheetEx

IMPLEMENT_DYNAMIC(CPropertySheetExt, CPropertySheet)

CPropertySheetExt::CPropertySheetExt()
{
	m_crBkgColour	= RGB(214,220,218);
	m_crTabSelected	= RGB(29,62,37);

	m_nCurrentTab = 0;
}

CPropertySheetExt::CPropertySheetExt(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	m_crBkgColour	= RGB(214,220,218);
}

CPropertySheetExt::~CPropertySheetExt()
{
}

void CPropertySheetExt::DoDataExchange(CDataExchange* pDX)
{
	CPropertySheet::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyPageExt)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPropertySheetExt, CPropertySheet)
	//{{AFX_MSG_MAP(CPropertySheetExt)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
//	ON_MESSAGE(WM_TABCHANGE, OnSelChange)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CPropertySheetExt operations

void CPropertySheetExt::SetColours(COLORREF BkgColour)
{
	m_crBkgColour = BkgColour;
	Invalidate();
}

COLORREF CPropertySheetExt::GetColours()
{
	return m_crBkgColour;
}

/////////////////////////////////////////////////////////////////////////////
// CPropertySheetExt message handlers

BOOL CPropertySheetExt::OnInitDialog() 
{
	CPropertySheet::OnInitDialog();

	if(GetTabControl())
		m_TabCtrlExt.SubclassWindow(GetTabControl()->m_hWnd);
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropertySheetExt::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	OnEraseBkgnd(&dc);
}

BOOL CPropertySheetExt::OnEraseBkgnd(CDC* pDC)
{
	CRect rcItem;

	GetClientRect(&rcItem);
	pDC->FillSolidRect(&rcItem, m_crBkgColour);
	return 0;
}


void CPropertySheetExt::SetTabColors(COLORREF selected)
{
	m_crTabSelected = selected;

	GetTabControl()->Invalidate();
}

COLORREF CPropertySheetExt::GetTabColor(int index)
{
	COLORREF cr;

	switch (index)
	{
	case TC_SELECT:
		cr = m_crTabSelected;
		break;
	}

	return cr;
}
