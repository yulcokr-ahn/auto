#if !defined(AFX_HOTEDIT_H__7661962F_B4BA_11D3_A635_00105A7C2F91__INCLUDED_)
#define AFX_HOTEDIT_H__7661962F_B4BA_11D3_A635_00105A7C2F91__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HotEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHotEdit window

class AFX_EXT_CLASS CHotEdit : public CEdit
{
// Construction
public:
	CHotEdit();

// Attributes
public:
	HBRUSH      m_hbr1;
	HBRUSH      m_hbr2;
	CFont	m_editFont, *m_pOldFont;	// Font�� �����Ѵ�.
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHotEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHotEdit();

	// Generated message map functions
protected:
	virtual void DrawBorder(bool fHot = true);
	COLORREF m_clr3DHilight;
	COLORREF m_clr3DLight;
	COLORREF m_clr3DDkShadow;
	COLORREF m_clr3DShadow;
	COLORREF m_clr3DFATS;
	bool m_fTimerSet;
	bool m_fGotFocus;
	//{{AFX_MSG(CHotEdit)
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnNcMouseMove(UINT nHitTest, CPoint point);
	afx_msg void OnSysColorChange();
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSetfocus();
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HOTEDIT_H__7661962F_B4BA_11D3_A635_00105A7C2F91__INCLUDED_ST_)
