#if !defined(AFX_KINDCOMBOEX_H__38FFD64D_D887_4859_B3CD_E08419A9577E__INCLUDED_)
#define AFX_KINDCOMBOEX_H__38FFD64D_D887_4859_B3CD_E08419A9577E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KindComboEx.h : header file
//

#include <afxtempl.h>	// Used for CArray
/////////////////////////////////////////////////////////////////////////////
// CKindComboEx window

class AFX_EXT_CLASS CKindComboEx : public CComboBox
{
// Construction
public:
	CKindComboEx();
	void SetPenSize(BOOL bBsn = FALSE);
// Attributes
public:
	int		m_iCurSel;
	int		m_nPenSize;			//���ؼ��� ��� ������ �ΰ��� Data�� ������ 
	// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKindComboEx)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:	
	virtual ~CKindComboEx();
	CArray<int, int> pens;
	CArray<CPoint, CPoint> points;

	int			m_nOffset;		// offset used during paint.
	BOOL		m_bLBtnDown;	// TRUE if left mouse button is pressed
	COLORREF	m_clrBtnHilite;	// set to the system color COLOR_BTNHILIGHT
	COLORREF	m_clrBtnShadow;	// set to the system color COLOR_BTNSHADOW
	COLORREF	m_clrBtnFace;	// set to the system color COLOR_BTNFACE
	
	enum STATE { normal = 1, raised = 2, pressed = 3 };

	void DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight);

	// Generated message map functions
protected:
	//{{AFX_MSG(CKindComboEx)	
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSelchange();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KINDCOMBOEX_H__38FFD64D_D887_4859_B3CD_E08419A9577E__INCLUDED_)
