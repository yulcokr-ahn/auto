#if !defined(AFX_SKINEDMDICHILDWND_H__2FB529D5_F213_4451_B593_982D12BC6D7A__INCLUDED_)
#define AFX_SKINEDMDICHILDWND_H__2FB529D5_F213_4451_B593_982D12BC6D7A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SkinedMDIChildWnd.h : header file
//
#include "SkinedFrameWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CSkinedMDIChildWnd frame

#ifdef _AFXEXT
	#ifndef _EXPORTCONTROLS
		#undef AFX_EXT_CLASS
		#undef AFX_EXT_API
		#undef AFX_EXT_DATA
		#define AFX_EXT_CLASS AFX_CLASS_IMPORT
		#define AFX_EXT_API AFX_API_IMPORT
		#define AFX_EXT_DATA AFX_DATA_IMPORT
	#endif
#endif

#define WM_ADDTASK			(WM_USER + 1901)
#define WM_XPX_ACTIVETASK		(WM_USER + 1902)
#define WM_INXPX_ACTIVETASK		(WM_USER + 1903)
#define WM_CHANGETASKTITLE	(WM_USER + 1904)
#define WM_DELETETASK		(WM_USER + 1905)

#define HT_EX_TRANSPARENT	HTHELP + 10
#define HT_EX_DOCKING		HTHELP + 11
#define HT_EX_POPUP			HTHELP + 12

class AFX_EXT_CLASS CSkinedMDIChildWnd : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CSkinedMDIChildWnd)
protected:
	CSkinedMDIChildWnd();           // protected constructor used by dynamic creation

// Attributes
public:
	CSkinedFrameWnd*	m_pPopWnd;
	// Dialog ó��
	CWnd*	m_pChildDlg;
	BOOL	m_bEnableResize;
	BOOL	m_bXPX_ACTIVE;
	BOOL	m_bInit;

// Operations
public:
	void LoadBitmaps();
	void SetDialog(CWnd* pDlg, CString strTitle, BOOL bResize = FALSE, BOOL bPopUp = FALSE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSkinedMDIChildWnd)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void ActivateFrame(int nCmdShow = -1);
	virtual void SetWindowText(LPCTSTR lpszString);

	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSkinedMDIChildWnd();

	// Generated message map functions
	//{{AFX_MSG(CSkinedMDIChildWnd)
	afx_msg void OnNcPaint();
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg BOOL OnNcActivate(BOOL bXPX_ACTIVE);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	//afx_msg void OnSetText(WPARAM wParam, LPCTSTR lpszString);
	afx_msg void OnNcMouseMove(UINT nHitTest, CPoint point);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMDIActivate(BOOL bActivate, CWnd* pActivateWnd, CWnd* pDeactivateWnd);
	afx_msg void OnChildActivate();
	afx_msg void OnWindowPosChanged(WINDOWPOS* lpwndpos);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void CalculateSize();
	void PaintFrameBorder();

	void UpdateButtons(UINT nHitTest);
	void CalcButtonsRect();
	void PaintButtons(CDC *pDC, int nHitTest);
	void PaintText(CDC *pDC);
	void GetFrameSize(CSize &szFrame);
	void GetCaptionRect(CRect &rcCaption);
	void PaintIcon(CDC *pDC);
	void PaintBackground(CDC *pDC);
	void PopWndPricessing(BOOL bTransparent, BOOL bCenter = FALSE);

	BOOL			m_bEnableTrans;	// ���� ������ ����
	BOOL			m_bEnablePopup;	// Popup window ����
	BOOL			m_bEnableDock;	// Docking Window ����

	BOOL			m_bTransparent;
	int				m_nTPRatio;

	CBitmap			m_bmCaptionOn;
	CBitmap			m_bmCaptionOff;

	CBitmap			m_bmButton[7][2];
	CRect			m_rcButton[7];
	CRect			m_rcSysMenu;
	CRect			m_rcCaption;
	CRect			m_rcText;

	BOOL			m_bLButtonDown;
	UINT			m_nHitTest;

	HICON			m_hIcon;
};


/////////////////////////////////////////////////////////////////////////////

#ifdef _AFXEXT
	#ifndef _EXPORTCONTROLS
		#undef AFX_EXT_CLASS
		#undef AFX_EXT_API
		#undef AFX_EXT_DATA
		#define AFX_EXT_CLASS AFX_CLASS_EXPORT
		#define AFX_EXT_API AFX_API_EXPORT
		#define AFX_EXT_DATA AFX_DATA_EXPORT
	#endif
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SKINEDMDICHILDWND_H__2FB529D5_F213_4451_B593_982D12BC6D7A__INCLUDED_)
