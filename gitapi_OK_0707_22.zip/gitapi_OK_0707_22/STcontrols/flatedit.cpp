// FlatEdit.cpp: implementation of the CAceDlgButton class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Flatedit.h"

//--------------------------------------
CFlatEditCtl::CFlatEditCtl()
{
}

CFlatEditCtl::~CFlatEditCtl()
{
}
BEGIN_MESSAGE_MAP(CFlatEditCtl, CEdit)
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
END_MESSAGE_MAP()

void CFlatEditCtl::OnChange()
{
	GetParent()->SendMessage(UM_EDITCHANGE,0,0);
}

////////////////////////////////////////////////////

CFlatEdit::CFlatEdit()
{
	m_lBorder = COLOR_BORDER;//RGB( 82,113,123);
	m_lBack   = RGB(255,255,255);
	m_bEnable = TRUE;

	m_Rect.SetRectEmpty();
}

CFlatEdit::~CFlatEdit()
{
	if (m_Font.GetSafeHandle())
		m_Font.DeleteObject();
}

BEGIN_MESSAGE_MAP(CFlatEdit, CWnd)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_NCCALCSIZE()
	ON_WM_NCPAINT()
END_MESSAGE_MAP()

void CFlatEdit::PreSubclassWindow()
{
	CWnd::PreSubclassWindow();

	CRect	rcWnd;
	DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL;

	GetClientRect(rcWnd);

	//rcWnd.DeflateRect(1,1);
	int xpos = 2;
	int ypos = (rcWnd.Height()-12) / 2;

	CRect	rcEdit(xpos,ypos,rcWnd.Width()-1, ypos+12);
	m_Edit.Create(dwStyle, rcEdit, this, 1000);

	m_Font.CreatePointFont(90, "����ü");
	m_Edit.SetFont(&m_Font);

	//ModifyStyleEx(WS_EX_STATICEDGE, 0);
}

void CFlatEdit::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS *lpncsp)
{
	InflateRect(&lpncsp->rgrc[0], 1, 1);

	CWnd::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void CFlatEdit::OnNcPaint()
{
	CWindowDC	dc(this);

	CRect		rcEdit;

	GetWindowRect(rcEdit);
	ScreenToClient(rcEdit);
	rcEdit.InflateRect(-1, -1, 1, 1);
	dc.Draw3dRect(rcEdit, m_lBorder, m_lBorder);
	ReleaseDC(&dc);
}

void CFlatEdit::OnPaint()
{
	CPaintDC	dc(this);

	CPen	pen, *tmpPen = NULL;
	CBrush	brush, *tmpBrush = NULL;

	pen.CreatePen(PS_SOLID, 1, m_lBorder);
	tmpPen = dc.SelectObject(&pen);

	brush.CreateSolidBrush((m_bEnable)?m_lBack: GetSysColor(COLOR_BTNFACE));
	tmpBrush = dc.SelectObject(&brush);

	CRect	rcWnd;

	GetWindowRect (rcWnd);
	ScreenToClient(rcWnd);

	dc.Rectangle(rcWnd);

	dc.SelectObject(tmpPen);
	dc.SelectObject(tmpBrush);

	pen.DeleteObject();
	brush.DeleteObject();
}

void CFlatEdit::OnSetFocus(CWnd *pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	m_Edit.SetFocus();
}

LRESULT CFlatEdit::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case UM_EDITCHANGE:
		GetParent()->SendMessage(message, wParam, (LPARAM)GetDlgCtrlID());
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}