// CaptureWndToFile.h: interface for the CCaptureWndToFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CAPTUREWNDTOFILE_H__497A0681_0C27_11D6_A8B1_444553540000__INCLUDED_)
#define AFX_CAPTUREWNDTOFILE_H__497A0681_0C27_11D6_A8B1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef short int       code_int;   
typedef long int        count_int;

typedef struct tagCxImageInfo {
	DWORD	dwEffWidth;			//DWORD aligned scan line width
	BYTE*	pImage;				//THE IMAGE BITS
	void*	pGhost;				//if this is a ghost, pGhost point to the body
	DWORD	dwType;				//original image format
	BYTE	bColorType;			//used for PNG, MNG
	char	szLastError[256];	//debugging
	long	nProgress;			//monitor
	long	nEscape;			//escape
	long	nBkgndIndex;		//used for GIF, PNG, MNG
	RGBQUAD nBkgndColor;		//used for RGB transparency
	BYTE	nQuality;			//used for JPEG
	long	nFrame;				//used for TIF, GIF, MNG : actual frame
	long	nNumFrames;			//used for TIF, GIF, MNG : total number of frames
	DWORD	dwFrameDelay;		//used for GIF, MNG
	long	xDPI;				//horizontal resolution
	long	yDPI;				//vertical resolution
} CXIMAGEINFO;

// needed for png & gif
struct rgb_color_struct { BYTE r,g,b; };
// needed for png & mng
#define COLORTYPE_PALETTE	1
#define COLORTYPE_COLOR		2
#define COLORTYPE_ALPHA		4

#define TRANSPARENCY_CODE 0xF9

#define	IMAGE_BMP			0
#define	IMAGE_GIF			1

class AFX_EXT_CLASS CCaptureWndToFile  
{
public:
	CCaptureWndToFile();
	virtual ~CCaptureWndToFile();

public:
	void*				m_hDib; //contains the header, the palette, the pixels
    BITMAPINFOHEADER    m_head; //stadnard header
	CXIMAGEINFO			m_info; //extended information

	int          Width, Height;
	int             curx, cury;
	int           BitsPerPixel;
	long             CountDown;
	unsigned long    cur_accum;
	int              cur_bits;
	unsigned char    *buffer;

	void Startup(DWORD imagetype);
	BOOL Capture(HWND hWnd);//, int nMode, CString strFileName);
	void CreateFromHBITMAP(HBITMAP hbmp);
	long GetSize();
	RGBQUAD* GetPalette() const;
	DWORD GetPaletteSize();
	BYTE* GetBits();
	void* Create(DWORD dwWidth, DWORD dwHeight, WORD wBpp, DWORD imagetype = 0);
	bool SaveFile(LPCSTR filename, DWORD imagetype);
	bool EncodeBMP(FILE * hFile);
	bool EncodeGIF(FILE * fp);
	void Putword(int w, FILE *fp );
	void BumpPixel();
	int GIFNextPixel();
	BYTE GetPixelIndex(long x,long y);
	void compress(int init_bits, FILE* outfile);
	void output(code_int  code);
	void char_init();
	void char_out(int c);
	void flush_char();
	void cl_block();
	void cl_hash(register count_int hsize);
};

#endif // !defined(AFX_CAPTUREWNDTOFILE_H__497A0681_0C27_11D6_A8B1_444553540000__INCLUDED_)
