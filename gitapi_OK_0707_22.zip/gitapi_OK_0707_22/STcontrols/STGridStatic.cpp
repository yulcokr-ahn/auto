// STGridStatic.cpp : implementation file
//

#include "stdafx.h"

#include "STGridStatic.h"
#include "Resource.h"
#include "../Include/hrefer.h"
#include "MemDC.h"
//20150708
//#include "../CommUDP_ORDER/CommUDP_ORDERAPI.h"
//20150708
//extern CALLLEE_API Config_DMA * GetConfig_DMAPtr();
//#include "../Order_KRX/KRX_nfsOrder_V20.h"

#define WM_GROUP_COLOR_UP   		    (WM_USER+420)  //20120905
#define WM_GROUP_COLOR_DN   		    (WM_USER+421)  //20120905


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSTGridStatic
/*
CSTGridStatic::CSTGridStatic()
{
}

CSTGridStatic::~CSTGridStatic()
{
}


BEGIN_MESSAGE_MAP(CSTGridStatic, CStatic)
	//{{AFX_MSG_MAP(CSTGridStatic)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
*/
/////////////////////////////////////////////////////////////////////////////
// CSTGridStatic message handlers

#define POS_VIEW_CNT 26 
#define SELL_ORDER		'S'  //�ŵ����� 
#define BUY_ORDER		'B'  //�ż����� 

#define ODER_BUY  2
#define ODER_SELL 3

#define INDEX_JANGO_MODE  100 // �ܰ�
#define ORDER_NO_MODE     110 // �ֹ���ȣ 
#define ORDER_PRICE_MODE  120 // �ֹ��� 
#define MECHE_INDEX_MODE  130 // ��ü��
#define PROFIT_PERCOST_MODE  140 // ���� 

#define SPACE_MODE   99 //GRIDSTATIC


//LogicManager\ CommOrder_ManagerAPI.h
///////////////////////////////////////////
/////////[ XPX ]////////////////////////////
///////////////////////////////////////////
#define XPX_ACTIVE_MODE  10 //��   ������
#define XPX_HEADGE_MODE  20 //���� ������
#define XPX_GAMMA_MODE   30 //���� ������
///////////////////////////////////////////
/////////[ XCX ]////////////////////////////
///////////////////////////////////////////
#define XCX_ACTIVE_MODE  11 //��   ������
#define XCX_HEADGE_MODE  21 //���� ������
#define XCX_GAMMA_MODE   31 //���� ������

///////////////////////////////////////////
/////////[ ZPZ ]////////////////////////////
///////////////////////////////////////////
#define ZPZ_ACTIVE_MODE  12 //��   ������
#define ZPZ_HEADGE_MODE  22 //���� ������
#define ZPZ_GAMMA_MODE   32 //���� ������

///////////////////////////////////////////
/////////[ ZCZ ]////////////////////////////
///////////////////////////////////////////
#define ZCZ_ACTIVE_MODE  41 //��   ������
#define ZCZ_HEADGE_MODE  41 //���� ������
#define ZCZ_GAMMA_MODE   41 //���� ������



//LogicManager\ CommOrder_ManagerAPI.h
///////////////////////////////////////////
/////////[ XPX ]////////////////////////////
///////////////////////////////////////////
#define SE_XPX_ACTIVE_NEW_ORDER		    11	 //�ű�
#define SE_XPX_ACTIVE_PAYOFF_ORDER		12	 //����û�� 
#define SE_XPX_HEADGE_NEW_ORDER		    21	 //�ű�
#define SE_XPX_HEADGE_PAYOFF_ORDER		22	 //����û�� 
#define SE_XPX_GAMMA_NEW_ORDER		    31	 //�ű�
#define SE_XPX_GAMMA_PAYOFF_ORDER		32	 //����û�� 

///////////////////////////////////////////
/////////[ XCX ]////////////////////////////
///////////////////////////////////////////
#define SE_XCX_ACTIVE_NEW_ORDER		    111	 //�ű�
#define SE_XCX_ACTIVE_PAYOFF_ORDER		112	 //����û�� 
#define SE_XCX_HEADGE_NEW_ORDER		    121	 //�ű�
#define SE_XCX_HEADGE_PAYOFF_ORDER		122	 //����û�� 
#define SE_XCX_GAMMA_NEW_ORDER		    131	 //�ű�
#define SE_XCX_GAMMA_PAYOFF_ORDER		132	 //����û�� 

///////////////////////////////////////////
/////////[ ZPZ ]////////////////////////////
///////////////////////////////////////////
#define SE_ZPZ_ACTIVE_NEW_ORDER		    211	 //�ű�
#define SE_ZPZ_ACTIVE_PAYOFF_ORDER		212	 //����û�� 
#define SE_ZPZ_HEADGE_NEW_ORDER		    221	 //�ű�
#define SE_ZPZ_HEADGE_PAYOFF_ORDER		222	 //����û�� 
#define SE_ZPZ_GAMMA_NEW_ORDER		    231	 //�ű�
#define SE_ZPZ_GAMMA_PAYOFF_ORDER		232	 //����û�� 


///////////////////////////////////////////
/////////[ ZCZ ]////////////////////////////
///////////////////////////////////////////
#define SE_ZCZ_ACTIVE_NEW_ORDER		    311	 //�ű�
#define SE_ZCZ_ACTIVE_PAYOFF_ORDER		312	 //����û�� 
#define SE_ZCZ_HEADGE_NEW_ORDER		    321	 //�ű�
#define SE_ZCZ_HEADGE_PAYOFF_ORDER		322	 //����û�� 
#define SE_ZCZ_GAMMA_NEW_ORDER		    331	 //�ű�
#define SE_ZCZ_GAMMA_PAYOFF_ORDER		332	 //����û�� 



#define INDEX_MODE 1
#define TIME_MODE 2
#define PRICE_MODE 3
#define POSTION_COLOR_GROUP 4
#define SUB_PRICE_MODE 5 //���� ���� 

/////////////////////////////////////////////////////////////////////////////
// CSTGridStatic





CSTGridStatic::CSTGridStatic()
{
	m_nAlign = DT_CENTER;
	m_crTextColor = RGB(0,0,0);
	m_crBackground = COLOR_TAB_BKGND;//RGB(215, 225, 215);
	m_bIsSymbol = FALSE;
	m_bVCenter = TRUE;
	m_nFontType = 0;
	m_bBorder = TRUE;
	m_nFontSize = 12;

	m_pSymbol = NULL;
	m_BLOCK_Array=0; //�������� ����� LINE�� �׸���. 20140606
	m_BLOCK_OnMODE=0; //�������� On ����� LINE�� �׸���. 20140606
	m_crBLOCK_ON_Background = COLOR_TAB_BKGND;
	m_pTextArray=NULL;
	m_pPOS_VIEW=NULL;


	m_COLOR_Array =0;//�������� ����� LINE�� �׸���. 20140606
	m_pGroupColor= NULL;
	m_pParent = NULL;
	nSize_GROUP_COLOR =0;
	nSize_POSTION = 0;


	m_nOrderType=0;
	m_nIndexOrderType=0;

	m_pROW_MAP= NULL;
}

CSTGridStatic::~CSTGridStatic()
{
	if (m_pSymbol)
	{
		m_pSymbol->DeleteObject();
		delete m_pSymbol;
	}
}


BEGIN_MESSAGE_MAP(CSTGridStatic, CStatic)
	//{{AFX_MSG_MAP(CSTGridStatic)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_CHAR()







	ON_WM_LBUTTONDOWN()

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSTGridStatic message handlers


void CSTGridStatic::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if(m_BLOCK_Array || m_COLOR_Array) //�������� ����� LINE�� �׸���. 20140606
	{
		if(m_pGroupColor) 
		{
			CRect rcItem, rcSymbol;
			GetWindowRect(&rcItem);

			int nIndex=0;
			int nTerm= rcItem.Width()/m_COLOR_Array;
			int nPoint_index = point.x / nTerm;

			CString strLog("");
			if(nPoint_index < nSize_GROUP_COLOR)
			{
				if(m_pParent)
				{
					if(m_BLOCK_OnMODE==XPX_HEADGE_MODE) m_pParent->SendMessage(WM_GROUP_COLOR_UP, (WPARAM) &m_pGroupColor[nPoint_index], (LPARAM) nPoint_index);
					if(m_BLOCK_OnMODE==XPX_GAMMA_MODE ) m_pParent->SendMessage(WM_GROUP_COLOR_DN, (WPARAM) &m_pGroupColor[nPoint_index], (LPARAM) nPoint_index);

					if(m_BLOCK_OnMODE==XCX_HEADGE_MODE) m_pParent->SendMessage(WM_GROUP_COLOR_UP, (WPARAM) &m_pGroupColor[nPoint_index], (LPARAM) nPoint_index);
					if(m_BLOCK_OnMODE==XCX_GAMMA_MODE ) m_pParent->SendMessage(WM_GROUP_COLOR_DN, (WPARAM) &m_pGroupColor[nPoint_index], (LPARAM) nPoint_index);
					
					if(m_BLOCK_OnMODE==ZPZ_HEADGE_MODE) m_pParent->SendMessage(WM_GROUP_COLOR_UP, (WPARAM) &m_pGroupColor[nPoint_index], (LPARAM) nPoint_index);
					if(m_BLOCK_OnMODE==ZPZ_GAMMA_MODE ) m_pParent->SendMessage(WM_GROUP_COLOR_DN, (WPARAM) &m_pGroupColor[nPoint_index], (LPARAM) nPoint_index);

					if(m_BLOCK_OnMODE==ZCZ_HEADGE_MODE) m_pParent->SendMessage(WM_GROUP_COLOR_UP, (WPARAM) &m_pGroupColor[nPoint_index], (LPARAM) nPoint_index);
					if(m_BLOCK_OnMODE==ZCZ_GAMMA_MODE ) m_pParent->SendMessage(WM_GROUP_COLOR_DN, (WPARAM) &m_pGroupColor[nPoint_index], (LPARAM) nPoint_index);


				}
			}
			else
			{			
			}
		}
	}



	CStatic::OnLButtonDown(nFlags, point);
}










void CSTGridStatic::OnPaint() 
{
/*
	CDC *pDCReceiv = GetDC();
	if(pDCReceiv)
	{
		CMemDC MemDC(pDCReceiv);	
		MemDC.SetBkMode(TRANSPARENT);
		DrawBorder(&MemDC);
	}
	ReleaseDC(pDCReceiv);
*/


/*
	CPaintDC dc(this); // device context for painting
		CMemDC MemDC(&dc);	
		MemDC.SetBkMode(TRANSPARENT);
		DrawBorder(&MemDC);
*/

	CPaintDC dc(this); // device context for painting
	DrawBorder(&dc);

	if(m_strText.GetLength() == 0)
	CStatic::GetWindowText(m_strText);
}



#ifdef _SKINMODE_BLOCK
	#define COLOR_CONTROL_STATIC_LINE    RGB(50,50,55)
#elif _SKINMOD_Orchid
	#define COLOR_CONTROL_STATIC_LINE    RGB(71,6,125) //������
#endif


void CSTGridStatic::SetTextArray(CStringArray &strTextArray, int *ArrayOn)
{

		
}
  
void CSTGridStatic::SetROW_KEPLER_ITEM(ROW_KEPLER_ITEM *TmpKepler, int nSize)
{
	m_pROW_MAP = TmpKepler;
	nROWSize=nSize;


//	SPACE_MODE
	int CellScaleY = 13;
	int CsY = 0;
 	int ch_Selltop    = 0; 
	int	ch_Sellbottom = 0;
	int nTerm =0;

//===================
	for(int nRow=0; nRow< nROWSize; nRow++)
	{
		if(m_pROW_MAP[nRow].m_BLOCK_OnMODE==SPACE_MODE)
		{
			if(nRow ==0)
			{
				m_pROW_MAP[nRow].top = 0;
				m_pROW_MAP[nRow].bottom = m_pROW_MAP[nRow].high;
			}
			else
			{
				m_pROW_MAP[nRow].top = m_pROW_MAP[nRow-1].bottom;
				m_pROW_MAP[nRow].bottom = m_pROW_MAP[nRow].top+m_pROW_MAP[nRow].high;
			}
		}
		else
		{
			if(nRow ==0)
			{
				m_pROW_MAP[nRow].top = 0;
				m_pROW_MAP[nRow].bottom = CellScaleY;
			}
			else
			{
				m_pROW_MAP[nRow].top = m_pROW_MAP[nRow-1].bottom;
				m_pROW_MAP[nRow].bottom = m_pROW_MAP[nRow].top+CellScaleY;
			}
		}
	}
}

                              
							//XPX_HEADGE/GAMMA     //ODER_BUY
void CSTGridStatic::SetBLOCKArray(int OnMODE,int nOrderType,int nIndexOrderType,int nArray,COLORREF m_crBlock) //�������� ����� LINE�� �׸���. 20140606
{
	m_pTextArray=NULL;
	m_ArrayOn=NULL;
	m_BLOCK_OnMODE=	OnMODE; //XPX_HEADGE/GAMMA
	m_BLOCK_Array =  nArray;
	m_crBLOCK_ON_Background = m_crBlock;
	m_nOrderType=nOrderType;
	m_nIndexOrderType=nIndexOrderType; //INDEX_JANGO_MODE;
}
void CSTGridStatic::Line(CDC* pDC,int xLeft, int yTop,int xRight, int yBottom, unsigned long c)
{
	if(pDC->GetSafeHdc() == NULL) return;
	pDC->MoveTo(xLeft, yTop);     pDC->LineTo(xRight,yBottom);

}
void CSTGridStatic::Line_BF(CDC* pDC,int xLeft, int yTop,int xRight, int yBottom, unsigned long c)
{
	if(pDC->GetSafeHdc() == NULL) return;
	CRect blockRect;
	blockRect.left =xLeft;
	blockRect.top =yTop;
	blockRect.right =xRight;
	blockRect.bottom =yBottom;
	CBrush brush(c);
	CBrush* pOldBrush=pDC->SelectObject(&brush);
	pDC->FillRect(blockRect,&brush);
	pDC->SelectObject(pOldBrush);
	brush.DeleteObject();
}



void CSTGridStatic::SetPOS_VIEW(POSTION_AESA *TmpKepler, int nSize,int iPostionType_P)
{
    m_pPOS_VIEW =TmpKepler;
	m_DS_iPostionType_P=iPostionType_P;
	nSize_POSTION = nSize;



	
	


	CDC *pDCReceiv = GetDC();
		if(pDCReceiv)
		{
			CMemDC MemDC(pDCReceiv);	
			MemDC.SetBkMode(TRANSPARENT);
	DrawBorder(&MemDC);
		}

	ReleaseDC(pDCReceiv);
}


void CSTGridStatic::SetCOLORArray(int nArray, int nMODE) //�������� ����� LINE�� �׸���. 20140606
{
	m_COLOR_Array =  nArray;
	m_BLOCK_OnMODE= nMODE;
}

void CSTGridStatic::SetGROUP_COLOR(CWnd *pParent, POSTION_GROUP_COLOR *TmpGROUP_COLOR, int nSize) //���콺 ��Į Ŭ���� �θ���� �޼����� color index ���۱�� 
{
	m_pParent = pParent;
    m_pGroupColor =TmpGROUP_COLOR;
	nSize_GROUP_COLOR = nSize;


	CDC *pDCReceiv = GetDC();
		if(pDCReceiv)
		{
			CMemDC MemDC(pDCReceiv);	
			MemDC.SetBkMode(TRANSPARENT);
	DrawBorder(&MemDC);
		}

	ReleaseDC(pDCReceiv);
}




void CSTGridStatic::DrawBorder(CDC* pDC)
{
	CRect rcItem, rcSymbol;

	CFont textfont;
	if(!m_nFontType)
		textfont.CreateFont(m_nFontSize, 0, 0, 0, FALSE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, 
							CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH|FF_DONTCARE, "����ü");
	else
		textfont.CreateFont(m_nFontSize, 0, 0, 0, FW_EXTRABOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, 
							CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH|FF_DONTCARE, "����ü");
	
	CFont* old_font = pDC->SelectObject(&textfont);

	GetWindowRect(&rcItem);
	ScreenToClient(&rcItem);

	CPen pen, *pOldPen;

	if(m_bBorder)
		pen.CreatePen(PS_SOLID, 1, COLOR_CONTROL_STATIC_LINE); 
	else
	{
		pen.CreatePen(PS_SOLID, 1, m_crBackground);
	}
	
	pOldPen = (CPen *)pDC->SelectObject(&pen);
	CBrush brush, *pOldBrush;


	brush.CreateSolidBrush(m_crBackground);
	pOldBrush = (CBrush *)pDC->SelectObject(&brush);
	pDC->Rectangle(&rcItem);


 	int ch_Selltop    = 0; 
	int	ch_Sellbottom = 0;
	int nTerm =0;

	if(m_BLOCK_Array ) //�������� ����� LINE�� �׸���. 20140606
	{
		int nIndex=0;
		nTerm= rcItem.Width()/m_BLOCK_Array;
		for(nIndex = 1; nIndex < m_BLOCK_Array; nIndex++ )																										
		{
			Line(pDC,nIndex*nTerm, rcItem.top   ,nIndex*nTerm, rcItem.bottom, COLOR_CONTROL_STATIC_LINE);			//Y
		}
	}

//===================
	for(int nRow=0; nRow< nROWSize; nRow++)
	{
		ch_Selltop    = m_pROW_MAP[nRow].top; 
		ch_Sellbottom = m_pROW_MAP[nRow].bottom;
		if(nRow != 0) 
		{
			Line(pDC,rcItem.left, ch_Selltop   ,rcItem.right, ch_Selltop, COLOR_CONTROL_STATIC_LINE);			//Y
		}

		if(m_pROW_MAP[nRow].m_BLOCK_OnMODE==SPACE_MODE)
		{
			Line_BF(pDC,rcItem.left, ch_Selltop+1   ,rcItem.right, ch_Sellbottom, m_pROW_MAP[nRow].m_crBlock );
			continue;
		}

		if(m_BLOCK_Array || m_COLOR_Array) //�������� ����� LINE�� �׸���. 20140606
		{

			if(m_pGroupColor) 
			{

				int nIndex=0;
				int nTerm= rcItem.Width()/m_COLOR_Array;
				for(nIndex = 1; nIndex < m_COLOR_Array; nIndex++ )																										
				{
					Line(pDC,nIndex*nTerm, ch_Selltop   ,nIndex*nTerm, ch_Sellbottom, COLOR_CONTROL_STATIC_LINE);			//Y
				}

				pDC->SetTextColor(m_crTextColor);
				pDC->SetBkMode(TRANSPARENT);

				CString strLog;
				for(int i=0; i< nSize_GROUP_COLOR; i++)
				{
					Line_BF(pDC,i*nTerm+1, ch_Selltop+1   ,((i+1)*nTerm)-1, ch_Sellbottom-1, m_pGroupColor[i].nGROUP_RGB );
					strLog.Format("C %d",m_pGroupColor[i].nGROUP_Index );	
					pDC->TextOut(i*nTerm+1, ch_Selltop+2,strLog );	
				}
			}
			else if(m_pPOS_VIEW)
			{

				pDC->SetTextColor(m_crTextColor);
				if(m_pROW_MAP[nRow].m_BLOCK_OnMODE==INDEX_MODE || m_pROW_MAP[nRow].m_BLOCK_OnMODE==TIME_MODE || m_pROW_MAP[nRow].m_BLOCK_OnMODE==PRICE_MODE)
				{
					pDC->SetTextColor(m_crTextColor);
				}
				else
				{
					if(m_pROW_MAP[nRow].m_BLOCK_OnMODE==XPX_HEADGE_MODE || m_pROW_MAP[nRow].m_BLOCK_OnMODE==XCX_HEADGE_MODE ||
						m_pROW_MAP[nRow].m_BLOCK_OnMODE==ZPZ_HEADGE_MODE || m_pROW_MAP[nRow].m_BLOCK_OnMODE==ZCZ_HEADGE_MODE)
					{
						pDC->SetTextColor(COLOR_CONTROL_STATIC_LINE);
					}
				}

				pDC->SetBkMode(TRANSPARENT);

				CString strLog;
				for(int i=0; i< nSize_POSTION; i++)
				{
					strLog="";
					long nCOLOR_RGB = m_pPOS_VIEW[i].nPOS_GROUP_ColorRGB; // * 30;
					
					if(m_pROW_MAP[nRow].m_BLOCK_OnMODE==INDEX_MODE)
					{
						strLog.Format("%d",m_pPOS_VIEW[i].nAESA_Cnt);	
					}                       //�������� �ð�  
					else if(m_pROW_MAP[nRow].m_BLOCK_OnMODE==TIME_MODE)
					{                       
						strLog.Format("%d",(int)m_pPOS_VIEW[i].nTime/100);						
					}                       //�������簡 
					else if(m_pROW_MAP[nRow].m_BLOCK_OnMODE==PRICE_MODE)
					{
						strLog.Format("%.2f",m_pPOS_VIEW[i].nClose/100.);	
						strLog =strLog.Mid(2);						
					}
					else if(m_pROW_MAP[nRow].m_BLOCK_OnMODE==SUB_PRICE_MODE)
					{
						float nSUB_Price =0.0f;
						if(i>0)
						{
							nSUB_Price = (m_pPOS_VIEW[i].nClose - m_pPOS_VIEW[i-1].nClose) /100;
						}

						strLog.Format("%.2f",nSUB_Price);
						strLog.Replace("0.","");

						if(m_pPOS_VIEW[i].nSignal==1)	//20141016 ������ �϶�=2	//20141016 if(nSUB_Price >= 0.0f) //20141016
						{
							pDC->SetTextColor(m_crTextColor);
						}
						else
						{
							pDC->SetTextColor(RGB(0,255,0));	//	strLog.Replace("-0.","");
							pDC->SetBkMode(TRANSPARENT);
						}
					}









//////////////////////////////////////////////////////////

					pDC->TextOut(i*nTerm+1, ch_Selltop+2,strLog );
				}		
			}
		}//	if(m_BLOCK_Array) 



	}//=========================


	pDC->SelectObject(pOldPen);
	pen.DeleteObject();
	pDC->SelectObject(pOldBrush);
	brush.DeleteObject();
	rcItem.DeflateRect(1, 1);



	UINT style = DT_SINGLELINE|DT_VCENTER;
	if(GetExStyle() & WS_EX_RIGHT || m_nAlign == DT_RIGHT)
	{
		style |= DT_RIGHT;
		rcItem.right -= 4;
	}
	else if(m_nAlign == DT_LEFT)
	{
		style |= DT_LEFT;
		rcItem.left += 4;
	}
	else
		style |= DT_CENTER;

	// Symbol �� �׸����� üũ�Ͽ�..
	// ��Ʈ�� �ε��Ͽ� �׷����� ���� ����ġ�� ������.
	if (m_bIsSymbol && m_nSymbol != 3)
	{
		COLORREF clrSignColor;
		CPoint P[7];
		int nPolyCount = 3;
		int X;
		int Y;
		X = 0;
		Y = 2;

		switch (m_nSymbol) 
		{
		case 1:		// ����
			{
				clrSignColor = RGB(255, 0, 0);
				nPolyCount = 7;
				P[0] = CPoint(X+7, Y+2);
				P[1] = CPoint(X+3, Y+6);
				P[2] = CPoint(X+6, Y+6);
				P[3] = CPoint(X+6, Y+10);
				P[4] = CPoint(X+8, Y+10);
				P[5] = CPoint(X+8, Y+6);
				P[6] = CPoint(X+11, Y+6);
			}
			break;
		case 2:		// ���
			{
				clrSignColor = RGB(255, 0, 0);
				P[0] = CPoint(X+7, Y+2);
				P[1] = CPoint(X+4, Y+9);
				P[2] = CPoint(X+10,Y+9);
			}
			break;
		case 5:		// �϶�
			{
				clrSignColor = RGB(0, 0, 255);
				P[0] = CPoint(X+4, Y+2);
				P[1] = CPoint(X+7, Y+9);
				P[2] = CPoint(X+10,Y+2);
			}
			break;
		case 4:		// ����
			{
				clrSignColor = RGB(0, 0, 255);
				nPolyCount = 7;
				P[0] = CPoint(X+6, Y+2);
				P[1] = CPoint(X+6, Y+6);
				P[2] = CPoint(X+3, Y+6);
				P[3] = CPoint(X+7, Y+10);
				P[4] = CPoint(X+11,Y+6);
				P[5] = CPoint(X+8, Y+6);
				P[6] = CPoint(X+8, Y+2);
			}
			break;
		}
		CPen  pen(PS_SOLID, 1, clrSignColor);
		CBrush	brush(clrSignColor);

		CPen* OldPen = pDC->SelectObject(&pen);
		CBrush* OldBrush = pDC->SelectObject(&brush);
		pDC->Polygon(P, nPolyCount);
		pDC->SelectObject(OldPen);
		pDC->SelectObject(OldBrush);
	}

	pDC->SetTextColor(m_crTextColor);
	pDC->SetBkMode(TRANSPARENT);

	if(!m_bVCenter)
		style &= ~(DT_SINGLELINE | DT_VCENTER);

	pDC->DrawText(m_strText, &rcItem, style);
	pDC->SelectObject(old_font);

	//rgn.DeleteObject();
	textfont.DeleteObject();
}



void CSTGridStatic::SetWindowText(LPCTSTR lpszString, int nAlign)
{
	if(m_strText.GetLength() == 0)
		CStatic::SetWindowText(lpszString);
	m_strText = lpszString;
	m_nAlign = nAlign;
	Invalidate();
}

void CSTGridStatic::GetWindowText(CString& rString)
{
	rString = m_strText;
}



COLORREF CSTGridStatic::textColor(COLORREF crColor)
{
	_ASSERT(::IsWindow(m_hWnd));

	COLORREF preColor = m_crTextColor;
	m_crTextColor = crColor;

	Invalidate();

	return preColor;
}

int CSTGridStatic::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CStatic::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	GetWindowText(m_strText);	

	ModifyStyleEx (WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE,0, SWP_FRAMECHANGED);

	return 0;
}

void CSTGridStatic::SetBkColor(COLORREF crBk)
{
	m_crBackground = crBk;
}

COLORREF CSTGridStatic::GetBkColor()
{
	return m_crBackground;
}

// Symbol �����Ѵ�.
void CSTGridStatic::SetSymbol(int symbol)
{
	ASSERT(symbol >= 1 && symbol <= 5);

	if (symbol == 3)
	{
		m_bIsSymbol = FALSE;
		return;
	}

	m_bIsSymbol = TRUE;
	// Symbol�� �о�´�.
	// �ش� Symbol�� �̸� �����.
	if (m_nSymbol != symbol)
	{
		m_nSymbol = symbol;

		if (m_pSymbol)
		{
			m_pSymbol->DeleteObject();
			delete m_pSymbol;
		}

		m_pSymbol = new CBitmap();
		switch(m_nSymbol)
		{
		case 1:
			m_pSymbol->LoadBitmap(IDB_HIGH);
			break;
		case 2:
			m_pSymbol->LoadBitmap(IDB_UP);
			break;
		case 4:
			m_pSymbol->LoadBitmap(IDB_LOW);
			break;
		case 5:
			m_pSymbol->LoadBitmap(IDB_DOWN);
			break;
		}
	}
}

void CSTGridStatic::SetBorder(BOOL bBorder)
{
	m_bBorder = bBorder;
}

void CSTGridStatic::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if(nChar == '+')
	{
		//ȭ���ȣ �Է�â���� ��Ŀ���̵�
		AfxGetMainWnd()->SendMessage(WM_KEYDOWN_ADD, 0, 0);
		return;
	}
	CStatic::OnChar(nChar, nRepCnt, nFlags);
}
