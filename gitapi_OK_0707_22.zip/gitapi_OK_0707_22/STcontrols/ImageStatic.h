#if !defined(AFX_IMAGESTATIC_H__552F4B54_7189_4755_A180_374CC13B95E8__INCLUDED_)
#define AFX_IMAGESTATIC_H__552F4B54_7189_4755_A180_374CC13B95E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImageStatic.h : header file
//

#define BMPIMAGE	1000
#define BMPCANDLE	1001

typedef struct tagCHTData
{
	int		nDate;
	long	lOpen;
	long	lHigh;
	long	lLow;
	long	lCls;
	long	dwTrdngVlm;
	CRect   rcBong;	
}CHTData,*LPCHTData;

/////////////////////////////////////////////////////////////////////////////
// CImageStatic window

class AFX_EXT_CLASS CImageStatic : public CStatic
{
// Construction
public:
	CImageStatic();	
// Attributes
public:
	int		m_nChtListCnt;	//��Ʈ(��)�� ����
	int		m_nChtArrayCnt;	
	CRect   m_rcCht;		//Real Chart Region 
	CRect   m_rcVrtCht;		//Virtual Chart Region
	CRect   m_rcTot;		//Chart Tot Region
	int		m_nCurIdx;		//���� CurIdx
	int		m_nMaxData;		//�������� Data�� ���� ū��
	int		m_nMinData;		//������
	int		m_nMinGap;
	int		m_nMaxGap;
	CString m_strSymbolName;
	int		m_nChtKind;

	int		m_nTotCnt;
	int		m_nVwStartIdx;
	int		m_nVwEndIdx;
	
	int		m_nSaveMode; 
	CSize   m_szSaveWndExt;
	CSize   m_szSaveVwExt;
	CPoint  m_ptSaveWndOrg;
	CPoint  m_ptSaveVwOrg;

	CFont m_chtFont,*m_chtOldFont;		

	int		m_nChtFillUm;
	int		m_nChtFillYang;
	CRect m_rcCandle;
	CRect m_rcImage;	
	BOOL	m_bCurDraw;	
	int		m_nDrawingCnt;
	BOOL	m_bDrawingChart;

	int		m_nBYUnit;
	int		m_nBaseLine[3];			//���ؼ� Maximum 3�� 
// Operations
public:
	CFont *SetTextFont(CDC *pDC, int iFontSize = 10,
					BOOL bBold = FALSE, BOOL bItalic = FALSE, BOOL bUnderLine = FALSE,
					int iJustify = 1, CString strFont = "����ü",
					COLORREF rgbTextColor = RGB(0, 0, 0), COLORREF rgbBkColor = RGB(255, 255, 255));
	void SetOldFont(CDC *pDC, CFont *cfFont);

	long GetData(int kind, int idx, long *retData);
	long GetMinData(int nKind, int nStPos, int nEndPos);
	long GetMaxData(int nKind, int nStPos, int nEndPos);
	void CandleChart(CDC *pDC, long lMax, long lMin);	
	void DrawYAxis(CDC *pDC, long max, long min);	
	void SetOldMode(CDC *pDC);
	void DeleteMemory();		
	int	 ReadChtData(CHTData *pDataList,int nDataCnt,BOOL bArray);	
	int  AddChtDataList(CHTData chtData);
	int  AddChtDataArray(CHTData chtData);	
	int  SetChtDataList(CHTData chtData,int nIdx);

	int  DrawCandle(CDC *pDC);
	void CandleChart(CDC *pDC,int nMax,int nMin);
	int  DrawImage(CDC *pDC,CRect rect,UINT uFlag,int nStretch = 1/*Default*/);	
	
	void SetStretch(int nStretch){	m_nStretch = nStretch; }
	int  GetStretch() { return m_nStretch; }
	UINT GetImageStyle() { return m_uStyle; }
	void SetImageStyle(UINT uStyle) { m_uStyle = uStyle; }
	WORD GetDrawEnum() { return m_wDrawEnum; }
	void SetDrawEnum(WORD wStyle) { m_wDrawEnum = wStyle; }	
	//int  GetDrawingCnt() { return m_nDrawingCnt; }
	//void SetDrawingCnt(int nCnt) { m_nDrawingCnt = nCnt; }
	int  GetDrawingPos() { return m_bPosImage; }
	void SetDrawingPos(BOOL bPosImage) { m_bPosImage = bPosImage; }

	void SetUpperData(int nUpper)
	{	m_nUpperData = nUpper;	}
	void SetLowerData(int nLower)
	{	m_nLowerData = nLower;	}
	int GetUpperData()
	{	return m_nUpperData;	}
	int GetLowerData()
	{	return m_nLowerData;	}
	CString GetFilePath()
	{	return m_strFileName;	}
	void SetFilePath(CString strPath)
	{	m_strFileName = strPath;	}
	virtual CDC *GetDC()
	{	return m_pClientDC;		}
	virtual void SetDC(CDC *pDC)
	{	m_pClientDC = pDC;		}	
private:
	CString m_strFileName;	
	CDC		*m_pClientDC;
	int		m_nUpperData;	//���Ѱ� 
	int		m_nLowerData;	//���Ѱ�
	CHTData *m_pChtDataList;
	CHTData m_pChtDataArray[10];
	
	BOOL m_bPosImage;	//TRUE:Upper,FALSE:Lower	
	int m_nStretch;	
	UINT m_uStyle;
	WORD m_wDrawEnum;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImageStatic)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CImageStatic();

	// Generated message map functions
protected:
	//{{AFX_MSG(CImageStatic)
	afx_msg void OnPaint();	
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMAGESTATIC_H__552F4B54_7189_4755_A180_374CC13B95E8__INCLUDED_)
