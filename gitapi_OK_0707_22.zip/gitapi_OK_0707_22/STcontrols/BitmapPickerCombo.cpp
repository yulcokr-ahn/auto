//----------------------------------------------------------------------------
// N O L D U S   I N F O R M A T I O N   T E C H N O L O G Y   B . V .
//----------------------------------------------------------------------------
// Filename:      BitmapPickerCombo.cpp
// Project:       EthoVision
// Module:        BitmapPicker
// Programmer:    Anneke Sicherer-Roetman
// Version:       1.00
// Revision Date: 06-10-1999
//----------------------------------------------------------------------------
// Description:   Definition of class CBitmapPickerCombo
//                See CBitmapPickerCombo.h
//----------------------------------------------------------------------------
// Acknowledgements: based on Joel Wahlberg's CIconComboBox
//                  (joel.wahlberg@enator.se)
//----------------------------------------------------------------------------
// Revision history:
// 06-10-1999 - First implementation
// 08-01-2002 - Next  Implementation by jwp - FlatCombo��� Add 	
//----------------------------------------------------------------------------

#include "stdafx.h"
#include "BitmapPickerCombo.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
               
BEGIN_MESSAGE_MAP(CBitmapPickerCombo, CComboBox)
	//{{AFX_MSG_MAP(CToolBarCombo)
	ON_WM_PAINT()
	ON_WM_SYSCOLORCHANGE()
	ON_WM_CTLCOLOR()	
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP	
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////////////////////////////////

static void DrawBitmap(const CBitmap *bitmap, const CDC *pDC, const CPoint &point)
{
	BITMAP bm; ((CBitmap*)bitmap)->GetBitmap(&bm);
	int w = bm.bmWidth; 
	int h = bm.bmHeight;
	CDC memDC; memDC.CreateCompatibleDC((CDC*)pDC);
	CBitmap *pBmp = memDC.SelectObject((CBitmap*)bitmap);
	((CDC*)pDC)->BitBlt(point.x, point.y, w, h, &memDC, 0, 0, SRCCOPY);
	memDC.SelectObject(pBmp);
	memDC.DeleteDC();
}

static void DrawBitmap(const CBitmap *bitmap, const CDC *pDC, const CRect &rect)
{
	BITMAP bm; ((CBitmap*)bitmap)->GetBitmap(&bm);
	int w = bm.bmWidth; 
	int h = bm.bmHeight;
	CPoint point;
	point.x = rect.left + ((rect.right - rect.left) / 2) - (w / 2);
	point.y = rect.top + ((rect.bottom - rect.top) / 2) - (h / 2);
	DrawBitmap(bitmap, pDC, point);
}

CBitmapPickerCombo::CBitmapPickerCombo():  CComboBox(), m_nItemWidth(0), m_nItemHeight(0)
{
	m_iCurSel = -1;
	m_bCloseUp = FALSE;
	m_bLBtnDown = FALSE;
	
	// by jwp 
	m_clrBtnHilite  = ::GetSysColor(COLOR_BTNHILIGHT);
	m_clrBtnShadow  = ::GetSysColor(COLOR_BTNSHADOW);
	m_clrBtnFace    = ::GetSysColor(COLOR_BTNFACE);
	m_nOffset		= ::GetSystemMetrics(SM_CXHTHUMB);

	m_hbr = CreateSolidBrush( RGB(255,255,255));

	m_bDrawCursor = FALSE;
}

CBitmapPickerCombo::~CBitmapPickerCombo()
{
	DeleteObject(m_hbr);
}

int CBitmapPickerCombo::AddBitmap(const CBitmap *bitmap, const char *string)
{
	return InsertBitmap(GetCount(), bitmap, string);
}

int CBitmapPickerCombo::InsertBitmap(int nIndex, const CBitmap *bitmap, const char *string)
{
	int n = CComboBox::InsertString(nIndex, string ? string : "");
	if (n != CB_ERR && n != CB_ERRSPACE) 
	{
		SetItemData(n, (DWORD)bitmap);
		BITMAP bm; ((CBitmap*)bitmap)->GetBitmap(&bm);
		SetSize(bm.bmWidth, bm.bmHeight);
	}
	return n;
}

void CBitmapPickerCombo::MeasureItem(LPMEASUREITEMSTRUCT lpMIS)
{ 
	lpMIS->itemWidth = (m_nItemWidth + 2);
	lpMIS->itemHeight = (m_nItemHeight + 2);
}

void CBitmapPickerCombo::DrawItem(LPDRAWITEMSTRUCT lpDIS)
{
	CDC* pDC = CDC::FromHandle(lpDIS->hDC);

	if (!IsWindowEnabled()) 
	{
		CBrush brDisabled(RGB(192,192,192)); // light gray
		CBrush* pOldBrush = pDC->SelectObject(&brDisabled);
		CPen penDisabled(PS_SOLID, 1, RGB(192,192,192));
		CPen* pOldPen = pDC->SelectObject(&penDisabled);
		OutputBitmap(lpDIS, false);
		pDC->SelectObject(pOldBrush);
		pDC->SelectObject(pOldPen);
		return;
	}

	// Selected
	if ((lpDIS->itemState & ODS_SELECTED) 
		&& (lpDIS->itemAction & (ODA_SELECT | ODA_DRAWENTIRE))) 
	{
		CBrush brHighlight(::GetSysColor(COLOR_HIGHLIGHT)); 
		CBrush* pOldBrush = pDC->SelectObject(&brHighlight);
		CPen penHighlight(PS_SOLID, 1, ::GetSysColor(COLOR_HIGHLIGHT));
		CPen* pOldPen = pDC->SelectObject(&penHighlight);
		pDC->Rectangle(&lpDIS->rcItem);
		pDC->SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		pDC->SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
		OutputBitmap(lpDIS, true);
		pDC->SelectObject(pOldBrush);
		pDC->SelectObject(pOldPen);
	}

	// De-Selected
	if (!(lpDIS->itemState & ODS_SELECTED) 
		&& (lpDIS->itemAction & (ODA_SELECT | ODA_DRAWENTIRE))) 
	{
		CBrush brWindow(::GetSysColor(COLOR_WINDOW)); 
		CBrush* pOldBrush = pDC->SelectObject(&brWindow);
		CPen penHighlight(PS_SOLID, 1, ::GetSysColor(COLOR_WINDOW));
	    CPen* pOldPen = pDC->SelectObject(&penHighlight);
		pDC->Rectangle(&lpDIS->rcItem);
		pDC->SetBkColor(::GetSysColor(COLOR_WINDOW));
		pDC->SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
		OutputBitmap(lpDIS, false);
		pDC->SelectObject(pOldBrush);
		pDC->SelectObject(pOldPen);
	}

	// Focus
	if (lpDIS->itemAction & ODA_FOCUS) 
		pDC->DrawFocusRect(&lpDIS->rcItem);
}

void CBitmapPickerCombo::OutputBitmap(LPDRAWITEMSTRUCT lpDIS, bool selected)
{
	const CBitmap *bitmap = (const CBitmap*)(lpDIS->itemData);
	if (bitmap && bitmap != (const CBitmap *)(0xffffffff)) 
	{
		CDC* pDC = CDC::FromHandle(lpDIS->hDC);
		CString string; 
		if (lpDIS->itemID != -1) 
			GetLBText(lpDIS->itemID, string); 
		if (string.IsEmpty()) 
			DrawBitmap(bitmap, pDC, lpDIS->rcItem);
		else 
		{
			CPoint point;
			point.x = lpDIS->rcItem.left + 2;
			point.y = lpDIS->rcItem.top + ((lpDIS->rcItem.bottom - lpDIS->rcItem.top) / 2) - (m_nItemHeight / 2); 
			DrawBitmap(bitmap, pDC, point);
			CRect rcText(lpDIS->rcItem); 
			rcText.DeflateRect(m_nItemWidth + 4, 0, 0, 0);

			// 2001/11/20 by jwp font Change
			CFont bmpFont,*pOldFont;
			bmpFont.CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, 
				DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
				DEFAULT_QUALITY, DEFAULT_PITCH, "����ü");
			pOldFont = (CFont *)pDC->SelectObject( &bmpFont );

			pDC->DrawText(string, rcText, DT_SINGLELINE |DT_VCENTER );
			pDC->SelectObject( pOldFont );
		}
	}
}               

void CBitmapPickerCombo::SetSize(int width, int height)
{
	if (width > m_nItemWidth)
		m_nItemWidth = width;
	if (height > m_nItemHeight)
		m_nItemHeight = height;
	for (int i = -1; i < GetCount(); i++) 
	{
		SetItemHeight(i, m_nItemHeight + 6);
	}
}

//----------------------------------------------------------------------------
// ���� Debug version������ 
#ifdef _DEBUG
	void CBitmapPickerCombo::PreSubclassWindow() 
	{
	  CComboBox::PreSubclassWindow();

	  // ensure some styles are set
	  // modifying style here has NO effect!?!
	  ASSERT(GetStyle() & CBS_DROPDOWNLIST);
	  ASSERT(GetStyle() & CBS_OWNERDRAWVARIABLE);
	  ASSERT(GetStyle() & CBS_HASSTRINGS);
	}
#endif

//----------------------------------------------------------------------------
#if 0
void CBitmapPickerCombo::OnMouseMove(UINT nFlags, CPoint point) 
{
	HCURSOR hCurCursor;
	CRect crRect;

	GetClientRect(crRect);
	crRect.right = 20;

	if( crRect.PtInRect(point) )
	{
		hCurCursor = GetCursor();
		SetCursor(AfxGetApp()->LoadCursor(IDC_ANIMATE));
	}
	CComboBox::OnMouseMove(nFlags, point);
}
#endif

////////////////////////////////////////////////////////////////////////////////
//		2002/01/08 BmpPickercombo + CFlatcombo
void CBitmapPickerCombo::OnPaint() 
{
	ModifyStyleEx (WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE,
		0, SWP_FRAMECHANGED);
	
	Default();	
	CRect rcItem;
	GetWindowRect(&rcItem);

	/*	if ((rcItem.PtInRect(pt)) || m_bHasFocus)
		DrawCombo( raised, m_clrBtnShadow, m_clrBtnHilite );
	else*/
		DrawCombo( normal, COLOR_BORDER, COLOR_BORDER);
}

BOOL CBitmapPickerCombo::PreTranslateMessage(MSG* pMsg) 
{
	// Catch the Alt key so we don't choke if focus 
	// is going to an owner drawn button
	if (pMsg->message == WM_SYSCHAR)
		return TRUE;
		
	return CComboBox::PreTranslateMessage(pMsg);
}

HBRUSH CBitmapPickerCombo::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{	
	HBRUSH hbr = CComboBox::OnCtlColor(pDC, pWnd, nCtlColor);

	//if ( nCtlColor == CTLCOLOR_LISTBOX )
	//{
	pDC->SetBkColor( RGB(255,255,255) );
	pDC->SetTextColor( RGB(0,0,0) );		
	//}
	
	return m_hbr;
}

void CBitmapPickerCombo::OnSysColorChange() 
{
	CComboBox::OnSysColorChange();

	// re-initialize system colors.
	m_clrBtnHilite  = ::GetSysColor(COLOR_BTNHILIGHT);
	m_clrBtnShadow  = ::GetSysColor(COLOR_BTNSHADOW);
	m_clrBtnFace    = ::GetSysColor(COLOR_BTNFACE);
}

void CBitmapPickerCombo::DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight)
{
	CRect rcItem;
	GetClientRect(&rcItem);
	CDC* pDC = GetDC();

	// Cover up dark 3D shadow.
	pDC->Draw3dRect(rcItem, clrTopLeft, clrBottomRight);
	rcItem.DeflateRect(1,1);

	if (!IsWindowEnabled()) 
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
	else 
		pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );

	// Cover up dark 3D shadow on drop arrow.
	rcItem.DeflateRect(1,1);
	rcItem.left = rcItem.right-m_nOffset;
	pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );
	
	// Cover up normal 3D shadow on drop arrow.
	rcItem.DeflateRect(1,1);
	pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );
	
	if (!IsWindowEnabled()) 
	{
		ReleaseDC(pDC);
		return;
	}

	switch (eState)
	{
	case normal:
		rcItem.top -= 1;
		rcItem.bottom += 1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		rcItem.left -= 1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		break;
	}

	ReleaseDC(pDC);
}

BOOL CBitmapPickerCombo::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	return TRUE;
}

