// NumEdit.cpp : implementation file
//

#include "stdafx.h"
#include "NumSpinEdit.h"
#include "Float.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/*
IMPLEMENT_DYNAMIC(CSTNumEdit, CEdit)

CSTNumEdit::CSTNumEdit()
{
	m_nNumberOfNumberAfterPoint = 0;
	m_Verbose = TRUE;
	m_MinValue = -FLT_MAX;
	m_MaxValue = FLT_MAX;
	m_Delta = FLT_ROUNDS;
	m_bAutoInsertComma = TRUE;
	m_bAutoDot = FALSE;
	m_lBkColor = RGB(255,255,255);
	m_hbr1 = CreateSolidBrush(RGB(255,255,255));
	m_bInt = FALSE;
	m_bNotDot = FALSE;
}

CSTNumEdit::~CSTNumEdit()
{
	DeleteObject(m_hbr1);
}


BEGIN_MESSAGE_MAP(CSTNumEdit, CEdit)
	//{{AFX_MSG_MAP(CSTNumEdit)
	ON_WM_CHAR()
	ON_WM_LBUTTONDOWN()
	ON_CONTROL_REFLECT(EN_SETFOCUS, OnSetfocus)
	ON_WM_CTLCOLOR_REFLECT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSTNumEdit message handlers

float CSTNumEdit::GetValue() const
{
	float f = m_MinValue;
	if (IsValid() == VALID)
	{
		CString str;
		GetWindowText(str);
		str.Remove(',');
		sscanf(str, "%f", &f);
	}
	return f;
}

int CSTNumEdit::GetValueInt() const
{
	int f = (int)m_MinValue;
	if (IsValid() == VALID)
	{
		CString str;
		GetWindowText(str);
		str.Remove(',');
		sscanf(str, "%d", &f);
	}
	return f;
}


BOOL CSTNumEdit::SetValue(float val)
{
	if (val > m_MaxValue || val < m_MinValue) return FALSE;
	CString str, s;
	ConstructFormat(s, val);
	str.Format((LPCTSTR)s, val);
	if(m_bAutoInsertComma)
		InsertComma(str);
	else
		str.TrimLeft();
	SetWindowText(str);
	return TRUE;
}

BOOL CSTNumEdit::SetValueInt(int val)
{
	if (val > m_MaxValue || val < m_MinValue) return FALSE;
	CString str;
	str.Format("%d", val);
	if(m_bAutoInsertComma)
		InsertComma(str);
	else
		str.TrimLeft();
	SetWindowText(str);
	return TRUE;
}


int CSTNumEdit::IsValid() const
{
	CString str;
	GetWindowText(str);
	str.Remove(',');

	int res = VALID;
	float f;
	char lp[10];
	if ((str.GetLength() == 1) && ((str[0] == '+') || (str[0] == '-'))) 
		res = MINUS_PLUS;
	else if (str.GetLength() == 0)
		return res;
	else if (sscanf(str, "%f%s", &f, lp) != 1) 
		res = INVALID_CHAR;
	else if (f > m_MaxValue || f < m_MinValue) 
		res = OUT_OF_RANGE;

	if (m_Verbose && (res != VALID) && (res != MINUS_PLUS))
	{
		str.Empty();
		if (res & OUT_OF_RANGE) str += _T("������ ������ϴ�.\n");
		if (res & INVALID_CHAR) str += _T("���ڸ� �Է� �����մϴ�.\n");
		AfxMessageBox(str, MB_OK | MB_ICONSTOP);
		((CWnd*)this)->SetFocus();
	}
	return res;
}

int CSTNumEdit::IsValid(const CString &str) const
{
	int res = VALID;
	float f;
	char lp[10];
	if ((str.GetLength() == 1) && ((str[0] == '+') || (str[0] == '-'))) res = MINUS_PLUS;
	else if (sscanf(str, "%f%s", &f, lp) != 1) res = INVALID_CHAR;
	else if (f > m_MaxValue || f < m_MinValue) res = OUT_OF_RANGE;
	if (m_Verbose && (res != VALID) && (res != MINUS_PLUS))
	{
		CString msg;
		msg.Empty();
		if (res & OUT_OF_RANGE) msg += _T("Given value is out of range.\n");
		if (res & INVALID_CHAR) msg += _T("Characters must be a number.\n");
		AfxMessageBox(str, MB_OK | MB_ICONSTOP);
		((CWnd*)this)->SetFocus();
	}
	return res;
}


void CSTNumEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (nChar == ' ') return;
	int nStart, nEnd, nLen1, nLen2, nLen3;
	float oldValue;
	CString s;
	oldValue = GetValue();
TRACE("\n CSTNumEdit::OnChar oldValue=[%f]", oldValue);

	CEdit::OnChar(nChar, nRepCnt, nFlags);

	if(m_bNotDot)
	{

	}
	else
	{
		if(m_bAutoDot && nChar == 46)
		{
			GetWindowText(s);
			int nFind = s.Find(".");
			CString strSub = s.Left(nFind);
			nLen1 = atoi(strSub.GetBuffer(0));
			s.Delete(0, nFind+1);
			if(nLen1 > 0)
			{
				strSub.Format("%d", nLen1);
				s = strSub + s;
			}
			

			SetWindowText(s);
			SetSel(s.GetLength(), s.GetLength());
			return;
		}
	}
	
	int val = IsValid();
	if(val == OUT_OF_RANGE)
		val = VALID;
	switch (val)
	{
		case VALID:
		{
			if(!m_bAutoDot)
			{
				//�ڵ� Comma
				ConstructFormat(s, GetValue());
				GetWindowText(s);
				nLen1 = s.GetLength();
				GetSel(nStart, nEnd);
				SetValue(GetValue());
				GetWindowText(s);
				nLen2 = s.GetLength();
				//ĳ���� �Ű� �߰����� �����.
				if(nStart == nLen1)
					nLen3 = nLen2 - nLen1 + 1;
				else
					nLen3 = nLen2 - nLen1;
				SetSel(nStart+nLen3, nEnd+nLen3);
			}
			else
			{
				//�ڵ��Ҽ���ó��

				if(m_bNotDot)
				{
					GetWindowText(s);
					s.Remove('.');
					//ConstructFormat(s, GetValue());	
					SetWindowText(s);
					SetSel(s.GetLength(), s.GetLength());
					
					TRACE("\n CSTNumEdit::OnChar s=[%s]", s);
				}
				else
				{
					GetWindowText(s);
					s.Remove('.');
					if(s.GetLength() < 3)
						s = "0." + s;
					else
					{
						s.Insert(s.GetLength()-2, ".");
						if(s.GetAt(0) == '0')
							s.Delete(0);
					}
					SetWindowText(s);
					SetSel(s.GetLength(), s.GetLength());
				}
			}
			break;
		}
		case MINUS_PLUS: break;
		default:
			SetValue(oldValue);
			SetSel(0, -1);
			MSG msg;
			while (::PeekMessage(&msg, m_hWnd, WM_CHAR, WM_CHAR, PM_REMOVE));
			break;
	}	
}


BOOL CSTNumEdit::Verbose() const
{
	return m_Verbose;
}

void CSTNumEdit::Verbose(BOOL v)
{
	m_Verbose = v;
}

void CSTNumEdit::SetRange(float min, float max)
{
	m_MinValue = min;
	m_MaxValue = max;
}

void CSTNumEdit::GetRange(float & min, float & max) const
{
	min = m_MinValue;
	max = m_MaxValue;
}

void CSTNumEdit::SetDelta(float delta)
{
	m_Delta = delta;
}

float CSTNumEdit::GetDelta()
{
	return m_Delta;
}

void CSTNumEdit::ChangeAmount(int step)
{
	float f = GetValue() + step * m_Delta;
	if (f > m_MaxValue) f = m_MaxValue;
	else if (f < m_MinValue) f = m_MinValue;
	SetValue(f);
}

CString& CSTNumEdit::ConstructFormat(CString &str, float num)
{
	CString strPrec;

	str.Format("%20f", num);
	int n = str.Find('.');

	if (n >= 0)
	{
		strPrec = str.Mid(n+1, str.GetLength()-(n+1));
		int nLength = strPrec.GetLength();

		if(atoi(strPrec) > 0)
		{
			for(int i=nLength-1; i >= 0; i--)
			{
				if(strPrec[i] == '0')
					strPrec.SetAt(i, NULL);
				else
					break;
			}
			m_nNumberOfNumberAfterPoint = strlen((LPCTSTR)strPrec);
		}
		else
			m_nNumberOfNumberAfterPoint = 0;
	}

	if(m_nNumberOfNumberAfterPoint > 0)
		str.Format("%%20.2f");		
	else
		str.Format("%%20.0f");	

	return str;
}


void CSTNumEdit::InsertComma(CString &strData,UINT nIndent)
{
	BOOL bMinus = FALSE;
	int nSize,nLength;

	strData.Replace(",","");
	strData.TrimLeft();
	strData.TrimRight();

	if((nLength = strData.Find('.')) == -1)
		nLength=strData.GetLength();
	if(nLength<=0) 
		return;	
	
	if((strData.GetAt(0)=='-') || (strData.GetAt(0)=='+'))		
		bMinus=TRUE;

	nSize=nLength-nIndent;	
	while(nSize>0)
	{			
		if(bMinus)
		{
			if(nLength>4)
				strData.Insert(nSize,",");
		}
		else
			strData.Insert(nSize,",");
			
		nLength-=nIndent;
		nSize=nLength-nIndent;	
	}	
}

void CSTNumEdit::SetNumAfterPoint(int nPoint)
{
	m_nNumberOfNumberAfterPoint = nPoint;
}

void CSTNumEdit::SetAutoInsertComma(BOOL bSet)
{
	m_bAutoInsertComma = bSet;
}

void CSTNumEdit::SetAutoDot(BOOL bSet)
{
	m_bAutoDot = bSet;
}

void CSTNumEdit::SetNotDot(BOOL bSet)
{
	m_bNotDot = bSet;
}




void CSTNumEdit::SetInt(BOOL bSet)
{
	m_bInt = bSet;
}



void CSTNumEdit::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if(GetFocus() != this)
	{
		SetFocus();
	}
	else CEdit::OnLButtonDown(nFlags, point);
}

void CSTNumEdit::OnSetfocus() 
{
	SetSel(0, -1);
}

void CSTNumEdit::SetWndBkColor(long lBkColor)
{
	m_lBkColor = lBkColor;
	DeleteObject(m_hbr1);
	m_hbr1 = CreateSolidBrush(lBkColor);
}

HBRUSH CSTNumEdit::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	if(nCtlColor == CTLCOLOR_EDIT)
	{
		pDC->SetBkColor(m_lBkColor);
		pDC->SetTextColor(RGB(0,0,0));
		return m_hbr1;
	}
	return NULL;
}
*/


IMPLEMENT_DYNAMIC(CSTNumEdit, CEdit)

CSTNumEdit::CSTNumEdit()
{
	m_nNumberOfNumberAfterPoint = 0;
	m_Verbose = TRUE;
	m_MinValue = -FLT_MAX;
	m_MaxValue = FLT_MAX;
	m_Delta = FLT_ROUNDS;
	m_bAutoInsertComma = TRUE;
	m_bAutoDot = FALSE;
	m_lBkColor = RGB(255,255,255);
	m_hbr1 = CreateSolidBrush(RGB(255,255,255));
	m_bInt = FALSE;
	m_bNotDot = FALSE;

	
	m_clrBoardColor = RGB(200,200,200);


	m_clr3DFATS = GetSysColor(COLOR_3DFACE);
	m_clr3DLight = GetSysColor(COLOR_3DLIGHT);
	m_clr3DHilight = GetSysColor(COLOR_3DHILIGHT);
	m_clr3DShadow = GetSysColor(COLOR_3DSHADOW);
	m_clr3DDkShadow = GetSysColor(COLOR_3DDKSHADOW);
	m_fGotFocus = false;
	m_fTimerSet = false;
	m_hbr2 = CreateSolidBrush( RGB(208,252,205));
	m_TextColor = RGB(0,0,0);

	m_editFont.CreateFont(10, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH, "����ü");
}

CSTNumEdit::~CSTNumEdit()
{
	DeleteObject(m_hbr1);
	DeleteObject(m_hbr2);
}


BEGIN_MESSAGE_MAP(CSTNumEdit, CEdit)
	//{{AFX_MSG_MAP(CSTNumEdit)
	ON_WM_CHAR()
	ON_WM_LBUTTONDOWN()
	ON_CONTROL_REFLECT(EN_SETFOCUS, OnSetfocus)
	ON_WM_CTLCOLOR_REFLECT()


	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEMOVE()
	ON_WM_NCMOUSEMOVE()
	ON_WM_SYSCOLORCHANGE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSTNumEdit message handlers
void CSTNumEdit::OnKillFocus(CWnd* pNewWnd) 
{
	CEdit::OnKillFocus(pNewWnd);
	
	
}

float CSTNumEdit::GetValue() const
{
	float f = m_MinValue;
	if (IsValid() == VALID)
	{
		CString str;
		GetWindowText(str);
		str.Remove(',');
		sscanf(str, "%f", &f);
	}
	return f;
}

int CSTNumEdit::GetValueInt() const
{
	int f = (int)m_MinValue;
	if (IsValid() == VALID)
	{
		CString str;
		GetWindowText(str);
		str.Remove(',');
		sscanf(str, "%d", &f);
	}
	return f;
}


BOOL CSTNumEdit::SetValue(float val)
{
	if (val > m_MaxValue || val < m_MinValue) return FALSE;
	CString str, s;
	ConstructFormat(s, val);
	str.Format((LPCTSTR)s, val);
	if(m_bAutoInsertComma)
		InsertComma(str);
	else
		str.TrimLeft();
	SetWindowText(str);
	return TRUE;
}

BOOL CSTNumEdit::SetValueInt(int val)
{
	if (val > m_MaxValue || val < m_MinValue) return FALSE;
	CString str;
	str.Format("%d", val);
	if(m_bAutoInsertComma)
		InsertComma(str);
	else
		str.TrimLeft();
	SetWindowText(str);
	return TRUE;
}


int CSTNumEdit::IsValid() const
{
	CString str;
	GetWindowText(str);
	str.Remove(',');

	int res = VALID;
	float f;
	char lp[10];
	if ((str.GetLength() == 1) && ((str[0] == '+') || (str[0] == '-'))) 
		res = MINUS_PLUS;
	else if (str.GetLength() == 0)
		return res;
	else if (sscanf(str, "%f%s", &f, lp) != 1) 
		res = INVALID_CHAR;
	else if (f > m_MaxValue || f < m_MinValue) 
		res = OUT_OF_RANGE;

	if (m_Verbose && (res != VALID) && (res != MINUS_PLUS))
	{
		str.Empty();
		if (res & OUT_OF_RANGE) str += _T("������ ������ϴ�.\n");
		if (res & INVALID_CHAR) str += _T("���ڸ� �Է� �����մϴ�.\n");
		AfxMessageBox(str, MB_OK | MB_ICONSTOP);
		((CWnd*)this)->SetFocus();
	}
	return res;
}

int CSTNumEdit::IsValid(const CString &str) const
{
	int res = VALID;
	float f;
	char lp[10];
	if ((str.GetLength() == 1) && ((str[0] == '+') || (str[0] == '-'))) res = MINUS_PLUS;
	else if (sscanf(str, "%f%s", &f, lp) != 1) res = INVALID_CHAR;
	else if (f > m_MaxValue || f < m_MinValue) res = OUT_OF_RANGE;
	if (m_Verbose && (res != VALID) && (res != MINUS_PLUS))
	{
		CString msg;
		msg.Empty();
		if (res & OUT_OF_RANGE) msg += _T("Given value is out of range.\n");
		if (res & INVALID_CHAR) msg += _T("Characters must be a number.\n");
		AfxMessageBox(str, MB_OK | MB_ICONSTOP);
		((CWnd*)this)->SetFocus();
	}
	return res;
}


void CSTNumEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (nChar == ' ') return;
	int nStart, nEnd, nLen1, nLen2, nLen3;
	float oldValue;
	CString s;
	oldValue = GetValue();
TRACE("\n CSTNumEdit::OnChar oldValue=[%f]", oldValue);

	CEdit::OnChar(nChar, nRepCnt, nFlags);

	if(m_bNotDot)
	{

	}
	else
	{
		if(m_bAutoDot && nChar == 46)
		{
			GetWindowText(s);
			int nFind = s.Find(".");
			CString strSub = s.Left(nFind);
			nLen1 = atoi(strSub.GetBuffer(0));
			s.Delete(0, nFind+1);
			if(nLen1 > 0)
			{
				strSub.Format("%d", nLen1);
				s = strSub + s;
			}
			

			SetWindowText(s);
			SetSel(s.GetLength(), s.GetLength());
			return;
		}
	}
	
	int val = IsValid();
	if(val == OUT_OF_RANGE)
		val = VALID;
	switch (val)
	{
		case VALID:
		{
			if(!m_bAutoDot)
			{
				//�ڵ� Comma
				ConstructFormat(s, GetValue());
				GetWindowText(s);
				nLen1 = s.GetLength();
				GetSel(nStart, nEnd);
				SetValue(GetValue());
				GetWindowText(s);
				nLen2 = s.GetLength();
				//ĳ���� �Ű� �߰����� �����.
				if(nStart == nLen1)
					nLen3 = nLen2 - nLen1 + 1;
				else
					nLen3 = nLen2 - nLen1;
				SetSel(nStart+nLen3, nEnd+nLen3);
			}
			else
			{
				//�ڵ��Ҽ���ó��

				if(m_bNotDot)
				{
					GetWindowText(s);
					s.Remove('.');
					//ConstructFormat(s, GetValue());	
					SetWindowText(s);
					SetSel(s.GetLength(), s.GetLength());
					
					TRACE("\n CSTNumEdit::OnChar s=[%s]", s);
				}
				else
				{
					GetWindowText(s);
					s.Remove('.');
					if(s.GetLength() < 3)
						s = "0." + s;
					else
					{
						s.Insert(s.GetLength()-2, ".");
						if(s.GetAt(0) == '0')
							s.Delete(0);
					}
					SetWindowText(s);
					SetSel(s.GetLength(), s.GetLength());
				}
			}
			break;
		}
		case MINUS_PLUS: break;
		default:
			SetValue(oldValue);
			SetSel(0, -1);
			MSG msg;
			while (::PeekMessage(&msg, m_hWnd, WM_CHAR, WM_CHAR, PM_REMOVE));
			break;
	}	
}


BOOL CSTNumEdit::Verbose() const
{
	return m_Verbose;
}

void CSTNumEdit::Verbose(BOOL v)
{
	m_Verbose = v;
}

void CSTNumEdit::SetRange(float min, float max)
{
	m_MinValue = min;
	m_MaxValue = max;
}

void CSTNumEdit::GetRange(float & min, float & max) const
{
	min = m_MinValue;
	max = m_MaxValue;
}

void CSTNumEdit::SetDelta(float delta)
{
	m_Delta = delta;
}

float CSTNumEdit::GetDelta()
{
	return m_Delta;
}

void CSTNumEdit::ChangeAmount(int step)
{
	float f = GetValue() + step * m_Delta;
	if (f > m_MaxValue) f = m_MaxValue;
	else if (f < m_MinValue) f = m_MinValue;
	SetValue(f);
}

CString& CSTNumEdit::ConstructFormat(CString &str, float num)
{
	CString strPrec;

	str.Format("%20f", num);
	int n = str.Find('.');

	if (n >= 0)
	{
		strPrec = str.Mid(n+1, str.GetLength()-(n+1));
		int nLength = strPrec.GetLength();

		if(atoi(strPrec) > 0)
		{
			for(int i=nLength-1; i >= 0; i--)
			{
				if(strPrec[i] == '0')
					strPrec.SetAt(i, NULL);
				else
					break;
			}
			m_nNumberOfNumberAfterPoint = strlen((LPCTSTR)strPrec);
		}
		else
			m_nNumberOfNumberAfterPoint = 0;
	}

	if(m_nNumberOfNumberAfterPoint > 0)
		str.Format("%%20.2f");		
	else
		str.Format("%%20.0f");	

	return str;
}


void CSTNumEdit::InsertComma(CString &strData,UINT nIndent)
{
	BOOL bMinus = FALSE;
	int nSize,nLength;

	strData.Replace(",","");
	strData.TrimLeft();
	strData.TrimRight();

	if((nLength = strData.Find('.')) == -1)
		nLength=strData.GetLength();
	if(nLength<=0) 
		return;	
	
	if((strData.GetAt(0)=='-') || (strData.GetAt(0)=='+'))		
		bMinus=TRUE;

	nSize=nLength-nIndent;	
	while(nSize>0)
	{			
		if(bMinus)
		{
			if(nLength>4)
				strData.Insert(nSize,",");
		}
		else
			strData.Insert(nSize,",");
			
		nLength-=nIndent;
		nSize=nLength-nIndent;	
	}	
}

void CSTNumEdit::SetNumAfterPoint(int nPoint)
{
	m_nNumberOfNumberAfterPoint = nPoint;
}

void CSTNumEdit::SetAutoInsertComma(BOOL bSet)
{
	m_bAutoInsertComma = bSet;
}

void CSTNumEdit::SetAutoDot(BOOL bSet)
{
	m_bAutoDot = bSet;
}

void CSTNumEdit::SetNotDot(BOOL bSet)
{
	m_bNotDot = bSet;
}




void CSTNumEdit::SetInt(BOOL bSet)
{
	m_bInt = bSet;
}



void CSTNumEdit::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if(GetFocus() != this)
	{
		SetFocus();
	}
	else CEdit::OnLButtonDown(nFlags, point);
}

void CSTNumEdit::SetWndBkColor(long lBkColor)
{
	m_lBkColor = lBkColor;
	DeleteObject(m_hbr1);
	m_hbr1 = CreateSolidBrush(lBkColor);
}


void CSTNumEdit::OnSetfocus() 
{
	SetSel(0, -1);
}









void CSTNumEdit::SetBkColor(COLORREF color)
{
	DeleteObject(m_hbr1);
	DeleteObject(m_hbr2);
	m_lBkColor = color;
	m_hbr1 = CreateSolidBrush( color );
	m_hbr2 = CreateSolidBrush( color );
}

void CSTNumEdit::SetBoardColor(COLORREF color)
{
//	DeleteObject(m_hbr1);
//	DeleteObject(m_hbr2);
	m_clrBoardColor = color;
//	m_hbr1 = CreateSolidBrush( color );
//	m_hbr2 = CreateSolidBrush( color );
}




void CSTNumEdit::SetFont(char *font, int FontBold, BOOL FontItalic, int FontSize, COLORREF	FontColor)
{
	
	m_editFont.CreateFont(FontSize, 0, 0, 0, FontBold, FontItalic, FALSE, FALSE, 
		DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH, font);
	m_TextColor = FontColor;
}


void CSTNumEdit::OnPaint() 
{
	
	Default();
	
	
	if (m_fGotFocus) 
	{
		DrawBorder();
	} 
	else 
	{
		DrawBorder(false);
	}
}


void CSTNumEdit::OnSetFocus(CWnd* pOldWnd) 
{
	CEdit::OnSetFocus(pOldWnd);
	m_fGotFocus = true;
	DrawBorder();
}


void CSTNumEdit::OnMouseMove(UINT nFlags, CPoint point) 
{
	DrawBorder();
	CEdit::OnMouseMove(nFlags, point);
}


void CSTNumEdit::OnNcMouseMove(UINT nHitTest, CPoint point) 
{
	DrawBorder();
	CEdit::OnNcMouseMove(nHitTest, point);
}


void CSTNumEdit::OnSysColorChange() 
{
	CEdit::OnSysColorChange();
	m_clr3DFATS = GetSysColor(COLOR_3DFACE);
	m_clr3DLight = GetSysColor(COLOR_3DLIGHT);
	m_clr3DHilight = GetSysColor(COLOR_3DHILIGHT);
	m_clr3DShadow = GetSysColor(COLOR_3DSHADOW);
	m_clr3DDkShadow = GetSysColor(COLOR_3DDKSHADOW);
}


void CSTNumEdit::DrawBorder(bool fHot)
{
	CRect rcItem;
	DWORD dwExStyle = GetExStyle();
	CDC* pDC = GetDC();
	COLORREF clrBlack;
	int nBorderWidth = 0;
	int nLoop;
	
	m_pOldFont = (CFont *)pDC->SelectObject( &m_editFont );
	
	GetWindowRect(&rcItem);
	ScreenToClient(&rcItem);
	
	clrBlack = RGB(0, 0, 0);
	
	if (!IsWindowEnabled()) {
		fHot = true;
	}
	
	pDC->SetBkColor( m_lBkColor );//RGB(208,252,205) );
	pDC->SetTextColor( m_TextColor );//RGB(0,0,0) );
	
	if (dwExStyle & WS_EX_DLGMODALFRAME) {
		nBorderWidth += 3;
	}
	if (dwExStyle & WS_EX_CLIENTEDGE) {
		nBorderWidth += 2;
	}
	if (dwExStyle & WS_EX_STATICEDGE && !(dwExStyle & WS_EX_DLGMODALFRAME)) {
		nBorderWidth ++;
	}
	
	for (nLoop = 0; nLoop < nBorderWidth; nLoop++) {
		if(nLoop == 0)
			pDC->Draw3dRect(rcItem, m_clrBoardColor, m_clrBoardColor);
		else
			pDC->Draw3dRect(rcItem, m_lBkColor,m_lBkColor);
		rcItem.DeflateRect(1, 1);
	}

/*	
	for (nLoop = 0; nLoop < nBorderWidth; nLoop++) 
	{
		pDC->Draw3dRect(rcItem, m_clrBoardColor, m_clrBoardColor);
		rcItem.DeflateRect(1, 1);
	}
//
	if(nBorderWidth>=2)
	{
		rcItem.InflateRect(-1,-1);
		pDC->Draw3dRect(rcItem, m_clrBoardColor, m_clrBoardColor);
	}
*/
	pDC->SelectObject( m_pOldFont );
	m_editFont.DeleteObject();
	
	
	ReleaseDC(pDC);
}

HBRUSH CSTNumEdit::CtlColor(CDC* pDC, UINT nCtlColor) 
{
//>>
	if( nCtlColor == CTLCOLOR_STATIC )
	{
		pDC->SetBkColor( m_lBkColor );// RGB(199,226,226) );
		pDC->SetTextColor( m_TextColor );
		return  m_hbr1;
	}
//<<

	if(nCtlColor == CTLCOLOR_EDIT)
	{
		pDC->SetBkColor(m_lBkColor);
		pDC->SetTextColor( m_TextColor );
		return  m_hbr2;
	}
	return NULL;
}

















IMPLEMENT_DYNAMIC(CNumSpinCtrl, CSpinButtonCtrl)

CNumSpinCtrl::CNumSpinCtrl()
{
}

CNumSpinCtrl::~CNumSpinCtrl()
{
}


BEGIN_MESSAGE_MAP(CNumSpinCtrl, CSkinSpinButtonCtrl)
	//{{AFX_MSG_MAP(CNumSpinCtrl)
	ON_NOTIFY_REFLECT_EX(UDN_DELTAPOS, OnDeltapos)	// parent�� ó����
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNumSpinCtrl message handlers

void CNumSpinCtrl::SetPos(float val)
{
	CSkinSpinButtonCtrl::SetPos(500);
	CSTNumEdit *m_Edit = GetBuddy();
	if (m_Edit)
		if (m_Edit->IsKindOf(RUNTIME_CLASS(CSTNumEdit)))
			m_Edit->SetValue(val);
}

float CNumSpinCtrl::GetPos()
{
	CSTNumEdit *m_Edit = GetBuddy();
	if (m_Edit)
		if (m_Edit->IsKindOf(RUNTIME_CLASS(CSTNumEdit)))
			return m_Edit->GetValue();
	return 0.0f;
}

void CNumSpinCtrl::SetRange(float nLower, float nUpper)
{
	CSkinSpinButtonCtrl::SetRange(0, UD_MAXVAL);
	CSTNumEdit *m_Edit = GetBuddy();
	if (m_Edit)
		if (m_Edit->IsKindOf(RUNTIME_CLASS(CSTNumEdit)))
			m_Edit->SetRange(nLower, nUpper);
}

void CNumSpinCtrl::GetRange(float & lower, float & upper) const
{
	CSTNumEdit *m_Edit = GetBuddy();
	if (m_Edit)
		if (m_Edit->IsKindOf(RUNTIME_CLASS(CSTNumEdit)))
			m_Edit->GetRange(lower, upper);
}

CSTNumEdit* CNumSpinCtrl::GetBuddy() const
{
	return (CSTNumEdit *)CSkinSpinButtonCtrl::GetBuddy();
}

void CNumSpinCtrl::SetBuddy(CSTNumEdit * edit)
{
	CSkinSpinButtonCtrl::SetBuddy(edit);
	if (edit)
		if (edit->IsKindOf(RUNTIME_CLASS(CSTNumEdit)))
			edit->SetValue(0.0f);
}

BOOL CNumSpinCtrl::OnDeltapos(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	if ((pNMUpDown->iPos <= pNMUpDown->iDelta) ||
		(pNMUpDown->iPos >= 1000 - pNMUpDown->iDelta)) pNMUpDown->iPos = 500;
	CSTNumEdit *m_Edit = GetBuddy();
	if (m_Edit)
		if (m_Edit->IsKindOf(RUNTIME_CLASS(CSTNumEdit)))
			m_Edit->ChangeAmount(pNMUpDown->iDelta);
	*pResult = 0; 
	return FALSE; // handle allow to parent
}

float CNumSpinCtrl::GetDelta()
{
	CSTNumEdit *m_Edit = GetBuddy();
	if (m_Edit)
		if (m_Edit->IsKindOf(RUNTIME_CLASS(CSTNumEdit)))
			return m_Edit->GetDelta();
	return 0.0f;
}

void CNumSpinCtrl::SetDelta(float delta)
{
	CSTNumEdit *m_Edit = GetBuddy();
	if (m_Edit)
		if (m_Edit->IsKindOf(RUNTIME_CLASS(CSTNumEdit)))
			m_Edit->SetDelta(delta);
}
