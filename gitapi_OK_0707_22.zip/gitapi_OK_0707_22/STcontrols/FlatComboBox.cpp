// FlatComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "FlatComboBox.h"
#include "../TR/hrefer.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFlatComboBox

#define SIHWANG_INTERVAL	1000

static void PaintRect(CDC* pDC, int x, int y, int w, int h, COLORREF color)
{
	CBrush brush(color);
	CBrush* pOldBrush = pDC->SelectObject(&brush);
	pDC->PatBlt(x, y, w, h, PATCOPY);
	pDC->SelectObject(pOldBrush);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNAMIC(CFlatComboBox, CComboBox)
BEGIN_MESSAGE_MAP(CFlatComboBox, CComboBox)
	//{{AFX_MSG_MAP(CFlatComboBox)
	ON_WM_CREATE()
	ON_WM_PAINT()
    ON_WM_KILLFOCUS()
    ON_WM_SETFOCUS()
	ON_WM_DRAWITEM()
	ON_WM_MEASUREITEM()
	ON_WM_CTLCOLOR()
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
	ON_WM_TIMER()
	ON_MESSAGE(WM_MOUSELEAVE, OnMouseLeave)
	ON_CONTROL_REFLECT(CBN_DROPDOWN, OnDropDown)
	ON_CONTROL_REFLECT(CBN_CLOSEUP, OnCloseup)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlatComboBox::CFlatComboBox()
{
	m_bLBtnDown	= FALSE;
	m_bPainted	= FALSE;
	m_bHasFocus	= FALSE;
	m_bAutoComp = TRUE;
	m_nFontSize = -12;
	m_nFontSizeList = -12;
	m_nDropDownCount = 8;
	m_nItemHeight = 19;

	m_clrBtnHilite  = COLOR_BTN_HILIGHT;//::GetSysColor(COLOR_BTNHILIGHT);
	m_clrBtnShadow  = COLOR_BTN_SHADOW;//::GetSysColor(COLOR_BTNSHADOW);
	m_clrBtnFace    = COLOR_BTN_FATS;//::GetSysColor(COLOR_BTNFACE);
	m_clrBorder		= COLOR_BORDER;
	m_nOffset		= 17;//::GetSystemMetrics(SM_CXHTHUMB);

	m_clrBkColor	= RGB(189, 119, 236);
	m_clrTextColor = RGB(0, 0, 0);
	m_BkBrush.CreateSolidBrush(m_clrBkColor);
	m_bSihwang = FALSE;
	m_rcBtn.SetRectEmpty();

	m_bBlink = TRUE;
}

CFlatComboBox::~CFlatComboBox()
{
	m_BkBrush.DeleteObject();
}

int CFlatComboBox::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CComboBox::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_HandCursor = AfxGetApp()->LoadCursor(IDC_HAND_CURSOR_EX);
	m_NormalCursor = AfxGetApp()->LoadCursor(IDC_ARROW);

	m_Font.CreateFont(m_nFontSize, 0, 0, 0, FW_BOLD,0, 0,
					  0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
					  PROOF_QUALITY,TMPF_FIXED_PITCH, "����ü");

	m_FontList.CreateFont(m_nFontSizeList, 0, 0, 0, FW_NORMAL,0, 0,
					  0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
					  PROOF_QUALITY,TMPF_FIXED_PITCH, "����ü");

	SetFont(&m_FontList);

	return 0;
}

void CFlatComboBox::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	if (lpDrawItemStruct->itemID == -1)
		return;
	
	CDC dc;
	CRect rcTemp, rcItem = lpDrawItemStruct->rcItem;
	
	dc.Attach(lpDrawItemStruct->hDC);
	CFont *pOldFont = dc.SelectObject(&m_FontList);
	
	COLORREF crOldTextColor = dc.GetTextColor();
	COLORREF crOldBkColor = dc.GetBkColor();
	
	CString lpszText;
	GetLBText(lpDrawItemStruct->itemID, lpszText);

	//COLORREF clrText = dc.GetNearestColor(0x00FFFFFF & (~m_clrBkColor));
	//dc.SetTextColor(clrText); 
	
	if ((lpDrawItemStruct->itemAction | ODA_SELECT) &&
		(lpDrawItemStruct->itemState  & ODS_SELECTED))
	{
		dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
		dc.SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		dc.FillSolidRect(&rcItem, ::GetSysColor(COLOR_HIGHLIGHT));
	}
	else
		dc.FillSolidRect(&rcItem, crOldBkColor);
	
	if (m_bSihwang)
	{
		CRect rcItem1, rcItem2;
		CString strItem1, strItem2;
		int nPos = lpszText.Find("] ");
		strItem1 = lpszText.Mid(1, nPos-1);
		strItem2 = lpszText.Mid(nPos+2);
		strItem2.TrimLeft();

		rcItem1 = rcItem;
		rcItem2 = rcItem;
		rcItem1.right = rcItem1.left + 80;
		rcItem2.left = rcItem1.right + 4;

		CPen pen;
		COLORREF clrBlack = RGB(0, 0, 0);
		COLORREF clrWhite = RGB(189, 119, 236);

		if ((lpDrawItemStruct->itemAction | ODA_SELECT) &&
			(lpDrawItemStruct->itemState  & ODS_SELECTED))
			pen.CreatePen(PS_SOLID, 1, clrWhite);
		else
			pen.CreatePen(PS_SOLID, 1, clrBlack);

		CPen* pOldPen = dc.SelectObject(&pen);
		dc.MoveTo(rcItem1.right, rcItem1.top);
		dc.LineTo(rcItem1.right, rcItem1.bottom);
		dc.SelectObject(&pOldPen);
		
		dc.DrawText(strItem1, -1, &rcItem1, DT_CENTER | DT_SINGLELINE|DT_VCENTER|DT_NOPREFIX);
		dc.DrawText(strItem2, -1, &rcItem2, DT_LEFT | DT_SINGLELINE|DT_VCENTER|DT_NOPREFIX);
	}
	else
	{
		rcTemp = rcItem;
		rcTemp.left += 2;
		dc.DrawText(lpszText, -1, &rcTemp, DT_SINGLELINE|DT_VCENTER|DT_NOPREFIX);
	}
	
	dc.SetTextColor(crOldTextColor);
	dc.SetBkColor(crOldBkColor);
	
	dc.SelectObject(pOldFont);

	dc.Detach();
	
	//CComboBox::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CFlatComboBox::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	lpMeasureItemStruct->itemHeight = 18;
	
//	CComboBox::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}

void CFlatComboBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
/*
	if (m_strCmbItem.GetSize() <= 0) return;

	ASSERT(lpDrawItemStruct->CtlType == ODT_COMBOBOX);
	LPCTSTR lpszText = (LPCTSTR) lpDrawItemStruct->itemData;
	ASSERT(lpszText != NULL);

	CDC dc;
	
	dc.Attach(lpDrawItemStruct->hDC);
	CFont *pOldFont = dc.SelectObject(&m_FontList);
		 
	// Save these value to restore them when done drawing.
	COLORREF crOldTextColor = dc.GetTextColor();
	COLORREF crOldBkColor = dc.GetBkColor();
	
	// If this item is selected, set the background color 
	// and the text color to appropriate values. Erase
	// the rect by filling it with the background color.
	if ((lpDrawItemStruct->itemAction | ODA_SELECT) &&
		(lpDrawItemStruct->itemState  & ODS_SELECTED))
	{
		dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
		dc.SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		dc.FillSolidRect(&lpDrawItemStruct->rcItem, ::GetSysColor(COLOR_HIGHLIGHT));
	}
	else
		dc.FillSolidRect(&lpDrawItemStruct->rcItem, crOldBkColor);
	
	// Draw the text.
	CString		strItem = m_strCmbItem.GetAt(lpDrawItemStruct->itemID);
	dc.DrawText(	strItem,
					strItem.GetLength(),
					&lpDrawItemStruct->rcItem,
					DT_LEFT|DT_SINGLELINE|DT_VCENTER|DT_NOPREFIX
				);

	// Reset the background color and the text color back to their
	// original values.
	dc.SetTextColor(crOldTextColor);
	dc.SetBkColor(crOldBkColor);
	
	dc.SelectObject(pOldFont);
	dc.Detach();
*/	
}

void CFlatComboBox::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	ASSERT(lpMeasureItemStruct->CtlType == ODT_COMBOBOX);
	
	if (lpMeasureItemStruct->itemID != (UINT) -1)
	{
		LPCTSTR lpszText = (LPCTSTR) lpMeasureItemStruct->itemData;
		ASSERT(lpszText != NULL);
		CSize   sz;
		CDC*    pDC = GetDC();
		
		sz = pDC->GetTextExtent(lpszText);
		
		ReleaseDC(pDC);
		
		//lpMeasureItemStruct->itemHeight = sz.cy;
		lpMeasureItemStruct->itemHeight += 4; //m_nItemHeight;
	}
}

BOOL CFlatComboBox::OnChildNotify(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pLResult) 
{
	if (message == WM_DRAWITEM)
	{
		//OnPaint();
	}
	// TODO: Add your specialized code here and/or call the base class
	
	return CComboBox::OnChildNotify(message, wParam, lParam, pLResult);
}

void CFlatComboBox::OnKillFocus(CWnd* pNewWnd)
{
    CComboBox::OnSetFocus(pNewWnd);

	OnPaint();
}

void CFlatComboBox::OnSetFocus(CWnd* pOldWnd) 
{
	CComboBox::OnSetFocus(pOldWnd);
	
	OnPaint();
}

void CFlatComboBox::OnPaint() 
{
	ModifyStyleEx (WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE, 0, SWP_FRAMECHANGED);
	
	Default();

	CPoint pt;
	GetCursorPos(&pt);

	CRect rcItem;
	GetWindowRect(&rcItem);

	if (GetDroppedState())
		DrawCombo(pressed, m_clrBtnShadow, m_clrBtnHilite );
	else if ((rcItem.PtInRect(pt)) || m_bHasFocus)
		DrawCombo( raised, m_clrBtnShadow, m_clrBtnHilite );
	else
		DrawCombo( normal, m_clrBtnFace, m_clrBtnFace );
}

void CFlatComboBox::DrawButton(CDC *pDC, BYTE State, CRect BorderRect)
{
	CBrush br(RGB(0, 0, 0));  
	CRect bdrR = BorderRect;
	//bdrR.left--;
	//bdrR.right++;

	COLORREF clrTopLeft, clrBottomRight;

	int Red, Green, Blue, Diff;
	Diff = 40;
	Red = GetRValue(m_clrBtnFace);
	Green = GetGValue(m_clrBtnFace);
	Blue = GetBValue(m_clrBtnFace);

	pDC->FillSolidRect(&bdrR, m_clrBtnFace);

	pDC->Draw3dRect(bdrR, m_clrBorder, m_clrBorder);
 	//pDC->FrameRect(bdrR, &br);

	InflateRect(bdrR, -1, -1);
	if (State == pressed) 
	{	
		clrTopLeft     = RGB(max(0, Red-Diff), max(0, Green-Diff), max(0, Blue-Diff));
		clrBottomRight = RGB(min(255, Red+Diff), min(255, Green+Diff), min(255, Blue+Diff));
	}
	else
	{
		clrTopLeft     = RGB(min(255, Red+Diff), min(255, Green+Diff), min(255, Blue+Diff));
		clrBottomRight = RGB(max(0, Red-Diff), max(0, Green-Diff), max(0, Blue-Diff));
	}

	pDC->Draw3dRect(bdrR, clrTopLeft, clrBottomRight);
	InflateRect(bdrR, -1, -1);
	pDC->Draw3dRect(bdrR, clrTopLeft, clrBottomRight);
}

void CFlatComboBox::DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight)
{
	CRect rcItem;
	GetClientRect(rcItem);

	CWindowDC dc(this);					

	//if (GetStyle() & CBS_DROPDOWNLIST)
	{
		dc.SetBkMode(TRANSPARENT);
		dc.FillSolidRect(&rcItem, m_clrBkColor);
	}

	CString strText;
	GetWindowText(strText);
	CRect rcText = rcItem;
	rcText.right -= m_nOffset;
	rcText.left += 4;

	CFont *pOldFont = dc.SelectObject(&m_FontList);
	dc.SetBkMode(TRANSPARENT);
	//COLORREF clrText = dc.GetNearestColor(0x00FFFFFF & (~m_clrBkColor));
	dc.SetTextColor(m_clrTextColor);//RGB(0, 0, 0));
	dc.DrawText(strText, rcText, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX);
	dc.SelectObject(pOldFont);

	CPen penBlack(PS_SOLID, 1, RGB(0,0,0));
	CRect rcBorder(rcItem);
	dc.Draw3dRect(rcBorder, m_clrBorder, m_clrBorder);

	// Cover up dark 3D shadow on drop arrow.
	//rcItem.DeflateRect(1,1);
	rcItem.left = rcItem.right-m_nOffset;
	
	CBrush		brWhite(RGB(189, 119, 236)); 
	CBrush		brBlack(RGB(0, 0, 0)); 
	int			nOffset = 0;

	int	X = rcItem.left+5;
	int	Y = (rcItem.bottom/2)-2;

	m_rcBtn = rcItem;
	m_rcBtn.left = m_rcBtn.right - m_nOffset;

	DrawButton(&dc, eState == pressed ? pressed : normal, m_rcBtn);
	
	if (eState == pressed) 
	{
		X++;
		Y++;
	}

	int Red, Green, Blue, Diff;
	Diff = 50;
	Red = GetRValue(m_clrBkColor);
	Green = GetGValue(m_clrBkColor);
	Blue = GetBValue(m_clrBkColor);
	
	//COLORREF clrHilight = RGB(min(255, Red+Diff), min(255, Green+Diff), min(255, Blue+Diff));
	//COLORREF clrShadow = RGB(max(0, Red-Diff), max(0, Green-Diff), max(0, Blue-Diff));
	COLORREF clrShadow  = RGB(max(0, Red-50), max(0, Green-50), max(0, Blue-50));
	COLORREF clrHilight = RGB(min(255, Red+80), min(255, Green+80), min(255, Blue+80));

	CPoint P1[3];
	P1[0] = CPoint(X,   Y);
	P1[1] = CPoint(X+6, Y);
	P1[2] = CPoint(X+3, Y+3);

	CPen* pOldPen = dc.SelectObject(&penBlack);
	CBrush* pOldBr = dc.SelectObject(&brBlack);
	dc.Polygon(P1, 3);

	dc.SelectObject(pOldPen);
	dc.SelectObject(pOldBr);
}
/****************************************************************/
/* ��  ��  ��  : CFlatComboBox::OnDestroy()						*/
/* ��      ��  : ���� ó��										*/
/****************************************************************/
void CFlatComboBox::OnDestroy() 
{
	CComboBox::OnDestroy();

	m_Font.DeleteObject();
	m_FontList.DeleteObject();
}

/****************************************************************/
/* ��  ��  ��  : CFlatComboBox::OnDropDown()					*/
/* ��      ��  : ����Ʈ�� ���� ó��								*/
/****************************************************************/
void CFlatComboBox::OnDropDown()
{
	int nCount = GetCount();
	if (nCount > m_nDropDownCount) nCount = m_nDropDownCount;
	if (nCount < 1) nCount = 1;

	CRect rc;
	GetWindowRect(&rc);

	int nHeight = m_nItemHeight * nCount + rc.Height() + 2;
	SetWindowPos(NULL,0,0,rc.Width(),nHeight, SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOREDRAW|SWP_HIDEWINDOW);
	SetWindowPos(NULL,0,0,0,0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOREDRAW|SWP_SHOWWINDOW);
}

void CFlatComboBox::OnCloseup() 
{
	Invalidate();
}

void CFlatComboBox::SetBkColor(COLORREF clrBkColor)
{
	m_clrBkColor = clrBkColor;

	m_BkBrush.DeleteObject();
	m_BkBrush.CreateSolidBrush(m_clrBkColor);
}

void CFlatComboBox::BlinkComboBox()
{
	m_bBlink = TRUE;
	m_nTimeOut = 5000;
	KillTimer(1);
	SetTimer(1, 500, NULL);
	Invalidate();
}

HBRUSH CFlatComboBox::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr;

	switch (nCtlColor) 
	{
	case CTLCOLOR_EDIT:
		{
			//pDC->SetBkColor(m_clrBkColor);
			//pDC->SetTextColor(RGB(189, 119, 236));
			//pDC->SetTextColor(RGB(0, 0, 0));
			//hbr = (HBRUSH)m_BkBrush;
		}
		break;
	case CTLCOLOR_LISTBOX:
		{
			//pDC->SetBkColor(m_clrBkColor);
			//pDC->SetTextColor(RGB(189, 119, 236));
			//pDC->SetTextColor(RGB(0, 0, 0));
			hbr = (HBRUSH)m_BkBrush;
		}
		break;
	default:
		{
			hbr = CComboBox::OnCtlColor(pDC, pWnd, nCtlColor);
		}
	}


	return hbr;
}

void CFlatComboBox::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (m_bSihwang)
	{
		CPoint pt;
		GetCursorPos(&pt);
		ScreenToClient(&pt);
		if (!m_rcBtn.PtInRect(pt))
		{
			CWnd* pParent;
			pParent = GetParent();
			pParent->SendMessage(WM_COMMAND, MAKEWPARAM(GetDlgCtrlID(), CBN_SELENDOK), (LPARAM)GetSafeHwnd());
			return;
		}
		else
			CComboBox::OnLButtonDown(nFlags, point);
	}
	else
		CComboBox::OnLButtonDown(nFlags, point);
}

BOOL CFlatComboBox::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	BOOL bRet = CComboBox::OnSetCursor(pWnd, nHitTest, message);;

	if (m_bSihwang)
	{
		CPoint pt;
		GetCursorPos(&pt);
		ScreenToClient(&pt);
		::SetCursor(m_HandCursor);
	}
	else
	{
		SetCursor(LoadCursor(NULL, IDC_ARROW));
		//::SetCursor(m_NormalCursor);
	}
	return bRet;
}

LRESULT CFlatComboBox::OnMouseLeave(WPARAM wparam, LPARAM lparam)
{
	::SetCursor(m_NormalCursor);
	return 0;
}

void CFlatComboBox::OnTimer(UINT nIDEvent) 
{
	m_nTimeOut -= SIHWANG_INTERVAL;
	
	if (m_bBlink)
	{
		m_clrBkColor = RGB(0, 0, 128);
		m_clrTextColor = RGB(189, 119, 236);
	}
	else
	{
		m_clrBkColor = RGB(189, 119, 236);
		m_clrTextColor = RGB(0, 0, 0);
	}

	m_bBlink = !m_bBlink;
	Invalidate();

	if (m_nTimeOut <= 0)
	{
		m_clrBkColor = RGB(189, 119, 236);
		m_clrTextColor = RGB(0, 0, 0);
		Invalidate();
		KillTimer(1);
	}
	
	CWnd::OnTimer(nIDEvent);
}
