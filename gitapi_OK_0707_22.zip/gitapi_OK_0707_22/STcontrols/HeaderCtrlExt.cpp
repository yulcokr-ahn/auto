// HeaderCtrlExt.cpp : implementation file
//
// 2001.10.12 cyber.dream.sukim

#include "stdafx.h"
#include "HeaderCtrlExt.h"
#include "..\include\hrefer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlExt

CHeaderCtrlExt::CHeaderCtrlExt()
{
	m_bClicked = FALSE;
	m_clrHilight = ::GetSysColor(COLOR_BTNHILIGHT);
	m_clrShadow = ::GetSysColor(COLOR_BTNSHADOW);
	m_clrFace	 = COLOR_HEADER;
	m_nHeight = 19;

	m_textfont.CreateFont(12, 0, 0, 0, FALSE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, 
							CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH|FF_DONTCARE, "����ü");
}

CHeaderCtrlExt::~CHeaderCtrlExt()
{
	m_textfont.DeleteObject();
}

IMPLEMENT_DYNAMIC(CHeaderCtrlExt, CHeaderCtrl)

BEGIN_MESSAGE_MAP(CHeaderCtrlExt, CHeaderCtrl)
	//{{AFX_MSG_MAP(CHeaderCtrlExt)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
	ON_MESSAGE(HDM_LAYOUT, OnLayout)
END_MESSAGE_MAP()


LRESULT CHeaderCtrlExt::OnLayout(WPARAM wParam, LPARAM lParam)
{
	LPHDLAYOUT lphdlayout = (LPHDLAYOUT)lParam;

	LRESULT lResult = CHeaderCtrl::DefWindowProc(HDM_LAYOUT, 0, lParam);

	if(m_nHeight > 0)
		lphdlayout->pwpos->cy = 17;//m_nHeight;

	return lResult;
}

void CHeaderCtrlExt::SetColours(COLORREF Colour)
{
	m_clrFace = Colour;
	Invalidate();
}

/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlExt message handlers

void CHeaderCtrlExt::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_bClicked = TRUE;
	m_SelPoint = point;
	CHeaderCtrl::OnLButtonDown(nFlags, point);
	Invalidate();
}

void CHeaderCtrlExt::OnLButtonUp(UINT nFlags, CPoint point) 
{

	m_bClicked = FALSE;
	Invalidate();
	CHeaderCtrl::OnLButtonUp(nFlags, point);
}

void CHeaderCtrlExt::OnPaint() 
{
    PAINTSTRUCT ps;
    CDC* pDC = BeginPaint(&ps);
	CFont* old_font = pDC->SelectObject(&m_textfont);

	CRect rcItem;
	GetClientRect(&rcItem);
	pDC->FillSolidRect(&rcItem, m_clrFace);

	COLORREF crGridLine = COLOR_LIST_LINE;
	CPen pen(PS_SOLID, 1, crGridLine);
	CPen* pPen = pDC->SelectObject(&pen);
	pDC->MoveTo(rcItem.left, rcItem.bottom-1);
	pDC->LineTo(rcItem.right, rcItem.bottom-1);
	pDC->SelectObject(pPen);

	UINT count = GetItemCount();

	for(UINT i=0; i < count; i++)
	{
		CRect   rcItem;
		HDITEM	hdi;
		TCHAR   lpBuffer[256];

		hdi.mask = HDI_TEXT;
		hdi.pszText = lpBuffer;
		hdi.cchTextMax = 256;

		GetItem(i, &hdi);
		GetItemRect(i, rcItem);

		if(m_bClicked && PtInRect(rcItem, m_SelPoint))
		{
			pDC->Draw3dRect(rcItem, m_clrShadow,  m_clrFace);
			rcItem.OffsetRect(1,1);
		}
		else
		{
			//pDC->Draw3dRect(rcItem, m_clrHilight, m_clrShadow);
			COLORREF crGridLine = COLOR_LIST_LINE;
			CPen pen(PS_SOLID, 1, crGridLine);
			CPen* pPen = pDC->SelectObject(&pen);
			pDC->MoveTo(rcItem.right, rcItem.top);
			pDC->LineTo(rcItem.right, rcItem.bottom);
		}
		//rcItem.DeflateRect(2,2);

		pDC->SetTextColor(RGB(0,0,0));
		pDC->SetBkColor(m_clrFace);
		if (rcItem.Width() > 0)
			pDC->DrawText(hdi.pszText, &rcItem, DT_SINGLELINE|DT_VCENTER|DT_CENTER|DT_END_ELLIPSIS);
	}
	
	pDC->SelectObject(old_font);
    EndPaint(&ps);
}

BOOL CHeaderCtrlExt::OnEraseBkgnd(CDC* pDC)
{
	CRect rcItem;

	GetClientRect(&rcItem);
	pDC->FillSolidRect(&rcItem, m_clrFace);

	return TRUE;
}

void CHeaderCtrlExt::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CHeaderCtrl::OnMouseMove(nFlags, point);
}

void CHeaderCtrlExt::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CHeaderCtrl::OnLButtonDblClk(nFlags, point);
}
