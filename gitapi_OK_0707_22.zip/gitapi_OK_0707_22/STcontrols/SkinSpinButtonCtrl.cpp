#include "stdafx.h"
#include "SkinSpinButtonCtrl.h"

#pragma warning(disable:4786)
#include <map>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace std;
typedef map <HWND,HWND> HWNDMAP;
static HWNDMAP gHandleMap;


static LRESULT CALLBACK FilterBuddyMsgProc(int code,WPARAM wParam,  LPARAM lParam );
static HHOOK ghHook=NULL;

/////////////////////////////////////////////////////////////////////////////
// CSkinSpinButtonCtrl

CSkinSpinButtonCtrl::CSkinSpinButtonCtrl():m_hWndBuddy(NULL),
				   m_bVertical(true),m_nSpinAlign(Outside),
				   m_bDefaultDirection(true),m_bBuddyIsEdit(false),
				   m_rctIsPressed(0,0,0,0),m_bXPX_ACTIVESpinPressed(false),
				   m_bAutoDisable(true)
{
	
}

CSkinSpinButtonCtrl::~CSkinSpinButtonCtrl()
{
}


BEGIN_MESSAGE_MAP(CSkinSpinButtonCtrl, CSpinButtonCtrl)
	//{{AFX_MSG_MAP(CSkinSpinButtonCtrl)
	ON_NOTIFY_REFLECT_EX(UDN_DELTAPOS, OnDeltapos)
	ON_WM_LBUTTONDOWN()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONUP()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSkinSpinButtonCtrl message handlers

void CSkinSpinButtonCtrl::PreSubclassWindow() 
{
	COLORREF clr=RGB(181,138,255); //::GetSysColor(COLOR_3DDKSHADOW);
	m_penDarkShadow=::CreatePen(PS_SOLID,0,clr);	

	clr=RGB(156,97,247); //::GetSysColor(COLOR_BTNSHADOW);
	m_penShadow=::CreatePen(PS_SOLID,0,clr);

	clr=RGB(90,28,189); //::GetSysColor(COLOR_3DHILIGHT);
	m_penLight=::CreatePen(PS_SOLID,0,clr);

	clr=RGB(156,97,247); //::GetSysColor(COLOR_3DLIGHT);
	m_penLightShadow=::CreatePen(PS_SOLID,0,clr);

	clr=RGB(181,138,255); //::GetSysColor(COLOR_BTNFACE);
	m_penButtonFATS=::CreatePen(PS_SOLID,0,clr);

	Init();
	CSpinButtonCtrl::PreSubclassWindow();
}

void CSkinSpinButtonCtrl::OnPaint() 
{

	CPaintDC dc(this); 
	
	CRect rc;
	GetClientRect(&rc);
	COLORREF crBk = RGB(123,48,214);
	dc.FillSolidRect(&rc, crBk); 


	COLORREF crOverBk = RGB(222,231,173);
	CRect rcTemp = rc;
	rcTemp.bottom = rc.top + rc.Height()/2;
CRect m_rUp = rcTemp;
	
	// ��ȭ��ǥ 
	rcTemp.DeflateRect(1, 1);
	rcTemp.OffsetRect(0, -1);

	CPen pen;
	pen.CreatePen(PS_SOLID, 1, RGB(200,150,255));
	CPen* pOldPen = dc.SelectObject(&pen);
	
	dc.MoveTo(rcTemp.left,  rcTemp.bottom-0);
	dc.LineTo(rcTemp.right, rcTemp.bottom-0);

	int i,y;
	for(i=1, y=rcTemp.bottom-1; y>rcTemp.top; y--, i++)
	{
		dc.MoveTo(rcTemp.left + i,  y);
		dc.LineTo(rcTemp.right - i, y);
	}

	// �Ʒ�ȭ��ǥ 
	rcTemp = rc;
	rcTemp.top = rc.top + rc.Height()/2;
CRect	m_rDown = rcTemp;
	rcTemp.DeflateRect(1, 1);
	rcTemp.OffsetRect(0, 1);

	dc.MoveTo(rcTemp.left,  rcTemp.top + 0);
	dc.LineTo(rcTemp.right, rcTemp.top + 0);
	for(i=1, y=rcTemp.top+1; y<rcTemp.bottom; y++, i++)
	{
		dc.MoveTo(rcTemp.left + i,  y);
		dc.LineTo(rcTemp.right - i, y);
	}

	// ��� �� 
//	dc.MoveTo(m_rUp.left,  m_rUp.bottom);
//	dc.LineTo(m_rUp.right, m_rUp.bottom);

	dc.SelectObject(pOldPen);
	pen.DeleteObject();




		if(::IsWindow(m_hWndBuddy) && m_nSpinAlign!=Outside )
		{
			if(m_nSpinAlign == OnRightInside)
			{
				::SelectObject(dc.m_hDC,m_penShadow);
				dc.MoveTo(m_rctClient.left,m_rctClient.top);
				dc.LineTo(m_rctClient.right,m_rctClient.top);

				::SelectObject(dc.m_hDC,m_penDarkShadow);
				dc.MoveTo(m_rctClient.left,m_rctClient.top+1);
				dc.LineTo(m_rctClient.right-1,m_rctClient.top+1);

				::SelectObject(dc.m_hDC,m_penLight);
				dc.LineTo(m_rctClient.right-1,m_rctClient.bottom-1);
				dc.LineTo(m_rctClient.left-1,m_rctClient.bottom-1);
			}
			else
			{
				::SelectObject(dc.m_hDC,m_penShadow);
				dc.MoveTo(m_rctClient.right,m_rctClient.top);
				dc.LineTo(m_rctClient.left,m_rctClient.top);
				dc.LineTo(m_rctClient.left,m_rctClient.bottom);

				::SelectObject(dc.m_hDC,m_penDarkShadow);
				dc.MoveTo(m_rctClient.right,m_rctClient.top+1);
				dc.LineTo(m_rctClient.left+1,m_rctClient.top+1);
				dc.LineTo(m_rctClient.left+1,m_rctClient.top+1);
				dc.LineTo(m_rctClient.left+1,m_rctClient.bottom-1);

				::SelectObject(dc.m_hDC,m_penLight);
				dc.LineTo(m_rctClient.right+1,m_rctClient.bottom-1);
			}

		}





/*	
	if(m_bAutoDisable)
	{
		CPaintDC RealDC(this);
		CRect rctPaint=m_rctClient;




		CRect rcPaintUp,rcPaintDown;

		CDC dc;
		CBitmap bmpMem,*pOldMemBmp;
		dc.CreateCompatibleDC(&RealDC);
		bmpMem.CreateCompatibleBitmap(&RealDC,rctPaint.Width(),rctPaint.Height());
		pOldMemBmp=dc.SelectObject(&bmpMem);
		dc.FillSolidRect(&rctPaint,RGB(181,138,255) );


		if(::IsWindow(m_hWndBuddy) && m_nSpinAlign!=Outside )
		{
			rctPaint.top+=2;
			rctPaint.bottom-=2;
			if(m_nSpinAlign == OnRightInside)
				rctPaint.right-=2;
			else
				rctPaint.left+=2;
		}

		rcPaintUp= rctPaint;
----------
if(m_bVertical)
{
	rcPaintUp.bottom=rcPaintUp.top+rcPaintUp.Height()/2;
	rcPaintDown=rctPaint;
	rcPaintDown.top=rcPaintDown.bottom-rcPaintUp.Height();

	dc.DrawFrameControl(&rcPaintUp,DFC_SCROLL,DFCS_SCROLLUP);
	dc.DrawFrameControl(&rcPaintDown,DFC_SCROLL,DFCS_SCROLLDOWN);

}
else
{
	rcPaintUp.right=rcPaintUp.left+rcPaintUp.Width()/2;
	rcPaintDown=rctPaint;
	rcPaintDown.left=rcPaintDown.right-rcPaintUp.Width();

	dc.DrawFrameControl(&rcPaintUp,DFC_SCROLL,DFCS_SCROLLLEFT);
	dc.DrawFrameControl(&rcPaintDown,DFC_SCROLL,DFCS_SCROLLRIGHT);

}
---------


	COLORREF crOverBk = RGB(222,231,173);
	CRect rcTemp = m_rctClient;
	rcTemp.bottom = m_rctClient.top + m_rctClient.Height()/2;
CRect m_rUp = rcTemp;
	
	// ��ȭ��ǥ 
	rcTemp.DeflateRect(1, 1);
	rcTemp.OffsetRect(0, -1);

	CPen pen;
	pen.CreatePen(PS_SOLID, 1, RGB(181,138,255));
	CPen* pOldPen = dc.SelectObject(&pen);
	
	dc.MoveTo(rcTemp.left,  rcTemp.bottom-1);
	dc.LineTo(rcTemp.right, rcTemp.bottom-1);

	int i,y;
	for(i=1, y=rcTemp.bottom-1; y>rcTemp.top; y--, i++)
	{
		dc.MoveTo(rcTemp.left + i,  y);
		dc.LineTo(rcTemp.right - i, y);
	}

	// �Ʒ�ȭ��ǥ 
	rcTemp = m_rctClient;
	rcTemp.top = m_rctClient.top + m_rctClient.Height()/2;
CRect	m_rDown = rcTemp;
	rcTemp.DeflateRect(1, 1);
	rcTemp.OffsetRect(0, 1);

	dc.MoveTo(rcTemp.left,  rcTemp.top + 1);
	dc.LineTo(rcTemp.right, rcTemp.top + 1);
	for(i=1, y=rcTemp.top+1; y<rcTemp.bottom; y++, i++)
	{
		dc.MoveTo(rcTemp.left + i,  y);
		dc.LineTo(rcTemp.right - i, y);
	}

	// ��� �� 
	dc.MoveTo(m_rUp.left,  m_rUp.bottom);
	dc.LineTo(m_rUp.right, m_rUp.bottom);

	dc.SelectObject(pOldPen);
	pen.DeleteObject();






		if(::IsWindow(m_hWndBuddy) && m_nSpinAlign!=Outside )
		{
			if(m_nSpinAlign == OnRightInside)
			{
				::SelectObject(dc.m_hDC,m_penShadow);
				dc.MoveTo(m_rctClient.left,m_rctClient.top);
				dc.LineTo(m_rctClient.right,m_rctClient.top);

				::SelectObject(dc.m_hDC,m_penDarkShadow);
				dc.MoveTo(m_rctClient.left,m_rctClient.top+1);
				dc.LineTo(m_rctClient.right-1,m_rctClient.top+1);

				::SelectObject(dc.m_hDC,m_penLight);
				dc.LineTo(m_rctClient.right-1,m_rctClient.bottom-1);
				dc.LineTo(m_rctClient.left-1,m_rctClient.bottom-1);
			}
			else
			{
				::SelectObject(dc.m_hDC,m_penShadow);
				dc.MoveTo(m_rctClient.right,m_rctClient.top);
				dc.LineTo(m_rctClient.left,m_rctClient.top);
				dc.LineTo(m_rctClient.left,m_rctClient.bottom);

				::SelectObject(dc.m_hDC,m_penDarkShadow);
				dc.MoveTo(m_rctClient.right,m_rctClient.top+1);
				dc.LineTo(m_rctClient.left+1,m_rctClient.top+1);
				dc.LineTo(m_rctClient.left+1,m_rctClient.top+1);
				dc.LineTo(m_rctClient.left+1,m_rctClient.bottom-1);

				::SelectObject(dc.m_hDC,m_penLight);
				dc.LineTo(m_rctClient.right+1,m_rctClient.bottom-1);
			}

		}

		switch (m_nSpinState)
		{
			case DisableRight:
								if(m_bDefaultDirection)
								{
									if(m_bVertical)
										DisableRect(dc,rcPaintDown);
									else
										DisableRect(dc,rcPaintUp);
								}
								else
								{
									if(m_bVertical)
										DisableRect(dc,rcPaintUp);
									else
										DisableRect(dc,rcPaintDown);
								}

								break;
			case DisableLeft:
								if(m_bDefaultDirection)
								{
									if(m_bVertical)
										DisableRect(dc,rcPaintUp);
									else
										DisableRect(dc,rcPaintDown);
								
								}
								else
								{
									if(m_bVertical)
										DisableRect(dc,rcPaintDown); 
									else
										DisableRect(dc,rcPaintUp);

								}
								break;
		}
---------
		if(m_bXPX_ACTIVESpinPressed)
		{
			if(m_rctIsPressed.IsRectEmpty())
			{
				CPoint pt=::GetMessagePos();
				ScreenToClient(&pt);
				if(rcPaintUp.PtInRect(pt))
				{
					m_rctIsPressed = rcPaintUp;
				}
				else
				{
					if(rcPaintDown.PtInRect(pt))
					{
						m_rctIsPressed = rcPaintDown; 
					}
				}

			}
			DrawPressedRect(dc,m_rctIsPressed);
			m_bXPX_ACTIVESpinPressed=false;

		}


		RealDC.BitBlt(m_rctClient.left,m_rctClient.top,m_rctClient.Width(),
			m_rctClient.Height(),&dc,m_rctClient.left,m_rctClient.top,SRCCOPY);

		dc.SelectObject(pOldMemBmp);
		dc.DeleteDC();
		bmpMem.DeleteObject();

	}
	else
	{
		Default();
		return;
	}

*/



}
void CSkinSpinButtonCtrl::DisableRect(CDC &dc, const CRect &rectDisable) const
{
	CBitmap bmpMask,*pBmpBeforeMask;
	CBrush	brushMask,*pOldBrush;
	COLORREF clrOldBack,clrOldText;
	CDC memDC;
	memDC.CreateCompatibleDC(&dc);

	
	CRect rctClient;
	CRect rectToDisable=rectDisable;
	GetClientRect(&rctClient);

	bmpMask.CreateBitmap(rctClient.Width(),rctClient.Height(),1,1,NULL);
	pBmpBeforeMask=memDC.SelectObject(&bmpMask);

	CDC dcSrc;
	dcSrc.CreateCompatibleDC(&dc);
	CBitmap bmpSrc,*pBmpBeforeSrc;
	
	bmpSrc.CreateCompatibleBitmap(&dc,rctClient.Width(),rctClient.Height());
	pBmpBeforeSrc=dcSrc.SelectObject(&bmpSrc);

	clrOldBack=dc.SetBkColor(RGB(0,0,0));

	memDC.BitBlt(rectToDisable.left,rectToDisable.top,
		rectToDisable.Width(),rectToDisable.Height(),&dc,
		rectToDisable.left,rectToDisable.top,SRCCOPY);

	dcSrc.BitBlt(rectToDisable.left,rectToDisable.top,
		rectToDisable.Width(),rectToDisable.Height(),&dc,
		rectToDisable.left,rectToDisable.top,SRCCOPY);

	CBrush brushSrc;
	rectToDisable.DeflateRect(1,1);

	brushSrc.CreateSolidBrush(RGB(181,138,255)); //::GetSysColor(COLOR_3DSHADOW));
	dcSrc.SelectObject(&brushSrc);
	dcSrc.SetBkColor(RGB(255,255,255));
	dcSrc.SetTextColor(RGB(0,0,0));
	dcSrc.BitBlt(rectToDisable.left,rectToDisable.top,
		rectToDisable.Width(),rectToDisable.Height(),&memDC,
		rectToDisable.left,rectToDisable.top,0x00E20746L);

	brushMask.CreateSolidBrush(RGB(181,138,255)); //::GetSysColor(COLOR_3DHILIGHT));
	pOldBrush = dc.SelectObject(&brushMask);
	dc.SetBkColor(RGB(255,255,255));
	clrOldText=dc.SetTextColor(RGB(0,0,0));
	dc.BitBlt(rectToDisable.left+1,rectToDisable.top+1,
		rectToDisable.Width()-1,rectToDisable.Height()-1,&memDC,
		rectToDisable.left,rectToDisable.top,0x00E20746L);

	dcSrc.SetBkColor(RGB(181,138,255) ); //GetSysColor(COLOR_BTNFACE));
	memDC.BitBlt(rectToDisable.left,rectToDisable.top,
		rectToDisable.Width(),rectToDisable.Height(),&dcSrc,
		rectToDisable.left,rectToDisable.top,SRCCOPY);

	dc.BitBlt(rectToDisable.left,rectToDisable.top,
		rectToDisable.Width(),rectToDisable.Height(),&dcSrc,
		rectToDisable.left,rectToDisable.top,SRCINVERT);

	dc.BitBlt(rectToDisable.left,rectToDisable.top,
		rectToDisable.Width(),rectToDisable.Height(),&memDC,
		rectToDisable.left,rectToDisable.top,SRCAND);
	dc.BitBlt(rectToDisable.left,rectToDisable.top,
		rectToDisable.Width(),rectToDisable.Height(),&dcSrc,
		rectToDisable.left,rectToDisable.top,SRCINVERT);

	memDC.SelectObject(pBmpBeforeMask);
	dcSrc.SelectObject(pBmpBeforeSrc);

	dc.SetBkColor(clrOldBack);
	dc.SetTextColor(clrOldText);
	dc.SelectObject(pOldBrush);

	bmpMask.DeleteObject();
	memDC.DeleteDC();
	dcSrc.DeleteDC();
}

void CSkinSpinButtonCtrl::DrawPressedRect(CDC &dc, const CRect &rctToDown) const
{

	CRect 	rctDown=rctToDown;
	HPEN hOldPen;
	
	
	dc.BitBlt(rctDown.left+1,rctDown.top+1,
	rctDown.Width()-1,rctDown.Height()-1,&dc,
	rctDown.left,rctDown.top,SRCCOPY);

	rctDown.bottom-=1;

	hOldPen = (HPEN)SelectObject(dc.m_hDC,m_penShadow);
	dc.MoveTo(rctDown.left,rctDown.bottom-1);
	dc.LineTo(rctDown.left,rctDown.top);
	dc.LineTo(rctDown.right-1,rctDown.top);
	
	SelectObject(dc.m_hDC,m_penLight);
	dc.LineTo(rctDown.right-1,rctDown.bottom);
	dc.LineTo(rctDown.left-1,rctDown.bottom);


	SelectObject(dc.m_hDC,m_penDarkShadow);
	dc.MoveTo(rctDown.left+1,rctDown.bottom-2);
	dc.LineTo(rctDown.left+1,rctDown.top+1);
	dc.LineTo(rctDown.right-2,rctDown.top+1);

	SelectObject(dc.m_hDC,m_penLightShadow);
	dc.LineTo(rctDown.right-2,rctDown.bottom-1);
	dc.LineTo(rctDown.left,rctDown.bottom-1);

	SelectObject(dc.m_hDC,m_penButtonFATS);
	dc.MoveTo(rctDown.left+2,rctDown.bottom-2);
	dc.LineTo(rctDown.left+2,rctDown.top+2);
	dc.LineTo(rctDown.right-2,rctDown.top+2);
	
	SelectObject(dc.m_hDC,hOldPen);
}

void CSkinSpinButtonCtrl::Init()
{ 
	m_hWndBuddy=(HWND)::SendMessage(m_hWnd, UDM_GETBUDDY, 0, 0l);

	DWORD dwStyle=::GetWindowLong(m_hWnd,GWL_STYLE);
	if(dwStyle & UDS_WRAP)
		m_bAutoDisable=false;
	
	if(m_bAutoDisable) 
	{
		if(dwStyle & UDS_ALIGNRIGHT )
			m_nSpinAlign=OnRightInside;
		else
		{
			if(dwStyle & UDS_ALIGNLEFT)
			{
				m_nSpinAlign=OnLeftInside;
			
			}
		}
		if(dwStyle & UDS_HORZ)
			m_bVertical=false;


		GetRange32(m_nMinPos,m_nMaxPos);	
		if( m_nMinPos < m_nMaxPos)
			m_bDefaultDirection =false;
		else
		{
			int nTemp = m_nMinPos;
			m_nMinPos = m_nMaxPos;
			m_nMaxPos=nTemp;
		}

		GetClientRect(&m_rctClient);

		m_nPrevPos = GetPos();

		if(m_nPrevPos < m_nMinPos || m_nPrevPos > m_nMaxPos)
			m_nPrevPos=m_nMinPos;

		m_nSpinState = BothEnable;
		if(m_nPrevPos == m_nMinPos)
				m_nSpinState = DisableLeft;
		else
		{
			if(m_nPrevPos == m_nMaxPos)
				m_nSpinState = DisableRight;

		}

		if(::IsWindow(m_hWndBuddy))
		{
			char buf[5];
			::GetClassName(m_hWndBuddy,buf,sizeof(buf)/sizeof(buf[0]));
			
			if(!strcmp(buf,"Edit"))
			{
				m_bBuddyIsEdit=true;

				if(ghHook==NULL)
					ghHook=SetWindowsHookEx(WH_CALLWNDPROC,FilterBuddyMsgProc,NULL, //WH_GETMESSAGE
											GetCurrentThreadId());
				HWNDMAP::iterator iterHwnd=gHandleMap.find(m_hWndBuddy);
				if(iterHwnd != gHandleMap.end())
				{
					if((*iterHwnd).second != m_hWnd)
					{
						gHandleMap.erase(iterHwnd);	
						gHandleMap.insert(HWNDMAP::value_type(m_hWndBuddy,m_hWnd));
					}
				}
				else
					gHandleMap.insert(HWNDMAP::value_type(m_hWndBuddy,m_hWnd));
			}
		}
		Invalidate(FALSE);
	}
}

BOOL CSkinSpinButtonCtrl::OnDeltapos(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if(m_bAutoDisable)
	{
		NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

		int nNextPos=pNMUpDown->iPos+pNMUpDown->iDelta;

		if(nNextPos > m_nMaxPos)
			nNextPos = m_nMaxPos;
		else
		{
			if(nNextPos < m_nMinPos)
				nNextPos = m_nMinPos;
		}
	
		if(m_nPrevPos!=nNextPos)
		{
			if(pNMUpDown->iDelta)
				m_bXPX_ACTIVESpinPressed=true;

			if(nNextPos  <m_nMaxPos && nNextPos >m_nMinPos)
			{
				m_nSpinState = BothEnable;
			}
			else
			{
				if(nNextPos == m_nMaxPos)
				{
					if(m_nMaxPos != m_nMinPos)
					{
						m_nSpinState=DisableRight;
						m_bXPX_ACTIVESpinPressed=false;
					}
					else
					{
						m_nSpinState = BothDisable;
						m_bXPX_ACTIVESpinPressed=false;
					}
				}
				else
				{
					if(nNextPos == m_nMinPos)
					{
						m_nSpinState=DisableLeft;
						m_bXPX_ACTIVESpinPressed=false;
					}
				}
			}
			m_nPrevPos=nNextPos;
			Invalidate(FALSE);

			*pResult = 0;
			return FALSE;
		}
		else
		{
			*pResult = 1;
			return TRUE;
		}
	}
	else
	{ 
		*pResult = 0;
		return FALSE;
	}
}


LRESULT CSkinSpinButtonCtrl::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	LRESULT nRet = CSpinButtonCtrl::WindowProc(message, wParam, lParam);

	switch(message)
	{
		case UDM_SETRANGE32:
		case UDM_SETRANGE: 
							Init();
							break;

		case UDM_SETBUDDY :
							CleanUpHook();
							Init();
							if(::IsWindow(m_hWndBuddy))
								::SetWindowPos(m_hWnd,m_hWndBuddy,0,0,0,0,
									           SWP_NOMOVE|SWP_NOSIZE);

							break;
	}
	return nRet;

}

void CSkinSpinButtonCtrl::CleanUpHook() const
{
	if(m_bBuddyIsEdit)
	{
		HWNDMAP::iterator iterHwnd=gHandleMap.find(m_hWndBuddy);
		if(iterHwnd != gHandleMap.end() && (*iterHwnd).second == m_hWnd)
		{
			iterHwnd = gHandleMap.erase(iterHwnd);
			if(!gHandleMap.size() && ghHook!=NULL)
			{
				UnhookWindowsHookEx( ghHook);
				ghHook=NULL;
			}
		}
	}
}

void CSkinSpinButtonCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_rctIsPressed.SetRectEmpty();
	CSpinButtonCtrl::OnLButtonDown(nFlags, point);
}

BOOL CSkinSpinButtonCtrl::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE	;

}

void CSkinSpinButtonCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	Invalidate();	
	UpdateWindow();
	CSpinButtonCtrl::OnLButtonUp(nFlags, point);
}

bool CSkinSpinButtonCtrl::SetAutoDisable(bool bSetOn)
{
	bool bPrev = m_bAutoDisable;
	m_bAutoDisable = bSetOn;
	Init();

	return bPrev;
}

LRESULT CALLBACK FilterBuddyMsgProc(  int code,  WPARAM wParam,  LPARAM lParam )
{
	CWPSTRUCT* pData=reinterpret_cast<CWPSTRUCT*>(lParam);
	if(WM_COMMAND==pData->message && EN_UPDATE==HIWORD(pData->wParam))
	{
		HWNDMAP::iterator iterHwnd=gHandleMap.find(reinterpret_cast<HWND>(pData->lParam));
		if(iterHwnd != gHandleMap.end())
		{
			CString strText;
			int nLen=::GetWindowTextLength((*iterHwnd).first);
			::GetWindowText((*iterHwnd).first,strText.GetBufferSetLength(nLen),nLen+1);
			strText.ReleaseBuffer();

			strText.Remove((TCHAR)0xA0);

			NMUPDOWN nmUpDn;
			nmUpDn.iDelta=0;
			nmUpDn.iPos=atoi(strText);
			nmUpDn.hdr.code=UDN_DELTAPOS;
			nmUpDn.hdr.hwndFrom=(*iterHwnd).second;
			nmUpDn.hdr.idFrom=::GetDlgCtrlID((*iterHwnd).second);

			::SendMessage(::GetParent((*iterHwnd).second),
							WM_NOTIFY,(WPARAM)nmUpDn.hdr.idFrom,
							(LPARAM)&nmUpDn);
		}
	}
	return CallNextHookEx(ghHook,code,wParam,lParam);
}

void CSkinSpinButtonCtrl::OnDestroy() 
{
	CleanUpHook();

	CSpinButtonCtrl::OnDestroy();
}
