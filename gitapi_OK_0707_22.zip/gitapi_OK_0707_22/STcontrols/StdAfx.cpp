// stdafx.cpp : source file that includes just the standard includes
//	STcontrols.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



__declspec(dllexport) void GetCurrMonitorWorkArea(HWND hWnd, LPRECT lpRect)
{
	HMONITOR hMonitor;
	MONITORINFO MonitorInfo;
	CRect rcWork;
	
	hMonitor = MonitorFromWindow(hWnd, MONITOR_DEFAULTTONEAREST);
	if (hMonitor)
	{
		MonitorInfo.cbSize = sizeof(MONITORINFO);
		if (GetMonitorInfo(hMonitor, &MonitorInfo))
			rcWork = MonitorInfo.rcWork;
	}
	else
		SystemParametersInfo(SPI_GETWORKAREA, 0, &rcWork, 0);
	
	CopyRect(lpRect, rcWork);
}

__declspec(dllexport) void GetCurrMonitorWorkArea(POINT Point, LPRECT lpRect)
{
	HMONITOR hMonitor;
	MONITORINFO MonitorInfo;
	CRect rcWork;
	
	hMonitor = MonitorFromPoint(Point, MONITOR_DEFAULTTONEAREST);
	if (hMonitor)
	{
		MonitorInfo.cbSize = sizeof(MonitorInfo);
		if (GetMonitorInfo(hMonitor, &MonitorInfo))
			rcWork = MonitorInfo.rcWork;
	}
	else
		SystemParametersInfo(SPI_GETWORKAREA, 0, &rcWork, 0);
	
	CopyRect(lpRect, rcWork);
}