// SkinedFrameWnd.cpp : implementation file
//

#include "stdafx.h"
#include "Resource.h"
#include "SkinedFrameWnd.h"
#include "SkinedMDIChildWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define WS_EX_LAYERED 0x00080000
#define LWA_ALPHA     0x00000002
#define DEF_TPRATIO		50

/////////////////////////////////////////////////////////////////////////////
// CSkinedFrameWnd
IMPLEMENT_DYNCREATE(CSkinedFrameWnd, CWnd)

CSkinedFrameWnd::CSkinedFrameWnd()
{
	LoadBitmaps();

	m_bLButtonDown = FALSE;
	m_bTransparent = FALSE;
	m_nTPRatio = DEF_TPRATIO;

	m_bEnablePopup = TRUE;	// Popup window ����
	m_bEnableDock = FALSE;	// Docking Window ����
	m_bEnableTrans = FALSE;	// ���� ������ ����
	m_bBypassPopUp = FALSE;

	m_bEnableResize = FALSE;

	m_pChildDlg = NULL;

	OSVERSIONINFO osinfo;
	osinfo.dwOSVersionInfoSize = sizeof(osinfo);
	GetVersionEx(&osinfo);

	if(osinfo.dwPlatformId != VER_PLATFORM_WIN32_WINDOWS)
		m_bEnableTrans = TRUE;	// ���� ������ ����
}


CSkinedFrameWnd::~CSkinedFrameWnd()
{
	for (int i=0; i<7; i++)
	{
		for (int j=0; j<2; j++)
			m_bmButton[i][j].DeleteObject();
	}
}


BEGIN_MESSAGE_MAP(CSkinedFrameWnd, CWnd)
	//{{AFX_MSG_MAP(CSkinedFrameWnd)
	//ON_MESSAGE(WM_SETTEXT, OnSetText)
	ON_WM_NCPAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_NCACTIVATE()
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_NCLBUTTONUP()
	ON_WM_NCMOUSEMOVE()
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_WINDOWPOSCHANGED()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSkinedFrameWnd message handlers

void CSkinedFrameWnd::OnNcPaint() 
{
	CalculateSize();
	
	PaintFrameBorder();		// FrameBorder�� �׸���.

	CDC *pDC = GetWindowDC();
	CRect rcWindow;
	GetWindowRect(&rcWindow);

	CDC dcCaption;
	dcCaption.CreateCompatibleDC(pDC);

	CBitmap bmCaption;
	bmCaption.CreateCompatibleBitmap(pDC, m_rcCaption.Width(), m_rcCaption.Height());
	CBitmap* pOldBitmap = dcCaption.SelectObject(&bmCaption);

	PaintBackground(&dcCaption);
	PaintIcon(&dcCaption);
	PaintText(&dcCaption);
	PaintButtons(&dcCaption, -1);
	
	pDC->BitBlt(m_rcCaption.left, m_rcCaption.top, m_rcCaption.Width(), m_rcCaption.Height(), &dcCaption, 0, 0, SRCCOPY);
	dcCaption.SelectObject(pOldBitmap);

	bmCaption.DeleteObject();
	dcCaption.DeleteDC();	
	ReleaseDC(pDC);
}

BOOL CSkinedFrameWnd::OnNcActivate(BOOL bXPX_ACTIVE) 
{
	DWORD dwStyle = GetStyle();
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, (dwStyle & ~ WS_VISIBLE));

	MSG& msg = AfxGetThreadState()->m_lastSentMsg;
	msg.wParam = bXPX_ACTIVE;
	Default();
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);
	return TRUE;
}

void CSkinedFrameWnd::PaintBackground(CDC *pDC)
{
	CBrush brPattern;

	CDC memDC;

	memDC.CreateCompatibleDC(pDC);
	if (m_bXPX_ACTIVE)
		memDC.SelectObject(&m_bmCaptionOn);
	else
		memDC.SelectObject(&m_bmCaptionOff);

	CRect rcCaption;
	GetCaptionRect(rcCaption);
	rcCaption -= rcCaption.TopLeft();
	
	pDC->StretchBlt(rcCaption.left, rcCaption.top, rcCaption.Width(), rcCaption.Height(), &memDC, 0, 0, 1, rcCaption.Height(), SRCCOPY);
	memDC.DeleteDC();	
}

void CSkinedFrameWnd::PaintIcon(CDC *pDC)
{
	CRect rc(0, 0, 16, 16);
	rc.OffsetRect(2,0);
	DrawIconEx(pDC->m_hDC, rc.left, rc.top, 
			m_hIcon,
			rc.Width(), rc.Height(), 0, NULL, DI_NORMAL);
}


void CSkinedFrameWnd::GetCaptionRect(CRect &rcCaption)
{
	CSize szFrame;

	GetWindowRect(&rcCaption);
	rcCaption -= rcCaption.TopLeft();
	rcCaption.DeflateRect(1, 1);
	rcCaption.bottom = rcCaption.top + 20;
}

void CSkinedFrameWnd::GetFrameSize(CSize &szFrame)
{
	szFrame.cx = 1;
	szFrame.cy = 1;
}

void CSkinedFrameWnd::PaintText(CDC *pDC)
{
	CPoint pt;
	CRect rcCaption, rcDrawText;
	GetCaptionRect(rcCaption);

	// Draw Text
	HFONT hOldFont = (HFONT)::SelectObject(pDC->GetSafeHdc(), (HFONT)::GetStockObject(DEFAULT_GUI_FONT));

	CSize szTextExtent = pDC->GetTextExtent(m_strTitle);
	
	pt.x = GetSystemMetrics(SM_CXSIZE) + 4;
	pt.y = (rcCaption.Height() - szTextExtent.cy) >> 1;

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(GetSysColor(COLOR_CAPTIONTEXT));

	pDC->TextOut(pt.x, pt.y, m_strTitle);

	::SelectObject(pDC->GetSafeHdc(), hOldFont);
}

void CSkinedFrameWnd::PaintButtons(CDC *pDC, int nHitTest)
{
	CRect rcBtn;
	CDC		dcBtn;
	dcBtn.CreateCompatibleDC(pDC);


	// Close ��ư�� �׸���.
	rcBtn = m_rcButton[SB_CLOSE];
	if(nHitTest < 0)
		rcBtn -= m_rcCaption.TopLeft();

	if (nHitTest == HTCLOSE && m_bLButtonDown)
		dcBtn.SelectObject(&m_bmButton[SB_CLOSE][1]);
	else
		dcBtn.SelectObject(&m_bmButton[SB_CLOSE][0]);

	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	// �ִ�ȭ��ư�� �׸���.
	rcBtn = m_rcButton[SB_MAXIMIZE];
	if(nHitTest < 0)
		rcBtn -= m_rcCaption.TopLeft();

	if (nHitTest == HTMAXBUTTON && m_bLButtonDown)
		dcBtn.SelectObject(&m_bmButton[SB_MAXIMIZE][1]);
	else
		dcBtn.SelectObject(&m_bmButton[SB_MAXIMIZE][0]);

	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	// �ּ�ȭ��ư�� �׸���.
	rcBtn = m_rcButton[SB_MINIMIZE];
	if(nHitTest < 0)
		rcBtn -= m_rcCaption.TopLeft();

	if (nHitTest == HTMINBUTTON && m_bLButtonDown)
		dcBtn.SelectObject(&m_bmButton[SB_MINIMIZE][1]);
	else
		dcBtn.SelectObject(&m_bmButton[SB_MINIMIZE][0]);

	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	// PopUp ��ư�� �׸���.
	if(m_bEnablePopup)
	{
		rcBtn = m_rcButton[SB_POPUP];
		if(nHitTest < 0)
			rcBtn -= m_rcCaption.TopLeft();

		if (nHitTest == HT_EX_POPUP && m_bLButtonDown)
			dcBtn.SelectObject(&m_bmButton[SB_POPUP][1]);
		else
			dcBtn.SelectObject(&m_bmButton[SB_POPUP][0]);

		pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);
	}

	// Docking ��ư�� �׸���.
	if(m_bEnableDock)
	{
		rcBtn = m_rcButton[SB_DOCKING];
		if(nHitTest < 0)
			rcBtn -= m_rcCaption.TopLeft();

		if (nHitTest == HT_EX_DOCKING && m_bLButtonDown)
			dcBtn.SelectObject(&m_bmButton[SB_DOCKING][1]);
		else
			dcBtn.SelectObject(&m_bmButton[SB_DOCKING][0]);

		pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);
	}

	// ���� ��ư�� �׸���.
	if(m_bEnableTrans)
	{
		rcBtn = m_rcButton[SB_TRANSPARENT];
		if(nHitTest < 0)
			rcBtn -= m_rcCaption.TopLeft();

		if (nHitTest == HT_EX_TRANSPARENT && m_bLButtonDown)
			dcBtn.SelectObject(&m_bmButton[SB_TRANSPARENT][1]);
		else
			dcBtn.SelectObject(&m_bmButton[SB_TRANSPARENT][0]);

		pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);
	}

	// ���򸻹�ư�� �׸���.
	rcBtn = m_rcButton[SB_HELP];
	if(nHitTest < 0)
		rcBtn -= m_rcCaption.TopLeft();

	if (nHitTest == HTHELP && m_bLButtonDown)
		dcBtn.SelectObject(&m_bmButton[SB_HELP][1]);
	else
		dcBtn.SelectObject(&m_bmButton[SB_HELP][0]);

	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	dcBtn.DeleteDC();
}

LRESULT CSkinedFrameWnd::OnNcHitTest(CPoint point) 
{
	UINT uHitTest;

	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	point -= rcWindow.TopLeft();
	
	CRect rcSize;
	int nSize = 4;

	rcWindow -= rcWindow.TopLeft();

	//corner
	if(m_bEnableResize)
	{
		rcSize.SetRect(rcWindow.left, rcWindow.top, rcWindow.left+nSize, rcWindow.top+nSize);
		if(rcSize.PtInRect(point))
			return HTTOPLEFT;
		rcSize.SetRect(rcWindow.right-nSize, rcWindow.top, rcWindow.right, rcWindow.top+nSize);
		if(rcSize.PtInRect(point))
			return HTTOPRIGHT;
		rcSize.SetRect(rcWindow.left, rcWindow.bottom-nSize, rcWindow.left+nSize, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTBOTTOMLEFT;
		rcSize.SetRect(rcWindow.right-nSize, rcWindow.bottom-nSize, rcWindow.right, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTBOTTOMRIGHT;

		// border
		rcSize.SetRect(rcWindow.left, rcWindow.top, rcWindow.right, rcWindow.top+nSize);
		if(rcSize.PtInRect(point))
			return HTTOP;
		rcSize.SetRect(rcWindow.left, rcWindow.bottom-nSize, rcWindow.right, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTBOTTOM;
		rcSize.SetRect(rcWindow.left, rcWindow.top, rcWindow.left+nSize, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTLEFT;
		rcSize.SetRect(rcWindow.right-nSize, rcWindow.top, rcWindow.right, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTRIGHT;
	}

	if (m_rcSysMenu.PtInRect(point))
		uHitTest = HTSYSMENU;
	else if (m_rcButton[SB_CLOSE].PtInRect(point))
		uHitTest = HTCLOSE;
	else if (m_rcButton[SB_MAXIMIZE].PtInRect(point))
		uHitTest = HTMAXBUTTON;
	else if (m_rcButton[SB_MINIMIZE].PtInRect(point))
		uHitTest = HTMINBUTTON;
	else if (m_rcButton[SB_POPUP].PtInRect(point))
		uHitTest = HT_EX_POPUP;
	else if (m_rcButton[SB_DOCKING].PtInRect(point))
		uHitTest = HT_EX_DOCKING;
	else if (m_rcButton[SB_TRANSPARENT].PtInRect(point))
		uHitTest = HT_EX_TRANSPARENT;
	else if (m_rcButton[SB_HELP].PtInRect(point))
		uHitTest = HTHELP;
	else if (rcCaption.PtInRect(point))
		uHitTest = HTCAPTION;
	else
		uHitTest = HTNOWHERE;
	return uHitTest;
}

void CSkinedFrameWnd::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	DWORD dwStyle = GetStyle();
	CSize szFrame = (dwStyle & WS_THICKFRAME) ?
		CSize(GetSystemMetrics(SM_CXSIZEFRAME),
			   GetSystemMetrics(SM_CYSIZEFRAME)) :
		CSize(GetSystemMetrics(SM_CXFIXEDFRAME),
				GetSystemMetrics(SM_CYFIXEDFRAME));

	int nCaptionY = GetSystemMetrics(SM_CYCAPTION);

	InflateRect(&lpncsp->rgrc[0], szFrame.cx-1, szFrame.cy-1);
	lpncsp->rgrc[0].top -= (nCaptionY - 20);

	CWnd::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void CSkinedFrameWnd::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	m_bXPX_ACTIVE = TRUE;

	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	rcCaption -= rcWindow.TopLeft();

	switch(nHitTest)
	{
	case HTCLOSE:
	case HTMAXBUTTON:
	case HTMINBUTTON:
	case HT_EX_POPUP:
	case HT_EX_DOCKING:
	case HT_EX_TRANSPARENT:
	case HTHELP:
		m_bLButtonDown = TRUE;
		m_nHitTest = nHitTest;
		break;
	case HTCAPTION:
		SetFocus();
		SendMessage(WM_SYSCOMMAND, 0x0000F012, 0x0);
		break;
	default:
		CWnd::OnNcLButtonDown(nHitTest, point);
		break;

	}
	OnNcPaint();
	UpdateButtons(nHitTest);
}

void CSkinedFrameWnd::OnNcLButtonUp(UINT nHitTest, CPoint point) 
{
	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	rcCaption -= rcWindow.TopLeft();

	if (m_bLButtonDown && m_nHitTest == nHitTest)
	{
		switch(nHitTest)
		{
		case HTCLOSE:
			SendMessage(WM_SYSCOMMAND, (WPARAM)SC_CLOSE);
			return;
		case HTMINBUTTON:
			if (IsIconic())
				SendMessage(WM_SYSCOMMAND, (WPARAM)SC_RESTORE);
			else
			{
				SendMessage(WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE);
				return;
			}
			break;
		case HTMAXBUTTON:
			if(IsZoomed())
				SendMessage(WM_SYSCOMMAND, (WPARAM)SC_RESTORE);
			else if(m_bEnableResize)
				SendMessage(WM_SYSCOMMAND, (WPARAM)SC_MAXIMIZE);
			break;
		case HT_EX_TRANSPARENT:
			if(m_bBypassPopUp)
			{
				PopWndPricessing(FALSE);
			}
			m_bTransparent = !m_bTransparent;
			SetTransParent(m_bTransparent);
			break;
		case HT_EX_DOCKING:
			PopWndPricessing(TRUE);
			break;
		case HT_EX_POPUP:
			PopWndPricessing(FALSE);
			break;
		default:
			CWnd::OnNcLButtonUp(nHitTest, point);
			break;
		}
	}
	else
	{
		CWnd::OnNcLButtonUp(nHitTest, point);
	}

	m_bLButtonDown = FALSE;
	m_nHitTest = HTNOWHERE;
	OnNcPaint();
	UpdateButtons(HTNOWHERE);
}

void CSkinedFrameWnd::CalcButtonsRect()
{
	CRect rcTmp;

	DWORD dwStyle = GetStyle();
	
	// �����ư
	rcTmp.right = m_rcCaption.right -5;
	rcTmp.left = rcTmp.right - 14;
	rcTmp.top = m_rcCaption.top + 2;
	rcTmp.bottom = rcTmp.top + 13;

	m_rcButton[SB_CLOSE] = rcTmp;

	BOOL bGroup = FALSE;

	// �ִ�ȭ
	rcTmp.right = rcTmp.left - 2;
	rcTmp.left = rcTmp.right - 14;
	m_rcButton[SB_MAXIMIZE] = rcTmp;
	bGroup = TRUE;

	// �ּ�ȭ
	rcTmp.right = rcTmp.left;
	if (!bGroup)
		rcTmp.right -= 2;
	rcTmp.left = rcTmp.right - 14;
	m_rcButton[SB_MINIMIZE] = rcTmp;
	bGroup = TRUE;

	// popup
	if(m_bEnablePopup)
	{
		rcTmp.right = rcTmp.left - 2;
		if (!bGroup)
			rcTmp.right -= 2;

		rcTmp.left = rcTmp.right - 14;
		m_rcButton[SB_POPUP] = rcTmp;
	}

	if(m_bEnableTrans)
	{
		rcTmp.right = rcTmp.left;
		if (!bGroup)
			rcTmp.right -= 2;

		rcTmp.left = rcTmp.right - 14;
		m_rcButton[SB_TRANSPARENT] = rcTmp;
	}

	// docking
	if(m_bEnableDock)
	{
		rcTmp.right = rcTmp.left - 2;
		if (!bGroup)
			rcTmp.right -= 2;

		rcTmp.left = rcTmp.right - 14;
		m_rcButton[SB_DOCKING] = rcTmp;
	}

	// ����
	rcTmp.right = rcTmp.left - 2;
	rcTmp.left = rcTmp.right - 14;
	m_rcButton[SB_HELP] = rcTmp;

	m_rcText.right = rcTmp.left - 2;
}


void CSkinedFrameWnd::LoadBitmaps()
{
	m_bmCaptionOn.LoadBitmap(IDB_CAPTIONON);
	m_bmCaptionOff.LoadBitmap(IDB_CAPTIONOFF);

	m_bmButton[SB_HELP][0].LoadBitmap(IDB_HELP_UP);
	m_bmButton[SB_HELP][1].LoadBitmap(IDB_HELP_DOWN);

	m_bmButton[SB_TRANSPARENT][0].LoadBitmap(IDB_TRANS_UP);
	m_bmButton[SB_TRANSPARENT][1].LoadBitmap(IDB_TRANS_DOWN);

	m_bmButton[SB_DOCKING][0].LoadBitmap(IDB_DOCKING_UP);
	m_bmButton[SB_DOCKING][1].LoadBitmap(IDB_DOCKING_DOWN);

	m_bmButton[SB_POPUP][0].LoadBitmap(IDB_FULLOUT_UP);
	m_bmButton[SB_POPUP][1].LoadBitmap(IDB_FULLOUT_DOWN);

	m_bmButton[SB_MINIMIZE][0].LoadBitmap(IDB_MINIMIZE_UP);
	m_bmButton[SB_MINIMIZE][1].LoadBitmap(IDB_MINIMIZE_DOWN);

	m_bmButton[SB_MAXIMIZE][0].LoadBitmap(IDB_REDUCE_UP);
	m_bmButton[SB_MAXIMIZE][1].LoadBitmap(IDB_REDUCE_DOWN);

	m_bmButton[SB_CLOSE][0].LoadBitmap(IDB_CLOSE_UP);
	m_bmButton[SB_CLOSE][1].LoadBitmap(IDB_CLOSE_DOWN);

}

void CSkinedFrameWnd::UpdateButtons(UINT nHitTest)
{
	CWindowDC dc(this);
	PaintButtons(&dc, nHitTest);
}

#if 0
void CSkinedFrameWnd::OnSetText(WPARAM wParam, LPCTSTR lpszString)
{
	if(strlen(lpszString) <= 0)
		return;
	CWnd *pWnd = AfxGetMainWnd();
	//pWnd->SendMessage(WM_CHANGETASKTITLE, (WPARAM)this, (LPARAM)lpszString);
	m_strTitle = lpszString;
	OnNcPaint();
}
#endif

void CSkinedFrameWnd::PaintFrameBorder()
{
	CWindowDC	dc(this);
	CRect		rcWindow;
	GetWindowRect(&rcWindow);
	rcWindow -= rcWindow.TopLeft();

	CPen penBorder(PS_SOLID, 1, RGB(83,83,83));
	CPen* pOldPen = dc.SelectObject(&penBorder);
	dc.SelectObject(GetStockObject(NULL_BRUSH));
	dc.Rectangle(rcWindow);
	dc.SelectObject(pOldPen);
	penBorder.DeleteObject();

	rcWindow.DeflateRect(1, 21, 1, 1);
	dc.DrawEdge(&rcWindow, EDGE_SUNKEN, BF_RECT);
}

BOOL CSkinedFrameWnd::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= WS_CLIPCHILDREN;
	cs.style &= ~WS_VISIBLE;
	return CWnd::PreCreateWindow(cs);
}


int CSkinedFrameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO: Add your specialized creation code here
	CWnd *pWnd = AfxGetMainWnd();

	DWORD dwStyle = GetStyle();
	dwStyle |= WS_CAPTION;
	dwStyle &= ~(WS_MAXIMIZEBOX);
	SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	DWORD dwExStyle = GetExStyle();
	dwExStyle &= ~(WS_EX_CLIENTEDGE);
	SetWindowLong(m_hWnd, GWL_EXSTYLE, dwExStyle);

	m_hIcon = (HICON)LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_WINDOW));
	SetWindowLong(m_hWnd, GCL_HICONSM, (LONG)m_hIcon);
	SetWindowLong(m_hWnd, GCL_HICON, (LONG)m_hIcon);

	CRect rc;
	GetWindowRect(&rc);
	int nCaptionY = GetSystemMetrics(SM_CYCAPTION);
	rc.right -= 3;
	rc.bottom -= (nCaptionY - 20);

	return 0;
}


void CSkinedFrameWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	CRect rcClient;
	if (m_pChildDlg)
	{
		GetClientRect(&rcClient);
		m_pChildDlg->SetWindowPos(NULL, 0, 0, cx, cy, SWP_NOMOVE | SWP_NOZORDER);
	}
}


BOOL CSkinedFrameWnd::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CWnd::PreTranslateMessage(pMsg);
}

void CSkinedFrameWnd::CalculateSize()
{
	GetCaptionRect(m_rcCaption);

	int cxIcon = GetSystemMetrics(SM_CXSIZE);
	CRect rc(0, 0, cxIcon, GetSystemMetrics(SM_CYSIZE));
	rc.DeflateRect(0,1);
	rc.left += 2;

	m_rcSysMenu = rc;
	CSize szFrame;
	GetFrameSize(szFrame);

	m_rcSysMenu += szFrame;

	m_rcText.left = m_rcSysMenu.right + 1;
	m_rcText.top = m_rcCaption.top;
	m_rcText.bottom = m_rcCaption.bottom;
	m_rcText.right = m_rcCaption.right - 1;

	CalcButtonsRect();		// ��ư�� ������ ����Ѵ�.
}

void CSkinedFrameWnd::OnNcMouseMove(UINT nHitTest, CPoint point) 
{
	if (m_bLButtonDown && (m_nHitTest != nHitTest))
	{
		m_bLButtonDown = FALSE;
		m_nHitTest = HTNOWHERE;
	}
	OnNcPaint();
}


void CSkinedFrameWnd::OnDestroy() 
{
	CWnd::OnDestroy();

	DeleteObject(m_hIcon);

	if(m_pPrevWnd)
	{
		m_pChildDlg->SetParent(m_pPrevWnd);
		m_pPrevWnd->SendMessage(WM_CLOSE, 0, 0);
	}

	delete this;
	//CWnd *pWnd = AfxGetMainWnd();
	//pWnd->SendMessage(WM_DELETETASK, (WPARAM)this, (LPARAM)0);
}


void CSkinedFrameWnd::OnWindowPosChanged(WINDOWPOS* lpwndpos)
{
	CWnd::OnWindowPosChanged(lpwndpos);
	OnNcPaint();
}


void CSkinedFrameWnd::PopWndPricessing(BOOL bDocking)
{
	CSkinedMDIChildWnd *pWnd = (CSkinedMDIChildWnd *)m_pPrevWnd;
	pWnd->m_pPopWnd = NULL;
	m_pChildDlg->SetParent(pWnd);
	pWnd->ShowWindow(SW_RESTORE);
	pWnd->ShowWindow(SW_SHOW);
	m_pPrevWnd = NULL;
	pWnd->MDIActivate();
	pWnd->m_bXPX_ACTIVE = TRUE;
	if(bDocking)
		pWnd->SendMessage(WM_NCLBUTTONUP, HT_EX_DOCKING, 0);
	PostMessage(WM_DESTROY, 0, 0);
}


void CSkinedFrameWnd::SetDialog(CWnd *pDlg, CString strTitle, BOOL bResize)
{
	ASSERT(pDlg != NULL);
	m_pChildDlg = pDlg;
	m_pPrevWnd = m_pChildDlg->GetParent();
	m_pChildDlg->SetParent(this);
	m_strTitle = strTitle;
	SetWindowText(m_strTitle);

	m_bEnableResize = bResize;

	CRect rtWindow, rtClient;
	GetWindowRect(&rtWindow);
	GetClientRect(&rtClient);

	SetWindowPos(NULL, rtWindow.left, rtWindow.top, rtWindow.Width(), rtWindow.Height(), SWP_NOMOVE | SWP_NOZORDER);
	pDlg->SetWindowPos(NULL, 0, 0, rtClient.Width(), rtClient.Height(), SWP_NOMOVE | SWP_NOZORDER);
	m_pChildDlg->ShowWindow(SW_SHOW);   
	ShowWindow(SW_NORMAL);
	UpdateWindow();
}
	
void CSkinedFrameWnd::SetWindowText(LPCTSTR lpszString)
{
	m_strTitle = lpszString;
	DWORD dwStyle = GetStyle();
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, (dwStyle & ~ WS_VISIBLE));

	CWnd::SetWindowText(lpszString);
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);
	OnNcPaint();
}


void CSkinedFrameWnd::SetTransParent(BOOL bOnOff)
{
	OSVERSIONINFO osinfo;
	osinfo.dwOSVersionInfoSize = sizeof(osinfo);
	GetVersionEx(&osinfo);

	if(osinfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
		return;

	typedef BOOL(WINAPI *SLWA)(HWND, COLORREF, BYTE, DWORD);
	SLWA pSetLayeredWindowAttributes = NULL;
	HINSTANCE hmodUSER32 = LoadLibrary("USER32.DLL");
	pSetLayeredWindowAttributes = (SLWA)GetProcAddress(hmodUSER32,"SetLayeredWindowAttributes");
	HWND hwnd = this->m_hWnd; 

	BOOL bResult;

	if(bOnOff)
	{
		::SetWindowPos(hwnd,wndTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
		SetWindowLong(hwnd, GWL_EXSTYLE,GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED);
		bResult = pSetLayeredWindowAttributes(hwnd, 0, (BYTE)(255*((float)m_nTPRatio/100.)), LWA_ALPHA);
	}
	else
	{
		::SetWindowPos(hwnd,wndNoTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
		bResult = SetWindowLong(hwnd, GWL_EXSTYLE,GetWindowLong(hwnd, GWL_EXSTYLE) & ~WS_EX_LAYERED);
	}
	m_bTransparent = bOnOff;
}
