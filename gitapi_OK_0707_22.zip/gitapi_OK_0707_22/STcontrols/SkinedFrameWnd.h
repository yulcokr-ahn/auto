#if !defined(AFX_SKINEDFRAMEWND_H__2FB529D5_F213_4451_B593_982D12BC6D7A__INCLUDED_)
#define AFX_SKINEDFRAMEWND_H__2FB529D5_F213_4451_B593_982D12BC6D7A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SkinedFrameWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSkinedFrameWnd frame

#ifdef _AFXEXT
	#ifndef _EXPORTCONTROLS
		#undef AFX_EXT_CLASS
		#undef AFX_EXT_API
		#undef AFX_EXT_DATA
		#define AFX_EXT_CLASS AFX_CLASS_IMPORT
		#define AFX_EXT_API AFX_API_IMPORT
		#define AFX_EXT_DATA AFX_DATA_IMPORT
	#endif
#endif


class AFX_EXT_CLASS CSkinedFrameWnd : public CWnd
{
	DECLARE_DYNCREATE(CSkinedFrameWnd)
public:
	CSkinedFrameWnd();           // protected constructor used by dynamic creation
	virtual ~CSkinedFrameWnd();

// Attributes
public:
	BOOL	m_bEnableTrans;	// ���� ������ ����
	BOOL	m_bEnablePopup;	// Popup window ����
	BOOL	m_bEnableDock;	// Docking Window ����
	BOOL	m_bBypassPopUp;
	CWnd*	m_pPrevWnd;

// Operations
public:
	void LoadBitmaps();
	void SetDialog(CWnd* pDlg, CString strTitle, BOOL bResize = FALSE);
	void SetTransParent(BOOL bOnOff);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSkinedFrameWnd)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void SetWindowText(LPCTSTR lpszString);

	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSkinedFrameWnd)
	afx_msg void OnNcPaint();
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg BOOL OnNcActivate(BOOL bXPX_ACTIVE);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	//afx_msg void OnSetText(WPARAM wParam, LPCTSTR lpszString);
	afx_msg void OnNcMouseMove(UINT nHitTest, CPoint point);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnWindowPosChanged(WINDOWPOS* lpwndpos);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CString		m_strTitle;
	CWnd*		m_pDialog;
	CRect		m_rcDialog;

	UINT		m_nState;
	DWORD		m_dwStyle;

	CPoint		m_ptMax, m_ptTrackMax, m_ptTrackMin;
	int			m_nDiffWidth, m_nDiffHeight;

protected:
	void CalculateSize();
	void PaintFrameBorder();

	void UpdateButtons(UINT nHitTest);
	void CalcButtonsRect();
	void PaintButtons(CDC *pDC, int nHitTest);
	void PaintText(CDC *pDC);
	void GetFrameSize(CSize &szFrame);
	void GetCaptionRect(CRect &rcCaption);
	void PaintIcon(CDC *pDC);
	void PaintBackground(CDC *pDC);
	void PopWndPricessing(BOOL bDocking);

	BOOL			m_bXPX_ACTIVE;
	BOOL			m_bTransparent;
	int				m_nTPRatio;

	CBitmap			m_bmCaptionOn;
	CBitmap			m_bmCaptionOff;

	CBitmap			m_bmButton[7][2];
	CRect			m_rcButton[7];
	CRect			m_rcSysMenu;
	CRect			m_rcCaption;
	CRect			m_rcText;

	BOOL			m_bLButtonDown;
	UINT			m_nHitTest;

	HICON			m_hIcon;

	// Dialog ó��
	CWnd*			m_pChildDlg;
	BOOL			m_bEnableResize;
};


/////////////////////////////////////////////////////////////////////////////

#ifdef _AFXEXT
	#ifndef _EXPORTCONTROLS
		#undef AFX_EXT_CLASS
		#undef AFX_EXT_API
		#undef AFX_EXT_DATA
		#define AFX_EXT_CLASS AFX_CLASS_EXPORT
		#define AFX_EXT_API AFX_API_EXPORT
		#define AFX_EXT_DATA AFX_DATA_EXPORT
	#endif
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SKINEDFRAMEWND_H__2FB529D5_F213_4451_B593_982D12BC6D7A__INCLUDED_)
