// STcontrols.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <afxdllx.h>
#include "Resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


static AFX_EXTENSION_MODULE STcontrolsDLL = { NULL, NULL };
//2011.01.13
HINSTANCE hChartInstance;
HINSTANCE g_hInstance;
extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
//		TRACE0("STcontrols.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(STcontrolsDLL, hInstance))
			return 0;

		// Insert this DLL into the resource chain
		// NOTE: If this Extension DLL is being implicitly linked to by
		//  an MFC Regular DLL (such as an XPX_ACTIVEX Control)
		//  instead of an MFC application, then you will want to
		//  remove this line from DllMain and put it in a separate
		//  function exported from this Extension DLL.  The Regular DLL
		//  that uses this Extension DLL should then explicitly call that
		//  function to initialize this Extension DLL.  Otherwise,
		//  the CDynLinkLibrary object will not be attached to the
		//  Regular DLL's resource chain, and serious problems will
		//  result.

		new CDynLinkLibrary(STcontrolsDLL);
//2011.01.13
		hChartInstance = hInstance;
		g_hInstance = hInstance;
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
//		TRACE0("STcontrols.DLL Terminating!\n");
		// Terminate the library before destructors are called
		AfxTermExtensionModule(STcontrolsDLL);
	}
	return 1;   // ok
}

struct MENUDBITEM   //Add share--[Cx]]2009.06
{
	char		cMenuOp;
	char		sTRCode[4+1];
	char		sShortName[10+1];
	char		sLongName[40+1];
	char		sTab[4+1];
	char		sATSFileName[8+1];
	char		cScreenType;
	char		sCheckLevel[64+1];
	int			nMenuID;
};   //Add--[Cx]]2009.06


static CMapStringToOb* g_pMenuMapList;


__declspec(dllexport) CString GetTrCodeToScreenName(LPCSTR strTrCode)
{
	MENUDBITEM* pMemItem;
	CString strLongName = "";
	
	if(g_pMenuMapList)
	{
		
		if(g_pMenuMapList->Lookup(strTrCode, (CObject *&)pMemItem))
			strLongName = pMemItem->sLongName;
	}		
	return strLongName;
}



__declspec(dllexport) void SetMemuListPtr(CMapStringToOb* pMenuMapPtr)
{
	g_pMenuMapList = pMenuMapPtr;
}

// ��98���Ϲ��������� �𷡽ð谡 ���´�.
__declspec(dllexport) HCURSOR LoadAniCursor()
{
	HCURSOR hAniCursor;

	if (GetVersion() < 0x80000000)
	{
		HINSTANCE hInstance = ::AfxFindResourceHandle(MAKEINTRESOURCE(IDR_DREAMCURSOR), RT_ANICURSOR);
		HRSRC hrSrc = ::FindResource(hInstance, MAKEINTRESOURCE(IDR_DREAMCURSOR), RT_ANICURSOR);
		DWORD dwSize = ::SizeofResource(hInstance, hrSrc);
		HGLOBAL hCursor = ::LoadResource(hInstance, hrSrc);
		LPBYTE pBytes = (LPBYTE)::LockResource(hCursor);
		
		if(pBytes)
		{
			hAniCursor = (HCURSOR)CreateIconFromResource(pBytes, dwSize, FALSE, 0x00030000);
			UnlockResource(hCursor);
			FreeResource(hCursor);
		}
	}
	else
		hAniCursor = LoadCursor(NULL, IDC_WAIT);

	return hAniCursor;
}

__declspec(dllexport) void CloseChildWindow(CWnd* pWnd)
{
	CWnd* pParentWnd = pWnd->GetParent();
	while (pParentWnd != NULL)
	{
		DWORD dwExStyle = GetWindowLong(pParentWnd->GetSafeHwnd(), GWL_STYLE);
		if ( dwExStyle & WS_SYSMENU)
		{
			pParentWnd->PostMessage(WM_CLOSE, 0, 0L);
			return;
		}
		pParentWnd = pParentWnd->GetParent();
	}
}

__declspec(dllexport) HCURSOR LoadAniCursorFromFile(LPCTSTR lpszFilename)
{
	HCURSOR hCursor;
	LPBYTE	lpByte;
	DWORD	dwSize, nNumberOfBytesRead;

	HANDLE hFile = ::CreateFile(
						lpszFilename, 
						GENERIC_READ,
						FILE_SHARE_READ,
						NULL,
						OPEN_EXISTING,
						FILE_ATTRIBUTE_NORMAL,
						NULL);
	if (hFile == INVALID_HANDLE_VALUE)
		return NULL;

	// ���� ũ�⸦ ���Ѵ�.
	dwSize = ::GetFileSize(hFile, NULL);

	if (dwSize == 0xFFFFFFFF)
		return NULL;

	lpByte = new BYTE[dwSize];
	
	if (!ReadFile(hFile, lpByte, dwSize, &nNumberOfBytesRead, NULL))
		return FALSE;

	hCursor = (HCURSOR)::CreateIconFromResource(lpByte, dwSize, FALSE, 0x00030000);

	CloseHandle(hFile);

	return hCursor;
}

__declspec(dllexport) CString GetST_ProfileString(CString strlpAppName, CString strKeyName) 
{

	CString strPathIni;
	char		buff[256];	::GetModuleFileName(AfxGetInstanceHandle(), buff, 255);		
	int i=0;
	for( i=strlen(buff)-1; i>=0 && buff[i]!='\\'; i--);	buff[i]=0;	
	strPathIni.Format("%s\\AegisTrading.INI",buff); //d:=CurPath   ,  windows=chSysPath);



/* 20150913
	char CurPath[_MAX_PATH] = "", chTemp[_MAX_PATH] = "",chSysPath[_MAX_PATH] = "";
	int ReadLen = GetCurrentDirectory(_MAX_PATH, CurPath );
	int nSysRead = GetWindowsDirectory(chSysPath,_MAX_PATH);
	CString strPath,strPathIni,strSysDir;
	strPath = CurPath;
	strPath.MakeUpper();
	// PWR
	strPathIni.Format("%s\\AegisTrading.INI",CurPath); //d:=CurPath   ,  windows=chSysPath);
*/


	char	buffer[MAX_PATH];
	GetPrivateProfileString(strlpAppName,strKeyName, "0", buffer, sizeof(buffer), strPathIni);
//	CString mTempPath(_T(buffer) );
CString	mTempPath;
//20150919 
mTempPath.Format("%s%s",buff,buffer); //d:=CurPath   ,  windows=chSysPath);
//mTempPath.Format("%s",buffer); //d:=CurPath   ,  windows=chSysPath);



	return mTempPath;
}


int WriteEnvironmentInt(CString strSection, CString strKey, int nValue)
{
	CString strPath, strUserPath;
	char chData[100] ="";
	itoa(nValue, chData, 10);

	strUserPath = GetST_ProfileString("Aegis", "EncUserPath");
	strPath.Format("%s\\Environment.ini", strUserPath);

TRACE("\n ��� STcontrols-STcontrols.cpp WriteEnvironmentInt() strPath=[%s]", strPath);

	return WritePrivateProfileString(strSection, strKey, chData, strPath);
}


int GetEnvironmentInt(CString strSection, CString strKey)
{
	CString strPath, strUserPath;
	strUserPath = GetST_ProfileString("Aegis", "EncUserPath");
	strPath.Format("%s\\Environment.ini", strUserPath);

TRACE("\n ��� STcontrols-STcontrols.cpp GetEnvironmentInt() strPath=[%s]", strPath);

	return GetPrivateProfileInt(strSection, strKey, 0, strPath);
}


int WriteEnvironmentString(CString strSection, CString strKey, CString strValue)
{
	CString strPath, strUserPath;
	strUserPath = GetST_ProfileString("Aegis", "EncUserPath");
	strPath.Format("%s\\Environment.ini", strUserPath);

TRACE("\n ��� STcontrols-STcontrols.cpp WriteEnvironmentString() strPath=[%s]", strPath);

	return WritePrivateProfileString(strSection, strKey, strValue, strPath);
}


int GetEnvironmentString(CString strSection, CString strKey, CString& strValue)
{
	CString strPath, strUserPath;
	char chData[100] ="";

	strUserPath = GetST_ProfileString("Aegis", "EncUserPath");
	strPath.Format("%s\\Environment.ini", strUserPath);

TRACE("\n ��� STcontrols-STcontrols.cpp GetEnvironmentString() strPath=[%s]", strPath);

	int ret = GetPrivateProfileString(strSection, strKey, "", chData, 100, strPath);
	strValue.Format("%s", chData);
	return ret;
}
