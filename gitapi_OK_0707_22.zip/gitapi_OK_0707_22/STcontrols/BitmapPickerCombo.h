//----------------------------------------------------------------------------
// N O L D U S   I N F O R M A T I O N   T E C H N O L O G Y   B . V .
//----------------------------------------------------------------------------
// Filename:      BitmapPickerCombo.h
// Project:       EthoVision
// Module:        BitmapPicker
// Programmer:    Anneke Sicherer-Roetman
// Version:       1.00
// Revision Date: 06-10-1999
//----------------------------------------------------------------------------
// Description:   Declaration of class CBitmapPickerCombo
//----------------------------------------------------------------------------
// Revision history:
// 06-10-1999 - First implementation
// 08-01-2002 - Next  Implementation by jwp - FlatCombo��� Add
//----------------------------------------------------------------------------

#if !defined(AFX_CBITMAPPICKERCOMBO_H__8AAE34F7_7B02_11D3_A615_0060085FE616__INCLUDED_)
#define AFX_CBITMAPPICKERCOMBO_H__8AAE34F7_7B02_11D3_A615_0060085FE616__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000 

#define WM_COMBO_CELLDRAG    0x0131
class AFX_EXT_CLASS CBitmapPickerCombo : public CComboBox
{
public:
	int		m_iCurSel;		
	BOOL	m_bCloseUp;
	BOOL	m_bLBtnDown;
	int		m_nDragIndex;
	BOOL	m_bDrawCursor;
	BOOL	m_bCancelDrag;

public:
    CBitmapPickerCombo();
    virtual ~CBitmapPickerCombo();

    int AddBitmap(const CBitmap *bitmap, const char *string = NULL);
    int InsertBitmap(int nIndex, const CBitmap *bitmap, const char *string = NULL);
  
protected:
	//++by jwp 2002/02/
	int			m_nOffset;		// offset used during paint.
	BOOL		m_bPainted;		// used during paint operationsv
	BOOL		m_bHasFocus;	// TRUE if control has focus
	COLORREF	m_clrBtnHilite;	// set to the system color COLOR_BTNHILIGHT
	COLORREF	m_clrBtnShadow;	// set to the system color COLOR_BTNSHADOW
	COLORREF	m_clrBtnFace;	// set to the system color COLOR_BTNFACE
	HBRUSH      m_hbr;
	BOOL		m_bAlreadyDsp;

	// enum used to determine the state the combo box should be
	//
	enum STATE { normal = 1, raised = 2, pressed = 3 };
	//--
  
    virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);
    virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMIS);
  
    virtual int AddString(LPCTSTR lpszString) { return -1; }
    virtual int InsertString(int nIndex, LPCTSTR lpszString) { return -1; }
    virtual int DeleteString(int nIndex) { return -1; }
#ifdef _DEBUG  
    virtual void PreSubclassWindow();
#endif


private:
    int m_nItemWidth, m_nItemHeight; // @cmember size of items  
    void OutputBitmap(LPDRAWITEMSTRUCT lpDIS, bool selected);

    void SetSize(int width, int height);
protected:
	void DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight);
    // Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolBarCombo)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CToolBarCombo)	
	afx_msg void OnPaint();		
	afx_msg void OnSysColorChange();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);	

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CBITMAPPICKERCOMBO_H__8AAE34F7_7B02_11D3_A615_0060085FE616__INCLUDED_)
