// DNDListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "DNDListCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDNDListCtrl

CDNDListCtrl::CDNDListCtrl()
	: m_iNumColumns(0)
	, m_iSortColumn(-1)
	, m_bSortAscending(TRUE)
	, m_nRowHeight(17)
	, m_bRowSelect(TRUE)
{
	m_shWndListCtrl = NULL;
	m_nSourceType	= 1;			// 1�̸� list , 2�̸� Tree�� �Ѵ�.
	m_shWndListCtrlParent = NULL;
}

CDNDListCtrl::~CDNDListCtrl()
{
}


BEGIN_MESSAGE_MAP(CDNDListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CDNDListCtrl)
	ON_NOTIFY_REFLECT(LVN_BEGINDRAG, OnBegindrag)
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnclick)
	ON_WM_MEASUREITEM_REFLECT()
	ON_WM_DRAWITEM_REFLECT()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDNDListCtrl message handlers


void CDNDListCtrl::PreSubclassWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	ModifyStyle(LVS_SMALLICON | LVS_LIST | LVS_ICON , LVS_OWNERDRAWFIXED | LVS_REPORT);

	m_wndHeader.SubclassWnd(GetHeaderCtrl()->GetSafeHwnd());
	
	CListCtrl::PreSubclassWindow();
}

void CDNDListCtrl::RegistDropTarget()
{
	m_ListDropTarget.Register(m_sHandle);
}

void CDNDListCtrl::SetDragInfor() 
{
	m_sHandle		= this;
	m_shWndListCtrl = m_hWnd;
	m_nSourceType	= 1;			// 1�̸� list , 2�̸� Tree�� �Ѵ�.
	m_shWndListCtrlParent = GetParent()->m_hWnd;
}

void CDNDListCtrl::OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	SetFocus();

	m_DragList.RemoveAll();

	// Drag�Ǵ� ��� ����� �̸� ����� �д�.	
	POSITION pos = GetFirstSelectedItemPosition();
	while (pos)
	{
		m_DragList.Add( GetNextSelectedItem(pos) );
	}


	COleDataSource *poleSourceObj = new COleDataSource ;

	CListDropTarget::m_shWndListCtrl = m_shWndListCtrl;
	CListDropTarget::m_shWndListCtrlParent =m_shWndListCtrlParent;
	CListDropTarget::m_nSourceType = m_nSourceType;

	// Begin Drag operation
	DROPEFFECT dropeffect = poleSourceObj->DoDragDrop();

	
	// If user is moving item by pressing Shift, delete selected item
	//if ( dropeffect == DROPEFFECT_MOVE)
	//	DeleteItem(hTSelItem); 

	delete poleSourceObj;

	*pResult = 0;
}

void CDNDListCtrl::UpdateSelection(int nDropIndex)
{
	if (nDropIndex <0 || nDropIndex >= GetItemCount())
		nDropIndex = GetItemCount()-1;		// Used by DropItem().
	
	// Drop index is valid and has changed since last mouse movement.
	RestorePrevDropItemState();

	// Save information about current potential drop target for restoring next time round.
	m_nPrevDropIndex = nDropIndex;
	m_uPrevDropState = GetItemState(nDropIndex, LVIS_SELECTED);

	// Select current potential drop target.
	SetItemState(nDropIndex, LVIS_SELECTED, LVIS_SELECTED);
	m_nDropIndex = nDropIndex;		// Used by DropItem().

	UpdateWindow();
}

void CDNDListCtrl::RestorePrevDropItemState()
{
	if (m_nPrevDropIndex > -1 && m_nPrevDropIndex < GetItemCount())
	{
		// Restore state of previous potential drop target.
		SetItemState(m_nPrevDropIndex, m_uPrevDropState, LVIS_SELECTED);
	}
}

void CDNDListCtrl::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	lpMeasureItemStruct->itemHeight = m_nRowHeight;
}

void CDNDListCtrl::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	// TODO: Add your message handler code here and/or call default
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);

	if (pDC->IsPrinting()) return;

	CRect rcItem(lpDrawItemStruct->rcItem);

	int nItem = lpDrawItemStruct->itemID;

	LV_ITEM lvi;
	lvi.mask = LVIF_STATE;
	lvi.iItem = nItem;
	lvi.iSubItem = 0;
	lvi.stateMask = 0xFFFF;		// get all state flags
	GetItem(&lvi);

	BOOL bFocus = ((lvi.state & LVIS_FOCUSED) == LVIS_FOCUSED);
	BOOL bSelected = (GetStyle() & LVS_SHOWSELALWAYS) && (lvi.state & LVIS_SELECTED);
	bSelected = bSelected || (lvi.state & LVIS_DROPHILITED);
	CString strCode = GetItemText(nItem, 0);
	BOOL bPopupMenu = (!strCode.IsEmpty() && strCode.GetLength() == 4 && strCode.GetAt(0) == 'P');

	CRect rcAllLabels;
	GetItemRect(nItem, rcAllLabels, LVIR_BOUNDS);

    //CMemDC memDC(pDC);
	CDC memDC; 

	memDC.CreateCompatibleDC(pDC);
	//memDC.SetMapMode(pDC->GetMapMode());

	CBitmap bitmap;
	bitmap.CreateCompatibleBitmap(pDC, rcAllLabels.Width(), rcAllLabels.Height());
	CBitmap* pOldBitmap = memDC.SelectObject(&bitmap);
	//pDC->ExcludeClipRect(rcItem);
	memDC.SetWindowOrg(rcAllLabels.left, rcAllLabels.top);

	CFont* pOldFont = memDC.SelectObject(GetFont());
	memDC.SetBkMode(TRANSPARENT);

	COLORREF crSelected = COLOR_SEL_BK;//RGB(239,255,247);
	COLORREF crBkGnd;
	
	div_t div_result;
	div_result = div(nItem, 5*2);//10);
    crBkGnd = div_result.rem < 5  ? COLOR_LIST_ROW1 : COLOR_LIST_ROW2; 
    //crBkGnd = div_result.rem < 5  ? ::GetSysColor(COLOR_WINDOW) : RGB(247, 247, 247); 

	if (bFocus)
	{
		memDC.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
		crSelected = ::GetSysColor(COLOR_HIGHLIGHT);
	}
	else if (bPopupMenu)
	{
		crBkGnd = ::GetSysColor(COLOR_3DFACE);
	}

	memDC.FillSolidRect(rcAllLabels, bFocus && m_bRowSelect ? crSelected : crBkGnd);

	// draw item
	COLORREF crGridLine = RGB(128,128,128);
	CBrush brush(crGridLine);
	CPen pen(PS_SOLID, 1, crGridLine);
	CPen* pPen = memDC.SelectObject(&pen);

	GetItemRect(nItem, rcItem, LVIR_LABEL);
	LV_COLUMN lvc;
	lvc.mask = LVCF_FMT | LVCF_WIDTH;
	rcItem.OffsetRect(-2, 0);

	for(int nColumn = 0; GetColumn(nColumn, &lvc); nColumn++)
	{
		rcItem.right = rcItem.left + lvc.cx;

		CRect drawRect(rcItem);

		CString sText = GetItemText(nItem, nColumn);

		drawRect.InflateRect(-1,0);
		//drawRect.InflateRect(1,1);
		//pDC->FrameRect(drawRect, &brush);
		memDC.MoveTo(drawRect.right, drawRect.top);
		memDC.LineTo(drawRect.right, drawRect.bottom);

		drawRect.OffsetRect(1,1);
		drawRect.InflateRect(-2,0);

		UINT nJustify = DT_LEFT;
		switch(lvc.fmt & LVCFMT_JUSTIFYMASK)
		{
		case LVCFMT_RIGHT:
			nJustify = DT_RIGHT;
			break;
		case LVCFMT_CENTER:
			nJustify = DT_CENTER;
			break;
		default:
			break;
		}

		memDC.DrawText(sText, -1, drawRect, nJustify | DT_END_ELLIPSIS | DT_SINGLELINE | DT_NOPREFIX | DT_VCENTER);

		rcItem.left = rcItem.right;
	}

	memDC.MoveTo(rcAllLabels.left, rcAllLabels.bottom-1);
	memDC.LineTo(rcAllLabels.right, rcAllLabels.bottom-1);

	if (bFocus && m_bRowSelect)
	{
		CRect rc(rcAllLabels);
		rc.right--;
		rc.bottom--;
		memDC.DrawFocusRect(rc);
	}

	if (bPopupMenu)
	{
		CRect rc(rcAllLabels);
		//rc.right--;
		//rc.bottom--;
		memDC.Draw3dRect(rc, ::GetSysColor(COLOR_BTNHIGHLIGHT), ::GetSysColor(COLOR_BTNSHADOW));
	}

	//pDC->BitBlt(rcAllLabels.left, rcAllLabels.top, rcAllLabels.Width(), rcAllLabels.Height(),
	//	&memDC, rcAllLabels.left, rcAllLabels.top, SRCCOPY);            
	pDC->BitBlt(0, 0, rcAllLabels.right, rcAllLabels.bottom, &memDC, 0, 0, SRCCOPY);

	memDC.SelectObject(pOldFont);
	memDC.SelectObject(pOldBitmap);
	bitmap.DeleteObject();
	memDC.DeleteDC();
}

void CDNDListCtrl::OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	const int iColumn = pNMListView->iSubItem;

	Sort( iColumn, iColumn == m_iSortColumn ? !m_bSortAscending : TRUE );

	*pResult = 0;
}

void CDNDListCtrl::Sort(int iColumn, BOOL bAscending)
{
	m_iSortColumn = iColumn;
	m_bSortAscending = bAscending;

	if (iColumn < 0)
	{
		m_wndHeader.SetSortColumn(-1, FALSE);
		return;
	}

	m_wndHeader.SetSortColumn(m_iSortColumn, m_bSortAscending);

	VERIFY(SortItems(CompareFunction, reinterpret_cast<DWORD>(this)));

	for (int i=0; i < GetItemCount(); i++)
	{
	   SetItemData(i, i);
	}
}

int CALLBACK CDNDListCtrl::CompareFunction( LPARAM lParam1, LPARAM lParam2, LPARAM lParamData )
{
/*
	CDNDListCtrl* pListCtrl = reinterpret_cast<CDNDListCtrl*>(lParamData);
	ASSERT(pListCtrl->IsKindOf(RUNTIME_CLASS(CListCtrl)));

	CItem* item1 = reinterpret_cast<CItem*>(lParam1);
	CItem* item2 = reinterpret_cast<CItem*>(lParam2);

	ASSERT(item1);
	ASSERT(item2);

	LPCTSTR pszText1 = item1->arrpsz[pListCtrl->m_iSortColumn];
	LPCTSTR pszText2 = item2->arrpsz[pListCtrl->m_iSortColumn];
*/
	return 0; //pListCtrl->m_bSortAscending ? lstrcmp( pszText1, pszText2 ) : lstrcmp( pszText2, pszText1 );
}

BOOL CDNDListCtrl::SetCurSel(int nItem)
{
	return SetItemState(nItem, LVIS_FOCUSED | LVIS_SELECTED,
		LVIS_FOCUSED | LVIS_SELECTED);
}

int CDNDListCtrl::GetCurSel()
{
	POSITION pos = GetFirstSelectedItemPosition();
	int nSelectedItem = -1;
	if (pos != NULL)
		nSelectedItem = GetNextSelectedItem(pos);
	return nSelectedItem;
}

void CDNDListCtrl::SetRowHeight(UINT nRowHeight)
{
	m_nRowHeight = nRowHeight;
}

void CDNDListCtrl::SetHeaderColor(COLORREF crHeader)
{
	m_wndHeader.m_cr3DFace = crHeader;
}

void CDNDListCtrl::SetHeaderCaption(UINT nCol, LPTSTR lpCaption)
{
	if (nCol < 0) return;

	HDITEM hdi;
	TCHAR  lpBuffer[256];

	hdi.mask = HDI_TEXT;
	hdi.pszText = lpBuffer;
	hdi.cchTextMax = 256;

	GetHeaderCtrl()->GetItem(nCol, &hdi);
	strcpy(hdi.pszText, lpCaption);
	GetHeaderCtrl()->SetItem(nCol, &hdi);
}

void CDNDListCtrl::SetRowSelect(BOOL bRowSelect)
{
	m_bRowSelect = bRowSelect;
}

// Sorting ����
BOOL CDNDListCtrl::DeleteItem(int iItem)
{
	FreeItemMemory(iItem);
	return CListCtrl::DeleteItem( iItem );
}

BOOL CDNDListCtrl::DeleteAllItems()
{
	for(int iItem = 0; iItem < GetItemCount(); iItem++)
		FreeItemMemory( iItem );
	return CListCtrl::DeleteAllItems();
}

int  CDNDListCtrl::InsertItem(int nItem, LPCTSTR lpszItem)
{
	const int nIndex = CListCtrl::InsertItem(nItem, lpszItem);
	const int iNumColumns = GetHeaderCtrl()->GetItemCount();

	LPTSTR* arrpsz = new LPTSTR[iNumColumns];
	arrpsz[0] = new TCHAR[lstrlen(lpszItem) + 1];
	lstrcpy(arrpsz[0], lpszItem);

	for (int i=1; i<iNumColumns; i++)
		arrpsz[i] = NULL;

//	VERIFY(SetTextArray(nIndex, arrpsz));

	return nIndex;
}

BOOL CDNDListCtrl::SetItemText(int nItem, int nSubItem, LPCTSTR lpszText)
{
	if (!CListCtrl::SetItemText(nItem, nSubItem, lpszText))
		return FALSE;

	LPTSTR* arrpsz = GetTextArray(nItem);
	if(arrpsz==NULL) return 0;

	LPTSTR pszText = arrpsz[nSubItem];

	if (pszText)
		delete[] pszText;

	pszText = new TCHAR[lstrlen(lpszText) + 1];
	lstrcpy(pszText, lpszText);
	arrpsz[nSubItem] = pszText;

	return TRUE;
}

BOOL CDNDListCtrl::SetItemData(int nItem, DWORD dwData)
{
	if( nItem >= GetItemCount() )
		return FALSE;


	return TRUE;
}

DWORD CDNDListCtrl::GetItemData(int nItem) const
{

	return 0; //item->dwData;
}

BOOL CDNDListCtrl::SetTextArray(int iItem, LPTSTR* arrpsz)
{
	return 0; //item->arrpsz;
	CListCtrl::SetItemData(iItem, reinterpret_cast<DWORD>(arrpsz));
}

LPTSTR* CDNDListCtrl::GetTextArray(int iItem) const
{
	return 0; //item->arrpsz;
}

void CDNDListCtrl::FreeItemMemory(const int iItem)
{
}

void CDNDListCtrl::OnDestroy() 
{
	const int iNumColumns = GetItemCount();
	for(int iItem=0; iItem<iNumColumns; iItem++)
		FreeItemMemory(iItem);

	CListCtrl::OnDestroy();
}
