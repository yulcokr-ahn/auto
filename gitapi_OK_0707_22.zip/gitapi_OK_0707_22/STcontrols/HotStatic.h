#if !defined(AFX_HOTSTATIC_H__EE9873AD_A985_11D4_B9A6_0050DA80C84F__INCLUDED_ST_)
#define AFX_HOTSTATIC_H__EE9873AD_A985_11D4_B9A6_0050DA80C84F__INCLUDED_ST_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HotStatic.h : header file
//

#include "../Include/hrefer.h" //2010616

/////////////////////////////////////////////////////////////////////////////
// CSTHotStatic window

class AFX_EXT_CLASS CSTHotStatic : public CStatic
{
// Construction
public:
	CSTHotStatic();
	
	//20140606
	void Line(CDC* pDC,int xLeft, int yTop,int xRight, int yBottom, unsigned long c);
	int  m_BLOCK_Array; //�������� ����� LINE�� �׸���. 20140606
	int  m_BLOCK_OnMODE; //�������� On ����� LINE�� �׸���. 20140606
	COLORREF m_crBLOCK_ON_Background;

	void SetBLOCKArray(int OnMODE,int nOrderType,int nIndexOrderType,int nArray,COLORREF m_crBlock); //�������� ����� LINE�� �׸���. 20140606
	void SetTextArray(CStringArray &strTextArray, int *ArrayOn);
	CStringArray *m_pTextArray;
	int *m_ArrayOn;
	void Line_BF(CDC* pDC,int xLeft, int yTop,int xRight, int yBottom, unsigned long c);

	int	m_nOrderType;
	int	m_nIndexOrderType;



	long            m_DS_iPostionType_P; 	// ����������  SE_XPX_ACTIVE_NEW_ORDER    = �ű�, SE_XPX_ACTIVE_PAYOFF_ORDER = û��
	POSTION_AESA *m_pPOS_VIEW;
	void SetPOS_VIEW(POSTION_AESA *TmpKepler, int nSize,int iPostionType_P);

	int nSize_GROUP_COLOR; //<-POSTION_GROUP_COLOR

	int m_COLOR_Array;
	CWnd *m_pParent;
	POSTION_GROUP_COLOR *m_pGroupColor;
	void SetGROUP_COLOR(CWnd *pParent, POSTION_GROUP_COLOR *TmpGROUP_COLOR, int nSize); //���콺 ��Į Ŭ���� �θ���� �޼����� color index ���۱�� 
	void SetCOLORArray(int nArray, int nMODE); //�������� ����� LINE�� �׸���. 20140606


	COLORREF textColor( COLORREF );
    COLORREF textColor() const { return m_crTextColor; }
// Attributes
public:
	COLORREF m_crTextColor;
	COLORREF m_crBackground;
//	CFont	m_textfont;
	CString	m_strText;
	int		m_nAlign;
	BOOL	m_bVCenter;
	int		m_nFontType;
	int		m_nFontSize;
	BOOL	m_bBorder;

	CRect		m_rcCmbBtn;

// Operations
public:
	void DrawBorder(CDC* pDC);

// Overrides
	// ClassWizard generated virtual function overrides
	virtual void SetWindowText(LPCTSTR lpszString, int nAlign = DT_CENTER);
	virtual void GetWindowText(CString& rString);
	//{{AFX_VIRTUAL(CSTHotStatic)
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetFontSize(int nSize)	{	m_nFontSize = nSize; }
	int  GetFontSize()			{	return m_nFontSize;	}
	void SetSymbol(int symbol = 1);
	COLORREF GetBkColor();
	void SetBkColor(COLORREF crBk);
	void SetBorder(BOOL bBorder);
	virtual ~CSTHotStatic();

	// Generated message map functions
protected:
	//{{AFX_MSG(CSTHotStatic)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
	BOOL				m_bIsSymbol;
	int					m_nSymbol;

	CBitmap				*m_pSymbol;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HOTSTATIC_H__EE9873AD_A985_11D4_B9A6_0050DA80C84F__INCLUDED_ST_)
