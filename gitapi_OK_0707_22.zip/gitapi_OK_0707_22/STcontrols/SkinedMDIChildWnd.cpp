// SkinedMDIChildWnd.cpp : implementation file
//

#include "stdafx.h"
#include "Resource.h"
#include "SkinedMDIChildWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CSkinedMDIChildWnd
IMPLEMENT_DYNCREATE(CSkinedMDIChildWnd, CMDIChildWnd)

CSkinedMDIChildWnd::CSkinedMDIChildWnd()
{
	LoadBitmaps();

	m_bLButtonDown = FALSE;
	m_bInit = FALSE;

	m_bEnableTrans = FALSE;	// ���� ������ ����
	m_bEnablePopup = TRUE;	// Popup window ����
	m_bEnableDock = FALSE;	// Docking Window ����
	m_bEnableResize = TRUE;

	m_pChildDlg = NULL;
	m_pPopWnd = NULL;

	OSVERSIONINFO osinfo;
	osinfo.dwOSVersionInfoSize = sizeof(osinfo);
	GetVersionEx(&osinfo);

	if(osinfo.dwPlatformId != VER_PLATFORM_WIN32_WINDOWS)
		m_bEnableTrans = TRUE;	// ���� ������ ����
}

CSkinedMDIChildWnd::~CSkinedMDIChildWnd()
{
	for (int i=0; i<7; i++)
	{
		for (int j=0; j<2; j++)
			m_bmButton[i][j].DeleteObject();
	}
}


BEGIN_MESSAGE_MAP(CSkinedMDIChildWnd, CMDIChildWnd)
	//{{AFX_MSG_MAP(CSkinedMDIChildWnd)
	//ON_MESSAGE(WM_SETTEXT, OnSetText)
	ON_WM_NCPAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_NCACTIVATE()
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_NCLBUTTONUP()
	ON_WM_NCMOUSEMOVE()
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_MDIACTIVATE()
	ON_WM_CHILDACTIVATE()
	ON_WM_WINDOWPOSCHANGED()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSkinedMDIChildWnd message handlers


void CSkinedMDIChildWnd::OnNcPaint() 
{
	CalculateSize();
	
	if (IsZoomed() || IsIconic())
	{
		CMDIChildWnd::OnNcPaint();
		return;
	}

	PaintFrameBorder();		// FrameBorder�� �׸���.

	CDC *pDC = GetWindowDC();
	CRect rcWindow;
	GetWindowRect(&rcWindow);

	CDC dcCaption;
	dcCaption.CreateCompatibleDC(pDC);

	CBitmap bmCaption;
	bmCaption.CreateCompatibleBitmap(pDC, m_rcCaption.Width(), m_rcCaption.Height());
	CBitmap* pOldBitmap = dcCaption.SelectObject(&bmCaption);

	PaintBackground(&dcCaption);
	PaintIcon(&dcCaption);
	PaintText(&dcCaption);
	PaintButtons(&dcCaption, -1);
	
	pDC->BitBlt(m_rcCaption.left, m_rcCaption.top, m_rcCaption.Width(), m_rcCaption.Height(), &dcCaption, 0, 0, SRCCOPY);
	dcCaption.SelectObject(pOldBitmap);

	bmCaption.DeleteObject();
	dcCaption.DeleteDC();	
	ReleaseDC(pDC);
}

BOOL CSkinedMDIChildWnd::OnNcActivate(BOOL bXPX_ACTIVE) 
{
	DWORD dwStyle = GetStyle();

	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, (dwStyle & ~ WS_VISIBLE));

	MSG& msg = AfxGetThreadState()->m_lastSentMsg;
	msg.wParam = bXPX_ACTIVE;
	Default();
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	// 2005.06.08 Add
	m_bXPX_ACTIVE = bXPX_ACTIVE;
	AfxGetMainWnd()->SendMessage(WM_XPX_ACTIVETASK, (WPARAM)this, (LPARAM)m_bXPX_ACTIVE);
	OnNcPaint();
	//==========================

	return TRUE;
}

void CSkinedMDIChildWnd::PaintBackground(CDC *pDC)
{
	CBrush brPattern;

	CDC memDC;

	memDC.CreateCompatibleDC(pDC);
	if (m_bXPX_ACTIVE)
		memDC.SelectObject(&m_bmCaptionOn);
	else
		memDC.SelectObject(&m_bmCaptionOff);

	CRect rcCaption;
	GetCaptionRect(rcCaption);
	rcCaption -= rcCaption.TopLeft();
	
	pDC->StretchBlt(rcCaption.left, rcCaption.top, rcCaption.Width(), rcCaption.Height(), &memDC, 0, 0, 1, rcCaption.Height(), SRCCOPY);
	memDC.DeleteDC();	
}

void CSkinedMDIChildWnd::PaintIcon(CDC *pDC)
{
	CRect rc(0, 0, 16, 16);
	rc.OffsetRect(2,0);
	DrawIconEx(pDC->m_hDC, rc.left, rc.top, 
			m_hIcon,
			rc.Width(), rc.Height(), 0, NULL, DI_NORMAL);
}


void CSkinedMDIChildWnd::GetCaptionRect(CRect &rcCaption)
{
	CSize szFrame;

	GetWindowRect(&rcCaption);
	rcCaption -= rcCaption.TopLeft();
	rcCaption.DeflateRect(1, 1);
	rcCaption.bottom = rcCaption.top + 20;
}

void CSkinedMDIChildWnd::GetFrameSize(CSize &szFrame)
{
	szFrame.cx = 1;
	szFrame.cy = 1;
}

void CSkinedMDIChildWnd::PaintText(CDC *pDC)
{
	CString strTitle;
	CPoint pt;
	CRect rcCaption, rcDrawText;
	GetCaptionRect(rcCaption);

	// Draw Text
	HFONT hOldFont = (HFONT)::SelectObject(pDC->GetSafeHdc(), (HFONT)::GetStockObject(DEFAULT_GUI_FONT));

	CSize szTextExtent = pDC->GetTextExtent(m_strTitle);
	
	pt.x = GetSystemMetrics(SM_CXSIZE) + 4;
	pt.y = (rcCaption.Height() - szTextExtent.cy) >> 1;

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(GetSysColor(COLOR_CAPTIONTEXT));

	pDC->TextOut(pt.x, pt.y, m_strTitle);

	::SelectObject(pDC->GetSafeHdc(), hOldFont);
}

void CSkinedMDIChildWnd::PaintButtons(CDC *pDC, int nHitTest)
{
	CRect rcBtn;
	CDC		dcBtn;
	dcBtn.CreateCompatibleDC(pDC);


	// Close ��ư�� �׸���.
	rcBtn = m_rcButton[SB_CLOSE];
	if(nHitTest < 0)
		rcBtn -= m_rcCaption.TopLeft();

	if (nHitTest == HTCLOSE && m_bLButtonDown)
		dcBtn.SelectObject(&m_bmButton[SB_CLOSE][1]);
	else
		dcBtn.SelectObject(&m_bmButton[SB_CLOSE][0]);

	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	// �ִ�ȭ��ư�� �׸���.
	rcBtn = m_rcButton[SB_MAXIMIZE];
	if(nHitTest < 0)
		rcBtn -= m_rcCaption.TopLeft();

	if (nHitTest == HTMAXBUTTON && m_bLButtonDown)
		dcBtn.SelectObject(&m_bmButton[SB_MAXIMIZE][1]);
	else
		dcBtn.SelectObject(&m_bmButton[SB_MAXIMIZE][0]);

	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	// �ּ�ȭ��ư�� �׸���.
	rcBtn = m_rcButton[SB_MINIMIZE];
	if(nHitTest < 0)
		rcBtn -= m_rcCaption.TopLeft();

	if (nHitTest == HTMINBUTTON && m_bLButtonDown)
		dcBtn.SelectObject(&m_bmButton[SB_MINIMIZE][1]);
	else
		dcBtn.SelectObject(&m_bmButton[SB_MINIMIZE][0]);

	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	// Docking ��ư�� �׸���.
	if(m_bEnableDock)
	{
		rcBtn = m_rcButton[SB_DOCKING];
		if(nHitTest < 0)
			rcBtn -= m_rcCaption.TopLeft();

		if (nHitTest == HT_EX_DOCKING && m_bLButtonDown)
			dcBtn.SelectObject(&m_bmButton[SB_DOCKING][1]);
		else
			dcBtn.SelectObject(&m_bmButton[SB_DOCKING][0]);

		pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);
	}

	// PopUp ��ư�� �׸���.
	if(m_bEnablePopup || m_bEnableDock)
	{
		rcBtn = m_rcButton[SB_POPUP];
		if(nHitTest < 0)
			rcBtn -= m_rcCaption.TopLeft();

		if (nHitTest == HT_EX_POPUP && m_bLButtonDown)
			dcBtn.SelectObject(&m_bmButton[SB_POPUP][1]);
		else
			dcBtn.SelectObject(&m_bmButton[SB_POPUP][0]);

		pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);
	}

	// ���� ��ư�� �׸���.
	if(m_bEnableTrans)
	{
		rcBtn = m_rcButton[SB_TRANSPARENT];
		if(nHitTest < 0)
			rcBtn -= m_rcCaption.TopLeft();

		if (nHitTest == HT_EX_TRANSPARENT && m_bLButtonDown)
			dcBtn.SelectObject(&m_bmButton[SB_TRANSPARENT][1]);
		else
			dcBtn.SelectObject(&m_bmButton[SB_TRANSPARENT][0]);

		pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);
	}

	// ���򸻹�ư�� �׸���.
	rcBtn = m_rcButton[SB_HELP];
	if(nHitTest < 0)
		rcBtn -= m_rcCaption.TopLeft();

	if (nHitTest == HTHELP && m_bLButtonDown)
		dcBtn.SelectObject(&m_bmButton[SB_HELP][1]);
	else
		dcBtn.SelectObject(&m_bmButton[SB_HELP][0]);

	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	dcBtn.DeleteDC();
}

LRESULT CSkinedMDIChildWnd::OnNcHitTest(CPoint point) 
{
	if (IsZoomed()  || IsIconic())
	{
		return CMDIChildWnd::OnNcHitTest(point);
	}

	UINT uHitTest;

	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	point -= rcWindow.TopLeft();
	
	CRect rcSize;
	int nSize = 4;

	rcWindow -= rcWindow.TopLeft();

	//corner
	if(m_bEnableResize)
	{
		rcSize.SetRect(rcWindow.left, rcWindow.top, rcWindow.left+nSize, rcWindow.top+nSize);
		if(rcSize.PtInRect(point))
			return HTTOPLEFT;
		rcSize.SetRect(rcWindow.right-nSize, rcWindow.top, rcWindow.right, rcWindow.top+nSize);
		if(rcSize.PtInRect(point))
			return HTTOPRIGHT;
		rcSize.SetRect(rcWindow.left, rcWindow.bottom-nSize, rcWindow.left+nSize, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTBOTTOMLEFT;
		rcSize.SetRect(rcWindow.right-nSize, rcWindow.bottom-nSize, rcWindow.right, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTBOTTOMRIGHT;

		// border
		rcSize.SetRect(rcWindow.left, rcWindow.top, rcWindow.right, rcWindow.top+nSize);
		if(rcSize.PtInRect(point))
			return HTTOP;
		rcSize.SetRect(rcWindow.left, rcWindow.bottom-nSize, rcWindow.right, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTBOTTOM;
		rcSize.SetRect(rcWindow.left, rcWindow.top, rcWindow.left+nSize, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTLEFT;
		rcSize.SetRect(rcWindow.right-nSize, rcWindow.top, rcWindow.right, rcWindow.bottom);
		if(rcSize.PtInRect(point))
			return HTRIGHT;
	}

	if(m_bEnableDock)
	{
		if (m_rcButton[SB_DOCKING].PtInRect(point))
		{
			uHitTest = HT_EX_DOCKING;
			return uHitTest;
		}
	}

	if (m_rcSysMenu.PtInRect(point))
		uHitTest = HTSYSMENU;
	else if (m_rcButton[SB_CLOSE].PtInRect(point))
		uHitTest = HTCLOSE;
	else if (m_rcButton[SB_MAXIMIZE].PtInRect(point))
		uHitTest = HTMAXBUTTON;
	else if (m_rcButton[SB_MINIMIZE].PtInRect(point))
		uHitTest = HTMINBUTTON;
	else if (m_rcButton[SB_POPUP].PtInRect(point))
		uHitTest = HT_EX_POPUP;
	else if (m_rcButton[SB_TRANSPARENT].PtInRect(point))
		uHitTest = HT_EX_TRANSPARENT;
	else if (m_rcButton[SB_HELP].PtInRect(point))
		uHitTest = HTHELP;
	else if (rcCaption.PtInRect(point))
		uHitTest = HTCAPTION;
	else
		uHitTest = HTNOWHERE;
	return uHitTest;
}

void CSkinedMDIChildWnd::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	if (IsZoomed()  || IsIconic())
	{
		CMDIChildWnd::OnNcCalcSize(bCalcValidRects, lpncsp);
		return;
	}

	DWORD dwStyle = GetStyle();
	CSize szFrame = (dwStyle & WS_THICKFRAME) ?
		CSize(GetSystemMetrics(SM_CXSIZEFRAME),
			   GetSystemMetrics(SM_CYSIZEFRAME)) :
		CSize(GetSystemMetrics(SM_CXFIXEDFRAME),
				GetSystemMetrics(SM_CYFIXEDFRAME));

	int nCaptionY = GetSystemMetrics(SM_CYCAPTION);

	InflateRect(&lpncsp->rgrc[0], szFrame.cx-1, szFrame.cy-1);
	lpncsp->rgrc[0].top -= (nCaptionY - 20);

	CMDIChildWnd::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void CSkinedMDIChildWnd::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	// 2005.06.08 Delete
	//m_bXPX_ACTIVE = TRUE;
	//==========================

	if (IsZoomed()  || IsIconic())
	{
		CMDIChildWnd::OnNcLButtonDown(nHitTest, point);
		return;
	}

	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	rcCaption -= rcWindow.TopLeft();

	switch(nHitTest)
	{
	case HTCLOSE:
	case HTMAXBUTTON:
	case HTMINBUTTON:
	case HT_EX_POPUP:
	case HT_EX_DOCKING:
	case HT_EX_TRANSPARENT:
	case HTHELP:
		m_bLButtonDown = TRUE;
		m_nHitTest = nHitTest;
		break;
	case HTCAPTION:
		// 2005.06.08 Delete
		//SetFocus();
		//SendMessage(WM_SYSCOMMAND, 0x0000F012, 0x0);
		//break;
		//==========================

		// 2005.06.08 Add
		SetFocus();
		UpdateWindow();
		Default();
		return;
		//==========================
	default:
		CMDIChildWnd::OnNcLButtonDown(nHitTest, point);
		break;

	}
	OnNcPaint();
	UpdateButtons(nHitTest);
}

void CSkinedMDIChildWnd::OnNcLButtonUp(UINT nHitTest, CPoint point) 
{
	if (IsZoomed()  || IsIconic())
	{
		CMDIChildWnd::OnNcLButtonUp(nHitTest, point);
		return;
	}

	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	rcCaption -= rcWindow.TopLeft();

	if (m_bLButtonDown && m_nHitTest == nHitTest)
	{
		switch(nHitTest)
		{
		case HTCLOSE:
			// 2005.06.14 Add
			ShowWindow(SW_HIDE);
			::UpdateWindow(((CMDIFrameWnd*)AfxGetMainWnd())->m_hWndMDIClient);
			//==========================
			SendMessage(WM_SYSCOMMAND, (WPARAM)SC_CLOSE);
			return;
		case HTMINBUTTON:
			if (IsIconic())
				SendMessage(WM_SYSCOMMAND, (WPARAM)SC_RESTORE);
			else
			{
				SendMessage(WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE);
				return;
			}
			break;
		case HTMAXBUTTON:
			if(m_bEnableResize)
				SendMessage(WM_SYSCOMMAND, (WPARAM)SC_MAXIMIZE);
			break;
		case HT_EX_TRANSPARENT:
			PopWndPricessing(TRUE);
			break;
		case HT_EX_POPUP:
			PopWndPricessing(FALSE);
			break;
		default:
			CMDIChildWnd::OnNcLButtonUp(nHitTest, point);
			break;
		}
	}
	else
	{
		CMDIChildWnd::OnNcLButtonUp(nHitTest, point);
	}

	m_bLButtonDown = FALSE;
	m_nHitTest = HTNOWHERE;
	OnNcPaint();
	UpdateButtons(HTNOWHERE);
}

void CSkinedMDIChildWnd::CalcButtonsRect()
{
	CRect rcTmp;

	DWORD dwStyle = GetStyle();
	
	// �����ư
	rcTmp.right = m_rcCaption.right -5;
	rcTmp.left = rcTmp.right - 14;
	rcTmp.top = m_rcCaption.top + 2;
	rcTmp.bottom = rcTmp.top + 13;

	m_rcButton[SB_CLOSE] = rcTmp;

	BOOL bGroup = FALSE;

	// �ִ�ȭ
	rcTmp.right = rcTmp.left - 2;
	rcTmp.left = rcTmp.right - 14;
	m_rcButton[SB_MAXIMIZE] = rcTmp;
	bGroup = TRUE;

	// �ּ�ȭ
	rcTmp.right = rcTmp.left;
	if (!bGroup)
		rcTmp.right -= 2;
	rcTmp.left = rcTmp.right - 14;
	m_rcButton[SB_MINIMIZE] = rcTmp;
	bGroup = TRUE;

	// popup
	if(m_bEnablePopup)
	{
		rcTmp.right = rcTmp.left - 2;
		if (!bGroup)
			rcTmp.right -= 2;

		rcTmp.left = rcTmp.right - 14;
		m_rcButton[SB_POPUP] = rcTmp;
	}

	// ����
	if(m_bEnableTrans)
	{
		rcTmp.right = rcTmp.left;
		if (!bGroup)
			rcTmp.right -= 2;

		rcTmp.left = rcTmp.right - 14;
		m_rcButton[SB_TRANSPARENT] = rcTmp;
	}

	// docking
	if(m_bEnableDock)
	{
		rcTmp.right = rcTmp.left - 2;
		if (!bGroup)
			rcTmp.right -= 2;

		rcTmp.left = rcTmp.right - 14;
		m_rcButton[SB_DOCKING] = rcTmp;
	}

	// ����
	rcTmp.right = rcTmp.left - 2;
	rcTmp.left = rcTmp.right - 14;
	m_rcButton[SB_HELP] = rcTmp;

	m_rcText.right = rcTmp.left - 2;
}


void CSkinedMDIChildWnd::LoadBitmaps()
{
	m_bmCaptionOn.LoadBitmap(IDB_CAPTIONON);
	m_bmCaptionOff.LoadBitmap(IDB_CAPTIONOFF);

	m_bmButton[SB_HELP][0].LoadBitmap(IDB_HELP_UP);
	m_bmButton[SB_HELP][1].LoadBitmap(IDB_HELP_DOWN);

	m_bmButton[SB_TRANSPARENT][0].LoadBitmap(IDB_TRANS_UP);
	m_bmButton[SB_TRANSPARENT][1].LoadBitmap(IDB_TRANS_DOWN);

	m_bmButton[SB_DOCKING][0].LoadBitmap(IDB_DOCKING_UP);
	m_bmButton[SB_DOCKING][1].LoadBitmap(IDB_DOCKING_DOWN);

	m_bmButton[SB_POPUP][0].LoadBitmap(IDB_FULLSCREEN_UP);
	m_bmButton[SB_POPUP][1].LoadBitmap(IDB_FULLSCREEN_DOWN);

	m_bmButton[SB_MINIMIZE][0].LoadBitmap(IDB_MINIMIZE_UP);
	m_bmButton[SB_MINIMIZE][1].LoadBitmap(IDB_MINIMIZE_DOWN);

	m_bmButton[SB_MAXIMIZE][0].LoadBitmap(IDB_REDUCE_UP);
	m_bmButton[SB_MAXIMIZE][1].LoadBitmap(IDB_REDUCE_DOWN);

	m_bmButton[SB_CLOSE][0].LoadBitmap(IDB_CLOSE_UP);
	m_bmButton[SB_CLOSE][1].LoadBitmap(IDB_CLOSE_DOWN);

}

void CSkinedMDIChildWnd::UpdateButtons(UINT nHitTest)
{
	CWindowDC dc(this);
	PaintButtons(&dc, nHitTest);
}

#if 0
void CSkinedMDIChildWnd::OnSetText(WPARAM wParam, LPCTSTR lpszString)
{
	if(strlen(lpszString) <= 0)
		return;
	CWnd *pWnd = AfxGetMainWnd();
	pWnd->SendMessage(WM_CHANGETASKTITLE, (WPARAM)this, (LPARAM)lpszString);
	m_strTitle = lpszString;

	if(!(IsZoomed() || IsIconic()))
		OnNcPaint();
}
#endif

void CSkinedMDIChildWnd::PaintFrameBorder()
{
	CWindowDC	dc(this);
	CRect		rcWindow;
	GetWindowRect(&rcWindow);
	rcWindow -= rcWindow.TopLeft();

	CPen penBorder(PS_SOLID, 1, RGB(83,83,83));
	CPen* pOldPen = dc.SelectObject(&penBorder);
	dc.SelectObject(GetStockObject(NULL_BRUSH));
	dc.Rectangle(rcWindow);
	dc.SelectObject(pOldPen);
	penBorder.DeleteObject();

	//rcWindow.DeflateRect(1, 21, 1, 1);
	//dc.DrawEdge(&rcWindow, EDGE_SUNKEN, BF_RECT);
}

BOOL CSkinedMDIChildWnd::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= WS_CLIPCHILDREN;
	cs.style &= ~WS_VISIBLE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;


	CWinApp *pApp = AfxGetApp();
	pApp->m_nCmdShow = SW_HIDE;
	return CMDIChildWnd::PreCreateWindow(cs);
}

void CSkinedMDIChildWnd::ActivateFrame(int nCmdShow)
{
	CMDIChildWnd::ActivateFrame((nCmdShow < 0)?SW_HIDE:nCmdShow);
}


int CSkinedMDIChildWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO: Add your specialized creation code here
	CWnd *pWnd = AfxGetMainWnd();

	DWORD dwStyle = GetStyle();
	dwStyle |= WS_CAPTION;
	dwStyle &= ~(WS_MAXIMIZEBOX);
	SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	DWORD dwExStyle = GetExStyle();
	dwExStyle &= ~(WS_EX_CLIENTEDGE);
	SetWindowLong(m_hWnd, GWL_EXSTYLE, dwExStyle);

	m_hIcon = (HICON)LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_WINDOW));
	SetWindowLong(m_hWnd, GCL_HICONSM, (LONG)m_hIcon);
	SetWindowLong(m_hWnd, GCL_HICON, (LONG)m_hIcon);

	pWnd->SendMessage(WM_ADDTASK, (WPARAM)this, (LPARAM)(LPCTSTR)m_strTitle);

	CRect rc;
	GetWindowRect(&rc);
	int nCaptionY = GetSystemMetrics(SM_CYCAPTION);
	rc.right -= 3;
	rc.bottom -= (nCaptionY - 20);
	
	return 0;
}


void CSkinedMDIChildWnd::OnSize(UINT nType, int cx, int cy) 
{
	CMDIChildWnd::OnSize(nType, cx, cy);

	CRect rcClient;
	if (m_pChildDlg)
	{
		GetClientRect(&rcClient);
		m_pChildDlg->SetWindowPos(NULL, 0, 0, cx, cy, SWP_NOMOVE | SWP_NOZORDER);
	}
}


BOOL CSkinedMDIChildWnd::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	// 2005.06.14 Add
	if (pMsg->message == WM_SYSCOMMAND && pMsg->wParam ==  SC_SIZE && !m_bEnableResize)
	{
		pMsg->message = 0;
		return 1;
	}
	//==========================

	return CMDIChildWnd::PreTranslateMessage(pMsg);
}

void CSkinedMDIChildWnd::CalculateSize()
{
	GetCaptionRect(m_rcCaption);

	int cxIcon = GetSystemMetrics(SM_CXSIZE);
	CRect rc(0, 0, cxIcon, GetSystemMetrics(SM_CYSIZE));
	rc.DeflateRect(0,1);
	rc.left += 2;

	m_rcSysMenu = rc;
	CSize szFrame;
	GetFrameSize(szFrame);

	m_rcSysMenu += szFrame;

	m_rcText.left = m_rcSysMenu.right + 1;
	m_rcText.top = m_rcCaption.top;
	m_rcText.bottom = m_rcCaption.bottom;
	m_rcText.right = m_rcCaption.right - 1;

	CalcButtonsRect();		// ��ư�� ������ ����Ѵ�.
}

void CSkinedMDIChildWnd::OnNcMouseMove(UINT nHitTest, CPoint point) 
{
	if (IsZoomed()  || IsIconic())
	{
		CMDIChildWnd::OnNcMouseMove(nHitTest, point);
		return;
	}

	if (m_bLButtonDown && (m_nHitTest != nHitTest))
	{
		m_bLButtonDown = FALSE;
		m_nHitTest = HTNOWHERE;
	}
	//CMDIChildWnd::OnNcMouseMove(nHitTest, point);

	// 2005.06.08 Add
	if (nHitTest > HTHELP)
	{
		OnNcPaint();
	}
	//==========================

	// 2005.06.08 Delete
	//OnNcPaint();
	//==========================
}

void CSkinedMDIChildWnd::OnDestroy() 
{
	CMDIChildWnd::OnDestroy();

	DeleteObject(m_hIcon);

	if(m_pChildDlg)
	{
		if(!m_pChildDlg->IsKindOf(RUNTIME_CLASS(CView)))
		{
			m_pChildDlg->DestroyWindow();
			delete m_pChildDlg;
		}
	}

	CWnd *pWnd = AfxGetMainWnd();
	pWnd->SendMessage(WM_DELETETASK, (WPARAM)this, (LPARAM)0);
}


void CSkinedMDIChildWnd::OnMDIActivate(BOOL bActivate, CWnd* pActivateWnd, CWnd* pDeactivateWnd) 
{
	CWnd *pWnd = AfxGetMainWnd();

	if(m_pPopWnd && bActivate)
	{
		pWnd->SendMessage(WM_XPX_ACTIVETASK, (WPARAM)this, (LPARAM)bActivate);
		m_pPopWnd->SetForegroundWindow();
		return;
	}

	// 2005.06.08 Add
	DWORD dwStyle = GetStyle();
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, (dwStyle & ~ WS_VISIBLE));
	CMDIChildWnd::OnMDIActivate(bActivate, pActivateWnd, pDeactivateWnd);
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	SetWindowPos(&CWnd::wndTopMost, 0,0,0,0, 
		SWP_FRAMECHANGED|SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOSIZE|SWP_NOMOVE);
	UpdateWindow();
	//==========================

	// 2005.06.08 Delete
	/*
	DWORD dwStyle = GetStyle();

	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, (dwStyle & ~ WS_VISIBLE));
	CMDIChildWnd::OnMDIActivate(bActivate, pActivateWnd, pDeactivateWnd);
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	if(bActivate && m_bInit)
	{
		ShowWindow(SW_HIDE);
		ShowWindow(SW_SHOW);
	}

	m_bXPX_ACTIVE = bActivate;
	OnNcPaint();
	pWnd->SendMessage(WM_XPX_ACTIVETASK, (WPARAM)this, (LPARAM)bActivate);
	*/
}

void CSkinedMDIChildWnd::OnChildActivate() 
{
	CMDIChildWnd::OnChildActivate();
	//CWnd *pWnd = AfxGetMainWnd();
	//pWnd->SendMessage(WM_XPX_ACTIVETASK, (WPARAM)this, (LPARAM)TRUE);
}


void CSkinedMDIChildWnd::OnWindowPosChanged(WINDOWPOS* lpwndpos)
{
	if (IsZoomed()  || IsIconic())
	{
		CMDIChildWnd::OnWindowPosChanged(lpwndpos);
		return;
	}
	CMDIChildWnd::OnWindowPosChanged(lpwndpos);
	OnNcPaint();
}


void CSkinedMDIChildWnd::PopWndPricessing(BOOL bTransparent, BOOL bCenter)
{
	CRect rcWnd;
	GetWindowRect(rcWnd);

	ShowWindow(SW_HIDE);
	SendMessage(WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE);
	ShowWindow(SW_HIDE);

	m_pPopWnd = (CSkinedFrameWnd *)new CSkinedFrameWnd();
	CString wndclass = AfxRegisterWndClass(CS_DBLCLKS, LoadCursor(NULL, IDC_ARROW), NULL, 0);
	m_pPopWnd->CreateEx(NULL, wndclass, "SkinedFrameWnd", WS_OVERLAPPEDWINDOW|WS_POPUP|WS_VISIBLE, 
						rcWnd, NULL, NULL);
	if(bCenter)
		m_pPopWnd->CenterWindow(CWnd::GetDesktopWindow());

	m_pPopWnd->SetDialog(m_pChildDlg, m_strTitle, m_bEnableResize);
	if(bTransparent)
	{
		m_pPopWnd->SetTransParent(bTransparent);
		m_pPopWnd->m_bBypassPopUp = TRUE;
	}
	m_pPopWnd->m_bEnableDock = m_bEnableDock;
}


void CSkinedMDIChildWnd::SetDialog(CWnd *pDlg, CString strTitle, BOOL bResize, BOOL bPopUp)
{
	ASSERT(pDlg != NULL);
	m_pChildDlg = pDlg;
	m_pChildDlg->SetParent(this);
	m_strTitle = strTitle;
	SetWindowText(m_strTitle);

	m_bEnableResize = bResize;

	CRect rtWindow, rtClient;
	GetWindowRect(&rtWindow);
	GetClientRect(&rtClient);

	int nDiffWidth = rtWindow.Width() - rtClient.Width();
	int nDiffHeight = rtWindow.Height() - rtClient.Height();

	CRect rcDialog;
    pDlg->GetWindowRect(rcDialog);

	SetWindowPos(NULL, 0, 0, nDiffWidth + rcDialog.Width(), nDiffHeight + rcDialog.Height(), SWP_NOMOVE | SWP_NOZORDER);

	m_bInit = TRUE;

	if(!bPopUp)
	{
		CenterWindow(CWnd::GetDesktopWindow());
		m_pChildDlg->ShowWindow(SW_SHOW);   
		ShowWindow(SW_NORMAL);
		UpdateWindow();
	}
	if(bPopUp)
		PopWndPricessing(FALSE, TRUE);
}


void CSkinedMDIChildWnd::SetWindowText(LPCTSTR lpszString)
{
	m_strTitle = lpszString;
	DWORD dwStyle = GetStyle();
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, (dwStyle & ~ WS_VISIBLE));

	CMDIChildWnd::SetWindowText(lpszString);
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	OnNcPaint();
	CWnd *pWnd = AfxGetMainWnd();
	pWnd->SendMessage(WM_CHANGETASKTITLE, (WPARAM)this, (LPARAM)lpszString);
	if(m_pPopWnd)
		m_pPopWnd->SetWindowText(lpszString);
}

