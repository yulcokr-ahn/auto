// ImageStatic.cpp : implementation file
//

#include "stdafx.h"
#include "ImageStatic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImageStatic

CImageStatic::CImageStatic()
{
	m_nBYUnit = 1;
	m_nChtFillYang =1;
	m_nChtFillUm =1;
	m_nTotCnt =10;			//Default�� MaxSize�� 10���� �����Ѵ� 
	m_nChtListCnt =0;
	m_nChtArrayCnt =0;
	m_pChtDataList = new CHTData[10];
	m_bCurDraw = TRUE;
	m_bDrawingChart = FALSE;
	m_nUpperData = 1000;
	m_nLowerData = 0;
	memset(m_nBaseLine,0x00,sizeof(int)*3);
}

CImageStatic::~CImageStatic()
{
	DeleteMemory();
}


BEGIN_MESSAGE_MAP(CImageStatic, CStatic)
	//{{AFX_MSG_MAP(CImageStatic)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImageStatic message handlers

void CImageStatic::DeleteMemory()
{	
	if( m_pChtDataList == NULL)
		return;
	
	delete[] m_pChtDataList;
	m_pChtDataList = NULL;
}

//DataList�� �̹� ���� �Ҵ� 
int CImageStatic::ReadChtData(CHTData *pDataList,int nDataCnt,BOOL bArray)
{	
	if(bArray)
		m_nChtArrayCnt = nDataCnt;
	else
		m_nChtListCnt = nDataCnt;

	if(m_pChtDataList == NULL)
		m_pChtDataList = new CHTData[nDataCnt];

	memset(m_pChtDataList,0x00,sizeof(CHTData)*nDataCnt);
	memcpy(m_pChtDataList,pDataList,sizeof(CHTData)*nDataCnt);
	
	return nDataCnt;
}

//�������� Add�Ѵ� 
int CImageStatic::AddChtDataList(CHTData chtData)
{		
	m_nChtListCnt++;		
	memcpy(&m_pChtDataList[(m_nChtListCnt-1)],&chtData,sizeof(CHTData));	
	return m_nChtListCnt;
}

int CImageStatic::SetChtDataList(CHTData chtData,int nIdx)
{		
	memcpy(&m_pChtDataList[nIdx],&chtData,sizeof(CHTData));	
	return m_nChtListCnt;
}

int CImageStatic::AddChtDataArray(CHTData chtData)
{	
	m_nChtArrayCnt++;
	memcpy(&m_pChtDataList[(m_nChtArrayCnt-1)],&chtData,sizeof(CHTData));	
	return m_nChtArrayCnt;
}

void CImageStatic::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

		GetWindowRect(&m_rcCht);	
		CPen *pBackPen,*pOldBackPen;
		CBrush *pBackBrush,*pOldBackBrush;
		pBackBrush = new CBrush;
		pBackPen = new CPen;
		if(GetDrawEnum() == BMPIMAGE)
		{
			pBackPen->CreatePen(PS_SOLID,2,RGB(0,0,0));
			pBackBrush->CreateSolidBrush(RGB(255,255,255));
		}
		else if(GetDrawEnum() == BMPCANDLE)
		{			
			pBackPen->CreatePen(PS_SOLID,1,RGB(237, 237, 237));
			pBackBrush->CreateSolidBrush(RGB(237, 237, 237));
		}

		// ������ ��Brush�� ���� ���
		pOldBackPen = (CPen *)dc.SelectObject(pBackPen);
		pOldBackBrush = (CBrush *)dc.SelectObject(pBackBrush);
		
		CRect rect;
		GetClientRect(&rect);

		dc.Rectangle(rect);	
		dc.SelectObject(pOldBackPen);
		dc.SelectObject(pOldBackBrush);
		delete pBackPen;
		delete pBackBrush;
		
		if(GetDrawEnum() == BMPCANDLE)
		{
			CPen *pPen,*pOldPen;
			pPen = new CPen;
			pPen->CreatePen(PS_SOLID,2,RGB(0,0,0));
			pOldPen = (CPen *)dc.SelectObject(pPen);
			dc.MoveTo(rect.right,rect.top);
			dc.LineTo(rect.left,rect.top);
			
			dc.MoveTo(rect.right,rect.bottom);
			dc.LineTo(rect.left,rect.bottom);			
			dc.SelectObject(pOldPen);
			delete pPen;
		}
		
	if( GetDrawEnum() == BMPIMAGE)
	{
		UINT uFlag = GetImageStyle();
		int nIamgeResult = DrawImage(&dc,m_rcImage,uFlag,GetStretch());
	}
	else if( GetDrawEnum() == BMPCANDLE && m_bDrawingChart) 
	{
		int nCandleResult = DrawCandle(&dc);
	}
}

// nStretch = 0:NormalSize(Default),-1:SmallSize,1:LargeSize
int CImageStatic::DrawImage(CDC *pDC,CRect rect,UINT uFlag,int nStretch)
{	
	CFileFind finder;
	BOOL bFind = finder.FindFile(GetFilePath());
	finder.Close();

	if(!bFind)
		return -1;

	DrawCandle(pDC);	
	HBITMAP hBitmap = (HBITMAP)LoadImage(AfxGetInstanceHandle(), GetFilePath(), IMAGE_BITMAP, 0, 0, 
		GetImageStyle() | LR_LOADFROMFILE | LR_CREATEDIBSECTION | LR_DEFAULTSIZE); 
	
	VERIFY(hBitmap != NULL);
	
	CBitmap bitmap;
	bitmap.Attach(hBitmap);
    
	if( (HBITMAP)bitmap )
	{		
		CDC memDC;
		memDC.CreateCompatibleDC( pDC );
		CBitmap *pOldBmp = memDC.SelectObject( &bitmap );

		int nWidth,nHeight;
		BITMAP pNewBmp;
		bitmap.GetBitmap(&pNewBmp);					
		nWidth = pNewBmp.bmWidth;
		nHeight = pNewBmp.bmHeight;				
		if(nStretch==1)
			pDC->BitBlt( rect.left, rect.top, nWidth, nHeight, &memDC, 0, 0, SRCCOPY);
		else if(nStretch!=1)
			pDC->StretchBlt( rect.left, rect.top, rect.Width(), 
							 rect.Height(), &memDC, 0, 0, nWidth, nHeight, SRCCOPY );

		if(!m_strSymbolName.IsEmpty())
		{			
			CFont *pOldFont = SetTextFont(pDC,12);
			CRect textRect;
			CSize size = pDC->GetTextExtent(m_strSymbolName);
			if(GetDrawingPos())
			{
				textRect.SetRect(rect.left-size.cx,rect.top -12,rect.left+size.cx,rect.top);
				pDC->DrawText(m_strSymbolName,&textRect,DT_SINGLELINE |DT_RIGHT);
			}
			else
			{	
				textRect.SetRect(rect.left-size.cx,rect.top+nHeight-3,rect.left+size.cx,rect.top+nHeight+9);
				pDC->DrawText(m_strSymbolName,&textRect,DT_SINGLELINE |DT_RIGHT);
			}
			SetOldFont(pDC,pOldFont);
		}
		memDC.SelectObject( pOldBmp);
		memDC.DeleteDC();
	}		
	bitmap.Detach();	
	return 0;
}

int CImageStatic::DrawCandle(CDC *pDC)
{
	if(m_pChtDataList == NULL)
	{
		TRACE("ERROR:Chart Data Not Exist\n");
		return -1;
	}
		
	////////////////////////////////////////////////////
	long basicMax, basicMin;
	int nDwCnt = 3;
	int nStartIdx =0;
	int nEndIdx = 2;
	if( GetDrawEnum() == BMPIMAGE)
	{
		m_nDrawingCnt = 5;
		nDwCnt = m_nDrawingCnt+1;	
		int nCurIdx = m_nCurIdx;
		nStartIdx = nCurIdx - (int)(m_nDrawingCnt/2);
		nEndIdx = nCurIdx + (int)(m_nDrawingCnt/2);	
		//if((float)(m_nDrawingCnt/2) != 0.0f)
		//	nEndIdx++;

		if(nStartIdx <0)
		{
			nStartIdx = 0;
			nEndIdx = 4;
		}

		if(nEndIdx>(m_nTotCnt-1))
		{
			nEndIdx = (m_nTotCnt-1);
			nStartIdx = nEndIdx -4;
		}

		basicMax = GetMaxData(1, nStartIdx, nEndIdx);
		basicMin = GetMinData(2, nStartIdx, nEndIdx);
		m_rcCht.left = m_rcVrtCht.left +10;
		m_rcCht.right = m_rcVrtCht.right -10;
		m_rcCht.top = m_rcVrtCht.top +20;
		m_rcCht.bottom = m_rcVrtCht.bottom -20;		
	}
	else if( GetDrawEnum() == BMPCANDLE)
	{
		basicMax = GetUpperData();
		basicMin = GetLowerData();
		m_rcCht = m_rcVrtCht;
		m_nDrawingCnt = 3;
		m_nCurIdx = 1;
	}

	if(basicMin == 0 && basicMax == 1000)
		return 0;
	
	m_nBYUnit = 1;
	int height = basicMax - basicMin;	
	if( basicMax < 100000 && basicMax >= 10000  )
	{
		basicMax = basicMax / 10;
		basicMin = basicMin / 10;
		height = basicMax - basicMin;
		m_nBYUnit = 10;
	}
	else if( basicMax < 1000000 && basicMax >= 100000  )
	{
		basicMax = basicMax / 100;
		basicMin = basicMin / 100;
		height = basicMax - basicMin;
		m_nBYUnit = 100;
	}
	else if( basicMax < 10000000 && basicMax >= 1000000  )
	{
		basicMax = basicMax / 1000;
		basicMin = basicMin / 1000;
		height = basicMax - basicMin;
		m_nBYUnit = 1000;				
	}
	
	if( GetDrawEnum() == BMPIMAGE)
	{
		m_nMinGap = basicMin/60;
		m_nMaxGap = basicMax/60;
		
		basicMax +=m_nMaxGap;
		basicMin -=m_nMinGap;
	}

	if(height == 0)
		height = m_rcCht.Height();	
	/////////////////////////////////////////////////////
	m_nSaveMode		= pDC->SetMapMode( MM_ANISOTROPIC );	
	m_szSaveWndExt  = pDC->SetWindowExt	( nDwCnt*2, height );
	m_szSaveVwExt   = pDC->SetViewportExt( m_rcVrtCht.Width() , (-1)*m_rcVrtCht.Height());	
	m_ptSaveWndOrg  = pDC->SetWindowOrg(0, 0);
	m_ptSaveVwOrg   = pDC->SetViewportOrg( m_rcVrtCht.left, m_rcVrtCht.bottom); 	
		
	////////////////////////////////////////////////////
	// ���ؼ� Drawing 		
	if( GetDrawEnum() == BMPCANDLE)
		DrawYAxis(pDC, basicMax, basicMin);
	CandleChart(pDC, basicMax, basicMin);
	SetOldMode(pDC);	
	return 0;
}

void CImageStatic::SetOldMode(CDC *pDC)
{
	pDC->SetMapMode( m_nSaveMode);
	pDC->SetWindowExt( m_szSaveWndExt);
	pDC->SetViewportExt( m_szSaveVwExt);
	pDC->SetWindowOrg( m_ptSaveWndOrg);
	pDC->SetViewportOrg( m_ptSaveVwOrg); 
}

void CImageStatic::DrawYAxis(CDC *pDC,long max,long min)
{
	CPen *pBPen,*pBOldPen;
	pBPen = new CPen;
	pBPen->CreatePen(PS_SOLID, 0, RGB(0,0,0));// RGB(220, 220, 220));

	int height =0;	
	char cYAxis[20] = "";
	int nDwCnt = 3;
	height = max - min;
	if(height ==0)
		height = m_rcCht.Height();
	
	pDC->SetWindowExt( m_szSaveWndExt );
	m_szSaveWndExt  = pDC->SetWindowExt( nDwCnt*2, height );

	CPoint  ptList[100] ={CPoint(0,0),};
	long	lYList[100] ={0,};
	int	nYCnt = 0;
	long lBaseLine = (long)m_nBaseLine[0];
	if(m_nBYUnit!=1)
		lBaseLine = (long)m_nBaseLine[0]/m_nBYUnit;
	int i=0;		

	for(i=min;i<max;i++)
	{
		if( (i % lBaseLine) == 0)
		{
			ptList[nYCnt].x = 0;				
			ptList[nYCnt].y = i - min;
			pDC->LPtoDP( &ptList[nYCnt] );
			lYList[nYCnt] = i;				
			nYCnt++;
		}
	}
	
	// ������ ����
	pDC->SetWindowExt( m_szSaveWndExt  );
	m_szSaveWndExt  = pDC->SetWindowExt( m_rcCht.Width(), m_rcCht.Height());
	for(i=0; i<nYCnt; i++)
	{		
		pDC->DPtoLP( &ptList[i] );
		if( GetDrawEnum() == BMPCANDLE)
			ptList[i].y = m_rcCht.top + ptList[i].y;
		
		pBOldPen = (CPen *)pDC->SelectObject(pBPen);
		pDC->MoveTo(-m_rcCht.left +5, ptList[i].y );
		pDC->LineTo(-m_rcCht.left + m_rcCht.Width() -5, ptList[i].y );
		pDC->SelectObject(pBOldPen);
	}	
	delete pBPen;
}

void CImageStatic::CandleChart(CDC *pDC, long lMax, long lMin)
{
	CRect rect;
	long Mt_Y, Lt_Y;
	int nDwCnt = m_nDrawingCnt+1;	
	int nCurIdx = m_nCurIdx;
	int nStartIdx = nCurIdx - (int)(m_nDrawingCnt/2);
	int nEndIdx = nCurIdx + (int)(m_nDrawingCnt/2);	
	if((float)(m_nDrawingCnt/2) != 0.0f)
		nEndIdx++;

	if(nStartIdx <0)
	{
		nStartIdx = 0;
		nEndIdx = 4;
	}

	if(nEndIdx>(m_nTotCnt-1))
	{
		nEndIdx = (m_nTotCnt-1);
		nStartIdx = nEndIdx -4;
	}

	if( GetDrawEnum() == BMPCANDLE) 
	{
		nDwCnt = 3;
		nCurIdx = 1;
		nStartIdx = 0;
		nEndIdx = 2;
	}	
			
	// ��庯ȯ
	long height = lMax - lMin;
	if(height ==0)
		height = m_rcCht.Height();
	else if(height <0)
		height = lMin - lMax;
		
	pDC->SetWindowExt( m_szSaveWndExt );
	m_szSaveWndExt  = pDC->SetWindowExt( nDwCnt*2, height );
	
	CRect rcData[10];
	int bYangUm[10] = {1,};	//1-Yang,0-Um 
	CPoint	hpt_l[10], hpt_r[10];
	CPoint	lpt_l[10], lpt_r[10];
	
	long data[5] ={0,};
	int nBYUnit = m_nBYUnit;
	int i=0;		

	for( i=0; i<m_nDrawingCnt; i++ )	
	{				
		memset(data,0x00,sizeof(long)*5);
		if((nStartIdx+i)>(m_nTotCnt-1))
			continue;
		
		GetData(0,nStartIdx+i, data);
		if(data[0] == 0 && data[1] == 0 && data[2] == 0 && data[3] == 0)
			continue;

		nBYUnit = m_nBYUnit;
		if(nBYUnit >1)
		{
			data[0] = (long)data[0]/m_nBYUnit;
			data[1] = (long)data[1]/m_nBYUnit;
			data[2] = (long)data[2]/m_nBYUnit;
			data[3] = (long)data[3]/m_nBYUnit;
			nBYUnit = 1;
		}
		
		//����
		rect.left = i*2+1;
		rect.right = (i+1)*2+1;		
		rect.top =	 ( data[0]-lMin )/nBYUnit;
		rect.bottom =( data[3]-lMin )/nBYUnit;

		pDC->LPtoDP( &rect );
		rcData[i] = rect;

		if( data[0] > data[3] )			//�϶� ( �ð� > ���� )
			bYangUm[i] = 0;
		else if( data[0] < data[3] )	//��� (�ð� < ���� )
			bYangUm[i] = 1;
		else							 //���� ( �ð� == ���� )
		{
			long prePos = 0;
			if(i>0)
				prePos = GetData(3, nStartIdx+i-1,(long*)NULL);

			if( data[0] > prePos )		//���ϴ�� ���
				bYangUm[i] = 0;
			else if( data[3] < prePos) // ���ϴ�� �϶�
				bYangUm[i] = 1;
			else
			{			
				if(i>0)
					bYangUm[i] = bYangUm[i-1];
			}
		}

		//����
		if( data[0] > data[3] ) //�϶� ( �ð� > ���� )
		{
			Mt_Y = (data[0] - lMin);// �ð�
			Lt_Y = (data[1] - lMin);// ����
		}
		else if( data[0] < data[3] ) //��� ( �ð� < ���� )
		{
			Mt_Y = (data[3] - lMin);// ����
			Lt_Y = (data[1] - lMin);// ����
		}
		else // �ð� == ����
		{
			Mt_Y = (data[1] - lMin);// ���� - ����
			Lt_Y = (data[2] - lMin);// ���� - ����
		}

		hpt_l[i].x = (i*2)+1;
		hpt_l[i].y = Mt_Y;
		pDC->LPtoDP( &hpt_l[i] );

		hpt_r[i].x = (i*2)+1;
		hpt_r[i].y = Lt_Y;
		pDC->LPtoDP( &hpt_r[i] );
		
		//����
		if( data[0] > data[3] )		//�϶� ( �ð� > ���� )
		{
			Mt_Y = (data[3] - lMin);	// ����
			Lt_Y = (data[2] - lMin);	// ����
		}
		else if( data[0] < data[3] ) //��� ( �ð� < ���� )
		{
			Mt_Y = (data[0] - lMin);	// �ð�	
			Lt_Y = (data[2] - lMin);	// ����
		}
		else // �ð� == ����
		{
			Mt_Y = (data[2] - lMin);//  - ����
			Lt_Y = (data[2] - lMin);//  - ����
		}

		lpt_l[i].x = (i*2)+1;
		lpt_l[i].y = Mt_Y;
		pDC->LPtoDP( &lpt_l[i] );

		lpt_r[i].x = (i*2)+1;
		lpt_r[i].y = Lt_Y;
		pDC->LPtoDP( &lpt_r[i] );
	}		

	// ������ ����
	pDC->SetWindowExt( m_szSaveWndExt  );
	m_szSaveWndExt = pDC->SetWindowExt( m_rcCht.Width(), m_rcCht.Height());	
		
	int nGap =0;	
	CPoint hPt, lPt;
	
	CPen curPen,*pOldCurPen;
	CPen yangPen,umPen;
	CPen *pOldYangPen,*pOldUmPen;
	CBrush yangBrush,umBrush;
	CBrush *pOldYangBrush,*pOldUmBrush;	
		
	yangBrush.CreateSolidBrush( RGB(255,0,0));
	umBrush.CreateSolidBrush( RGB(0,0,255));
	yangPen.CreatePen(PS_SOLID, 0, RGB(255,0,0));
	umPen.CreatePen(PS_SOLID, 0, RGB(0,0,255));
	
	CRect rectCur;
	curPen.CreatePen(PS_SOLID,1, RGB(0,0,0));	

	for( i=0; i<m_nDrawingCnt; i++ )
	{			
		if( GetDrawEnum() == BMPCANDLE && i !=1)
			continue;

		pOldYangPen	  = pOldUmPen = NULL;
		pOldYangBrush = pOldUmBrush = NULL;
					
		pDC->DPtoLP( &rcData[i] );				
		
		if( GetDrawEnum() == BMPIMAGE)
			rcData[i].right = rcData[i].right-1;
		else if( GetDrawEnum() == BMPCANDLE && i ==1)
		{			
			rcData[i].top = m_rcCht.top + rcData[i].top;
			rcData[i].bottom = m_rcCht.top + rcData[i].bottom;			
			rcData[i].left = rcData[i].left -m_rcCht.left -10 ;
			rcData[i].right = rcData[i].right -m_rcCht.left -10 ;
			//rcData[i].left = rcData[i].left -65;
			//rcData[i].right = rcData[i].right -65;
		}

		if(bYangUm[i] ==1)
		{
			pOldYangPen = (CPen *)pDC->SelectObject(&yangPen);
			pOldYangBrush = (CBrush *)pDC->SelectObject(&yangBrush);			
		}
		else
		{
			pOldUmPen = (CPen *)pDC->SelectObject(&umPen);
			pOldUmBrush = (CBrush *)pDC->SelectObject(&umBrush);			
		}		

		if( rcData[i].top == rcData[i].bottom )
		{
			pDC->MoveTo(rcData[i].left , rcData[i].top);
			pDC->LineTo(rcData[i].right, rcData[i].bottom);
		}
		else
		{				
			if( (m_nChtFillYang ==1 && bYangUm[i] ==1) ||
				(m_nChtFillUm   ==1 && bYangUm[i] ==0))
			{
				pDC->Rectangle(&rcData[i]);
			}
			else
			{				
				pDC->MoveTo(rcData[i].left,rcData[i].top);
				pDC->LineTo(rcData[i].left,rcData[i].bottom);
				pDC->LineTo(rcData[i].right-1,rcData[i].bottom);
				pDC->LineTo(rcData[i].right-1,rcData[i].top);
				pDC->LineTo(rcData[i].left,rcData[i].top);				
			}
		}
			
		pDC->DPtoLP( &hpt_l[i] );
		pDC->DPtoLP( &hpt_r[i] );
		
		if( GetDrawEnum() == BMPCANDLE && i ==1)
		{			
			hpt_l[i].y = m_rcCht.top + hpt_l[i].y;
			hpt_r[i].y = m_rcCht.top + hpt_r[i].y;		
			hpt_l[i].x = hpt_l[i].x -m_rcCht.left -10 ;
			hpt_r[i].x = hpt_r[i].x -m_rcCht.left -10 ;
			//hpt_l[i].x = hpt_l[i].x -65;
			//hpt_r[i].x = hpt_r[i].x -65;
		}

		
		nGap = (rcData[i].right - rcData[i].left)/2;
		pDC->MoveTo(hpt_l[i].x+nGap, hpt_l[i].y);
		pDC->LineTo(hpt_r[i].x+nGap, hpt_r[i].y);
	
		pDC->DPtoLP( &lpt_l[i] );
		pDC->DPtoLP( &lpt_r[i] );

		if( GetDrawEnum() == BMPCANDLE && i ==1)
		{			
			lpt_l[i].y = m_rcCht.top + lpt_l[i].y;
			lpt_r[i].y = m_rcCht.top + lpt_r[i].y;		
			//lpt_l[i].x = lpt_l[i].x -65;
			//lpt_r[i].x = lpt_r[i].x -65;
			lpt_l[i].x = lpt_l[i].x -m_rcCht.left -10 ;
			lpt_r[i].x = lpt_r[i].x -m_rcCht.left -10 ;
		}
				
		pDC->MoveTo(lpt_l[i].x+nGap, lpt_l[i].y);
		pDC->LineTo(lpt_r[i].x+nGap, lpt_r[i].y);
		
		if(bYangUm[i] ==1)			
		{
			if(pOldYangPen != NULL)
				pDC->SelectObject(pOldYangPen);
			if(pOldYangBrush != NULL)
				pDC->SelectObject(pOldYangBrush);
		}
		else
		{
			if(pOldUmPen != NULL)
				pDC->SelectObject(pOldUmPen);
			if(pOldUmBrush != NULL)
				pDC->SelectObject(pOldUmBrush);
		}
		
		if(m_bCurDraw&&((nStartIdx+i) == nCurIdx))
		{
			CPoint ptHigh,ptLow,ptTemp1,ptTemp2;
			pDC->SelectObject(GetStockObject(NULL_BRUSH));
			pOldCurPen = (CPen *)pDC->SelectObject(&curPen);
			//High - bottom
			if(hpt_r[i].y > hpt_l[i].y)
				ptTemp1.y = hpt_r[i].y;
			else
				ptTemp1.y = hpt_l[i].y;

			if(lpt_r[i].y > lpt_l[i].y)
				ptTemp2.y = lpt_r[i].y;
			else
				ptTemp2.y = lpt_l[i].y;

			if(ptTemp1.y > ptTemp2.y)
				ptHigh.y = ptTemp1.y;
			else
				ptHigh.y = ptTemp2.y;
			//Low - top
			if(hpt_r[i].y > hpt_l[i].y)
				ptTemp1.y = hpt_l[i].y;
			else
				ptTemp1.y = hpt_r[i].y;

			if(lpt_r[i].y > lpt_l[i].y)
				ptTemp2.y = lpt_l[i].y;
			else
				ptTemp2.y = lpt_r[i].y;

			if(ptTemp1.y > ptTemp2.y)
				ptLow.y = ptTemp2.y;
			else
				ptLow.y = ptTemp1.y;
			
			ptHigh.y = ptHigh.y + 5;
			if(ptHigh.y > m_rcCht.bottom)
				ptHigh.y = 	m_rcCht.bottom;
			
			ptLow.y = ptLow.y -5;
			if(ptLow.y < m_rcCht.top)
				ptLow.y = 	m_rcCht.top;
			
			rectCur.SetRect(rcData[i].left,ptLow.y,rcData[i].right,ptHigh.y);
			pDC->Rectangle(&rectCur);
			pDC->SelectObject(pOldCurPen);
		}
	}	
}

long CImageStatic::GetMinData(int nKind, int nStPos, int nEndPos)
{
	// ��ü(�ð�����)�� ������ ã��
	long Min_Value = 99999999;
	BOOL bFirst = TRUE;
	int nIndex =0;
	for(int i=nStPos;i<=nEndPos;i++)
	{
		CHTData pChtData = m_pChtDataList[nIndex];
		nIndex++;		
		if( nKind == 0 )			// Open
		{
			if(bFirst)
			{
				Min_Value = pChtData.lOpen;
				bFirst = FALSE;
				continue;
			}

			if( pChtData.lOpen < Min_Value )
				Min_Value = pChtData.lOpen;
		}
		else if( nKind == 1 )	// High
		{
			if(bFirst)
			{
				Min_Value = pChtData.lHigh;
				bFirst = FALSE;
				continue;
			}

			if( pChtData.lHigh < Min_Value )
				Min_Value = pChtData.lHigh;
		}
		else if( nKind == 2 )	// Low
		{
			if(bFirst)
			{
				Min_Value = pChtData.lLow;
				bFirst = FALSE;
				continue;
			}

			if( pChtData.lLow < Min_Value )
				Min_Value = pChtData.lLow;
		}
		else if( nKind == 3 )	// Close
		{
			if(bFirst)
			{
				Min_Value = pChtData.lCls;
				bFirst = FALSE;
				continue;
			}

			if( pChtData.lCls < Min_Value )
				Min_Value = pChtData.lCls;	
		}
		else if( nKind == 4 )	// TrdngVlm
		{
			if(bFirst)
			{
				Min_Value = pChtData.dwTrdngVlm;
				bFirst = FALSE;
				continue;
			}
			if( pChtData.dwTrdngVlm <Min_Value )
				Min_Value = pChtData.dwTrdngVlm;
		}
	}

	return Min_Value;
}

long CImageStatic::GetMaxData(int nKind, int nStPos, int nEndPos)
{
	// ��ü(�ð�����)�� ������ ã��
	long Max_Value = 0;	
	BOOL bFirst = TRUE;	
	int nIndex =0;
	for(int i=nStPos;i<=nEndPos;i++)
	{
		CHTData pChtData = m_pChtDataList[nIndex];
		nIndex++;		
		if( nKind == 0 )			// Open
		{
			if(bFirst)
			{
				Max_Value = pChtData.lOpen;
				bFirst = FALSE;
				continue;
			}

			if( pChtData.lOpen > Max_Value )
				Max_Value = pChtData.lOpen;
		}
		else if( nKind == 1 )	// High
		{
			if(bFirst)
			{
				Max_Value = pChtData.lHigh;
				bFirst = FALSE;
				continue;
			}

			if( pChtData.lHigh > Max_Value )
				Max_Value = pChtData.lHigh;
		}
		else if( nKind == 2 )	// Low
		{
			if(bFirst)
			{
				Max_Value = pChtData.lLow;
				bFirst = FALSE;
				continue;
			}

			if( pChtData.lLow > Max_Value )
				Max_Value = pChtData.lLow;
		}
		else if( nKind == 3 )	// Close
		{
			if(bFirst)
			{
				Max_Value = pChtData.lCls;
				bFirst = FALSE;
				continue;
			}

			if( pChtData.lCls > Max_Value )
				Max_Value = pChtData.lCls;	
		}
		else if( nKind == 4 )	// TrdngVlm
		{
			if(bFirst)
			{
				Max_Value = pChtData.dwTrdngVlm;
				bFirst = FALSE;
				continue;
			}
			if( pChtData.dwTrdngVlm > Max_Value )
				Max_Value =pChtData.dwTrdngVlm;
		}
	}

	return Max_Value;
}

long CImageStatic::GetData(int kind, int idx, long *retData)
{
	if(m_pChtDataList == NULL )
		return -1;
	
	CHTData pElement = m_pChtDataList[idx];	
	if( retData == NULL ) 
		return pElement.lCls;

	if( kind == 0 )
	{
		retData[0] = pElement.lOpen;
		retData[1] = pElement.lHigh;
		retData[2] = pElement.lLow;
		retData[3] = pElement.lCls;
		retData[4] = pElement.dwTrdngVlm;		
	}
	else if( kind == 1 )		// OPEN
	{	retData[0] = pElement.lOpen;		}
	else if( kind == 2 )		// HIGH
	{	retData[0] = pElement.lHigh;		}
	else if( kind == 3 )		// LOW
	{	retData[0] = pElement.lLow;		}
	else if( kind == 4 )		// CLOSE
	{	retData[0] = pElement.lCls;		}
	else if( kind == 5 )		// TRDNGVLM
	{	retData[0] = pElement.dwTrdngVlm;	}
	
	return pElement.lCls ;
}

CFont* CImageStatic::SetTextFont(CDC *pDC, int iFontSize, BOOL bBold, BOOL bItalic, BOOL bUnderLine,
						int iJustify, CString strFont, COLORREF rgbTextColor, COLORREF rgbBkColor)
{
	CFont   cfFont1, cfFont2, *cfOldFont;
	LOGFONT logFont;

	cfFont1.CreateFont(0, 0, 0, 0, 400, FALSE, FALSE, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS,
					CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, strFont);

	cfFont1.GetObject(sizeof(LOGFONT), &logFont);

	if (bBold)      logFont.lfWeight    = 700;
	if (bItalic)    logFont.lfItalic    = TRUE;
	if (bUnderLine) logFont.lfUnderline = TRUE;

	logFont.lfHeight = iFontSize;
	
	cfFont2.CreateFontIndirect(&logFont);
	cfOldFont = pDC->SelectObject(&cfFont2);

	switch (iJustify)
	{
	case	0	:	pDC->SetTextAlign(TA_LEFT);   break;
	case	1	:	pDC->SetTextAlign(TA_CENTER); break;
	case	2	:	pDC->SetTextAlign(TA_RIGHT);  break;
	}	
	
	pDC->SetTextColor(rgbTextColor);
	pDC->SetBkColor  (rgbBkColor);

	return cfOldFont;
}

void CImageStatic::SetOldFont(CDC *pDC, CFont *cfFont)
{
	pDC->SelectObject(cfFont);
}