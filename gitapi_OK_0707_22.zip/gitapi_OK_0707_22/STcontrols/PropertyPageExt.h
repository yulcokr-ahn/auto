#if !defined(AFX_PROPERTYPAGEEXT_H__0696CA03_B426_11D5_A8B1_444553540000__INCLUDED_)
#define AFX_PROPERTYPAGEEXT_H__0696CA03_B426_11D5_A8B1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropertyPageExt.h : header file
// 2001.9.cyber.sukim
#include <afxdlgs.h>
/////////////////////////////////////////////////////////////////////////////
// CPropertyPageExt

#ifdef _AFXEXT
	#ifndef _EXPORTCONTROLS
		#undef AFX_EXT_CLASS
		#undef AFX_EXT_API
		#undef AFX_EXT_DATA
		#define AFX_EXT_CLASS AFX_CLASS_IMPORT
		#define AFX_EXT_API AFX_API_IMPORT
		#define AFX_EXT_DATA AFX_DATA_IMPORT
	#endif
#endif

class AFX_EXT_CLASS CPropertyPageExt : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropertyPageExt)

// Construction
public:
	CPropertyPageExt();
	CPropertyPageExt(UINT nIDTemplate);

	void SetColours(COLORREF BkgColour);  // set background color

// Dialog Data
	//{{AFX_DATA(CPropertyPageExt)
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertyPageExt)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	COLORREF m_crBkgColour;

	// Generated message map functions
	//{{AFX_MSG(CPropertyPageExt)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifdef _AFXEXT
	#ifndef _EXPORTCONTROLS
		#undef AFX_EXT_CLASS
		#undef AFX_EXT_API
		#undef AFX_EXT_DATA
		#define AFX_EXT_CLASS AFX_CLASS_EXPORT
		#define AFX_EXT_API AFX_API_EXPORT
		#define AFX_EXT_DATA AFX_DATA_EXPORT
	#endif
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYPAGEEXT_H__0696CA03_B426_11D5_A8B1_444553540000__INCLUDED_)
