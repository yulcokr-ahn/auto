#if !defined(AFX_PostionViewStatic_H__1B1972E2_7596_4136_B2E6_CA399128F845__INCLUDED_)
#define AFX_PostionViewStatic_H__1B1972E2_7596_4136_B2E6_CA399128F845__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PostionViewStatic.h : header file

#include "../Include/hrefer.h" //2010616

/////////////////////////////////////////////////////////////////////////////


#ifdef _SKINMODE_BLOCK
#define COLOR_CONTROL_STATIC_LINE    RGB(50,50,55)
#else ifdef _SKINMOD_Orchid
#define COLOR_CONTROL_STATIC_LINE    RGB(120,50,210) //��ȫ�� 20170212
#endif

#define BUT_MOD_SELL 10
#define BUT_MOD_BUY  20
#define _CD_ 0
#define _AB_ 1
#define _EF_ 2
#define _MAX_ 3

#define _O_MAX_ 6

class AFX_EXT_CLASS CPostionViewStatic : public CStatic
{
// Construction
public:
	CPostionViewStatic();

	void Line(CDC* pDC,int xLeft, int yTop,int xRight, int yBottom, unsigned long c=COLOR_CONTROL_STATIC_LINE);

	COLORREF m_crBLOCK_ON_Background;

	void Line_BF(CDC* pDC,int xLeft, int yTop,int xRight, int yBottom, unsigned long c);


	void SetROW_INFO_GRID_STATIC(ROWGRID_CODE_LISTSTATIC *TmpKepler, int nSize);
	ROWGRID_CODE_LISTSTATIC *m_pROW_MAP;
	int nROWSize;


	int nCOLSize;


	int nSize_POSTION;



	long            m_DS_iPostionType_P; 	// ����������  SE_xCDx_ACTIVE_NEW_ORDER    = �ű�, SE_xCDx_ACTIVE_PAYOFF_ORDER = û��

INTEREST_CODE_LIST *m_pPOS_VIEW;
POSTION_AESA *m_ptr_drawAESA;
int m_nLT;
int GetCurPostion_xCDx(LPOSTION_AESA pAESA_dat);
int GetCurPostion_xABx(LPOSTION_AESA pxABx_Data);
double m_Brk_TickUNIT[_MAX_];
double m_BrkCond_AESA[_MAX_];

void DrawGrid_PostionTandem_xCDx(LPOSTION_AESA pAESA_dat,CDC* pDC,CRect rcBody);
void DrawGrid_BackGroundTandem_xCDx(LPOSTION_AESA pAESA_dat,CDC* pDC,CRect rcBody);

void DrawGrid_PostionTandem_xABx(LPOSTION_AESA pxABx_Data,CDC* pDC,CRect rcBody);
void DrawGrid_BackGroundTandem_xABx(LPOSTION_AESA pxABx_Data,CDC* pDC,CRect rcBody);

void Button(CDC* pDC,int xLeft, int yTop,int xRight, int yBottom, int mode , int iValue=0);


	int nSize_GROUP_COLOR;


	CWnd *m_pParent;

	string Calculation_Tandem_xCDx_Quadruple_Print(POSTION_AESA *ptr_drawAESA,int nLT,double BrkCond_AESA , double Brk_TickUNIT );
	string Calculation_Tandem_xABx_Quadruple_Print(POSTION_AESA *ptr_drawAESA,int nLT,double BrkCond_AESA , double Brk_TickUNIT );




	COLORREF textColor( COLORREF );
    COLORREF textColor() const { return m_crTextColor; }

public:

	COLORREF m_crTextColor;
	COLORREF m_crBackground;

	CString	m_strText;
	int		m_nAlign;
	BOOL	m_bVCenter;
	int		m_nFontType;
	int		m_nFontSize;
	BOOL	m_bBorder;

	CRect		m_rcCmbBtn;

public:
	void DrawBorder(CDC* pDC);


	virtual void SetWindowText(LPCTSTR lpszString, int nAlign = DT_CENTER);
	virtual void GetWindowText(CString& rString);

	//{{AFX_VIRTUAL(CPostionViewStatic)
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetFontSize(int nSize)	{	m_nFontSize = nSize; }
	int  GetFontSize()			{	return m_nFontSize;	}
	void SetSymbol(int symbol = 1);
	COLORREF GetBkColor();
	void SetBkColor(COLORREF crBk);
	void SetBorder(BOOL bBorder);

	virtual ~CPostionViewStatic();

protected:
	//{{AFX_MSG(CPostionViewStatic)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	BOOL				m_bIsSymbol;
	int					m_nSymbol;

	CBitmap				*m_pSymbol;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PostionViewStatic_H__1B1972E2_7596_4136_B2E6_CA399128F845__INCLUDED_)
