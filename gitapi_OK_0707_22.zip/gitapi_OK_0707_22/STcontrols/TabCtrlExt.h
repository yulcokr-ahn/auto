#if !defined(AFX_TABCTRLEXT_H__28407441_38AF_11D1_ABBA_00A0243D1382__INCLUDED_)
#define AFX_TABCTRLEXT_H__28407441_38AF_11D1_ABBA_00A0243D1382__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// TabCtrlEx.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTabCtrlExt window


class AFX_EXT_CLASS CTabCtrlExt : public CTabCtrl
{
	// Construction/destruction
public:
	CTabCtrlExt();
	virtual ~CTabCtrlExt();
	
	// Attributes:
public:
	
	// Operations
public:
	void LoadTabImages();
	void SetBkColour(COLORREF crBkgnd);
	void SetFonts(CFont* pSelFont, CFont* pUnselFont);
	void SetFonts(int nSelWeight=FW_SEMIBOLD, BOOL bSelItalic=FALSE,   BOOL bSelUnderline=FALSE,
		int nUnselWeight=FW_MEDIUM, BOOL bUnselItalic=FALSE, BOOL bUnselUnderline=FALSE);
	
	void SetColours(COLORREF SelColour, COLORREF UnselColour, 
		COLORREF SelTabColour, COLORREF UnselTabColour, 
		COLORREF BkgColour);
	
	void SetTabColour(COLORREF crSelected);
	void SetControlMode(BOOL bSheetMode, COLORREF ParentColour);
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabCtrlExt)
public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	BOOL		m_bSheetMode;
	COLORREF	m_crSelTextColour, m_crUnselTextColour;
	COLORREF	m_crSelTabColour, m_crUnselTabColour;
	COLORREF	m_crBkgColour;
	COLORREF	m_crParent;
	CFont		m_SelFont,	m_UnselFont;
	CBitmap		m_bmOffLeft;
	CBitmap		m_bmOffCenter;
	CBitmap		m_bmOffRight;
	CBitmap		m_bmOnLeft;
	CBitmap		m_bmOnCenter;
	CBitmap		m_bmOnRight;
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CTabCtrlExt)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnEnable(BOOL bEnable);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABCTRLEXT_H__28407441_38AF_11D1_ABBA_00A0243D1382__INCLUDED_)
