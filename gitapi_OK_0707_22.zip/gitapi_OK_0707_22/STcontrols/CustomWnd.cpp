// CustomWnd.cpp : implementation file
//

#include "stdafx.h"
#include "CustomWnd.h"
#include "CoolDialogBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCustomWnd

IMPLEMENT_DYNCREATE(CCustomWnd, CSkinedMDIChildWnd)

CCustomWnd::CCustomWnd()
{
	m_pDialog = NULL;

	m_dwStyle = RESIZE_NONE;
	m_nDiffWidth = m_nDiffHeight = 0;
	m_bEnableDock = TRUE;
}

CCustomWnd::~CCustomWnd()
{
}


BEGIN_MESSAGE_MAP(CCustomWnd, CSkinedMDIChildWnd)
	//{{AFX_MSG_MAP(CCustomWnd)
	ON_WM_DESTROY()
	ON_WM_NCLBUTTONDBLCLK()
	ON_WM_GETMINMAXINFO()
	ON_WM_SIZE()
	ON_WM_NCLBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCustomWnd message handlers
void CCustomWnd::ActivateFrame(int nCmdShow)
{
	CSkinedMDIChildWnd::ActivateFrame(SW_HIDE);
}

void CCustomWnd::SetDialog(CDialog *pDlg, CRect rcDialog)
{
	ASSERT(pDlg != NULL);

	m_pDialog = pDlg;
	m_pChildDlg = pDlg;

	m_pPrevWnd = m_pDialog->GetParent();
	m_pDialog->SetParent(this);

	CRect rtWindow, rtClient;
	GetWindowRect(&rtWindow);
	GetClientRect(&rtClient);

	m_nDiffWidth = rtWindow.Width() - rtClient.Width();
	m_nDiffHeight = rtWindow.Height() - rtClient.Height();

	m_rcDialog = rcDialog;
	
	m_ptMax.x = m_ptTrackMax.x = m_ptTrackMin.x = m_rcDialog.Width() + m_nDiffWidth;
	m_ptMax.y = m_ptTrackMax.y = m_ptTrackMin.y = m_rcDialog.Height() + m_nDiffHeight;

	SetWindowPos(NULL, 0, 0, m_nDiffWidth + rcDialog.Width(), m_nDiffHeight + rcDialog.Height(), SWP_NOMOVE | SWP_NOZORDER);
	m_bInit = TRUE;
}

void CCustomWnd::OnDestroy() 
{
	CMDIChildWnd::OnDestroy();
	DeleteObject(m_hIcon);

	CWnd *pWnd = AfxGetMainWnd();
	pWnd->SendMessage(WM_DELETETASK, (WPARAM)this, (LPARAM)0);

	CFrameWnd *pFrame = (CFrameWnd *)AfxGetMainWnd();

	WINDOWPLACEMENT lpwndpl;
	GetWindowPlacement(&lpwndpl);

	CCoolDialogBar *pControlBar = (CCoolDialogBar *)m_pPrevWnd;
	pControlBar->m_lpwndpl = lpwndpl;
	pControlBar->m_rcView = lpwndpl.rcNormalPosition;

	// �����츦 �����.
	if (m_pPrevWnd->GetSafeHwnd() != NULL)
	{
		ShowWindow(SW_HIDE);
		m_pDialog->SetParent(m_pPrevWnd);

		::SendMessage(m_pPrevWnd->m_hWnd, WNM_DESTROY_WINDOW, (WPARAM)this, (LPARAM)&lpwndpl);
	}
	else
	{
		::SendMessage(m_pDialog->m_hWnd, WM_CLOSE, 0, 0);
	}
}

void CCustomWnd::OnNcLButtonDblClk(UINT nHitTest, CPoint point) 
{
	if (nHitTest == HTCAPTION)
	{	
		m_pDialog->SetParent(m_pPrevWnd);

		CFrameWnd *pFrame = (CFrameWnd *)AfxGetMainWnd();
		WINDOWPLACEMENT lpwndpl;
		GetWindowPlacement(&lpwndpl);

		// �����츦 �����.
		ShowWindow(SW_HIDE);
		m_pDialog->SetParent(m_pPrevWnd);

		::SendMessage(m_pPrevWnd->m_hWnd, WNM_TOGGLE_WINDOW, (WPARAM)this, (LPARAM)&lpwndpl);
		pFrame->ShowControlBar((CControlBar *)m_pPrevWnd, TRUE, FALSE);
		DestroyWindow();
	}
	else
		CSkinedMDIChildWnd::OnNcLButtonDblClk(nHitTest, point);
}


void CCustomWnd::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CPoint pt;

	BOOL bHorz = m_dwStyle & RESIZE_HORZ;
	BOOL bVert = m_dwStyle & RESIZE_VERT;

	if (m_pDialog)
	{
		if (bVert && !bHorz)
		{
			pt = lpMMI->ptMaxSize;
			pt.x = m_ptMax.x;
			lpMMI->ptMaxSize = pt;
		
			pt = lpMMI->ptMaxTrackSize;
			pt.x = m_ptTrackMax.x;
			lpMMI->ptMaxTrackSize = pt;
		
			pt = lpMMI->ptMinTrackSize;
			pt.x = m_ptTrackMin.x;
//			pt.y = m_ptTrackMin.y;
			lpMMI->ptMinTrackSize = pt;
		}
		else if (!bVert && bHorz)
		{
			pt = lpMMI->ptMaxSize;
			pt.y = m_ptMax.y;
			lpMMI->ptMaxSize = pt;
		
			pt = lpMMI->ptMaxTrackSize;
			pt.y = m_ptTrackMax.y;
			lpMMI->ptMaxTrackSize = pt;
		
			pt = lpMMI->ptMinTrackSize;
			pt.x = m_ptTrackMin.x;
//			pt.y = m_ptTrackMin.y;
			lpMMI->ptMinTrackSize = pt;
		}
	}

	CSkinedMDIChildWnd::OnGetMinMaxInfo(lpMMI);
}

void CCustomWnd::OnSize(UINT nType, int cx, int cy) 
{
	CSkinedMDIChildWnd::OnSize(nType, cx, cy);

	CRect rcClient;
	if (m_pDialog)
	{
		GetClientRect(&rcClient);
		m_pDialog->SetWindowPos(NULL, 0, 0, cx, cy, 
			SWP_NOMOVE | SWP_NOZORDER);
	}
}

BOOL CCustomWnd::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CSkinedMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.style |= WS_CLIPCHILDREN;
//	cs.style &= ~WS_MAXIMIZEBOX;
	cs.style &= ~WS_VISIBLE;

	if (cs.style & FWS_ADDTOTITLE)
		cs.style &= ~FWS_ADDTOTITLE;

	CWinApp *pApp = AfxGetApp();
	pApp->m_nCmdShow = SW_HIDE;

	return TRUE;
}

void CCustomWnd::SetStyle(DWORD dwStyle)
{
	m_dwStyle = dwStyle;
}


void CCustomWnd::OnNcLButtonUp(UINT nHitTest, CPoint point) 
{
	int nCurHittest = m_nHitTest;

	CSkinedMDIChildWnd::OnNcLButtonUp(nHitTest, point);
	if(nHitTest != HT_EX_DOCKING)
		return;

	m_pDialog->SetParent(m_pPrevWnd);

	CFrameWnd *pFrame = (CFrameWnd *)AfxGetMainWnd();
	WINDOWPLACEMENT lpwndpl;
	GetWindowPlacement(&lpwndpl);

	// �����츦 �����.
	ShowWindow(SW_HIDE);
	m_pDialog->SetParent(m_pPrevWnd);

	::SendMessage(m_pPrevWnd->m_hWnd, WNM_TOGGLE_WINDOW, (WPARAM)this, (LPARAM)&lpwndpl);
	pFrame->ShowControlBar((CControlBar *)m_pPrevWnd, TRUE, FALSE);
	DestroyWindow();
}
