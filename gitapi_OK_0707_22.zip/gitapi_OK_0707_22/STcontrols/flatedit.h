// FlatEdit.h: interface for the CAceDlgButton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FLATEDIT_H__4146AFA8_7178_44F6_B7A1_CB44D5A2A082__INCLUDED_)
#define AFX_FLATEDIT_H__4146AFA8_7178_44F6_B7A1_CB44D5A2A082__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define UM_EDITCHANGE		WM_USER+3001

class AFX_EXT_CLASS CFlatEditCtl : public CEdit
{
public:
	CFlatEditCtl();
	~CFlatEditCtl();

protected:
	afx_msg void OnChange();

	DECLARE_MESSAGE_MAP()
};

class AFX_EXT_CLASS CFlatEdit : public CWnd
{
public:
	CFlatEdit();
	~CFlatEdit();

	CEdit*	GetEdit()						{	return &m_Edit;							}
	void	LimitText(int nChars = 0)		{	m_Edit.LimitText(nChars);				}
	void	SetWindowText(LPCTSTR lpString)	{	m_Edit.SetWindowText(lpString);			}
	void	GetWindowText(CString &rString)	{	m_Edit.GetWindowText(rString);			}
	BOOL	EnableWindow(BOOL bEnable=TRUE)	{
												m_bEnable = bEnable;
												Invalidate(TRUE);
												return m_Edit.EnableWindow(bEnable);
											}
	int		GetWindowTextLength()			{	return m_Edit.GetWindowTextLength();	}

	int		GetLine(int nIndex, LPTSTR lpszBuffer) {
		return m_Edit.GetLine(nIndex, lpszBuffer);
	}
	int		GetLine(int nIndex, LPTSTR lpszBuffer, int nMaxLength) {
		return m_Edit.GetLine(nIndex, lpszBuffer, nMaxLength);
	}

protected:
	CFlatEditCtl	m_Edit;

	BOOL	m_bEnable;

	long	m_lBorder;
	long	m_lBack;

	CFont	m_Font;

	CRect	m_Rect;

	virtual void PreSubclassWindow();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnNcPaint();

	afx_msg	void OnPaint();
	afx_msg void OnSetFocus(CWnd *pOldWnd);

	DECLARE_MESSAGE_MAP()

};

#endif // !defined(AFX_FLATEDIT_H__4146AFA8_7178_44F6_B7A1_CB44D5A2A082__INCLUDED_)
