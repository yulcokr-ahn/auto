// SortClass.h: interface for the CSortClass class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SORTCLASS_H__C00A5A0E_833B_11D4_A433_004F4E0847C3__INCLUDED_)
#define AFX_SORTCLASS_H__C00A5A0E_833B_11D4_A433_004F4E0847C3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class AFX_EXT_CLASS CSortClass  
{
public:
	CSortClass(CListCtrl  *_pWnd, const int _iCol, const bool _bIsNumeric, const bool _bIsFloat = FALSE);
	virtual ~CSortClass();

	int iCol;
	CListCtrl * pWnd;
	bool bIsNumeric;
	bool bIsFloat;
	void Sort(const bool bAsc);

	static int CALLBACK CompareAsc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
	static int CALLBACK CompareDes(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
	static int CALLBACK CompareAscI(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
	static int CALLBACK CompareDesI(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
	static int CALLBACK CompareAscF(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
	static int CALLBACK CompareDesF(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);

public:
	class CSortItem
	{
		public:
		virtual  ~CSortItem();
		CSortItem(const DWORD _dw, const CString &_txt);
		CString txt;
		DWORD dw;
	};

	class CSortItemInt
	{
		public:
		CSortItemInt(const DWORD _dw, const CString &_txt);
		int iInt ;
		DWORD dw;
	};
	
	class CSortItemFloat
	{
		public:
		CSortItemFloat(const DWORD _dw, const CString &_txt);
		double dFloat;
		DWORD dw;
	};
};

#endif // !defined(AFX_SORTCLASS_H__C00A5A0E_833B_11D4_A433_004F4E0847C3__INCLUDED_)
