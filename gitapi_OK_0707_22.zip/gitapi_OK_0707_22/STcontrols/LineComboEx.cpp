// ColorComboEx.cpp : implementation file
//
// Eric Zimmerman coolez@one.net

#include "stdafx.h"
#include "LineComboEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorComboEx

CLineComboEx::CLineComboEx()
{
	// Add the colors to the array
	pens.Add( 1 );
	pens.Add( 2 );
	pens.Add( 3 );
	pens.Add( 4 );
	pens.Add( 5 );
	pens.Add( 6 );

	m_clrBtnHilite  = ::GetSysColor(COLOR_BTNHILIGHT);
	m_clrBtnShadow  = ::GetSysColor(COLOR_BTNSHADOW);
	m_clrBtnFace    = ::GetSysColor(COLOR_BTNFACE);
	m_nOffset		= ::GetSystemMetrics(SM_CXHTHUMB);

}

CLineComboEx::~CLineComboEx()
{
}


BEGIN_MESSAGE_MAP(CLineComboEx, CComboBox)
	//{{AFX_MSG_MAP(CColorComboEx)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorComboEx message handlers
void CLineComboEx::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_bLBtnDown = TRUE;
	CComboBox::OnLButtonDown(nFlags, point);
}

void CLineComboEx::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_bLBtnDown = FALSE;
	Invalidate();
	CComboBox::OnLButtonUp(nFlags, point);
}

void CLineComboEx::OnPaint() 
{
	ModifyStyleEx (WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE,
		0, SWP_FRAMECHANGED);
	
	Default();

	CPoint pt;
	GetCursorPos(&pt);

	CRect rcItem;
	GetWindowRect(&rcItem);

/*	if ((rcItem.PtInRect(pt)) || m_bHasFocus)
		DrawCombo( raised, m_clrBtnShadow, m_clrBtnHilite );
	else
*/	DrawCombo( normal, COLOR_BORDER, COLOR_BORDER);//m_clrBtnFace, m_clrBtnFace );
}

void CLineComboEx::DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight)
{
	CRect rcItem;
	GetClientRect(&rcItem);
	CDC* pDC = GetDC();
	
	// Cover up dark 3D shadow.
	pDC->Draw3dRect(rcItem, clrTopLeft, clrBottomRight);
	rcItem.DeflateRect(1,1);
	
	if (!IsWindowEnabled()) {
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
	}
	
	else {
		pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );
	}

	// Cover up dark 3D shadow on drop arrow.
	rcItem.DeflateRect(1,1);
	rcItem.left = rcItem.right-m_nOffset;
	pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );
	
	// Cover up normal 3D shadow on drop arrow.
	rcItem.DeflateRect(1,1);
	pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );
	
	if (!IsWindowEnabled()) {
		ReleaseDC(pDC);
		return;
	}

	switch (eState)
	{
	case normal:
		rcItem.top -= 1;
		rcItem.bottom += 1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		rcItem.left -= 1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		break;

/*	case raised:
		rcItem.top -= 1;
		rcItem.bottom += 1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnShadow);
		break;

	case pressed:
		rcItem.top -= 1;
		rcItem.bottom += 1;
		rcItem.OffsetRect(1,1);
		pDC->Draw3dRect( rcItem, m_clrBtnShadow, m_clrBtnHilite );
		break;*/
	}

	ReleaseDC(pDC);
}

void CLineComboEx::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// This function of course does all the work.
		
	CDC dc;
	dc.Attach(lpDrawItemStruct->hDC);
	CRect rect(&(lpDrawItemStruct->rcItem));
	
	// This switch statement draws the item in the combo box based on the itemID.
	// The itemID corresponds to the index in the COLORREF array.
	switch(lpDrawItemStruct->itemID)
	{
	// The automatic case
	case 16:
		{
			// Create the brush
/*			CBrush brush(colors.GetSize());
			CRect rect(&(lpDrawItemStruct->rcItem));
			rect.InflateRect(-2, -2);
			// Color the area
			dc.FillRect(rect, &brush);
			// Draw teh focus rect if the mosue is either over the item, or if the item
			// is selected
			if (lpDrawItemStruct->itemState & ODS_SELECTED)
				dc.DrawFocusRect(rect);
			
			// Draw the text
			CString strColor = "Automatic";
			CSize textSize = dc.GetOutputTextExtent(strColor);
			dc.SetBkMode(TRANSPARENT);
			dc.SetTextColor(RGB(255, 255, 255));
			dc.DrawText(strColor, rect, DT_SINGLELINE | DT_CENTER);
	*/		
		}
		break;
	default:
		// Drawing code for items accept the automatic color
		
		// Create the brush
		CBrush brush( RGB(255,255,255) );

		CPen Pen, *pOldPen;
		Pen.CreatePen(PS_SOLID, pens[lpDrawItemStruct->itemID], RGB(0,0,0));
		pOldPen = (CPen *)dc.SelectObject(&Pen);

		CRect rect(&(lpDrawItemStruct->rcItem));
		rect.InflateRect(-2, -2);

		// Color the area
		dc.FillRect(rect, &brush);

		int base = (rect.top + rect.bottom)/2;

		dc.MoveTo(rect.left+1, base);
		dc.LineTo(rect.right-1, base);
		// Draw the focus rect if the mouse is either over the item, or if the item
		// is selected
		if (lpDrawItemStruct->itemState & ODS_SELECTED)
			dc.DrawFocusRect(rect);

		dc.SelectObject(pOldPen);
		Pen.DeleteObject();		
    }
	
	// This draws the black frame around each of the colors so that they
	// do not look like they are kind of blended together
	CBrush frameBrush(RGB(255, 255, 255));
	dc.FrameRect(rect, &frameBrush);
	rect.InflateRect(-1, -1);
	
	dc.Detach();
	
}

void CLineComboEx::PreSubclassWindow() 
{
	//ModifyStyle(0, CBS_OWNERDRAWFIXED);

	for (int nColors = 0; nColors < pens.GetSize(); nColors++)
		// Add a dummy string for every array item so that WM_DRAWITEM message is sent.
		AddString("");
	
	// Select the first color when the control is created.
	SetCurSel(0);
	
	CComboBox::PreSubclassWindow();
}


void CLineComboEx::OnSelchange() 
{
	m_iCurSel = GetCurSel();
}
