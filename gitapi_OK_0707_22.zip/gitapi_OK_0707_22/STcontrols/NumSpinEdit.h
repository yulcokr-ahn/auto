#if !defined(AFX_NUMEDIT_H__7482F7FF_A479_11D2_A6A7_00600844997A__INCLUDED_ST_)
#define AFX_NUMEDIT_H__7482F7FF_A479_11D2_A6A7_00600844997A__INCLUDED_ST_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// NumEdit.h : header file
//

#include "SkinSpinButtonCtrl.h"


class CSTNumEdit;

//class CSkinSpinButtonCtrl;
#if !defined(def_CNumSpinCtrl)
#define def_CNumSpinCtrl

class AFX_EXT_CLASS CNumSpinCtrl : public CSkinSpinButtonCtrl
{
	DECLARE_DYNAMIC(CNumSpinCtrl)
// Construction
public:
	CNumSpinCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNumSpinCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual void SetDelta(float delta);
	virtual float GetDelta();
	virtual void SetBuddy(CSTNumEdit *edit);
	virtual CSTNumEdit* GetBuddy() const;
	virtual void GetRange(float &lower, float& upper ) const;
	virtual void SetRange(float nLower, float nUpper );
	virtual float GetPos();
	virtual void SetPos(float val);
	virtual ~CNumSpinCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CNumSpinCtrl)
	afx_msg BOOL OnDeltapos(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};
#endif


/////////////////////////////////////////////////////////////////////////////
// CSTNumEdit window
class AFX_EXT_CLASS CSTNumEdit : public CEdit
{
	DECLARE_DYNAMIC(CSTNumEdit)
// Construction
public:
	CSTNumEdit();
	long	m_lBkColor;
	HBRUSH	m_hbr1;
	HBRUSH	m_hbr2;
	long m_TextColor;
	CFont	m_editFont, *m_pOldFont;	// Font�� �����Ѵ�.

// Attributes
public:

	enum {VALID = 0x00, OUT_OF_RANGE = 0x01, INVALID_CHAR = 0x02, MINUS_PLUS = 0x03};
	void SetBkColor(COLORREF color);
	void SetFont(char *font, int FontBold, BOOL FontItalic, int FontSize, COLORREF	FontColor);

	void SetNumAfterPoint(int nPoint);
	void SetAutoInsertComma(BOOL bSet = TRUE);
	void SetAutoDot(BOOL bSet = TRUE);
	void SetNotDot(BOOL bSet = TRUE);
	void SetInt(BOOL bSet = TRUE);
	void SetWndBkColor(long lBkColor);

	void SetBoardColor(COLORREF color);

protected:
	virtual void DrawBorder(bool fHot = true);

	COLORREF m_clrBoardColor;

	COLORREF m_clr3DHilight;
	COLORREF m_clr3DLight;
	COLORREF m_clr3DDkShadow;
	COLORREF m_clr3DShadow;
	COLORREF m_clr3DFATS;
	bool m_fTimerSet;
	bool m_fGotFocus;
public:

	//{{AFX_VIRTUAL(CSTNumEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual void ChangeAmount(int step);
	virtual float GetDelta();
	virtual void SetDelta(float delta);
	virtual void GetRange(float &min, float &max)const; 
	virtual void SetRange(float min, float max);
	virtual void Verbose(BOOL v);
	virtual BOOL Verbose()const; 
	virtual int IsValid()const; 
	virtual int IsValid(const CString &str)const; 

	virtual BOOL SetValue(float val);
	virtual BOOL SetValueInt(int val);
	virtual int GetValueInt()const; 
	virtual float GetValue()const; 
	virtual ~CSTNumEdit();

	// Generated message map functions
protected:
	virtual CString& ConstructFormat(CString &str, float num);
	virtual void InsertComma(CString &strData,UINT nIndent=3);	

	int m_nNumberOfNumberAfterPoint;
	BOOL m_Verbose;
	float m_Delta, m_MinValue, m_MaxValue;
	BOOL		m_bAutoInsertComma;

	BOOL m_bAutoDot;
	BOOL m_bNotDot;
	BOOL m_bInt;

	//{{AFX_MSG(CSTNumEdit)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSetfocus();
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);


	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnNcMouseMove(UINT nHitTest, CPoint point);
	afx_msg void OnSysColorChange();


	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NUMEDIT_H__7482F7FF_A479_11D2_A6A7_00600844997A__INCLUDED_ST_)
