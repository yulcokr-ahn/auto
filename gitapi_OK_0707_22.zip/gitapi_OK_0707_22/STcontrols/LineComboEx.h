#ifndef __LINECOMBO_H__
#define __LINECOMBO_H__

#include <afxtempl.h>	// Used for CArray

/////////////////////////////////////////////////////////////////////////////
// CColorComboEx window

class AFX_EXT_CLASS CLineComboEx : public CComboBox
{
// Construction
public:
	CLineComboEx();

// Attributes
public:
	int m_iCurSel;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorComboEx)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
//	CArray<COLORREF, COLORREF> colors;
//	CArray<CPen, CPen> pens;
	CArray<int, int> pens;
	CArray<CPoint, CPoint> points;

	int			m_nOffset;		// offset used during paint.
	BOOL		m_bLBtnDown;	// TRUE if left mouse button is pressed
	COLORREF	m_clrBtnHilite;	// set to the system color COLOR_BTNHILIGHT
	COLORREF	m_clrBtnShadow;	// set to the system color COLOR_BTNSHADOW
	COLORREF	m_clrBtnFace;	// set to the system color COLOR_BTNFACE

	enum STATE { normal = 1, raised = 2, pressed = 3 };

	virtual ~CLineComboEx();
	
	void DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight);

	// Generated message map functions
protected:
	//{{AFX_MSG(CColorComboEx)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSelchange();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORCOMBOEX_H__82ACEB03_8F6E_11D1_B7B1_00A024DE65ED__INCLUDED_)
