#if !defined(AFX_CUSTOMWND_H__D390497C_4E6D_4F1D_B730_DA63CC59532E__INCLUDED_)
#define AFX_CUSTOMWND_H__D390497C_4E6D_4F1D_B730_DA63CC59532E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CustomWnd.h : header file
//

#define WNM_TOGGLE_WINDOW	(WM_USER + 501)
#define WNM_DESTROY_WINDOW	(WM_USER + 502)

// Message Map Handler
#define ON_WNM_TOGGLE_WINDOW() \
	{ WNM_TOGGLE_WINDOW, 0, 0, 0, AfxSig_vwl, \
		(AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(CWnd *, LPWINDOWPLACEMENT))&OnToggleWindow },
#define ON_WNM_DESTROY_WINDOW() \
	{ WNM_DESTROY_WINDOW, 0, 0, 0, AfxSig_vwl, \
		(AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(CWnd *, LPWINDOWPLACEMENT))&OnDestroyWindow },

#define	RESIZE_NONE		0x00000001

//20150911
#define RESIZE_VERT		0x00000010
#define RESIZE_HORZ		0x00000020
#define RESIZE_BOTH		0x00000030

#include "SkinedMDIChildWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CCustomWnd frame

class CCustomWnd : public CSkinedMDIChildWnd
{
	DECLARE_DYNCREATE(CCustomWnd)
protected:
	CCustomWnd();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	void SetStyle(DWORD dwStyle);
	CString		m_sTitle;
//	void SetTitle(CString strTitle);
	void SetDialog(CDialog *pDlg = NULL, CRect rcDialog = NULL);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCustomWnd)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void ActivateFrame(int nCmdShow = -1);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CCustomWnd();

	// Generated message map functions
	//{{AFX_MSG(CCustomWnd)
	afx_msg void OnDestroy();
	afx_msg void OnNcLButtonDblClk(UINT nHitTest, CPoint point);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CDialog		*m_pDialog;
	CWnd		*m_pPrevWnd;
	CRect		m_rcDialog;

	UINT		m_nState;
	DWORD		m_dwStyle;

	CPoint		m_ptMax, m_ptTrackMax, m_ptTrackMin;
	int			m_nDiffWidth, m_nDiffHeight;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CUSTOMWND_H__D390497C_4E6D_4F1D_B730_DA63CC59532E__INCLUDED_)
