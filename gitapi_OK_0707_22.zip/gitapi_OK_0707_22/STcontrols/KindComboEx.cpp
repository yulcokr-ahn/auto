// KindComboEx.cpp : implementation file
//

#include "stdafx.h"
#include "KindComboEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CKindComboEx

CKindComboEx::CKindComboEx()
{	
	m_iCurSel = 0;
	pens.Add( PS_SOLID );
	pens.Add( PS_DASH );
	pens.Add( PS_DOT );
	pens.Add( PS_DASHDOT );
	pens.Add( PS_DASHDOTDOT );	
	
	m_clrBtnHilite  = ::GetSysColor(COLOR_BTNHILIGHT);
	m_clrBtnShadow  = ::GetSysColor(COLOR_BTNSHADOW);
	m_clrBtnFace    = ::GetSysColor(COLOR_BTNFACE);
	m_nOffset		= ::GetSystemMetrics(SM_CXHTHUMB);	
	m_nPenSize = 5;
}

CKindComboEx::~CKindComboEx()
{
	pens.RemoveAll();
	points.RemoveAll();
}


BEGIN_MESSAGE_MAP(CKindComboEx, CComboBox)
	//{{AFX_MSG_MAP(CKindComboEx)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	//ON_CONTROL_REFLECT(CBN_SELCHANGE, OnSelchange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKindComboEx message handlers
void CKindComboEx::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_bLBtnDown = TRUE;
	CComboBox::OnLButtonDown(nFlags, point);
}

void CKindComboEx::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_bLBtnDown = FALSE;
	Invalidate();
	CComboBox::OnLButtonUp(nFlags, point);
}

void CKindComboEx::OnPaint() 
{
	ModifyStyleEx (WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE,
		0, SWP_FRAMECHANGED);
	
	Default();

	CPoint pt;
	GetCursorPos(&pt);

	CRect rcItem;
	GetWindowRect(&rcItem);

	DrawCombo( normal, COLOR_BORDER, COLOR_BORDER);//m_clrBtnFace, m_clrBtnFace );
}

void CKindComboEx::DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight)
{
	CRect rcItem;
	GetClientRect(&rcItem);
	CDC* pDC = GetDC();
	
	// Cover up dark 3D shadow.
	pDC->Draw3dRect(rcItem, clrTopLeft, clrBottomRight);
	rcItem.DeflateRect(1,1);
	
	if (!IsWindowEnabled()) {
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
	}
	
	else {
		pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );
	}

	// Cover up dark 3D shadow on drop arrow.
	rcItem.DeflateRect(1,1);
	rcItem.left = rcItem.right-m_nOffset;
	pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );
	
	// Cover up normal 3D shadow on drop arrow.
	rcItem.DeflateRect(1,1);
	pDC->Draw3dRect( rcItem, m_clrBtnFace, m_clrBtnFace );
	
	if (!IsWindowEnabled()) {
		ReleaseDC(pDC);
		return;
	}

	switch (eState)
	{
	case normal:
		rcItem.top -= 1;
		rcItem.bottom += 1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		rcItem.left -= 1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		break;

/*	case raised:
		rcItem.top -= 1;
		rcItem.bottom += 1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnShadow);
		break;

	case pressed:
		rcItem.top -= 1;
		rcItem.bottom += 1;
		rcItem.OffsetRect(1,1);
		pDC->Draw3dRect( rcItem, m_clrBtnShadow, m_clrBtnHilite );
		break;*/
	}

	ReleaseDC(pDC);
}

void CKindComboEx::SetPenSize(BOOL bBsn)
{
	m_nPenSize = pens.GetSize();
	if(!bBsn)		//���ؼ��� �ƴҶ�
		m_nPenSize = m_nPenSize + 3; //2005.2.22 stick �߰�(+1)
}

void CKindComboEx::PreSubclassWindow() 
{	
	for (int i = 0; i < m_nPenSize; i++)		
		AddString("");

	SetItemHeight(0,20);

	//ModifyStyle(0, CBS_OWNERDRAWFIXED);
	
	// Select the first color when the control is created.

	SetCurSel(0);
	
	CComboBox::PreSubclassWindow();
}

void CKindComboEx::OnSelchange() 
{
	m_iCurSel = GetCurSel();		
	GetParent()->SendMessage(CBN_SELCHANGE,0,0);
}

void CKindComboEx::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC dc;
	dc.Attach(lpDrawItemStruct->hDC);
	
	// Color the area
	CRect rect(&(lpDrawItemStruct->rcItem));
	dc.FillSolidRect(&rect, RGB(255,255,255));

	if (lpDrawItemStruct->itemState & ODS_SELECTED)
	{
		dc.DrawFocusRect(rect);			
	}
	
	switch(lpDrawItemStruct->itemID)
	{
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		{			
			int base = (rect.top + rect.bottom)/2;
			CPen Pen, *pOldPen;	

			Pen.CreatePen(pens[lpDrawItemStruct->itemID],1,RGB(0,0,0));
			pOldPen = (CPen *)dc.SelectObject(&Pen);
			dc.MoveTo(rect.left+1, base);
			dc.LineTo(rect.right-1, base);
			dc.SelectObject(pOldPen);
			Pen.DeleteObject();		
			break;
		}
		case 5:  // oscillator
		{
			int	oscdata[] = {3,7,8,8,7,3};

			CPen Pen, *pOldPen;	
			Pen.CreatePen(PS_SOLID,1,RGB(0,0,0));
			pOldPen = (CPen *)dc.SelectObject(&Pen);

			int ybase = (rect.top + rect.bottom)/2;
			int xbase = (rect.left + rect.right)/2 - (3*(3*6)/2);
			int i;

			for(i=0; i < 6; i++)
			{
				dc.MoveTo(xbase+(i*3), ybase);
				dc.LineTo(xbase+(i*3), ybase - oscdata[i]);
			}
			xbase += (++i*3);
			for(i=0; i < 6; i++)
			{
				dc.MoveTo(xbase+(i*3), ybase);
				dc.LineTo(xbase+(i*3), ybase + oscdata[i]);
			}
			xbase += ++i*3;
			for(i=0; i < 6; i++)
			{
				dc.MoveTo(xbase+(i*3), ybase - 0);
				dc.LineTo(xbase+(i*3), ybase - oscdata[i]);
			}
			dc.SelectObject(pOldPen);
			Pen.DeleteObject();		
			break;
		}
		case 6: // parabollic
		{
			int	oscdata[] = {-4,-6,-6,-4,-2,6,7,7,6,4};

			CPen Pen, *pOldPen;	
			Pen.CreatePen(PS_SOLID,2,RGB(0,0,0));
			pOldPen = (CPen *)dc.SelectObject(&Pen);

			int ybase = (rect.top + rect.bottom)/2;
			int xbase = (rect.left + rect.right)/2 - (5*10)/2;		

			int i;

			for(i=0; i < 10; i++)
			{
				dc.MoveTo(xbase+(i*5), ybase - oscdata[i]);
				dc.LineTo(xbase+(i*5)+1, ybase - oscdata[i]);
			}
			dc.SelectObject(pOldPen);
			Pen.DeleteObject();		
			break;
		}
		case 7: //2005.2.22 �ο��� stick�߰�
		{
			int	oscdata[] = {8,12,10,4,6,10,4,2,8};

			CPen Pen, *pOldPen;	
			CBrush Brush, *pOldBrush;
			Pen.CreatePen(PS_SOLID,1,RGB(0,0,0));
			pOldPen = (CPen *)dc.SelectObject(&Pen);
			Brush.CreateSolidBrush(RGB(192,192,192));
			pOldBrush = (CBrush *)dc.SelectObject(&Brush);

			int ybase = rect.bottom - 4;
			int xbase = (rect.left + rect.right)/2 - (6*9)/2;

			//baseline
			dc.MoveTo(rect.left+4, ybase);
			dc.LineTo(rect.right-4, ybase);

			int i;
			xbase += 2;
			for(i=0; i < 9; i++)
			{
				CRect rcStick;
				rcStick.bottom = ybase;
				rcStick.top = ybase - oscdata[i];
				rcStick.left = xbase+(i*6);
				rcStick.right = rcStick.left+3;				
				dc.Rectangle(rcStick);
			}
			dc.SelectObject(pOldPen);
			dc.SelectObject(pOldBrush);
			Pen.DeleteObject();
			Brush.DeleteObject();
			break;			
		}
	}

	// This draws the black frame around each of the colors so that they
	// do not look like they are kind of blended together
	//CBrush frameBrush(RGB(255, 255, 255));
	//pDC->FrameRect(rect, &frameBrush);
	//rect.InflateRect(-1, -1);
	
	dc.Detach();	
}

