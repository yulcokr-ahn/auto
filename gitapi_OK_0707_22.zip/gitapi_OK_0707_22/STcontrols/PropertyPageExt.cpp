// PropertyPageExt.cpp : implementation file
// 2001.9.cyber.sukim

#include "stdafx.h"
#include "PropertyPageExt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyPageExt property page

IMPLEMENT_DYNCREATE(CPropertyPageExt, CPropertyPage)

CPropertyPageExt::CPropertyPageExt()
{
	m_crBkgColour	= RGB(228,234,230);
	//{{AFX_DATA_INIT(CPropertyPageExt)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropertyPageExt::CPropertyPageExt(UINT nIDTemplate) : CPropertyPage(nIDTemplate)
{
	m_crBkgColour	= RGB(228,234,230);
	//{{AFX_DATA_INIT(CPropertyPageExt)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CPropertyPageExt::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyPageExt)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyPageExt, CPropertyPage)
	//{{AFX_MSG_MAP(CPropertyPageExt)
	ON_WM_ERASEBKGND()
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CPropertyPageExt operations

void CPropertyPageExt::SetColours(COLORREF BkgColour)
{
	m_crBkgColour = BkgColour;
	Invalidate();
}


/////////////////////////////////////////////////////////////////////////////
// CPropertyPageExt message handlers

BOOL CPropertyPageExt::OnEraseBkgnd(CDC* pDC)
{
	CRect rcItem;

	GetClientRect(&rcItem);
	pDC->FillSolidRect(&rcItem, m_crBkgColour);
	return 0;
}
