#if !defined(AFX_DNDLISTCTRL_H__BB5575FF_F092_11D3_A945_00104B15E488__INCLUDED_)
#define AFX_DNDLISTCTRL_H__BB5575FF_F092_11D3_A945_00104B15E488__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DNDListCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDNDListCtrl window

#include "ListDroptarget.h"
#include "FlatHeaderCtrl.h"
#include <afxtempl.h>
/*
class CItem
{
public:
	CItem() : arrpsz( NULL ), dwData( NULL ) {}

public:
	LPTSTR*	arrpsz;
	DWORD	dwData;

private:
	// ban copying.
	CItem(const CItem&);
	CItem& operator=(const CItem&);
};
*/
class AFX_EXT_CLASS CDNDListCtrl : public CListCtrl
{
// Construction
public:
	CDNDListCtrl();

// Attributes
public:
	CListDropTarget m_ListDropTarget;

	int			m_nDropIndex;
	int			m_nPrevDropIndex;
	UINT		m_uPrevDropState;

	CDWordArray	m_DragList;

	CWnd		*m_sHandle;
	HWND		m_shWndListCtrl;
	short		m_nSourceType;				// 1�̸� list , 2�̸� Tree�� �Ѵ�.
	HWND		m_shWndListCtrlParent;

	void Sort(int iColumn, BOOL bAscending);
	void SetHeaderColor(COLORREF crHeader);

	void SetRowSelect(BOOL bRowSelect);
	void SetHeaderCaption(UINT nCol, LPTSTR lpCaption);
	void SetRowHeight(UINT nRowHeight);

	BOOL SetCurSel(int nItem);
	int GetCurSel();
	
	// Sorting
	BOOL	DeleteItem(int iItem);
	BOOL	DeleteAllItems();
	int		InsertItem(int nItem, LPCTSTR lpszItem);
	BOOL	SetItemText( int nItem, int nSubItem, LPCTSTR lpszText );
	BOOL	SetItemData(int nItem, DWORD dwData);
	DWORD	GetItemData(int nItem) const;
	BOOL	SetTextArray(int iItem, LPTSTR* arrpsz);
	LPTSTR* GetTextArray(int iItem) const;
	void	FreeItemMemory(const int iItem);
protected:
	static int CALLBACK CompareFunction(LPARAM lParam1, LPARAM lParam2, LPARAM lParamData);

	int m_iNumColumns;
	int m_iSortColumn;
	BOOL m_bSortAscending;
	int m_nRowHeight;

	CFlatHeaderCtrl m_wndHeader;

	BOOL m_bRowSelect;
	
// Operations
public:
	void SetDragInfor();
	void RegistDropTarget();

	void UpdateSelection(int nDropIndex);
	void RestorePrevDropItemState();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDNDListCtrl)
	protected:
	virtual void PreSubclassWindow();
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);	
	virtual void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDNDListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDNDListCtrl)
	afx_msg void OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DNDLISTCTRL_H__BB5575FF_F092_11D3_A945_00104B15E488__INCLUDED_)
