#if !defined(AFX_MYCOLORLISTCTRL_H__E1D0DCCF_6C76_11D5_9280_0050DA8CA632__INCLUDED_)
#define AFX_MYCOLORLISTCTRL_H__E1D0DCCF_6C76_11D5_9280_0050DA8CA632__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyColorListCtrl.h : header file
//

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CMyColorListCtrl window
#define LVIS_COLOR_RED		0x0100
#define LVIS_COLOR_BLUE		0x0200
#define LVIS_COLOR_GREEN	0x0400
#define LVIS_SYMBOL			0x0800

#define LIST_RGB_RED		RGB(255,0,0)
#define LIST_RGB_BLUE		RGB(0,0,255)
#define LIST_RGB_GREEN		RGB(0,128,0)

#define LNM_RESIZE	(WM_USER + 1)

class AFX_EXT_CLASS CMyColorListCtrl : public CListCtrl
{
// Construction
public:
	CMyColorListCtrl();
	int HitTestEx(CPoint &point, int *col) const;
	CEdit* EditSubLabel( int nItem, int nCol );
	void SetEditable(BOOL bEdit);

	BOOL	m_bAutoEditMove;		//����Ű �Է½� ������ �ڵ����� �����Ұ��ΰ�
	int		m_nEditNextRow;			//����Ű �Է½� ���� ������ Row.
	int		m_nEditable, m_nEditColumn, m_nEditColumn2;
	BOOL	m_bDestColEdited;		//�����Ǿ��� Index�� ���Ұ��ΰ�
	BOOL	m_bInit;
	BOOL	m_bMouseMove;
	int		m_nLinkIndex1, m_nLinkIndex2;
	BOOL	m_bColColor;
	int		m_nColColorIdx;
	COLORREF	m_crCol;
	COLORREF    m_crBorder;
	int		m_nColorCount;
	
	//ToolTip ����
	BOOL	m_bEnableToolTip;
	int		m_nTipIndex;
	void SetEnableToolTips(int nTipIndex);
	virtual int OnToolHitTest(CPoint point, TOOLINFO * pTI) const;
	int CellRectFromPoint(CPoint & point, RECT * cellrect, int * col) const;

	//////����� Stick Graph
	BOOL m_bProgressBar;
	BOOL m_bProgressBar2;
	int m_nStickIndex;
	int m_nStickIndex2;
	int m_nStickDataIndex;
	int m_nStickDataIndex2;
	double m_dMaxVal;
	double m_dMaxVal2;
	void SetStickMax(double dMax);
	void SetStickMax2(double dMax);
	void DrawStick(CDC* pDC, int nRowIndex);
	void DrawStick2(CDC* pDC, int nRowIndex);
	//////

	//////Ư�� Row ���� ���� ���� (2004.9.13 min)
	int m_nBKCount;
	struct{
		int nIndex;
		COLORREF crBkColor;
	} m_BKColorList[100];
	void InitBKSetting();
	void SetRowBKColor(int nIndex, COLORREF crBKColor);
	int IsBKChangedRow(int nIndex);

	void SetBorderColor(COLORREF crBorder) { m_crBorder = crBorder; }

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyColorListCtrl)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMyColorListCtrl();

public:
	void SetRowColor(COLORREF crRow1, COLORREF crRow2 = NULL);
	enum EHighlight {HIGHLIGHT_NORMAL, HIGHLIGHT_ALLCOLUMNS, HIGHLIGHT_ROW};
protected:
	int  m_nHighlight;	
	void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	int SetHighlightType(EHighlight hilite);
// Generated message map functions
protected:
	//{{AFX_MSG(CMyColorListCtrl)
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnNcPaint();
	afx_msg void OnExcelSave();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnEndLabelEdit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg LRESULT OnResize(WPARAM wParam, LPARAM lParam);
	afx_msg void OnWindowPosChanged(WINDOWPOS FAR* lpwndpos);
	afx_msg void MeasureItem ( LPMEASUREITEMSTRUCT lpMeasureItemStruct );
	afx_msg BOOL OnToolTipText( UINT id, NMHDR * pNMHDR, LRESULT * pResult );
//	afx_msg void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	DECLARE_MESSAGE_MAP()
// 2002.07.16 �����߰��Ȼ���
private:
	BOOL				m_fAutoSize;

	COLORREF	m_crRow1;
	COLORREF	m_crRow2;

	// Column�� �߰��ɶ� Column�� ����� �ڵ� ������ �ϰԲ� �Ѵ�.
public:
	void SaveToCSV();
	int InsertColumn(int nCol, const LVCOLUMN *pColumn);
	void EnableAutoSize(BOOL bAuto = FALSE);
	void ResetColumnSize(int nCol, int nWidth);
	void SetAutoResize(BOOL bResize);
private:
	void ResizeColumn();
	CMap < int, int, LVCOLUMN, LVCOLUMN& >	m_Columns;
	CList < int, int&> m_ColumnNo;

	BOOL		m_bIsSizing;
	BOOL		m_bAutoResize;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYCOLORLISTCTRL_H__E1D0DCCF_6C76_11D5_9280_0050DA8CA632__INCLUDED_)
