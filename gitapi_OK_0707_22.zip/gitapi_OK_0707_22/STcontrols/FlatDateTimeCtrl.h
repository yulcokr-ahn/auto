#if !defined(AFX_FLATDATETIMECTRL_H__425BB3A3_B1E9_11D5_A8B1_444553540000__INCLUDED_ST_)
#define AFX_FLATDATETIMECTRL_H__425BB3A3_B1E9_11D5_A8B1_444553540000__INCLUDED_ST_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FlatDateTimeCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrl window
//2013.12.07
#if !defined(def_CDateTimeCtrl)
#define def_CDateTimeCtrl
class AFX_EXT_CLASS CFlatDateTimeCtrl : public CDateTimeCtrl
{
	DECLARE_DYNAMIC(CFlatDateTimeCtrl)

	// Construction
public:
	CFlatDateTimeCtrl();
	virtual ~CFlatDateTimeCtrl();

protected:
	int			m_nOffset;		// offset used during paint.
	BOOL		m_bLBtnDown;	// TRUE if left mouse button is pressed
	BOOL		m_bPainted;		// used during paint operations
	BOOL		m_bHasFocus;	// TRUE if control has focus
	BOOL		m_bAutoComp;	// Used by Autocompleting.
	COLORREF	m_clrBtnHilite;	// set to the system color COLOR_BTNHILIGHT
	COLORREF	m_clrBtnShadow;	// set to the system color COLOR_BTNSHADOW
	COLORREF	m_clrBtnFace;	// set to the system color COLOR_BTNFACE
	COLORREF	m_clrBkg;		// background color
	COLORREF	m_clrBorder;

	// enum used to determine the state the combo box should be
	//
	enum STATE { normal = 1, raised = 2, pressed = 3 };

public:
	// Call this member function to enable auto completion.
	//
	void EnableAutoCompletion(BOOL bEnable=TRUE);
	void SetBkgColor(COLORREF BkgColour);

protected:

	// this member function is called by the combo box whenever a paint
	// operation should occur.
	//
	void DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCJFlatComboBox)
	public:
	virtual BOOL OnChildNotify(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pLResult);
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CCJFlatComboBox)
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg	void	OnMouseMove(UINT nFlags, CPoint point);
	afx_msg	void	OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg	void	OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg	void	OnPaint();
	afx_msg	BOOL 	OnEraseBkgnd(CDC* pDC);
	afx_msg void	OnNcPaint();
	afx_msg void OnDropDown();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	

	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


  
inline void CFlatDateTimeCtrl::EnableAutoCompletion(BOOL bEnable )
	{ ASSERT(::IsWindow(m_hWnd)); m_bAutoComp = bEnable; }

#endif//def_CDateTimeCtrl










/*

#include "afxdtctl.h" // only needed for date/time controls

#define DTCEM_DESTROY_CALENDAR	(WM_USER+101)
#define DTCEM_RECREATE			(WM_USER+102)
#define DTCEM_PRESSENTER		(WM_USER+103)

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlButton window
class CFlatDateTimeCtrlButton : public CButton
{
public:
	CFlatDateTimeCtrlButton() { m_bRestoreFocus = FALSE; m_pWndLastFocus = NULL; m_bNonEditable = FALSE; }
	void RestoreFocus(BOOL bRestore = TRUE) { m_bRestoreFocus = bRestore; }
	void SetNonEditable(BOOL bNonEditable = TRUE) { m_bNonEditable = bNonEditable; }
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlatDateTimeCtrlButton)
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_VIRTUAL
	
	// Generated message map functions
protected:
	CWnd* m_pWndLastFocus;
	BOOL m_bRestoreFocus;
	BOOL m_bNonEditable;
	
	//{{AFX_MSG(CFlatDateTimeCtrlButton)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlEditCtrl window
class CFlatDateTimeCtrlEditCtrl : public CEdit
{
public:
	BOOL GetAllowUpDownKeys();
	void SetAllowUpDownKeys(BOOL bAllow = TRUE);
	CString GetValidChars();
	void SetValidChars(LPCTSTR lpszValidChars = NULL);
	BOOL GetValidCharsOnly();
	void SetValidCharsOnly(BOOL bValidCharsOnly = TRUE);
	CFlatDateTimeCtrlEditCtrl();
	void SetNonEditable(BOOL bNonEditable = TRUE) { m_bNonEditable = bNonEditable; }
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlatDateTimeCtrlEditCtrl)
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL
	
	// Generated message map functions
protected:
	void SendDateTimeChange();
	BOOL m_bNonEditable;
	BOOL m_bValidCharsOnly;
	CString m_sValidChars;
	BOOL m_bAllowUpDownKeys;
	
	//{{AFX_MSG(CFlatDateTimeCtrlEditCtrl)
	afx_msg LRESULT OnGetDlgCode();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSettingChange(UINT uFlags, LPCTSTR lpszSection);
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlMonthCalCtrl window

class CFlatDateTimeCtrlMonthCalCtrl : public CMonthCalCtrl
{
	// Construction
public:
	CFlatDateTimeCtrlMonthCalCtrl();
	
	// Attributes
public:
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlatDateTimeCtrlMonthCalCtrl)
protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	virtual ~CFlatDateTimeCtrlMonthCalCtrl();
	
	// Generated message map functions
protected:
	DWORD m_nIgnoreNextMessage;
	
	//{{AFX_MSG(CFlatDateTimeCtrlMonthCalCtrl)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlCalendarWnd window

class CFlatDateTimeCtrlCalendarWnd : public CWnd
{
	// Construction
public:
	CFlatDateTimeCtrlCalendarWnd(CWnd* pComboParent, DWORD dwMCStyle = 0);
	
	// Attributes
public:
	CFlatDateTimeCtrlMonthCalCtrl* GetMonthCalCtrl() { return m_pCalendar; }
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlatDateTimeCtrlCalendarWnd)
public:
	virtual BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual BOOL DestroyWindow();
protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	virtual ~CFlatDateTimeCtrlCalendarWnd();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CFlatDateTimeCtrlCalendarWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
#if _MFC_VER >= 0x0700
	afx_msg void OnActivateApp(BOOL bXPX_ACTIVE, DWORD dwThreadID);
#else
	afx_msg void OnActivateApp(BOOL bXPX_ACTIVE, HTASK hTask);
#endif
	DECLARE_MESSAGE_MAP()
		
private:
	CFlatDateTimeCtrlMonthCalCtrl* m_pCalendar;
	
	CWnd* m_pComboParent;
	
	DWORD m_dwMCStyle;
};

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrl window
class AFX_EXT_CLASS CFlatDateTimeCtrl : public CDateTimeCtrl
//class CFlatDateTimeCtrl : public CDateTimeCtrl
{
	DECLARE_DYNAMIC(CFlatDateTimeCtrl)
		
		// Construction
public:
	CFlatDateTimeCtrl();
	void Parse();
	COleDateTime& GetDate() { return m_date; };
	BOOL IsValid() const;
	void SetEmpty();
	void SetInitDate(COleDateTime& date);

	BOOL		m_bAutoComp;	// Used by Autocompleting.


	void EnableAutoCompletion(BOOL bEnable=TRUE);
	// Attributes
public:
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlatDateTimeCtrl)
protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	BOOL SetButtonImageID(UINT nID);
	UINT GetButtonImageID() const { return m_nBtnImageID; }
	BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
	virtual ~CFlatDateTimeCtrl();
	CEdit* GetEditControl() const { return m_pEdit; }
	void EnableButton(BOOL bEnable = TRUE);
	void RestoreFocus(BOOL bRestore = TRUE) { if (m_pBtn != NULL) m_pBtn->RestoreFocus(bRestore); }
	void SetNonEditable(BOOL bNonEditable = TRUE);
	BOOL GetNonEditable() { return m_bNonEditable; }
	virtual BOOL IsValidDate(LPCTSTR lpszDate = NULL);
	void SetValidCharsOnly(BOOL bValidCharsOnly = TRUE);
	BOOL GetValidCharsOnly();
	void SetValidChars(LPCTSTR lpszValidChars = NULL);
	CString GetValidChars();
	void SetAllowUpDownKeys(BOOL bAllow = TRUE);
	BOOL GetAllowUpDownKeys();
	
	// Generated message map functions
protected:
	BOOL DestroyCalendar(BOOL bDiscard = FALSE);
	BOOL CreateCalendar();
	CFlatDateTimeCtrlEditCtrl* m_pEdit;
	CFlatDateTimeCtrlButton* m_pBtn;
	UINT m_nBtnImageID;
	BOOL m_bNonEditable;
	BOOL m_bRightAlign;
	BOOL m_bEmpty;
	BOOL m_bUpdate;

	CSpinButtonCtrl* m_pSpin;
	
	CFlatDateTimeCtrlCalendarWnd* m_pCalWnd;
	CString m_sOrigDate;
	
	BOOL m_bInCreate;
	
	COleDateTime* m_pDateMin;
	COleDateTime* m_pDateMax;
	COleDateTime m_date;
	COleDateTime m_dtInitItem;

	// monthcal properties
	HFONT m_hMCFont;
	COLORREF m_acrMonthCal[6];
	
	//{{AFX_MSG(CFlatDateTimeCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnEnable(BOOL bEnable);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnCancelMode();
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	//}}AFX_MSG
	afx_msg LONG OnDestroyCalendar(WPARAM wParam, LPARAM lParam);
	afx_msg void OnStyleChanging(int nStyleType, LPSTYLESTRUCT lpStyleStruct);
	afx_msg LONG OnRecreate(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};


inline void CFlatDateTimeCtrl::EnableAutoCompletion(BOOL bEnable )
	{ ASSERT(::IsWindow(m_hWnd)); m_bAutoComp = bEnable; }





*/

/*
class AFX_EXT_CLASS CFlatDateTimeCtrl : public CDateTimeCtrl
{
	DECLARE_DYNAMIC(CFlatDateTimeCtrl)

	// Construction
public:
	CFlatDateTimeCtrl();
	virtual ~CFlatDateTimeCtrl();

protected:
	int			m_nOffset;		// offset used during paint.
	BOOL		m_bLBtnDown;	// TRUE if left mouse button is pressed
	BOOL		m_bPainted;		// used during paint operations
	BOOL		m_bHasFocus;	// TRUE if control has focus
	BOOL		m_bAutoComp;	// Used by Autocompleting.
	COLORREF	m_clrBtnHilite;	// set to the system color COLOR_BTNHILIGHT
	COLORREF	m_clrBtnShadow;	// set to the system color COLOR_BTNSHADOW
	COLORREF	m_clrBtnFace;	// set to the system color COLOR_BTNFACE
	COLORREF	m_clrBkg;		// background color

	// enum used to determine the state the combo box should be
	//
	enum STATE { normal = 1, raised = 2, pressed = 3 };

public:
	// Call this member function to enable auto completion.
	//
	void EnableAutoCompletion(BOOL bEnable=TRUE);
	void SetBkgColor(COLORREF BkgColour);

protected:

	// this member function is called by the combo box whenever a paint
	// operation should occur.
	//
	void DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSTCJFlatComboBox)
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CSTCJFlatComboBox)
	afx_msg	void	OnMouseMove(UINT nFlags, CPoint point);
	afx_msg	void	OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg	void	OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg	void	OnPaint();
	afx_msg	void	OnEraseBkgnd(CDC* pDC);
	afx_msg void	OnNcPaint();
	

	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};
*/

/////////////////////////////////////////////////////////////////////////////
//	Inline Functions
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLATDATETIMECTRL_H__425BB3A3_B1E9_11D5_A8B1_444553540000__INCLUDED_ST_)
