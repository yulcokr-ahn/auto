// ATSButton.cpp : implementation file
//

#include "stdafx.h"
#include "ATSButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CAceCmbBox::CAceCmbBox()
{
	m_clrOutBorder = RGB(82,113,123);
	m_clrBkColor   = RGB(255,255,255);	//�Էºκ��� ������ White
	m_clrBtnFace   = RGB(206,223,239);	//Temp
	m_clrBtnLight  = RGB(255,255,255);
	m_clrBtnShadow = ::GetSysColor(COLOR_BTNSHADOW);

	m_rcCmbBox.SetRectEmpty();
	m_rcCmbBtn.SetRectEmpty();
}
CAceCmbBox::~CAceCmbBox()
{
}

BEGIN_MESSAGE_MAP(CAceCmbBox, CComboBox)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()

void CAceCmbBox::PreSubclassWindow()
{
	CComboBox::PreSubclassWindow();

	ModifyStyleEx (WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE, 0, SWP_FRAMECHANGED);
	m_Font.CreateFont(12, 0, 0, 0, 0, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS, PROOF_QUALITY,TMPF_FIXED_PITCH, "����ü");
	SetFont(&m_Font);

	GetClientRect(m_rcCmbBox);
	m_rcCmbBtn = m_rcCmbBox;
	m_rcCmbBtn.left = m_rcCmbBtn.right - ::GetSystemMetrics(SM_CXHTHUMB);
}

void CAceCmbBox::SetBorderColor(COLORREF clrColor, BOOL bRedraw/*=FALSE*/)
{
	m_clrOutBorder = clrColor;
	if (bRedraw) Invalidate();
}
void CAceCmbBox::SetBtnFATSColor(COLORREF clrColor, BOOL bRedraw/*=FALSE*/)
{
	m_clrBtnFace = clrColor;
	if (bRedraw) Invalidate();
}

void CAceCmbBox::OnDestroy()
{
	CComboBox::OnDestroy();

	if (m_Font.GetSafeHandle())
		m_Font.DeleteObject();
}

void CAceCmbBox::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_rcCmbBtn.PtInRect(point))
	{
		DrawButton(DOWN);
	}
	else
	{
		CComboBox::OnLButtonDown(nFlags, point);
	}
}

void CAceCmbBox::OnMouseMove(UINT nFlags, CPoint point)
{
//	CComboBox::OnMouseMove(nFlags, point);
}

void CAceCmbBox::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (GetCapture() == this)
	{
		DrawButton(NORMAL);
	}
}

void CAceCmbBox::OnPaint()
{
	if (GetDroppedState())
		DrawButton(DOWN);
	else
		DrawButton(NORMAL);
}

void CAceCmbBox::DrawButton(BtnState btnState)
{
	Default();

	CDC *pDC = GetDC();

	if (IsWindowEnabled())
		pDC->FillSolidRect(m_rcCmbBox, m_clrBkColor);
	else
		pDC->FillSolidRect(m_rcCmbBox, ::GetSysColor(COLOR_3DLIGHT));


	CString strText;
	GetWindowText(strText);

	CRect	rcText = m_rcCmbBox;
	rcText.right = m_rcCmbBtn.left - 1;
	rcText.left  += 4;

	CFont *tmpFont = pDC->SelectObject(&m_Font);
	pDC->DrawText(strText, rcText, DT_SINGLELINE|DT_VCENTER|DT_LEFT);
	pDC->SelectObject(tmpFont);

	//Draw Border
	pDC->Draw3dRect(m_rcCmbBox, m_clrOutBorder, m_clrOutBorder);

	//Button Draw
	CRect rcBtn = m_rcCmbBtn;
	pDC->FillSolidRect(rcBtn, m_clrBtnFace);

	int		x = rcBtn.CenterPoint().x, y = rcBtn.CenterPoint().y;
	CPoint	ptObj[3];
	ptObj[0] = CPoint(x - 3, y - 2);
	ptObj[1] = CPoint(x + 3, y - 2);
	ptObj[2] = CPoint(x    , y + 1);

	CPen penBlack(PS_SOLID, 1, RGB(0,0,0));
	CBrush brsBlack(RGB(0,0,0));
	pDC->SelectObject(&penBlack);
	pDC->SelectObject(&brsBlack);
	pDC->Polygon(ptObj, 3);

	pDC->Draw3dRect(rcBtn, m_clrOutBorder, m_clrOutBorder);
	rcBtn.DeflateRect(1,1);

	COLORREF clrTopLeft = (btnState==NORMAL) ? m_clrBtnLight : m_clrBtnShadow,
		clrBottomRight = (btnState==NORMAL) ? m_clrBtnShadow : m_clrBtnLight;

	pDC->Draw3dRect(rcBtn, clrTopLeft, clrBottomRight);
	rcBtn.DeflateRect(1,1);
	pDC->Draw3dRect(rcBtn, clrTopLeft, clrBottomRight);



	ReleaseDC(pDC);
}

/*
void CAceCmbBox::DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight)
{
	CRect rcCmbBox;
	GetClientRect(rcCmbBox);

	CDC*  pDC = GetDC();
	pDC->SetBkMode(TRANSPARENT);
	pDC->FillSolidRect(rcCmbBox, m_clrBkColor);

	CString strText;
	GetWindowText(strText);

	CRect	rcText = rcCmbBox;
	rcText.right -= m_nOffset;
	rcText.left  += 4;

	CFont *tmpFont = pDC->SelectObject(&m_FontList);
	pDC->DrawText(strText, rcText, DT_SINGLELINE|DT_VCENTER|DT_LEFT);
	pDC->SelectObject(tmpFont);

	//Draw Border
	pDC->Draw3dRect(rcCmbBox, m_clrOutBorder, m_clrOutBorder);

	//Button Draw
	CRect rcBtn = rcCmbBox;
	rcBtn.left = rcBtn.right - m_nOffset;
	pDC->Draw3dRect(rcBtn, m_clrOutBorder, m_clrOutBorder);
	rcBtn.DeflateRect(1,1);
	pDC->Draw3dRect(rcBtn, clrTopLeft, clrBottomRight);
	rcBtn.DeflateRect(1,1);
	pDC->Draw3dRect(rcBtn, clrTopLeft, clrBottomRight);
}
*/


//AceEditCtrl
CAceEditCtrl::CAceEditCtrl()
{
	m_clrBorderColor = RGB(82,113,123);
}
CAceEditCtrl::~CAceEditCtrl()
{
}

BEGIN_MESSAGE_MAP(CAceEditCtrl, CEdit)
	ON_WM_NCCALCSIZE()
	ON_WM_NCPAINT()
END_MESSAGE_MAP()

void CAceEditCtrl::PreSubclassWindow()
{
	CEdit::PreSubclassWindow();
}

void CAceEditCtrl::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS *lpncsp)
{
	InflateRect(&lpncsp->rgrc[0], 1, 1);
	CEdit::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void CAceEditCtrl::OnNcPaint()
{
	CWindowDC	dc(this);
	CRect		rcEdit;

	GetWindowRect(rcEdit);
	ScreenToClient(rcEdit);
	rcEdit.InflateRect(-1, -1, 1, 1);
	dc.Draw3dRect(rcEdit, m_clrBorderColor, m_clrBorderColor);
	ReleaseDC(&dc);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAceDlgButton::CAceDlgButton()
{
	m_bDisabled	= FALSE;
	m_bFocus	= FALSE;
	m_bSelected	= FALSE;
	m_bDefault	= FALSE;

	m_btType	= BT_NORMAL;
}

CAceDlgButton::~CAceDlgButton()
{

}

BEGIN_MESSAGE_MAP(CAceDlgButton, CButton)
    //{{AFX_MSG_MAP(CAceDlgButton)
	ON_WM_ENABLE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CAceDlgButton::PreSubclassWindow() 
{
	ModifyStyle(SS_TYPEMASK, BS_OWNERDRAW, SWP_FRAMECHANGED);

	CButton::PreSubclassWindow();
}

void CAceDlgButton::OnEnable(BOOL bEnable) 
{
	CButton::OnEnable(bEnable);
	
	if (bEnable == FALSE)	
	{
		CWnd*	pWnd = GetParent()->GetNextDlgTabItem(this);
		if (pWnd)
			pWnd->SetFocus();
		else
			GetParent()->SetFocus();
	}
}

void CAceDlgButton::DrawItem(LPDRAWITEMSTRUCT lpDIS)
{
	CDC* pDC = CDC::FromHandle(lpDIS->hDC);

	m_bDisabled = (lpDIS->itemState & ODS_DISABLED);
	m_bFocus  = (lpDIS->itemState & ODS_FOCUS);
	m_bSelected = (lpDIS->itemState & ODS_SELECTED);
	m_bDefault = (lpDIS->itemState & ODS_DEFAULT);

	/*
	COLORREF clrWhite = RGB(255, 255, 255);
	COLORREF clrBlack = RGB(0, 0, 0);
	COLORREF clrBkColor = RGB(239, 239, 239);	//test-RGB(49,138,222);
	COLORREF clrWhiteGray = RGB(231, 231, 231);
	COLORREF clrMidGray = RGB(198, 198, 198);
	COLORREF clrGray = RGB(173, 173, 173);
	COLORREF clrDarkGray = RGB(132, 130, 132);
	*/
	COLORREF clrWhite;// = RGB(255, 255, 255);
	COLORREF clrBlack = RGB(0, 0, 0);
	COLORREF clrBkColor;	//test-RGB(49,138,222);
	COLORREF clrWhiteGray;
	COLORREF clrMidGray;
	COLORREF clrGray;
	COLORREF clrDarkGray;

	clrWhite = RGB(255,255,255);

	if (m_btType == BT_NORMAL)	//�ӽ÷� �ŵ��ż� ��ư�� Ÿ������ �����Ͽ� ����Ѵ�.
	{
	//	clrWhite	 = RGB(255, 255, 255);
		clrBkColor	 = RGB(239, 239, 239);
		clrWhiteGray = RGB(231, 231, 231);
		clrMidGray	 = RGB(198, 198, 198);
		clrGray		 = RGB(173, 173, 173);
		clrDarkGray	 = RGB(132, 130, 132);
	}
	else if (m_btType == BT_MEDO)
	{
	//	clrWhite	 = RGB( 90, 158, 255);
		clrBkColor	 = RGB( 49, 138, 222);
		clrWhiteGray = RGB( 42, 131, 204);
		clrMidGray	 = RGB( 10, 101, 178);
		clrGray		 = RGB( 10,  83, 152);
		clrDarkGray	 = RGB(  0,  73, 132);
	}
	else if (m_btType == BT_MESU)
	{
	//	clrWhite	 = RGB(222, 174, 198);
		clrBkColor	 = RGB(180, 101, 140);
		clrWhiteGray = RGB(140,  91, 122);
		clrMidGray	 = RGB(120,  71, 102);
		clrGray		 = RGB(100,  51,  88);
		clrDarkGray	 = RGB( 70,  31,  68);
	}

	CRect rcItem = lpDIS->rcItem;
	CRect rcTemp(rcItem);
	CRect rcText(rcItem);

	pDC->FillSolidRect(&rcItem, clrBkColor);
	pDC->Draw3dRect(&rcItem, clrBlack, clrBlack);

	InflateRect(&rcTemp, -1, -1);

	if (!m_bSelected)
	{
		pDC->Draw3dRect(&rcTemp, clrWhite, clrGray);
		InflateRect(&rcTemp, -1, -1);
		pDC->Draw3dRect(&rcTemp, clrWhite, clrMidGray);
		InflateRect(&rcTemp, -1, -1);
		pDC->Draw3dRect(&rcTemp, clrBkColor, clrWhiteGray);
	}
	else
	{
		pDC->Draw3dRect(&rcTemp, clrGray, clrWhite);
		InflateRect(&rcTemp, -1, -1);
		pDC->Draw3dRect(&rcTemp, clrMidGray, clrWhite);
		InflateRect(&rcTemp, -1, -1);
		pDC->Draw3dRect(&rcTemp, clrWhiteGray, clrBkColor);
	}

	if (m_bDefault)
	{
	}

	UINT nFormat = DT_CENTER | DT_VCENTER | DT_SINGLELINE;
	CString strItem;
	GetWindowText(strItem);

	pDC->SetBkMode(TRANSPARENT);

	if (m_bDisabled)
	{
		OffsetRect(&rcText, 1, 1);
		pDC->SetTextColor(clrWhite);
		pDC->DrawText(strItem, -1, rcText, nFormat);

		OffsetRect(&rcText, -1, -1);
		pDC->SetTextColor(clrDarkGray);//clrBlack);
		pDC->DrawText(strItem, -1, rcText, nFormat);
	}
	else
	{
		if (m_bSelected) OffsetRect(&rcText, 1, 1);

		if (m_btType == BT_MEDO || m_btType == BT_MESU)
			pDC->SetTextColor(clrWhite);
		else
			pDC->SetTextColor(clrBlack);
		pDC->DrawText(strItem, -1, rcText, nFormat);
	}

	if (m_bFocus)
	{
		CRect rcFocus = rcItem;
		rcFocus.DeflateRect(3, 3);
		pDC->DrawFocusRect(&rcFocus);
	}
}

void CAceDlgButton::SetButtonType(ButtonType btType)
{
	m_btType = btType;

	Invalidate();
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapBtn

CBitmapBtn::CBitmapBtn()
{
	m_nColor = GetSysColor(COLOR_BTNFACE);
	m_sColor = m_nColor;
	m_hColor = m_nColor;
	m_dColor = m_nColor;
	m_nBorder = 1;
	m_lfEscapement = 0;
	m_pNormal = NULL;
	m_pSelected = NULL;
	m_pHover = NULL;
	m_pDisabled = NULL;
	m_hRgn = 0;
	m_bHover = FALSE;
	m_bCapture = FALSE;
	m_bMouseDown = FALSE;
	m_bNeedBitmaps = TRUE;
}

CBitmapBtn::~CBitmapBtn()
{
	delete m_pNormal;
	delete m_pSelected;
	delete m_pHover;
	delete m_pDisabled;
// 2004.04.26 Edited by LHS ----->
//	DeleteObject(m_hRgn);
	m_hRgn = 0;
// ------------------------------<	
}

BEGIN_MESSAGE_MAP(CBitmapBtn, CButton)
	//{{AFX_MSG_MAP(CBitmapBtn)
	ON_WM_ERASEBKGND()
	ON_WM_MOUSEMOVE()
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBitmapBtn message handlers

BOOL CBitmapBtn::Create(LPCTSTR lpszCaption, DWORD dwStyle, const CPoint point, const HRGN hRgn, CWnd* pParentWnd, UINT nID)
{
	// store region in member variable
// 2004.04.26 Edited by LHS ----->
//	DeleteObject(m_hRgn);
	if(m_hRgn)
		DeleteObject(m_hRgn);
// ------------------------------<
	m_hRgn = CreateRectRgn(0, 0, 31, 31);
	CRect box(0, 0, 0, 0);
	if (m_hRgn != 0) 
		CombineRgn(m_hRgn, hRgn, 0, RGN_COPY);

	// make sure that region bounding rect is located in (0, 0)
	GetRgnBox(m_hRgn, &box);
	box.left = 0;
	box.top = 0;
/*	OffsetRgn(m_hRgn, -box.left, -box.top);
	GetRgnBox(m_hRgn, &box);*/

	// update position of region center for caption output
	m_CenterPoint = CPoint(box.left + box.Width() /2 , box.top + box.Height() /2);
	box.OffsetRect(point);

	return CButton::Create(lpszCaption, dwStyle, box, pParentWnd, nID);
}

BOOL CBitmapBtn::Create(LPCTSTR lpszCaption, DWORD dwStyle, const CPoint point, const HRGN hRgn, CWnd* pParentWnd, UINT nID, COLORREF color)
{
	m_sColor = color;
	m_hColor = color;

	// call another constructor
	return Create(lpszCaption, dwStyle, point, hRgn, pParentWnd, nID);
}

BOOL CBitmapBtn::Create(LPCTSTR lpszCaption, DWORD dwStyle, const CPoint point, const HRGN hRgn, CWnd* pParentWnd, UINT nID, UINT nBorder, LONG lfEscapement, COLORREF nColor, COLORREF sColor, COLORREF hColor, COLORREF dColor)
{
	m_lfEscapement = lfEscapement;
	return Create(lpszCaption, dwStyle, point, hRgn, pParentWnd, nID, nBorder, nColor, sColor, hColor, dColor);
}

BOOL CBitmapBtn::Create(LPCTSTR lpszCaption, DWORD dwStyle, const CPoint point, const HRGN hRgn, CWnd* pParentWnd, UINT nID, UINT nBorder, COLORREF nColor, COLORREF sColor, COLORREF hColor, COLORREF dColor)
{
	// change default colors
	m_nBorder = nBorder;
	m_nColor = nColor;
	m_sColor = sColor;
	m_hColor = hColor;
	m_dColor = dColor;

	// call another constructor
	return Create(lpszCaption, dwStyle, point, hRgn, pParentWnd, nID);
}

void CBitmapBtn::SetBitmap(HBITMAP hBitmap, HBITMAP hBitmapSel, HBITMAP hBitmapFocus, HBITMAP hBitmapDisabled)
{
	delete m_pNormal;
	delete m_pSelected;
	delete m_pHover;
	delete m_pDisabled;	
	
	m_pNormal = new CBitmap;
	m_pSelected = new CBitmap;
	m_pHover = new CBitmap;
	m_pDisabled = new CBitmap;

	m_pNormal->Attach(hBitmap);
	m_pSelected->Attach(hBitmapSel);
	m_pHover->Attach(hBitmapFocus);
	m_pDisabled->Attach(hBitmapDisabled);

	m_bNeedBitmaps = FALSE;
}
void CBitmapBtn::PreSubclassWindow() 
{
	// change window style to allow owner draw
	ModifyStyle(0, BS_OWNERDRAW | BS_PUSHBUTTON);	
	CButton::PreSubclassWindow();
}

int CBitmapBtn::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CButton::OnCreate(lpCreateStruct) == -1)
		return -1;

	// assign new region to a window
	m_bNeedBitmaps = TRUE;
	SetWindowRgn(m_hRgn, TRUE);

	return 0;
}

void CBitmapBtn::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// record that mouse is down
	m_bMouseDown = TRUE;
	if (!m_bCapture) {
		SetCapture();
		m_bCapture = TRUE;
	}
	CButton::OnLButtonDown(nFlags, point);
}

void CBitmapBtn::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// record that mouse is released
	CButton::OnLButtonUp(nFlags, point);

	m_bMouseDown = FALSE;	
	if (m_bCapture) {
		ReleaseCapture();
		m_bCapture = FALSE;
	}
	CheckHover(point);
}

void CBitmapBtn::OnMouseMove(UINT nFlags, CPoint point) 
{
	// Test if mouse is above the button.
	if (!m_bMouseDown)
		CheckHover(point);

	CButton::OnMouseMove(nFlags, point);
}

void CBitmapBtn::CheckHover(CPoint point)
{
		if (HitTest(point)) {
			if (!m_bCapture) {
				SetCapture();
				m_bCapture = TRUE;
			}
			if (!m_bHover) {
				m_bHover = TRUE;
				RedrawWindow();
			}
		}
		else {
			if (m_bCapture) {
				ReleaseCapture();
				m_bCapture = FALSE;
			}
			m_bHover = FALSE;
			RedrawWindow();
		}
}

LRESULT CBitmapBtn::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// I have noticed that default windows buttons can be clicked very quickly.
	// Double or single click both result in a button being pushed down.
	// For owner drawn buttons this is not the case. Double click does
	// not push button down. Here is a solution for the problem:
	// double click message is substituted for single click.

	if (message == WM_LBUTTONDBLCLK)
		message = WM_LBUTTONDOWN;
	
	return CButton::DefWindowProc(message, wParam, lParam);
}

BOOL CBitmapBtn::HitTest(CPoint point)
{
	BOOL result = FALSE;

	// Obtain handle to window region.
	HRGN hRgn = CreateRectRgn(0, 0, 0, 0);
	GetWindowRgn(hRgn);
	CRect rgnRect;
	GetRgnBox(hRgn, &rgnRect);

	// First check if point is in region bounding rect.
	// Then check if point is in the region in adition to being in the bouding rect.
	result = PtInRect(&rgnRect, point) && PtInRegion(hRgn, point.x, point.y);

	// Clean up and exit.
	DeleteObject(hRgn);
	return result;
}

BOOL CBitmapBtn::OnEraseBkgnd(CDC* pDC) 
{
	// do not erase background
	return 1;
}

//////////////////////// DRAWING ROUTINES ////////////////////////////

void CBitmapBtn::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// prepare DC
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct -> hDC);
	CRect rect;
	GetClientRect(rect);

	// prepare bitmaps they need to be prepared
	if (m_bNeedBitmaps)
		PrepareStateBitmaps(pDC, &rect);

	// draw button to the screen
	DrawButton(pDC, &rect, lpDrawItemStruct -> itemState);
}

void CBitmapBtn::PrepareStateBitmaps(CDC * pDC, CRect * pRect)
{
	// prepare memory DC
	CDC * pMemDC;
	pMemDC = new CDC;
	pMemDC -> CreateCompatibleDC(pDC);

	// prepare bitmaps for all button states and for the mask
	PrepareNormalState(pDC, pMemDC, pRect);
	PrepareSelectedState(pDC, pMemDC, pRect);
	PrepareHoverState(pDC, pMemDC, pRect);
	PrepareDisabledState(pDC, pMemDC, pRect);

	// clean up
	delete pMemDC; 
	m_bNeedBitmaps = FALSE;
}


void CBitmapBtn::PrepareNormalState(CDC * pDC, CDC * pMemDC, CRect * pRect)
{
	// prepare MYBS_NORMAL state bitmap
	delete m_pNormal;
	m_pNormal = new CBitmap;
	PaintRgn(pDC, pMemDC, m_pNormal, m_nColor, pRect, TRUE, FALSE);
}

void CBitmapBtn::PrepareSelectedState(CDC * pDC, CDC * pMemDC, CRect * pRect)
{
	// prepare MYBS_SELECTED state bitmap
	delete m_pSelected;
	m_pSelected = new CBitmap;
	PaintRgn(pDC, pMemDC, m_pSelected, m_sColor, pRect, TRUE, TRUE);
}

void CBitmapBtn::PrepareHoverState(CDC * pDC, CDC * pMemDC, CRect * pRect)
{
	// prepare MYBS_HOVER state bitmap
	delete m_pHover;
	m_pHover = new CBitmap;
	PaintRgn(pDC, pMemDC, m_pHover, m_hColor, pRect, TRUE, FALSE);
}

void CBitmapBtn::PrepareDisabledState(CDC * pDC, CDC * pMemDC, CRect * pRect)
{
	// prepare MYBS_DISABLED state bitmap
	delete m_pDisabled;
	m_pDisabled = new CBitmap;
	PaintRgn(pDC, pMemDC, m_pDisabled, m_dColor, pRect, FALSE, FALSE);
}

void CBitmapBtn::PaintRgn(CDC * pDC, CDC * pMemDC, CBitmap * pBitmap, COLORREF color, CRect * pRect, BOOL bEnabled, BOOL bSunken)
{
	// create bitmap
	pBitmap -> CreateCompatibleBitmap(pDC, pRect -> Width(), pRect -> Height());
	CBitmap * pOldBitmap = pMemDC -> SelectObject(pBitmap); 

	// prepare region
	HRGN hRgn = CreateRectRgn(0, 0, 0, 0);
	GetWindowRgn(hRgn);

	// fill rect a with transparent color and fill rgn
	HBRUSH hBrush = CreateSolidBrush(color);
	pMemDC -> FillSolidRect(pRect, RGB(0, 0, 0));
	FillRgn(pMemDC -> GetSafeHdc(), hRgn, hBrush);
	DeleteObject(hBrush);

	// draw 3D border and text
	DrawButtonCaption(pMemDC -> GetSafeHdc(), pRect, bEnabled, bSunken);
	FrameRgn3D(pMemDC -> GetSafeHdc(), hRgn, bSunken);

	// clean up
	DeleteObject(hRgn);
	pMemDC -> SelectObject(pOldBitmap); 
}

void CBitmapBtn::DrawButtonCaption(HDC hDC, CRect * pRect, BOOL bEnabled, BOOL bSunken) 
{
	// select parent font
	int nOldMode = SetBkMode(hDC, TRANSPARENT);
	CString text;
	GetWindowText(text);
	LOGFONT lf;
	GetParent() -> GetFont() -> GetLogFont(&lf);
	HFONT hFont = CreateFontIndirect(&lf);
	HFONT hOldFont = (HFONT) SelectObject(hDC, hFont);

	// determine point where to output text
	TEXTMETRIC tm;
	GetTextMetrics(hDC, &tm);
	CPoint p = CPoint(m_CenterPoint.x, m_CenterPoint.y + tm.tmHeight/ 2); 
	if (bSunken) 
		p.Offset(m_nBorder, m_nBorder); 
		
	// draw button caption depending upon button state
	if (bEnabled) {
		SetTextColor(hDC, GetSysColor(COLOR_BTNTEXT));
		SetTextAlign(hDC, TA_CENTER | TA_BOTTOM);
		TextOut(hDC, p.x, p.y, text, text.GetLength());
	}
	else {
		SetTextColor(hDC, GetSysColor(COLOR_3DHILIGHT));
		TextOut(hDC, p.x + 1, p.y + 1, text, text.GetLength());
		SetTextColor(hDC, GetSysColor(COLOR_3DSHADOW));
		TextOut(hDC, p.x, p.y, text, text.GetLength());
	}

	SelectObject(hDC, hOldFont);
	DeleteObject(hFont);
	SetBkMode(hDC, nOldMode);
}

void CBitmapBtn::FrameRgn3D(HDC hDC, const HRGN hRgn, BOOL bSunken)
{
	// we need two differenr regions to keep base region and border region
	HBRUSH hBrush;
	HRGN hBaseRgn = CreateRectRgn(0, 0, 0, 0);

	COLORREF ltOuter, ltInner, rbOuter, rbInner;	// colors of inner and outer shadow for top-left and right-bottom corners

	// decide on color scheme
	if (!bSunken) {
		ltOuter = GetSysColor(COLOR_3DLIGHT);
		ltInner = GetSysColor(COLOR_3DHILIGHT);
		rbOuter = GetSysColor(COLOR_3DDKSHADOW);
		rbInner = GetSysColor(COLOR_3DSHADOW);
	}
	else {
		rbInner = GetSysColor(COLOR_3DLIGHT);
		rbOuter = GetSysColor(COLOR_3DHILIGHT);
		ltInner = GetSysColor(COLOR_3DDKSHADOW);
		ltOuter = GetSysColor(COLOR_3DSHADOW);
	}

	// offset highlight and shadow regions
	// substract them from the base region 
	switch (m_nBorder)
	{
	case 2:
		CombineRgn(hBaseRgn, hRgn, 0, RGN_COPY);
		OffsetRgn(hBaseRgn, 2, 2);
		CombineRgn(hBaseRgn, hRgn, hBaseRgn, RGN_DIFF);
		hBrush = CreateSolidBrush(ltInner);
		FillRgn(hDC, hBaseRgn, hBrush);
		DeleteObject(hBrush);

		CombineRgn(hBaseRgn, hRgn, 0, RGN_COPY);
		OffsetRgn(hBaseRgn, -2, -2);
		CombineRgn(hBaseRgn, hRgn, hBaseRgn, RGN_DIFF);
		hBrush = CreateSolidBrush(rbInner);
		FillRgn(hDC, hBaseRgn, hBrush);
		DeleteObject(hBrush);

		CombineRgn(hBaseRgn, hRgn, 0, RGN_COPY);
		OffsetRgn(hBaseRgn, 1, 1);
		CombineRgn(hBaseRgn, hRgn, hBaseRgn, RGN_DIFF);
		hBrush = CreateSolidBrush(ltOuter);
		FillRgn(hDC, hBaseRgn, hBrush);
		DeleteObject(hBrush);

		CombineRgn(hBaseRgn, hRgn, 0, RGN_COPY);
		OffsetRgn(hBaseRgn, -1, -1);
		CombineRgn(hBaseRgn, hRgn, hBaseRgn, RGN_DIFF);
		hBrush = CreateSolidBrush(rbOuter);
		FillRgn(hDC, hBaseRgn, hBrush);
		DeleteObject(hBrush);
		break;
	default:
		CombineRgn(hBaseRgn, hRgn, 0, RGN_COPY);
		OffsetRgn(hBaseRgn, 1, 1);
		CombineRgn(hBaseRgn, hRgn, hBaseRgn, RGN_DIFF);
		hBrush = CreateSolidBrush(ltInner);
		FillRgn(hDC, hBaseRgn, hBrush);
		DeleteObject(hBrush);

		CombineRgn(hBaseRgn, hRgn, 0, RGN_COPY);
		OffsetRgn(hBaseRgn, -1, -1);
		CombineRgn(hBaseRgn, hRgn, hBaseRgn, RGN_DIFF);
		hBrush = CreateSolidBrush(rbOuter);
		FillRgn(hDC, hBaseRgn, hBrush);
		DeleteObject(hBrush);
		break;
	}
	
	// clean up regions
	DeleteObject(hBaseRgn);
}

void CBitmapBtn::DrawButton(CDC * pDC, CRect * pRect, UINT state)
{
	// create memory DC
	CDC * pMemDC = new CDC;
	pMemDC -> CreateCompatibleDC(pDC);
	pMemDC->SetBkMode(TRANSPARENT);
	CBitmap * pOldBitmap;

	// get region
	HRGN hRgn = CreateRectRgn(0, 0, 0, 0);
	GetWindowRgn(hRgn);

	// select bitmap to paint depending upon button state
	if (state & ODS_DISABLED)
		pOldBitmap = pMemDC -> SelectObject(m_pDisabled);
	else {
		if (state & ODS_SELECTED)
			pOldBitmap = pMemDC -> SelectObject(m_pSelected);
		else {
			if (m_bHover)
				pOldBitmap = pMemDC -> SelectObject(m_pHover);
			else 
				pOldBitmap = pMemDC -> SelectObject(m_pNormal);
		}	
	}

	// paint using region for clipping
	::SelectClipRgn(pDC -> GetSafeHdc(), hRgn);
	pDC -> BitBlt(0, 0, pRect -> Width(), pRect -> Height(), pMemDC, 0, 0, SRCCOPY);
	::SelectClipRgn(pDC -> GetSafeHdc(), NULL);

	// clean up
	DeleteObject(hRgn);
	pMemDC -> SelectObject(pOldBitmap);
	delete pMemDC;
}

void CBitmapBtn::RgnPixelWork(CDC * pDC, CRgn * pRgn)
{
	// get size of data composing region
	int size = pRgn -> GetRegionData(NULL, 0);
	HANDLE hData = GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT, size);
	RGNDATA * pData = (RGNDATA *)GlobalLock(hData);

	// retrieve region data
	int res = pRgn -> GetRegionData(pData, size);
	RECT * pRect = (RECT *) pData -> Buffer;

	// now we know how region is represented and we are able to manipulate it as we like
	for (DWORD i = 0; i < pData -> rdh.nCount; i++) {
		RECT rect = *(pRect + i);
		for (int x = rect.left; x < rect.right; x++)
			for (int y = rect.top; y < rect.bottom; y++) {
				// use SetPixel(x, y, color) to do pixel work
			}
	}

	// free region data
	GlobalUnlock(hData);
	GlobalFree(hData);
}

/*
//--------------------------------------
CFlatEditCtl::CFlatEditCtl()
{
}

CFlatEditCtl::~CFlatEditCtl()
{
}
BEGIN_MESSAGE_MAP(CFlatEditCtl, CEdit)
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
END_MESSAGE_MAP()

void CFlatEditCtl::OnChange()
{
	GetParent()->SendMessage(UM_EDITCHANGE,0,0);
}

////////////////////////////////////////////////////

CFlatEdit::CFlatEdit()
{
	m_lBorder = RGB( 82,113,123);
	m_lBack   = RGB(255,255,255);
	m_bEnable = TRUE;

	m_Rect.SetRectEmpty();
}

CFlatEdit::~CFlatEdit()
{
	if (m_Font.GetSafeHandle())
		m_Font.DeleteObject();
}

BEGIN_MESSAGE_MAP(CFlatEdit, CWnd)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_NCCALCSIZE()
	ON_WM_NCPAINT()
END_MESSAGE_MAP()

void CFlatEdit::PreSubclassWindow()
{
	CWnd::PreSubclassWindow();

	CRect	rcWnd;
	DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL;

	GetClientRect(rcWnd);

	//rcWnd.DeflateRect(1,1);
	int xpos = 2;
	int ypos = (rcWnd.Height()-12) / 2;

	CRect	rcEdit(xpos,ypos,rcWnd.Width()-1, ypos+12);
	m_Edit.Create(dwStyle, rcEdit, this, 1000);

	m_Font.CreatePointFont(90, "����ü");
	m_Edit.SetFont(&m_Font);

	//ModifyStyleEx(WS_EX_STATICEDGE, 0);
}

void CFlatEdit::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS *lpncsp)
{
	InflateRect(&lpncsp->rgrc[0], 1, 1);

	CWnd::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void CFlatEdit::OnNcPaint()
{
	CWindowDC	dc(this);

	CRect		rcEdit;

	GetWindowRect(rcEdit);
	ScreenToClient(rcEdit);
	rcEdit.InflateRect(-1, -1, 1, 1);
	dc.Draw3dRect(rcEdit, m_lBorder, m_lBorder);
	ReleaseDC(&dc);
}

void CFlatEdit::OnPaint()
{
	CPaintDC	dc(this);

	CPen	pen, *tmpPen = NULL;
	CBrush	brush, *tmpBrush = NULL;

	pen.CreatePen(PS_SOLID, 1, m_lBorder);
	tmpPen = dc.SelectObject(&pen);

	brush.CreateSolidBrush((m_bEnable)?m_lBack: GetSysColor(COLOR_BTNFACE));
	tmpBrush = dc.SelectObject(&brush);

	CRect	rcWnd;

	GetWindowRect (rcWnd);
	ScreenToClient(rcWnd);

	dc.Rectangle(rcWnd);

	dc.SelectObject(tmpPen);
	dc.SelectObject(tmpBrush);

	pen.DeleteObject();
	brush.DeleteObject();
}

void CFlatEdit::OnSetFocus(CWnd *pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	m_Edit.SetFocus();
}

LRESULT CFlatEdit::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case UM_EDITCHANGE:
		GetParent()->SendMessage(message, wParam, (LPARAM)GetDlgCtrlID());
		break;
	}

	return CWnd::DefWindowProc(message, wParam, lParam);
}*/

/////////////////////////////////////////////////////////////////////////////
// CAceBitmapButton

CAceBitmapButton::CAceBitmapButton()
{
	m_bTitle = TRUE;
	m_strTitle = "��ư";
}

CAceBitmapButton::~CAceBitmapButton()
{
}

BEGIN_MESSAGE_MAP(CAceBitmapButton, CBitmapButton)
	//{{AFX_MSG_MAP(CAceBitmapButton)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CAceBitmapButton message handlers
void CAceBitmapButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	LPDRAWITEMSTRUCT lpDIS = lpDrawItemStruct;

	ASSERT(lpDIS != NULL);
	// must have at least the first bitmap loaded before calling DrawItem
	if(m_hBitmap == NULL)     // required
		return;

	ASSERT(m_hBitmap != NULL);     // required

	// use the main bitmap for up, the selected bitmap for down
	HBITMAP hBitmap = m_hBitmap;
	UINT state = lpDIS->itemState;
	if ((state & ODS_SELECTED) && m_hBitmapSel != NULL)
		hBitmap = m_hBitmapSel;
	else if ((state & ODS_FOCUS) && m_hBitmapFocus != NULL)
		hBitmap = m_hBitmap;   // third image for focused
	else if ((state & ODS_DISABLED) && m_hBitmapDisabled != NULL)
		hBitmap = m_hBitmapDisabled;   // last image for disabled

	// draw the whole button

//////////////////////////////////////////////////////////////////
/*
	CDC* pDC = CDC::FromHandle(lpDIS->hDC);
	CDC memDC;
	memDC.CreateCompatibleDC(pDC);
	HBITMAP oldbitmap = (HBITMAP)::SelectObject(memDC.GetSafeHdc(), hBitmap);
//	CBitmap* pOld = memDC.SelectObject(pBitmap);
	if (oldbitmap == NULL)
		return;     // destructors will clean up

	CRect rect;
	rect.CopyRect(&lpDIS->rcItem);
	pDC->BitBlt(rect.left, rect.top, rect.Width(), rect.Height(),
		&memDC, 0, 0, SRCCOPY);
//	memDC.SelectObject(pOld);
	::SelectObject(memDC.GetSafeHdc(), oldbitmap);
*/
//////////////////////////////////////////////////////////////////

	CDC* pDC = CDC::FromHandle(lpDIS->hDC);
//	pDC->SetBkMode(TRANSPARENT);

	COLORREF crOldBack = pDC->SetBkColor(RGB(255,255,255));
	CRect rect;
	rect.CopyRect(&lpDIS->rcItem);
	DrawTransParentBitmap(pDC, rect.left, rect.top, hBitmap, RGB(255,0,255));
	pDC->SetBkColor(crOldBack);

	//////////////////////////////////////////////////////////////////

	if(m_bTitle)
	{
		CFont fonttext;
		int nFontSize = 9;
		LONG lfHeight = -MulDiv(nFontSize, GetDeviceCaps(pDC->GetSafeHdc(), LOGPIXELSY), 72);
		
		
		fonttext.CreateFont(
		   lfHeight,			                // nHeight
		   0,                         // nWidth
		   0,                         // nEscapement
		   0,                         // nOrientation
		   FW_MEDIUM,		           // nWeight
		   FALSE,                     // bItalic
		   FALSE,                     // bUnderline
		   0,                         // cStrikeOut
		   DEFAULT_CHARSET,              // nCharSet
		   OUT_DEFAULT_PRECIS,        // nOutPrecision
		   CLIP_DEFAULT_PRECIS,       // nClipPrecision
		   DEFAULT_QUALITY,           // nQuality
		   DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
		   "����ü");               // lpszFATSname
		

		CFont* poldfont = (CFont*) pDC->SelectObject(&fonttext);
		pDC->SetBkMode(TRANSPARENT);
		if ((state & ODS_SELECTED) && m_hBitmapSel != NULL)
			pDC->SetTextColor(RGB(255,255,255));
		else if(state & ODS_DISABLED)
			pDC->SetTextColor(RGB(192,192,192));
		else
			pDC->SetTextColor(RGB(255,255,255));

		CRect rc;
		GetClientRect(rc);
		pDC->DrawText(m_strTitle, rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX);
		pDC->SelectObject(poldfont);
		fonttext.DeleteObject();
	}
}

void CAceBitmapButton::DrawTransParentBitmap(CDC* pDC, int xPos, int yPos, HBITMAP hBitmap, long crTrans)
{
	// Create two memory dcs for the image and the mask
	CDC dcImage, dcTrans;
	dcImage.CreateCompatibleDC(pDC);
	dcTrans.CreateCompatibleDC(pDC);
	// Select the image into the appropriate dc
	CBitmap* pOldBmp = (CBitmap*)dcImage.SelectObject(CBitmap::FromHandle(hBitmap));

	// Create the mask bitmap
	CBitmap bitmapTrans;
	// get the image dimensions
	BITMAP bm = {NULL};
	GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
	int nWidth	= bm.bmWidth;
	int nHeight = bm.bmHeight;
	bitmapTrans.CreateBitmap(nWidth, nHeight, 1, 1, NULL);

	// Select the mask bitmap into the appropriate dc
	CBitmap* pOldTransBmp = (CBitmap*)dcTrans.SelectObject(&bitmapTrans);

	// Build mask based on transparent colour
	dcImage.SetBkColor(crTrans);
	dcTrans.BitBlt(0, 0, nWidth, nHeight, &dcImage, 0, 0, SRCCOPY);

	// Do the work - True Mask method - cool if not actual display
	pDC->BitBlt(xPos, yPos, nWidth, nHeight, &dcImage, 0, 0, SRCINVERT);
	pDC->BitBlt(xPos, yPos, nWidth, nHeight, &dcTrans, 0, 0, SRCAND);
	pDC->BitBlt(xPos, yPos, nWidth, nHeight, &dcImage, 0, 0, SRCINVERT);

	// Restore settings
	// don't delete this, since it is the bitmap
	dcImage.SelectObject(pOldBmp);
	dcTrans.SelectObject(pOldTransBmp);
	// delete bitmapTrans
	bitmapTrans.DeleteObject();
	// clean up
	dcImage.DeleteDC();
	dcTrans.DeleteDC();
}

void CAceBitmapButton::SetBitmap(HBITMAP hBitmap, HBITMAP hBitmapSel, HBITMAP hBitmapFocus, HBITMAP hBitmapDisabled)
{
	m_hBitmap = hBitmap;
	m_hBitmapSel = hBitmapSel;
	m_hBitmapFocus = hBitmapFocus;
	m_hBitmapDisabled = hBitmapDisabled;
}

void CAceBitmapButton::SetTitleString(CString title)
{
	m_strTitle = title;
}

void CAceBitmapButton::SetTitleShow(bool flag)
{
	m_bTitle = flag;
	
}