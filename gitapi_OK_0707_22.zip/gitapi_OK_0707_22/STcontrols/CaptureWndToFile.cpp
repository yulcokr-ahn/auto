// CaptureWndToFile.cpp: implementation of the CCaptureWndToFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CaptureWndToFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCaptureWndToFile::CCaptureWndToFile()
{
	Startup(0);
}

CCaptureWndToFile::~CCaptureWndToFile()
{
	if (m_hDib)
		free(m_hDib);
}

void CCaptureWndToFile::Startup(DWORD imagetype)
{
	m_hDib=NULL;
	memset(&m_head,0,sizeof(BITMAPINFOHEADER));
    m_head.biSize = sizeof(BITMAPINFOHEADER);
	memset(&m_info,0,sizeof(CXIMAGEINFO));
    m_info.dwType = imagetype;
	m_info.nQuality=75;
	m_info.nBkgndIndex=-1;
}

BOOL CCaptureWndToFile::Capture(HWND hWnd)//, int nType, CString strFileName)
{
	// get window size
	CRect r;
	::GetWindowRect(hWnd,&r);

	int xScreen,yScreen;	//check if the window is out of the screen or maximixed <Qiang>
	int xshift = 0, yshift = 0;
	xScreen = GetSystemMetrics(SM_CXSCREEN);
	yScreen = GetSystemMetrics(SM_CYSCREEN);
	if(r.right > xScreen)
		   r.right = xScreen;
	if(r.bottom > yScreen)
		   r.bottom = yScreen;
	if(r.left < 0){
		   xshift = -r.left;
		   r.left = 0;
	}
	if(r.top < 0){
		   yshift = -r.top;
		   r.top = 0;
	}
	
	CSize sz(r.Width(), r.Height());
	if(sz.cx <= 0 || sz.cy <= 0)
		return FALSE;

	// bring the window at the top most level
	::SetWindowPos(hWnd,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);

	// prepare the DCs
	HDC dstDC = ::GetDC(NULL);
    HDC srcDC = ::GetWindowDC(hWnd); //full window (::GetDC(hwnd); = clientarea)
	HDC memDC = ::CreateCompatibleDC(dstDC);
	
	// copy the screen to the bitmap
	HBITMAP bm =::CreateCompatibleBitmap(dstDC, sz.cx, sz.cy);
	HBITMAP oldbm = (HBITMAP)::SelectObject(memDC,bm);
	::BitBlt(memDC, 0, 0, sz.cx, sz.cy, srcDC, xshift, yshift, SRCCOPY);

	// restore the position
	::SetWindowPos(hWnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);

	CreateFromHBITMAP(bm);//, nType);

	// free objects
	SelectObject(memDC,oldbm);
	DeleteObject(memDC);

	::ReleaseDC(NULL, dstDC);
	::ReleaseDC(hWnd, srcDC);

	//if(!SaveFile((LPCTSTR)strFileName, nType))
	//	AfxMessageBox(m_info.szLastError);
	return TRUE;
}

void CCaptureWndToFile::CreateFromHBITMAP(HBITMAP hbmp)//, int nType)
{
	if (m_hDib)
		free(m_hDib);

	if (hbmp) { 
        BITMAP bm;
		// get informations about the bitmap
        GetObject(hbmp, sizeof(BITMAP), (LPSTR) &bm);
		// create the image
		bm.bmBitsPixel = 8; // ������ 8bit color
        Create(bm.bmWidth, bm.bmHeight, bm.bmBitsPixel, 0);

		// create a device context for the bitmap
        HDC dc = ::GetDC(NULL);
		// copy the pixels
        if (GetDIBits(dc, hbmp, 0, m_head.biHeight, m_info.pImage,
			(LPBITMAPINFO)m_hDib, DIB_RGB_COLORS) == 0){ //replace &head with hDib <Wil Stark>
            strcpy(m_info.szLastError,"GetDIBits failed");
			::ReleaseDC(NULL, dc);
			return;
        }
        ::ReleaseDC(NULL, dc);
    }
}

////////////////////////////////////////////////////////////////////////////////
// returns the palette dimension in byte
DWORD CCaptureWndToFile::GetPaletteSize()
{
	return (m_head.biClrUsed * sizeof(RGBQUAD));
}
////////////////////////////////////////////////////////////////////////////////
// returns the pointer to the image pixels
BYTE* CCaptureWndToFile::GetBits()
{ 
	if (m_hDib)	return ((BYTE*)m_hDib + *(LPDWORD)m_hDib + GetPaletteSize()); 
	return NULL;
}

void* CCaptureWndToFile::Create(DWORD dwWidth, DWORD dwHeight, WORD wBpp, DWORD imagetype)
{
	// destroy the existing image (if any)
	if (m_hDib) 
		free(m_hDib);
	m_hDib=NULL;

    // Make sure bits per pixel is valid
    if		(wBpp <= 1)	wBpp = 1;
    else if (wBpp <= 4)	wBpp = 4;
    else if (wBpp <= 8)	wBpp = 8;
    else				wBpp = 24;

	// set the correct bpp value
    switch (wBpp){
        case 1:
            m_head.biClrUsed = 2;	break;
        case 4:
            m_head.biClrUsed = 16; break;
        case 8:
            m_head.biClrUsed = 256; break;
        default:
            m_head.biClrUsed = 0;
    }

	//set the common image informations
	m_info.bColorType = (wBpp>8) ? COLORTYPE_COLOR : COLORTYPE_PALETTE;
    m_info.dwEffWidth = ((((wBpp * dwWidth) + 31) / 32) * 4);

    // initialize BITMAPINFOHEADER
    m_head.biWidth = dwWidth;		// fill in width from parameter
    m_head.biHeight = dwHeight;	// fill in height from parameter
    m_head.biPlanes = 1;			// must be 1
    m_head.biBitCount = wBpp;		// from parameter
    m_head.biCompression = BI_RGB;    
    m_head.biSizeImage = m_info.dwEffWidth * dwHeight;
//    head.biXPelsPerMeter = 0;
//    head.biYPelsPerMeter = 0;
    m_head.biClrImportant = 0;

	m_hDib = malloc(GetSize()); // alloc memory block to store our bitmap
    if (!m_hDib) return NULL;

    // use our bitmap info structure to fill in first part of
    // our DIB with the BITMAPINFOHEADER
    LPBITMAPINFOHEADER  lpbi;
	lpbi = (LPBITMAPINFOHEADER)(m_hDib);
    *lpbi = m_head;

	m_info.pImage=GetBits();
    return m_hDib; //return handle to the DIB
}


bool CCaptureWndToFile::SaveFile(LPCSTR filename, DWORD imagetype)
{
	FILE* hFile;	//file handle to write the image
	if ((hFile=fopen(filename,"wb"))==NULL)  return false;
	
	bool bOK;

	if(imagetype == IMAGE_BMP)
		bOK = EncodeBMP(hFile);
	else if(imagetype == IMAGE_GIF)
		bOK = EncodeGIF(hFile);

	fclose(hFile);
	return bOK;
}


bool CCaptureWndToFile::EncodeBMP(FILE * hFile)
{
	if (hFile==NULL) return false;

	BITMAPFILEHEADER	hdr;

	hdr.bfType = 0x4d42;   // 'BM' WINDOWS_BITMAP_SIGNATURE
	hdr.bfSize = GetSize() + sizeof(BITMAPFILEHEADER);
	hdr.bfReserved1 = hdr.bfReserved2 = 0;
	hdr.bfOffBits = (DWORD) sizeof(hdr) + m_head.biSize + GetPaletteSize();

	 //copy attributes
	memcpy(m_hDib,&m_head,sizeof(BITMAPINFOHEADER));
    // Write the file header
	fwrite(&hdr,sizeof(BITMAPFILEHEADER),1,hFile);
    // Write the DIB header and the pixels
	fwrite(m_hDib,GetSize(),1,hFile);
	return true;
}

////////////////////////////////////////////////////////////////////////////////
// SaveFile - writes GIF87a gif file
// Randy Spann 6/15/97
// R.Spann@ConnRiver.net
bool CCaptureWndToFile::EncodeGIF(FILE * fp)
{
	if (fp==NULL) {
		strcpy(m_info.szLastError,"Can't open GIF for writing");
		return FALSE;
	}

	if(m_head.biBitCount > 8)	{
		strcpy(m_info.szLastError,"GIF Images must be 8 bit or less");
		return FALSE;
	}

	int B;
	int LeftOfs, TopOfs;
	int Resolution;
	int InitCodeSize;	
	int BackGround = 0;

	Width = m_head.biWidth;
	Height = m_head.biHeight;
	BitsPerPixel = m_head.biBitCount;

	LeftOfs = TopOfs = 0;
	cur_accum = 0;
	cur_bits = 0;
	Resolution = BitsPerPixel;
 	CountDown = (long)Width * (long)Height;

	if (BitsPerPixel <=1)	InitCodeSize=2;
	else	InitCodeSize = BitsPerPixel;

	curx = 0;
	cury = Height - 1;	//because we read the image bottom to top

	fwrite("GIF87a",1,6,fp);	   //GIF Header

	Putword(Width,fp);			   //Logical screen descriptor
	Putword(Height,fp);

	B=0x80;						   
	B |=(Resolution - 1) << 5;
	B |=(BitsPerPixel - 1);

	fputc(B,fp);				   //GIF "packed fields"
	fputc(BackGround,fp);
	fputc(0,fp);				   //GIF "pixel aspect ratio"

	long bufsize = CountDown;
	bufsize *= 3;

	buffer = m_info.pImage;

	RGBQUAD* pPal = GetPalette();
	for(DWORD i=0; i<m_head.biClrUsed; ++i) 
	{
		fputc(pPal[i].rgbRed,fp);
		fputc(pPal[i].rgbGreen,fp);
		fputc(pPal[i].rgbBlue,fp);
	}

	// TRK BEGIN : transparency
	fputc('!',fp);
	fputc(TRANSPARENCY_CODE,fp);
	#pragma pack(1) //DON'T REMOVE : sizeof(gifgce) MUST be 4
	struct {
	  BYTE transpcolflag:1;
	  BYTE userinputflag:1;
	  BYTE dispmeth:3;
	  BYTE res:3;
	  WORD delaytime;
	  BYTE transpcolindex;
	} gifgce;
	gifgce.transpcolflag = (m_info.nBkgndIndex != -1) ? 1 : 0;
	gifgce.userinputflag = 0;
	gifgce.dispmeth = 0;
	gifgce.res = 0;
	gifgce.delaytime = (WORD)m_info.dwFrameDelay;
	gifgce.transpcolindex = (BYTE)m_info.nBkgndIndex;	   
	fputc(sizeof(gifgce),fp);
	fwrite(&gifgce, sizeof(gifgce), 1, fp);
	fputc(0,fp);
	// TRK END

	fputc(',',fp);

	Putword(LeftOfs,fp);
	Putword(TopOfs,fp);
	Putword(Width,fp);
	Putword(Height,fp);

	fputc(0x00,fp);

	 // Write out the initial code size
	fputc(InitCodeSize, fp );
	 // Go and actually compress the data
	compress(InitCodeSize+1, fp);
	 // Write out a Zero-length packet (to end the series)
	fputc( 0, fp );
	 // Write the GIF file terminator
	fputc( ';', fp );
	 // done!
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
void CCaptureWndToFile::Putword(int w, FILE *fp )
{
	fputc( w & 0xff, fp );
	fputc( (w / 256) & 0xff, fp );
}

////////////////////////////////////////////////////////////////////////////////
// returns the pointer to the first palette index 
RGBQUAD* CCaptureWndToFile::GetPalette() const
{
	if ((m_hDib)&&(m_head.biClrUsed))
		return (RGBQUAD*)((BYTE*)m_hDib + sizeof(BITMAPINFOHEADER));
	return NULL;
}

long CCaptureWndToFile::GetSize()
{
	return m_head.biSize + m_head.biSizeImage + GetPaletteSize();
}

////////////////////////////////////////////////////////////////////////////////
//  Bump the 'curx' and 'cury' to point to the next pixel
void CCaptureWndToFile::BumpPixel()
{
	// Bump the current X position
	++curx;
	if( curx == Width ){
		curx = 0;
		cury--;	             //bottom to top
	}
}
////////////////////////////////////////////////////////////////////////////////
// Return the next pixel from the image
// <DP> fix for 1 & 4 bpp images
int CCaptureWndToFile::GIFNextPixel( )
{
	if( CountDown == 0 ) return EOF;
	--CountDown;
	int r = GetPixelIndex(curx,cury);
	BumpPixel();
	return r;
}

////////////////////////////////////////////////////////////////////////////////
BYTE CCaptureWndToFile::GetPixelIndex(long x,long y)
{
	if ((m_hDib==NULL)||(m_head.biClrUsed==0)) return 0;

	if ((x<0)||(y<0)||(x>=m_head.biWidth)||(y>=m_head.biHeight)) {
		if (m_info.nBkgndIndex != -1)	return (BYTE)m_info.nBkgndIndex;
		else return 0;
	}
	if (m_head.biBitCount==8){
		return m_info.pImage[y*m_info.dwEffWidth + x];
	} else {
		BYTE pos;
		BYTE iDst= m_info.pImage[y*m_info.dwEffWidth + (x*m_head.biBitCount >> 3)];
		if (m_head.biBitCount==4){
			pos = 4*(1-x%2);
			iDst &= (0x0F<<pos);
			return iDst >> pos;
		} else if (m_head.biBitCount==1){
			pos = 7-x%8;
			iDst &= (0x01<<pos);
			return iDst >> pos;
		}
	}
	return 0;
}

/***************************************************************************
 *
 *  GIFCOMPR.C       -     LZW GIF Image compression routines
 *
 ***************************************************************************/
#define BITS    12
#define HSIZE  5003            /* 80% occupancy */
typedef        unsigned char   char_type;

static int n_bits;                        /* number of bits/code */
static int maxbits = BITS;                /* user settable max # bits/code */
static code_int maxcode;                  /* maximum code, given n_bits */
static code_int maxmaxcode = (code_int)1 << BITS; /* should NEVER generate this code */

#define MAXCODE(n_bits)        (((code_int) 1 << (n_bits)) - 1)

static count_int htab [HSIZE];
static unsigned short codetab [HSIZE];
#define HashTabOf(i)       htab[i]
#define CodeTabOf(i)    codetab[i]

static code_int free_ent = 0;                  /* first unused entry */

/*
 * block compression parameters -- after all codes are used up,
 * and compression rate changes, start over.
 */
static int clear_flg = 0;

/*
 * compress pixels to GIF packets
 */

static int g_init_bits;
static FILE* g_outfile;

static int ClearCode;
static int EOFCode;

void CCaptureWndToFile::compress( int init_bits, FILE* outfile)
{
	register long fcode;
	register code_int i /* = 0 */;
	register int c;
	register code_int ent;
	register code_int disp;
	register int hshift;

	/*
	 * Set up the globals:  g_init_bits - initial number of bits
	 *                      g_outfile   - pointer to output file
	 */
	g_init_bits = init_bits;
	g_outfile = outfile;

	 // Set up the necessary values
	clear_flg = 0;
	maxcode = MAXCODE(n_bits = g_init_bits);

	ClearCode = (1 << (init_bits - 1));
	EOFCode = ClearCode + 1;
	free_ent = ClearCode + 2;

	char_init();

	ent = GIFNextPixel( );

	hshift = 0;
	for ( fcode = (long) HSIZE;  fcode < 65536L; fcode *= 2L )
		++hshift;
	hshift = 8 - hshift;                /* set hash code range bound */

	cl_hash( (count_int) HSIZE);            /* clear hash table */

	output( (code_int)ClearCode );

	while ( (c = GIFNextPixel( )) != EOF ) {    

		fcode = (long) (((long) c << maxbits) + ent);
		i = (((code_int)c << hshift) ^ ent);    /* xor hashing */

		if ( HashTabOf (i) == fcode ) {
			ent = CodeTabOf (i);
			continue;
		} else if ( (long)HashTabOf (i) < 0 )      /* empty slot */
			goto nomatch;
		disp = HSIZE - i;           /* secondary hash (after G. Knott) */
		if ( i == 0 )
			disp = 1;
probe:
		if ( (i -= disp) < 0 )
			i += HSIZE;

		if ( HashTabOf (i) == fcode ) {
			ent = CodeTabOf (i);
			continue;
		}
		if ( (long)HashTabOf (i) > 0 )
			goto probe;
nomatch:
		output ( (code_int) ent );
		ent = c;
		if ( free_ent < maxmaxcode ) {  
			CodeTabOf (i) = free_ent++; /* code -> hashtable */
			HashTabOf (i) = fcode;
		} else
				cl_block();
	}
	 // Put out the final code.
	output( (code_int)ent );
	output( (code_int) EOFCode );
}

static unsigned long masks[] = { 0x0000, 0x0001, 0x0003, 0x0007, 0x000F,
								  0x001F, 0x003F, 0x007F, 0x00FF,
								  0x01FF, 0x03FF, 0x07FF, 0x0FFF,
								  0x1FFF, 0x3FFF, 0x7FFF, 0xFFFF };

void CCaptureWndToFile::output( code_int  code)
{
	cur_accum &= masks[ cur_bits ];

	if( cur_bits > 0 )
		cur_accum |= ((long)code << cur_bits);
	else
		cur_accum = code;

	cur_bits += n_bits;

	while( cur_bits >= 8 ) {
		char_out( (unsigned int)(cur_accum & 0xff) );
		cur_accum >>= 8;
		cur_bits -= 8;
	}

	/*
	 * If the next entry is going to be too big for the code size,
	 * then increase it, if possible.
	 */
   if ( free_ent > maxcode || clear_flg ) {
		if( clear_flg ) {
			maxcode = MAXCODE (n_bits = g_init_bits);
			clear_flg = 0;
		} else {
			++n_bits;
			if ( n_bits == maxbits )
				maxcode = maxmaxcode;
			else
				maxcode = MAXCODE(n_bits);
		}
	}
	
	if( code == EOFCode ) {
		 // At EOF, write the rest of the buffer.
		while( cur_bits > 0 ) {
			char_out( (unsigned int)(cur_accum & 0xff) );
			cur_accum >>= 8;
			cur_bits -= 8;
		}
	
		flush_char();
	
		fflush( g_outfile );
	
		if( ferror( g_outfile ) ) {
			strcpy(m_info.szLastError,"Write Error in GIF file");
		}
	}
}

static int a_count;

void CCaptureWndToFile::char_init()
{
	a_count=0;
}

static char accum[256];

void CCaptureWndToFile::char_out(int c)
{
	accum[a_count++]=c;
	if (a_count >=254)
		flush_char();
}

void CCaptureWndToFile::flush_char()
{
	if (a_count > 0) {
		fputc(a_count,g_outfile);
		fwrite(accum,1,a_count,g_outfile);
		a_count=0;
	}
}

void CCaptureWndToFile::cl_block()
{
	cl_hash((count_int)HSIZE);
	free_ent=ClearCode+2;
	clear_flg=1;

	output((code_int)ClearCode);
}
	
void CCaptureWndToFile::cl_hash(register count_int hsize)
{
	register count_int *htab_p = htab+hsize;

	register long i;
	register long m1 = -1L;

	i = hsize - 16;

	do {
		*(htab_p-16)=m1;
		*(htab_p-15)=m1;
		*(htab_p-14)=m1;
		*(htab_p-13)=m1;
		*(htab_p-12)=m1;
		*(htab_p-11)=m1;
		*(htab_p-10)=m1;
		*(htab_p-9)=m1;
		*(htab_p-8)=m1;
		*(htab_p-7)=m1;
		*(htab_p-6)=m1;
		*(htab_p-5)=m1;
		*(htab_p-4)=m1;
		*(htab_p-3)=m1;
		*(htab_p-2)=m1;
		*(htab_p-1)=m1;
		
		htab_p-=16;
	} while ((i-=16) >=0);

	for (i+=16;i>0;--i)
		*--htab_p=m1;
}
