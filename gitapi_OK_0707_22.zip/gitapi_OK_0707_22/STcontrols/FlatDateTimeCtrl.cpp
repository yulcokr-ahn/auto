// DateTimeCtrl3.cpp : implementation file
//

#include "stdafx.h"
#include "FlatDateTimeCtrl.h"
#include "../TR/hrefer.h"


 
#define BUTTONWIDTH	18



CFlatDateTimeCtrl::CFlatDateTimeCtrl()
{
	m_bLBtnDown	= FALSE;
	m_bPainted	= FALSE;
	m_bHasFocus	= FALSE;
	m_bAutoComp = TRUE;

	m_clrBtnHilite  = COLOR_BTN_HILIGHT;//::GetSysColor(COLOR_BTNHILIGHT);
	m_clrBtnShadow  = COLOR_BTN_SHADOW;//::GetSysColor(COLOR_BTNSHADOW);
	m_clrBtnFace    = COLOR_BTN_FATS;//::GetSysColor(COLOR_BTNFACE);
	m_clrBorder		= COLOR_BORDER;
	m_clrBkg		= RGB(255,0,255);
	m_nOffset		= ::GetSystemMetrics(SM_CXHTHUMB);
}

CFlatDateTimeCtrl::~CFlatDateTimeCtrl()
{
}


IMPLEMENT_DYNAMIC(CFlatDateTimeCtrl, CWnd)

BEGIN_MESSAGE_MAP(CFlatDateTimeCtrl, CDateTimeCtrl)
	//{{AFX_MSG_MAP(CFlatDateTimeCtrl)
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	ON_WM_NCPAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SETCURSOR()
	ON_CONTROL_REFLECT(DTN_DROPDOWN, OnDropDown)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrl operations
void CFlatDateTimeCtrl::SetBkgColor(COLORREF BkgColor)
{
	m_clrBkg = BkgColor;
	Invalidate();
}

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrl message handlers
void CFlatDateTimeCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	CDateTimeCtrl::OnMouseMove(nFlags, point);
}

void CFlatDateTimeCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_bLBtnDown = TRUE;
	Invalidate();
	CDateTimeCtrl::OnLButtonDown(nFlags, point);
}

void CFlatDateTimeCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_bLBtnDown = FALSE;
	Invalidate();
	CDateTimeCtrl::OnLButtonUp(nFlags, point);
}

void CFlatDateTimeCtrl::OnPaint() 
{
	ModifyStyleEx (WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE, 0, SWP_FRAMECHANGED);
	
	Default();

	CPoint pt;
	GetCursorPos(&pt);

	CRect rcItem;
	GetWindowRect(&rcItem);

	if (GetMonthCalCtrl())
		DrawCombo(pressed, m_clrBtnShadow, m_clrBtnHilite );
	else if ((rcItem.PtInRect(pt)) || m_bHasFocus)
		DrawCombo( raised, m_clrBtnShadow, m_clrBtnHilite );
	else
		DrawCombo( normal, m_clrBtnFace, m_clrBtnFace );
}

void CFlatDateTimeCtrl::DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight)
{
	CRect rcItem;
	GetClientRect(&rcItem);
	CDC* pDC = GetDC();
	
	COLORREF clBlack  = IsWindowEnabled() ? RGB(0, 0, 0) : RGB(12, 30, 32);
	CPen  penBlack(PS_SOLID, 1, clBlack);
	CBrush	brushBlack(clBlack);

	//pDC->FillSolidRect(rcItem, RGB(255, 255, 255));
	pDC->Draw3dRect(rcItem, m_clrBorder, m_clrBorder);

	rcItem.left = rcItem.right - BUTTONWIDTH;
	pDC->Draw3dRect(rcItem, m_clrBorder, m_clrBorder);

	InflateRect(rcItem, -1, -1);
	pDC->FillSolidRect(rcItem, COLOR_BTN_FATS);

	if (!IsWindowEnabled()) {
		ReleaseDC(pDC);
		return;
	}

	switch (eState)
	{
	case normal:
	case raised:
		pDC->Draw3dRect(rcItem, m_clrBtnHilite, m_clrBtnShadow);
		InflateRect(rcItem, -1, -1);
		pDC->Draw3dRect(rcItem, m_clrBtnHilite, m_clrBtnShadow);
		//rcItem.top -= 1;
		//rcItem.bottom += 1;
		//pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		//rcItem.left -= 1;
		//pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		break;


	case pressed:
		pDC->Draw3dRect(rcItem, m_clrBtnShadow, m_clrBtnHilite);
		InflateRect(rcItem, -1, -1);
		pDC->Draw3dRect(rcItem, m_clrBtnShadow, m_clrBtnHilite);
		//rcItem.top -= 1;
		//rcItem.bottom += 1;
		//rcItem.OffsetRect(1,1);
		//pDC->Draw3dRect( rcItem, m_clrBtnShadow, m_clrBtnHilite );
		break;
	}

	int X = rcItem.left+4;
	int Y = (rcItem.bottom/2)-1;

	if(eState == pressed)
	{
		X++;
		Y++;
	}

	CPoint P[3];
	P[0] = CPoint(X, Y);
	P[1] = CPoint(X+6, Y);
	P[2] = CPoint(X+3, Y+3);
	pDC->SelectObject(penBlack);
	pDC->SelectObject(brushBlack);
	pDC->Polygon(P, 3);

	ReleaseDC(pDC);
}

BOOL  CFlatDateTimeCtrl::OnEraseBkgnd(CDC* pDC)
{
	CRect rcItem;

	GetClientRect(&rcItem);
	pDC->FillSolidRect(&rcItem, m_clrBkg);

	return 0;
}

void CFlatDateTimeCtrl::OnNcPaint()
{
	OnPaint();
}

void CFlatDateTimeCtrl::OnDropDown() 
{
	OnPaint();
}

BOOL CFlatDateTimeCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	BOOL bRet = CDateTimeCtrl::OnSetCursor(pWnd, nHitTest, message);;

	return bRet;
}

void CFlatDateTimeCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	CDateTimeCtrl::OnSetFocus(pOldWnd);
	
	Invalidate();
}

void CFlatDateTimeCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	CDateTimeCtrl::OnKillFocus(pNewWnd);

	Invalidate();
}

BOOL CFlatDateTimeCtrl::OnChildNotify(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pLResult) 
{
	if (message == WM_DRAWITEM)
	{
		OnPaint();
	}
	// TODO: Add your specialized code here and/or call the base class
	
	return CDateTimeCtrl::OnChildNotify(message, wParam, lParam, pLResult);
}



#include <string>
using namespace std;

/*
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


static const UINT ID_EDIT = 1;
static const UINT ID_BUTTON = 2;
static const UINT ID_CALENDAR = 3;
static const UINT ID_DROPWND = 4;
#define CALENDAR_AS_POPUP 1

// the arrow button is 16 pixels wide
static const UINT CX_BTN = 16;

// to avoid reliance on uxtheme.h, and uxtheme.lib, we'll load 
// the theme functions, but only once
typedef HANDLE HTHEME;
typedef HTHEME(_stdcall *PFNOPENTHEMEDATA)(HWND, LPWSTR);
typedef HRESULT(_stdcall *PFNCLOSETHEMEDATA)(HTHEME);
typedef HRESULT(__stdcall *PFNDRAWTHEMEBACKGROUND)(HTHEME hTheme, HDC hdc, 
												   int iPartId, int iStateId, const RECT *pRect,  const RECT *pClipRect);
typedef BOOL(__stdcall *PFNISAPPTHEMED)(void);

#include <shlwapi.h>  // for DllGetVersion definitions

// comctl32.dll, and some other DLLs, export a DllGetVersion method 
// so we use that to see which version of comctl32.dll is currently loaded
static DWORD GetComCtl32Version()
{
	HINSTANCE hInstDll = LoadLibrary(_T("COMCTL32.DLL"));
	if (hInstDll == NULL)
		return 0;
	DLLGETVERSIONPROC pfnDllGetVersion = (DLLGETVERSIONPROC)GetProcAddress(hInstDll, "DllGetVersion");
	if (pfnDllGetVersion == NULL)
		return 0;
	DLLVERSIONINFO dvi = { sizeof(dvi) };
	pfnDllGetVersion(&dvi);
	DWORD dwMajor = dvi.dwMajorVersion;
	FreeLibrary(hInstDll);
	return dwMajor;
}

class CDateTimeEditXPStyle
{
public:
	CDateTimeEditXPStyle()
	{
		m_nIsAppXPStyled = -1;
		m_hThemeDLL = LoadLibrary(_T("uxtheme.dll"));
		if (m_hThemeDLL != NULL)
		{
			m_pfnOpenThemeData = (PFNOPENTHEMEDATA)GetProcAddress(m_hThemeDLL, "OpenThemeData");
			m_pfnCloseThemeData = (PFNCLOSETHEMEDATA)GetProcAddress(m_hThemeDLL, "CloseThemeData");
			m_pfnDrawThemeBackground = (PFNDRAWTHEMEBACKGROUND)GetProcAddress(m_hThemeDLL, "DrawThemeBackground");
			m_pfnIsAppThemed = (PFNISAPPTHEMED)GetProcAddress(m_hThemeDLL, "IsAppThemed");
		}
	}
	~CDateTimeEditXPStyle()
    { if (m_hThemeDLL != NULL) FreeLibrary(m_hThemeDLL); }
	HTHEME OpenThemeData(HWND hwnd, LPWSTR pszClassList)
    { return (m_pfnOpenThemeData != NULL) ? m_pfnOpenThemeData(hwnd, pszClassList) : NULL; }
	HRESULT CloseThemeData(HTHEME hTheme)
    { return (m_pfnCloseThemeData != NULL) ? m_pfnCloseThemeData(hTheme) : E_FAIL; }
	HRESULT DrawThemeBackground(HTHEME hTheme, HDC hdc, int iPartId, int iStateId, const RECT *pRect, const RECT *pClipRect = NULL)
    { return (m_pfnDrawThemeBackground != NULL) ? m_pfnDrawThemeBackground(hTheme, hdc, iPartId, iStateId, pRect, pClipRect) : E_FAIL; }
	BOOL IsAppThemed(void)
    { return (m_pfnIsAppThemed != NULL) ? m_pfnIsAppThemed() : FALSE; }
	BOOL IsAppXPStyled()
	{
		if (m_nIsAppXPStyled == -1)
			// IsAppThemed returns TRUE even if the app has no manifest file 
			// The only way to really check is to test the major version of comctl32.dll
			m_nIsAppXPStyled = (IsAppThemed() && GetComCtl32Version() >= 6) ? 1 : 0;
		return (m_nIsAppXPStyled > 0);
	}
protected:
	HINSTANCE m_hThemeDLL;  // DLL handle for XP styling library
	PFNOPENTHEMEDATA m_pfnOpenThemeData;
	PFNCLOSETHEMEDATA m_pfnCloseThemeData;
	PFNDRAWTHEMEBACKGROUND m_pfnDrawThemeBackground;
	PFNISAPPTHEMED m_pfnIsAppThemed;
	int m_nIsAppXPStyled;
};

static CDateTimeEditXPStyle s_xpstyle;

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlButton

BEGIN_MESSAGE_MAP(CFlatDateTimeCtrlButton, CButton)
//{{AFX_MSG_MAP(CFlatDateTimeCtrlButton)
ON_WM_LBUTTONDOWN()
ON_WM_LBUTTONUP()
ON_WM_KEYDOWN()
ON_WM_ERASEBKGND()
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlButton message handlers

void CFlatDateTimeCtrlButton::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CButton::OnLButtonUp(nFlags, point);
	// set the focus back to the parent, and stop it looking like the default button
	if ((GetStyle() & 0xf) != BS_OWNERDRAW)
		ModifyStyle(0xf, 0);
	if (! m_bNonEditable && m_bRestoreFocus && m_pWndLastFocus != NULL && ::IsWindow(m_pWndLastFocus->m_hWnd))
		m_pWndLastFocus->SetFocus();
	else
		GetParent()->SetFocus();
}

void CFlatDateTimeCtrlButton::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (!m_bNonEditable && m_bRestoreFocus)
		m_pWndLastFocus = CWnd::GetFocus();
	else
		m_pWndLastFocus = NULL;
	CButton::OnLButtonDown(nFlags, point);
	// stop it looking like the default button
	if ((GetStyle() & 0xf) != BS_OWNERDRAW)
		ModifyStyle(0xf, 0);
}

void CFlatDateTimeCtrlButton::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CButton::OnKeyDown(nChar, nRepCnt, nFlags);
	
	if (nChar == VK_F4)
		// hide or show cal ctrl, by simulating a button click
		GetParent()->PostMessage(WM_COMMAND, MAKEWPARAM(ID_BUTTON, BN_CLICKED), (LPARAM)GetNextWindow()->GetSafeHwnd());
}

BOOL CFlatDateTimeCtrlButton::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYDOWN && 
		(pMsg->wParam == VK_ESCAPE || pMsg->wParam == VK_RETURN))
	{
		// destroy calendar
		if (GetParent()->SendMessage(DTCEM_DESTROY_CALENDAR, (pMsg->wParam == VK_ESCAPE)))
			return TRUE;
	}
	return CButton::PreTranslateMessage(pMsg);
}

BOOL CFlatDateTimeCtrlButton::OnEraseBkgnd(CDC* pDC) 
{
	if (s_xpstyle.IsAppXPStyled())
	{
		// we want to let the default button show through
		pDC->SelectStockObject(NULL_BRUSH);
		return TRUE;
	}
	return CButton::OnEraseBkgnd(pDC);
}

#define CP_DROPDOWNBUTTON 1
#define CBXS_NORMAL 1
#define CBXS_PRESSED 3
#define CBXS_DISABLED 4

void CFlatDateTimeCtrlButton::DrawItem(LPDRAWITEMSTRUCT lpdis) 
{
	// if we're using XP styles, then draw the button as a combobox 
	// drop-down button, using the appropriate theme
	// then, if we are using a bitmap for the button, draw this on top
	ASSERT(s_xpstyle.IsAppXPStyled());
	HTHEME hTheme = s_xpstyle.OpenThemeData(m_hWnd, L"COMBOBOX");
	ASSERT(hTheme);
	VERIFY(s_xpstyle.DrawThemeBackground(hTheme, lpdis->hDC, CP_DROPDOWNBUTTON, 
		((GetState() & 0x0004) == BST_PUSHED) ? CBXS_PRESSED : 
    IsWindowEnabled() ? CBXS_NORMAL : CBXS_DISABLED, &lpdis->rcItem, NULL) == S_OK);
	s_xpstyle.CloseThemeData(hTheme);
	
	if (GetBitmap() != NULL)
	{
		// draw the bitmap in the centre of the button area
		CDC* pDC = CDC::FromHandle(lpdis->hDC);
		ASSERT(pDC);
		CDC dc;
		dc.CreateCompatibleDC(pDC);
		CBitmap* pBmp = CBitmap::FromHandle(GetBitmap());
		ASSERT(pBmp);
		dc.SelectObject(pBmp);
		BITMAP bmp;
		pBmp->GetBitmap(&bmp);
		CRect rcClient;
		GetClientRect(rcClient);
		rcClient.left = rcClient.right - CX_BTN;
		CPoint ptOrg = rcClient.CenterPoint();
		ptOrg.Offset(-bmp.bmWidth / 2, -bmp.bmHeight / 2);
		pDC->BitBlt(ptOrg.x, ptOrg.y, 16, 16, &dc, 0, 0, SRCCOPY);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlEditCtrl

BEGIN_MESSAGE_MAP(CFlatDateTimeCtrlEditCtrl, CEdit)
//{{AFX_MSG_MAP(CFlatDateTimeCtrlEditCtrl)
ON_WM_GETDLGCODE()
ON_WM_SETCURSOR()
ON_WM_CTLCOLOR_REFLECT()
ON_WM_KEYDOWN()
ON_WM_CHAR()
ON_WM_SETTINGCHANGE()
ON_WM_NCCALCSIZE()
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlEditCtrl message handlers

static TCHAR s_chDateSep = _T('/');
static TCHAR s_szDateFormat[81] = { _T('\0') };

CFlatDateTimeCtrlEditCtrl::CFlatDateTimeCtrlEditCtrl()
{
	m_bNonEditable = FALSE;
	m_bValidCharsOnly = FALSE;
	m_bAllowUpDownKeys = TRUE;
	
	int nLen = ::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SDATE, &s_chDateSep, 0);
	if (nLen != 0)
		::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SDATE, &s_chDateSep, nLen);
	nLen = ::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SSHORTDATE, s_szDateFormat, 0);
	if (nLen != 0)
		::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SSHORTDATE, s_szDateFormat, nLen);
}

UINT CFlatDateTimeCtrlEditCtrl::OnGetDlgCode() 
{
	if (m_bNonEditable)
		return DLGC_STATIC;
	return CEdit::OnGetDlgCode();
}

BOOL CFlatDateTimeCtrlEditCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// if we are non-editable, we want the cursor to look like an arrow
	// not like an I-bar
	if (m_bNonEditable && nHitTest == HTCLIENT)
	{
		AfxGetApp()->LoadStandardCursor(IDC_ARROW);
		return TRUE;
	}
	return CEdit::OnSetCursor(pWnd, nHitTest, message);
}

HBRUSH CFlatDateTimeCtrlEditCtrl::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	// if we are non-editable, we want the edit to be readonly, but look
	// like editable (ie with white (standard 'window') background)
	if (m_bNonEditable && IsWindowEnabled())
	{
		pDC->SetBkColor(GetSysColor(COLOR_WINDOW));
		return GetSysColorBrush(COLOR_WINDOW);
	}
	return NULL;
}

BOOL CFlatDateTimeCtrlEditCtrl::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYDOWN)
	{
		if (pMsg->wParam == VK_ESCAPE)
		{
			// destroy calendar		
			if (GetParent()->SendMessage(DTCEM_DESTROY_CALENDAR, (pMsg->wParam == VK_ESCAPE)))
				return TRUE;
		}
		if (pMsg->wParam == VK_RETURN)
		{
			if (GetParent()->GetParent()->SendMessage(DTCEM_PRESSENTER, (pMsg->wParam == VK_ESCAPE)))
				return TRUE;
		}
	}
	return CEdit::PreTranslateMessage(pMsg);
}

#ifdef _UNICODE
typedef wstring _tstring;
#else
typedef string _tstring;
#endif

int ReverseFindOneOf(const CString& sString, LPCTSTR lpszCharSet)
{
	_tstring s = sString;
	return s.find_last_of(lpszCharSet);
}

int FindOneOf(const CString& sString, LPCTSTR lpszCharSet, int nStart)
{
	_tstring s = sString;
	return s.find_first_of(lpszCharSet, nStart);
}

void CFlatDateTimeCtrlEditCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (m_bAllowUpDownKeys && nChar == VK_UP || nChar == VK_DOWN)
	{
		BOOL bInc = (nChar == VK_UP);
		// increment part of date in which cursor is positioned
		int nStart, nEnd;
		GetSel(nStart, nEnd);
		CString sText;
		GetWindowText(sText);
		CString sSeps = s_chDateSep;
		
		// find portion of text we're in, and select
		// between two separators
		if (! m_sValidChars.IsEmpty())
		{
			sSeps = m_sValidChars;
			for (TCHAR chRemove = _T('0'); chRemove <= _T('9'); chRemove++)
				sSeps.Remove(chRemove);
			// sSeps just contains the separators now
		}
		
		int nSep2 = FindOneOf(sText, sSeps, nEnd);
		CString sStart = sText;
		if (nSep2 >= 0)
			sStart = sText.Left(nSep2);
		int nPos = ReverseFindOneOf(sStart, sSeps);
		
		BOOL bLeftPos = TRUE;
		BOOL bMidPos = FALSE;
		int nSep1 = 0;
		if (nPos >= 0)
		{
			// mid position
			if (nSep2 >= 0)
			{
				bLeftPos = FALSE;
				bMidPos = TRUE;
			}
			nSep1 = nPos + 1;
		}
		if (nSep2 < 0)
		{
			// right-most portion
			nSep2 = sText.GetLength();
			bLeftPos = FALSE;
		}
		
		CString sDateFormat = s_szDateFormat;
		CString sPortion;
		
		int nFirstSep = sDateFormat.FindOneOf(sSeps);
		// find out which part of the format we are in
		if (bLeftPos)
		{
			// get bit before first sep
			if (nFirstSep > 0)
				sPortion = sDateFormat.Left(nFirstSep);
		}
		else if (bMidPos)
		{
			// get bit after first sep, and before last
			if (nFirstSep > 0)
			{
				nFirstSep++;
				int nPos = FindOneOf(sDateFormat, sSeps, nFirstSep);
				if (nPos >= nFirstSep)
					sPortion = sDateFormat.Mid(nFirstSep, nPos - nFirstSep);
			}
		}
		else
		{
			// get bit after last sep
			int nPos = ReverseFindOneOf(sDateFormat, sSeps);
			if (nPos >= 0)
				sPortion = sDateFormat.Right(sDateFormat.GetLength() - (nPos+1));
		}
		
		// select new portion
		SetSel(nSep1, nSep2);
		CString sVal = sStart.GetLength() > nSep1 ? sStart.Mid(nSep1) : sStart;
		
		LPTSTR lpszFormat = _T("%02d");
		int nVal = _ttoi(sVal);
		int nMin = 1;
		int nMax = 12;
		
		// make sure the number is within bounds depending on portion
		if (! sPortion.IsEmpty())
		{
			int nLen = sPortion.GetLength();
			if (nLen != 2)
				lpszFormat = _T("%0d");
			switch (sPortion.GetAt(0))
			{
			case _T('d'):	// day
			case _T('D'):	// day
				nMax = 31;
				break;
				
			case _T('M'):	// month
			case _T('m'):	// month
				nMax = 12;
				break;
				
			case _T('y'):	// year
			case _T('Y'):	// year
				{
					nMin = 0;
					if (nLen == 1)
						nMax = 9;
					else if (nLen == 2)
						nMax = 99;
					else if (nLen == 4)
					{
						lpszFormat = _T("%04d");
						nMax = 9999;
					}
				}
				break;
			};
		}
		
		if (bInc)
			nVal++;
		else
			nVal--;
		
		// wrap values
		if (nVal < nMin)
			nVal = nMax;
		else if (nVal > nMax)
			nVal = nMin;
		
		sVal.Format(lpszFormat, nVal);
		
		// replace and re-select new portion
		ReplaceSel(sVal);
		
		BOOL bInvalid = FALSE;
		
		// if this takes the value out of range, correct it
		CFlatDateTimeCtrl* pCtrl = DYNAMIC_DOWNCAST(CFlatDateTimeCtrl, GetParent());
		if (pCtrl != NULL)
		{
			CString sTextNew;
			GetWindowText(sTextNew);
			COleDateTime dateMin, dateMax;
			DWORD dwFlags = pCtrl->GetRange(&dateMin, &dateMax);
			COleDateTime date;
			date.ParseDateTime(sTextNew);
			if (dwFlags & GDTR_MIN && date < dateMin)
			{
				bInvalid = TRUE;
				date = dateMin;
			}
			else if (dwFlags & GDTR_MAX && date > dateMax)
			{
				bInvalid = TRUE;
				date = dateMax;
			}
			sText = date.Format(VAR_DATEVALUEONLY);
		}
		
		if (bInvalid)
		{
			SetWindowText(sText);
			SetSel(nStart, nEnd);
		}
		else
		{
			nSep2 = nSep1 + sVal.GetLength();
			SetSel(nSep1, nSep2);
		}
		
		SendDateTimeChange();
		
		return;
  }
  
  CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
  
  if (nChar == VK_F4)
	  // hide or show cal ctrl, by simulating a button click
	  GetParent()->PostMessage(WM_COMMAND, MAKEWPARAM(ID_BUTTON, BN_CLICKED), (LPARAM)GetNextWindow()->GetSafeHwnd());
}

void CFlatDateTimeCtrlEditCtrl::SendDateTimeChange()
{
	CFlatDateTimeCtrl* pCtrl = DYNAMIC_DOWNCAST(CFlatDateTimeCtrl, GetParent());
	if (pCtrl != NULL)
	{
		CWnd* pParent = pCtrl->GetParent();
		if (pParent != NULL)
		{
			COleDateTime date;
			CString sText;
			GetWindowText(sText);
			date.ParseDateTime(sText);
			SYSTEMTIME st = { '\0' };
			date.GetAsSystemTime(st);
			// tell parent about it (DTN_DATETIMECHANGE)
			NMDATETIMECHANGE nmdtc;
			nmdtc.nmhdr.code = DTN_DATETIMECHANGE;
			nmdtc.nmhdr.hwndFrom = pCtrl->GetSafeHwnd();
			nmdtc.nmhdr.idFrom = pCtrl->GetDlgCtrlID();
			nmdtc.dwFlags = GDT_VALID;
			nmdtc.st = st;
			pParent->SendMessage(WM_NOTIFY, (WPARAM)nmdtc.nmhdr.idFrom, (LPARAM)&nmdtc);
		}
	}
}

// set whether the user can only enter chars that are valid
void CFlatDateTimeCtrlEditCtrl::SetValidCharsOnly(BOOL bValidCharsOnly)
{
	m_bValidCharsOnly = bValidCharsOnly;
}

// returns whether the user can only enter valid chars into the edit control
BOOL CFlatDateTimeCtrlEditCtrl::GetValidCharsOnly()
{
	return m_bValidCharsOnly;
}

// sets the chars that are valid for the user to type into the edit control
// if NULL is specified, then the default chars are used (0-9 and current 
// user's locale's date separator). If the user changes the locale settings 
// then the control will automatically pick this up and use the new separator.
void CFlatDateTimeCtrlEditCtrl::SetValidChars(LPCTSTR lpszValidChars)
{
	m_sValidChars = lpszValidChars;
}

// returns the chars that are valid for the user to type into the edit control
CString CFlatDateTimeCtrlEditCtrl::GetValidChars()
{
	return m_sValidChars;
}

void CFlatDateTimeCtrlEditCtrl::SetAllowUpDownKeys(BOOL bAllow)
{
	m_bAllowUpDownKeys = bAllow;
}

BOOL CFlatDateTimeCtrlEditCtrl::GetAllowUpDownKeys()
{
	return m_bAllowUpDownKeys;
}

void CFlatDateTimeCtrlEditCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (m_bValidCharsOnly && nChar >= 0x20)
	{
		BOOL bValid = TRUE;
		if (m_sValidChars.IsEmpty())
		{
			// only allow numeric or date separator
			if (nChar >= 0x20 && (nChar < _T('0') || nChar > _T('9')) && nChar != (UINT)s_chDateSep)
				bValid = FALSE;
		}
		else
		{
			// see if the char is in the valid chars list
			if (m_sValidChars.Find((TCHAR)nChar) == -1)
				bValid = FALSE;
		}
		if (! bValid)
		{
			// don't allow it
			MessageBeep(MB_ICONEXCLAMATION);
			return;
		}
	}
	CEdit::OnChar(nChar, nRepCnt, nFlags);
	
	// tell the parent dialog of the change
	SendDateTimeChange();
}

void CFlatDateTimeCtrlEditCtrl::OnSettingChange(UINT uFlags, LPCTSTR lpszSection) 
{
	if (lpszSection != NULL && lstrcmpi(lpszSection, _T("intl")) == 0)
	{
		int nLen = ::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SDATE, &s_chDateSep, 0);
		if (nLen != 0)
			::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SDATE, &s_chDateSep, nLen);
	}
	CEdit::OnSettingChange(uFlags, lpszSection);
}

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlMonthCalCtrl

CFlatDateTimeCtrlMonthCalCtrl::CFlatDateTimeCtrlMonthCalCtrl()
{
	m_nIgnoreNextMessage = 0;
}

CFlatDateTimeCtrlMonthCalCtrl::~CFlatDateTimeCtrlMonthCalCtrl()
{
}

BEGIN_MESSAGE_MAP(CFlatDateTimeCtrlMonthCalCtrl, CMonthCalCtrl)
//{{AFX_MSG_MAP(CFlatDateTimeCtrlMonthCalCtrl)
ON_WM_CREATE()
ON_WM_KEYDOWN()
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlMonthCalCtrl message handlers

LRESULT CFlatDateTimeCtrlMonthCalCtrl::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	if (m_nIgnoreNextMessage != message)
	{
		if (message == WM_LBUTTONDOWN || 
			message == WM_MBUTTONDOWN || 
			message == WM_RBUTTONDOWN)
		{
			// Is mouse within control
			CPoint point(lParam);
			CRect rcClient;
			GetClientRect(rcClient);
			if (! rcClient.PtInRect(point))
			{
				ReleaseCapture();
				GetOwner()->PostMessage(DTCEM_DESTROY_CALENDAR);
			}
			else
				SetCapture();
		}
		else if (message == WM_LBUTTONUP || 
			message == WM_MBUTTONUP || 
			message == WM_RBUTTONUP)
		{
			CMonthCalCtrl::WindowProc(message, wParam, lParam);
			// we seem to lose capture on Xbuttonup, which stops us catching
			// out-of-rect messages after changing, for instance, the month
			// so we need to re-capture messages. However, if the Xbuttondown
			// was out-of-rect, then we won't exist by this point, so test validity
			if (::IsWindow(m_hWnd))
				SetCapture();
			return 0;
		}
		else if (message == WM_PARENTNOTIFY)
		{
			if (LOWORD(wParam) == WM_DESTROY)
				// just destroyed the 'year' edit/updown, but this makes us lose capture
				SetCapture();
		}
		else if (message == WM_MENUSELECT)
		{
			if (HIWORD(wParam) == 0xffff && lParam == 0)
			{
				// the month menu has been closed, so re-take capture
				SetCapture();
				// if the menu was closed by clicking outside of the client area, 
				// then by retaining the capture the mouse event will close the 
				// calendar, which is not what we want, so we need to ignore the 
				// next click of that mouse button in our code above
				m_nIgnoreNextMessage = 0;
				if (GetAsyncKeyState(MK_LBUTTON) & 0x80000000)
					m_nIgnoreNextMessage = WM_LBUTTONDOWN;
				else if (GetAsyncKeyState(MK_MBUTTON) & 0x80000000)
					m_nIgnoreNextMessage = WM_MBUTTONDOWN;
				else if (GetAsyncKeyState(MK_RBUTTON) & 0x80000000)
					m_nIgnoreNextMessage = WM_RBUTTONDOWN;
			}
		}
	}
	if (message == m_nIgnoreNextMessage)
		m_nIgnoreNextMessage = 0; // don't ignore it again
	return CMonthCalCtrl::WindowProc(message, wParam, lParam);
}

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlCalendarWnd

CFlatDateTimeCtrlCalendarWnd::CFlatDateTimeCtrlCalendarWnd(CWnd* pComboParent, DWORD dwMCStyle)
{
	m_pComboParent = pComboParent;
	m_dwMCStyle = dwMCStyle;
	m_pCalendar = NULL;
}

CFlatDateTimeCtrlCalendarWnd::~CFlatDateTimeCtrlCalendarWnd()
{
	delete m_pCalendar;
}

BEGIN_MESSAGE_MAP(CFlatDateTimeCtrlCalendarWnd, CWnd)
//{{AFX_MSG_MAP(CFlatDateTimeCtrlCalendarWnd)
ON_WM_CREATE()
ON_WM_SIZE()
ON_WM_ACTIVATEAPP()
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrlCalendarWnd message handlers

BOOL CFlatDateTimeCtrlCalendarWnd::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	return CWnd::Create(0, 0, dwStyle, rect, pParentWnd, nID, pContext);
}

int CFlatDateTimeCtrlCalendarWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// hide the taskbar button
	if (!(lpCreateStruct->style & WS_POPUP))
		ModifyStyleEx(0, WS_EX_TOOLWINDOW);
	
	// Create calendar control
	m_pCalendar = new CFlatDateTimeCtrlMonthCalCtrl;
	DWORD dwStyle = m_dwMCStyle & ~(WS_VISIBLE);
	VERIFY(m_pCalendar->Create(dwStyle | WS_CHILD, CPoint(0, 0), this, ID_CALENDAR));
	m_pCalendar->SizeMinReq();
	m_pCalendar->SetOwner(m_pComboParent);
	
	// size self to fit calendar
	// and make us top-most, so we're seen
	CRect rcCal;
	m_pCalendar->GetWindowRect(&rcCal);
	CalcWindowRect(&rcCal);
	SetWindowPos(&wndTopMost, 0, 0, rcCal.Width(), rcCal.Height(), SWP_NOMOVE | SWP_NOACTIVATE);
	
	m_pCalendar->ShowWindow(SW_SHOW);
	
	// the calendar needs to catch all mouse messages, so it can respond to
	// changes in the visible month etc
	m_pCalendar->SetCapture();
	
	return 0;
}

BOOL CFlatDateTimeCtrlCalendarWnd::DestroyWindow() 
{
	ReleaseCapture();
	m_pCalendar->DestroyWindow();
	return CWnd::DestroyWindow();
}

#if _MFC_VER >= 0x0700
void CFlatDateTimeCtrlCalendarWnd::OnActivateApp(BOOL bXPX_ACTIVE, DWORD dwThreadID) 
#else
void CFlatDateTimeCtrlCalendarWnd::OnActivateApp(BOOL bXPX_ACTIVE, HTASK hTask) 
#endif
{
#if _MFC_VER >= 0x0700
	CWnd::OnActivateApp(bXPX_ACTIVE, dwThreadID);
#else
	CWnd::OnActivateApp(bXPX_ACTIVE, hTask);
#endif
	if (! bXPX_ACTIVE && m_pComboParent != NULL)
		m_pComboParent->PostMessage(DTCEM_DESTROY_CALENDAR, TRUE);
}

BOOL CFlatDateTimeCtrlCalendarWnd::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	LPNMHDR lpnmhdr = (LPNMHDR)lParam;
	if (lpnmhdr != NULL && m_pComboParent != NULL && 
		(lpnmhdr->code == MCN_SELECT || lpnmhdr->code == MCN_SELCHANGE))
	{
		*pResult = m_pComboParent->SendMessage(WM_NOTIFY, wParam, lParam);
		return TRUE;
	}
	return CWnd::OnNotify(wParam, lParam, pResult);
}

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrl

#if _AFXDLL
IMPLEMENT_DYNAMIC(CDateTimeCtrl, CWnd)
#endif

IMPLEMENT_DYNAMIC(CFlatDateTimeCtrl, CDateTimeCtrl)

CFlatDateTimeCtrl::CFlatDateTimeCtrl()
{
	m_bAutoComp = TRUE;
	m_pEdit = NULL;
	m_pBtn = NULL;
	m_nBtnImageID = 0;
	m_bNonEditable = FALSE;
	m_bRightAlign = FALSE;
	m_pCalWnd = NULL;
	m_bInCreate = FALSE;
	m_hMCFont = NULL;
	// initial values of cal ctrl colours
	m_acrMonthCal[0] = (COLORREF)-1;		// the background color (between months)
	m_acrMonthCal[1] = GetSysColor(COLOR_BTNTEXT);// the dates
	m_acrMonthCal[2] = GetSysColor(COLOR_XPX_ACTIVECAPTION);	// background of the title
	m_acrMonthCal[3] = (COLORREF)-1;		// title text
	m_acrMonthCal[4] = (COLORREF)-1;		// background within the month cal
	m_acrMonthCal[5] = GetSysColor(COLOR_3DSHADOW);// the text color of header & trailing days
	m_pDateMin = NULL;
	m_pDateMax = NULL;
	m_bEmpty = TRUE;
	m_bUpdate = TRUE;
}

CFlatDateTimeCtrl::~CFlatDateTimeCtrl()
{
	delete m_pEdit;
	delete m_pBtn;
	delete m_pCalWnd;
	delete m_pDateMin;
	delete m_pDateMax;
	ReleaseCapture();
}

BEGIN_MESSAGE_MAP(CFlatDateTimeCtrl, CDateTimeCtrl)
//{{AFX_MSG_MAP(CFlatDateTimeCtrl)
ON_WM_CREATE()
ON_WM_ENABLE()
ON_WM_SETFOCUS()
ON_WM_SIZE()
ON_WM_CANCELMODE()
ON_WM_NCCALCSIZE()
ON_WM_KEYDOWN()
//}}AFX_MSG_MAP
ON_MESSAGE(DTCEM_DESTROY_CALENDAR, OnDestroyCalendar)
ON_WM_STYLECHANGING()
ON_MESSAGE(DTCEM_RECREATE, OnRecreate)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrl message handlers

LONG CFlatDateTimeCtrl::OnDestroyCalendar(WPARAM wParam, LPARAM lParam)
{
	// wParam is the key this is in response to if applicable

	if (wParam)
	{
		Parse();
		if (m_dtInitItem.m_dt == m_date.m_dt)
			return DestroyCalendar(wParam);

		SetTime(m_dtInitItem);
		return TRUE;
	}

	return DestroyCalendar(wParam);
}

BOOL CFlatDateTimeCtrl::Create(DWORD dwStyle, const RECT &rect, CWnd *pParentWnd, UINT nID)
{
	m_bInCreate = TRUE;
	if (! CWnd::Create(DATETIMEPICK_CLASS, NULL, dwStyle, rect, pParentWnd, nID))
		return FALSE;
	
	return TRUE;
}

int CFlatDateTimeCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	m_bInCreate = TRUE; // we're being created explicitly
	
	if (s_xpstyle.IsAppXPStyled() && m_nBtnImageID != 0)
		lpCreateStruct->style |= WS_BORDER;
	
	DWORD dwStyleDTS = (lpCreateStruct->style & 0xFF);
	lpCreateStruct->style &= ~0xFF;
	if (CDateTimeCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;

	ASSERT(!(dwStyleDTS & DTS_UPDOWN)); // updown not supported
	// 'show none' style not supported, as this control would be used instead
	ASSERT(!(dwStyleDTS & DTS_SHOWNONE));
	ASSERT(!(dwStyleDTS & DTS_APPCANPARSE));  // app parsing not supported
	ASSERT(!(dwStyleDTS & DTS_LONGDATEFORMAT)); // only short dates supported
	ASSERT(!(dwStyleDTS & DTS_TIMEFORMAT)); // only short dates supported
	
	if (dwStyleDTS & DTS_RIGHTALIGN)
		m_bRightAlign = TRUE;
	CRect rc(0, 0, 0, 0);
	
	m_pEdit = new CFlatDateTimeCtrlEditCtrl;
	m_pBtn = new CFlatDateTimeCtrlButton;
	
	// Get the edit control styles and create the edit control
	// we want to isolate the edit styles from the style, and
	// visible and disabled if specified
	// then add in WS_CHILD
	DWORD dwStyleEdit = lpCreateStruct->style & (WS_VISIBLE | WS_DISABLED | 0x3DFFL);
	dwStyleEdit |= WS_CHILD | WS_CLIPSIBLINGS;
	dwStyleEdit &= ~WS_BORDER;
	if (!m_pEdit->Create(dwStyleEdit, rc, this, ID_EDIT))
		return -1;
	
	// Get the button styles and create the button
	// just allow visible and disabled from the specified style
	// and add WS_CHILD and BS_PUSHBUTTON
	DWORD dwStyleBtn = lpCreateStruct->style & (WS_VISIBLE | WS_DISABLED);
	dwStyleBtn |= WS_CHILD | WS_CLIPSIBLINGS | BS_PUSHBUTTON;
	if (s_xpstyle.IsAppXPStyled())
		dwStyleBtn |= BS_OWNERDRAW;
	if (! m_pBtn->Create(_T("6"), dwStyleBtn, rc, this, ID_BUTTON))
		return -1;
	
	SetButtonImageID(m_nBtnImageID);
	
	// if the edit control is readonly, disable the button
	if (dwStyleEdit & ES_READONLY)
		m_pBtn->EnableWindow(FALSE);
	
	// get parent's font, and apply to this control
	CWnd* pParent = GetParent();
	if (pParent != NULL)
	{
		CFont* pFont = pParent->GetFont();
		SetFont(pFont);
	}
	
	CFont font;
	font.CreatePointFont(100, _T("Marlett"));
	HFONT hFont = (HFONT)font.Detach();
	m_pBtn->SendMessage(WM_SETFONT, (WPARAM)hFont, (LPARAM)TRUE);
	
	return 0;
}

void CFlatDateTimeCtrl::OnStyleChanging(int nStyleType, LPSTYLESTRUCT lpStyleStruct)
{
	ASSERT(lpStyleStruct != NULL);
	
	if (nStyleType & GWL_STYLE && !(nStyleType & GWL_EXSTYLE))
	{
		DWORD dwStyleDTSOld = (lpStyleStruct->styleOld & 0xFF);
		DWORD dwStyleDTSNew = (lpStyleStruct->styleNew & 0xFF);
		// isolate bits which have changed (xor old and new)
		DWORD dwStyleDTS = dwStyleDTSOld ^ dwStyleDTSNew;
		ASSERT(!(dwStyleDTS & DTS_UPDOWN));
		ASSERT(!(dwStyleDTS & DTS_SHOWNONE));
		ASSERT(!(dwStyleDTS & DTS_APPCANPARSE));
		ASSERT(!(dwStyleDTS & DTS_LONGDATEFORMAT));
		ASSERT(!(dwStyleDTS & DTS_TIMEFORMAT));
		
		if (dwStyleDTS & DTS_RIGHTALIGN)
			m_pEdit->ModifyStyle(dwStyleDTSOld & ES_RIGHT, dwStyleDTSNew & ES_RIGHT);
	}
}

void CFlatDateTimeCtrl::OnEnable(BOOL bEnable) 
{
	CDateTimeCtrl::OnEnable(bEnable);
	
	if (m_pEdit != NULL)
		m_pEdit->EnableWindow(bEnable);
	if (m_pBtn != NULL)
		m_pBtn->EnableWindow(bEnable);
}

void CFlatDateTimeCtrl::EnableButton(BOOL bEnable)
{
	if (m_pBtn != NULL)
		m_pBtn->EnableWindow(bEnable);
}

void CFlatDateTimeCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	CDateTimeCtrl::OnSetFocus(pOldWnd);
	
	if (m_bNonEditable && m_pBtn != NULL && ::IsWindow(m_pBtn->m_hWnd))
	{
		// set the focus to the button control
		m_pBtn->SetFocus();
	}
	else if (m_pEdit != NULL && ::IsWindow(m_pEdit->m_hWnd))
	{
		// set the focus to the edit control
		m_pEdit->SetFocus();
		m_pEdit->SetSel(0, -1);
	}
}

void CFlatDateTimeCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CDateTimeCtrl::OnSize(nType, cx, cy);
	
	if (cx == 0 || cy == 0)
		return;
	
	CPoint ptOrg(0, 0);
	CRect rcEdit(ptOrg, CSize(cx - cy, cy));
	CRect rcBtn(CPoint(cx - cy, ptOrg.y), CSize(cy, cy));
	
	if (s_xpstyle.IsAppXPStyled())
	{
		// set the size of the button
		rcBtn.left = rcBtn.right - CX_BTN;
		rcEdit.right = cx - rcBtn.Width();
	}
	
	// size the child controls
	if (m_pEdit != NULL && ::IsWindow(m_pEdit->m_hWnd))
		m_pEdit->MoveWindow(&rcEdit);
	if (m_pBtn != NULL && ::IsWindow(m_pBtn->m_hWnd))
		m_pBtn->MoveWindow(&rcBtn);
}

BOOL CFlatDateTimeCtrl::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	NMHDR* pnmhdr = (NMHDR*)lParam;
	if (pnmhdr != NULL)
	{
		// if notification from cal ctrl then act on them, and destroy cal ctrl
		if (m_pCalWnd != NULL && pnmhdr->idFrom == ID_CALENDAR)
		{
			if (pnmhdr->code == MCN_SELECT || 
				pnmhdr->code == MCN_SELCHANGE || 
				pnmhdr->code == MCN_GETDAYSTATE)
			{
				if (pnmhdr->code == MCN_SELCHANGE || pnmhdr->code == MCN_SELECT)
				{
					// get date, and put in edit ctrl
					LPNMSELCHANGE lpnmsc = (LPNMSELCHANGE)pnmhdr;
					COleDateTime date(lpnmsc->stSelStart);
					ASSERT(date.GetStatus() == COleDateTime::valid);
					CString sDate = date.Format(VAR_DATEVALUEONLY);
					m_pEdit->SetWindowText(sDate);
					
					// tell parent about it (DTN_DATETIMECHANGE)
					CWnd* pParent = GetParent();
					if (pParent != NULL)
					{
						NMDATETIMECHANGE nmdtc;
						nmdtc.nmhdr.code = DTN_DATETIMECHANGE;
						nmdtc.nmhdr.hwndFrom = GetSafeHwnd();
						nmdtc.nmhdr.idFrom = GetDlgCtrlID();
						nmdtc.dwFlags = GDT_VALID;
						nmdtc.st = lpnmsc->stSelStart;
						pParent->SendMessage(WM_NOTIFY, (WPARAM)nmdtc.nmhdr.idFrom, (LPARAM)&nmdtc);
#ifdef BOOKKEEPING
								GetParent()->SendMessage(WM_MODIFY);
#endif

					}
					if (pnmhdr->code == MCN_SELECT)
					{
						// we want to close the calendar when the user selects a date
						DestroyCalendar();
					}
				}
				return TRUE;
			}
		}
		// pass generic notifications from the controls to the parent
		CWnd* pParent = GetParent();
		if (pParent != NULL)
		{
			pnmhdr->idFrom = GetDlgCtrlID();
			pnmhdr->hwndFrom = GetSafeHwnd();
			*pResult = pParent->SendMessage(WM_NOTIFY, (WPARAM)pnmhdr->idFrom, lParam);
			return TRUE;
		}
	}
	return CDateTimeCtrl::OnNotify(wParam, lParam, pResult);
}

BOOL CFlatDateTimeCtrl::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	// if button clicked, show calendar control
	if (HIWORD(wParam) == BN_CLICKED && LOWORD(wParam) == ID_BUTTON)
	{
		if (m_pCalWnd != NULL)
			DestroyCalendar();
		else
			CreateCalendar();
		return TRUE;
	}
	return CDateTimeCtrl::OnCommand(wParam, lParam);
}

void CFlatDateTimeCtrl::SetNonEditable(BOOL bNonEditable)
{
	if (m_pEdit == NULL)
		return;
	m_bNonEditable = bNonEditable;
	DWORD dwStyleEdit = m_pEdit->GetStyle();
	CFont* pFont = m_pEdit->GetFont();
	CString sText;
	m_pEdit->GetWindowText(sText);
	m_pEdit->DestroyWindow();
	if (m_bNonEditable)
		dwStyleEdit |= ES_READONLY;
	else
		dwStyleEdit &= ~ES_READONLY;
	if (! m_pEdit->Create(dwStyleEdit, CRect(0, 0, 0, 0), this, ID_EDIT))
		return;
	m_pEdit->SetNonEditable(m_bNonEditable);
	m_pEdit->SetFont(pFont);
	m_pEdit->SetWindowText(sText);
	CRect rc;
	GetClientRect(&rc);
	m_pEdit->MoveWindow(0, 0, rc.Width() - rc.Height(), rc.Height());
	// tell the button whether we are non-editable, so it can decide
	// whether to try and restore the focus
	m_pBtn->SetNonEditable(m_bNonEditable);
}

BOOL CFlatDateTimeCtrl::CreateCalendar()
{
	CRect rc;
	ASSERT(m_pCalWnd == NULL);
	m_pCalWnd = new CFlatDateTimeCtrlCalendarWnd(this);
	GetWindowRect(&rc);
	rc.top = rc.bottom;
	
	// Get screen size
	CRect rcWorkArea;
	SystemParametersInfo(SPI_GETWORKAREA, 0, (LPRECT)rcWorkArea, 0);
	if (rc.bottom >= rcWorkArea.bottom)
		rc.bottom = rcWorkArea.bottom;
	
#if CALENDAR_AS_POPUP
	m_pCalWnd->CreateEx(0, NULL, NULL, WS_CHILD | WS_POPUP | WS_BORDER | WS_CLIPSIBLINGS, rc, this, 0);
#else
	m_pCalWnd->Create(WS_CHILD | WS_BORDER, rc, GetDesktopWindow(), ID_DROPWND);
#endif // CALENDAR_AS_POPUP
	
	// line calendar window up with appropriate edge of control
	CRect rcCal, rcEdit;
	GetClientRect(&rc);
	ClientToScreen(&rc);
	rc.top = rc.bottom;
	m_pCalWnd->GetWindowRect(&rcCal);
	m_pEdit->GetClientRect(&rcEdit);
	m_pEdit->ClientToScreen(&rcEdit);
	rc.bottom = rc.top + rcCal.Height();
	if (m_bRightAlign)
	{
		rc.right = rcEdit.right;
		rc.left = rc.right - rcCal.Width();
	}
	else
	{
		rc.left = rcEdit.left;
		rc.right = rc.left + rcCal.Width();
	}
	
	// if it goes off the bottom of the screen, then put it above this control
	if (rc.bottom > rcWorkArea.bottom)
	{
		CRect rcWnd;
		GetWindowRect(&rcWnd);
		rc.OffsetRect(0, -(rcCal.Height() + rcWnd.Height()));
	}
	// if it's off the left, then nudge it over
	if (rc.left < rcWorkArea.left)
	{
		rc.OffsetRect(rcWorkArea.left - rc.left, 0);
	}
	m_pCalWnd->SetWindowPos(NULL, rc.left, rc.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
	
	m_pCalWnd->ShowWindow(SW_SHOWNA);
	
	CFlatDateTimeCtrlMonthCalCtrl* pCal = m_pCalWnd->GetMonthCalCtrl();
	
	// set the min/max range if they've been set
	if (pCal != NULL)
		pCal->SetRange(m_pDateMin, m_pDateMax);
	
	// get edit's current date/time, and set ctrl accordingly
	m_pEdit->GetWindowText(m_sOrigDate);
	if (pCal != NULL)
	{
		COleDateTime dateInit(COleDateTime::GetCurrentTime());
		COleDateTime date;
		if (! m_sOrigDate.IsEmpty() && date.ParseDateTime(m_sOrigDate))
			dateInit = date;
		if (m_pDateMin != NULL && dateInit < *m_pDateMin)
			dateInit = *m_pDateMin;
		else if (m_pDateMax != NULL && dateInit > *m_pDateMax)
			dateInit = *m_pDateMax;

		if (dateInit.GetStatus() == GDT_VALID)
			pCal->SetCurSel(dateInit);
	}
	// set font of cal ctrl if font is non-NULL
	// set colours of cal ctrl if colours are not -1
	if (pCal != NULL)
	{
		if (m_hMCFont != NULL)
		{
			CFont* pFont = CFont::FromHandle(m_hMCFont);
			if (pFont != NULL)
				pCal->SetFont(pFont);
		}
		for (int n = 0; n < 6; n++)
		{
			if (m_acrMonthCal[n] != -1)
				pCal->SetColor(n, m_acrMonthCal[n]);
		}
	}
	
	// tell parent about it (DTN_DROPDOWN)
	CWnd* pParent = GetParent();
	if (pParent != NULL)
	{
		NMHDR nmhdr;
		nmhdr.code = DTN_DROPDOWN;
		nmhdr.hwndFrom = GetSafeHwnd();
		nmhdr.idFrom = GetDlgCtrlID();
		pParent->SendMessage(WM_NOTIFY, (WPARAM)nmhdr.idFrom, (LPARAM)&nmhdr);
	}
	
	return TRUE;
}

// destroy the cal ctrl if shown
// returns TRUE if destroyed, else FALSE if not shown
BOOL CFlatDateTimeCtrl::DestroyCalendar(BOOL bDiscard)
{
	if (m_pCalWnd == NULL)
		return FALSE;
	if (::IsWindow(m_pCalWnd->m_hWnd))
		m_pCalWnd->DestroyWindow();
	delete m_pCalWnd;
	m_pCalWnd = NULL;
	m_pEdit->SetFocus();
	CWnd* pParent = GetParent();
	// if we canceled, set the original time string, and send change
	if (bDiscard)
	{
		m_pEdit->SetWindowText(m_sOrigDate);
		// tell parent about it (DTN_DATETIMECHANGE)
		if (pParent != NULL)
		{
			NMDATETIMECHANGE nmdtc;
			nmdtc.nmhdr.code = DTN_DATETIMECHANGE;
			nmdtc.nmhdr.hwndFrom = GetSafeHwnd();
			nmdtc.nmhdr.idFrom = GetDlgCtrlID();
			COleDateTime date;
			date.ParseDateTime(m_sOrigDate);
			if (date.GetStatus() == COleDateTime::valid)
				nmdtc.dwFlags = GDT_VALID;
			else
				nmdtc.dwFlags = GDT_NONE;
			date.GetAsSystemTime(nmdtc.st);
			pParent->SendMessage(WM_NOTIFY, (WPARAM)nmdtc.nmhdr.idFrom, (LPARAM)&nmdtc);
		}
	}
	// tell parent about it (DTN_CLOSEUP)
	if (pParent != NULL)
	{
		NMHDR nmhdr;
		nmhdr.code = DTN_CLOSEUP;
		nmhdr.hwndFrom = GetSafeHwnd();
		nmhdr.idFrom = GetDlgCtrlID();
		pParent->SendMessage(WM_NOTIFY, (WPARAM)nmhdr.idFrom, (LPARAM)&nmhdr);
	}
	return TRUE;
}

void CFlatDateTimeCtrl::OnCancelMode() 
{
	CDateTimeCtrl::OnCancelMode();
	DestroyCalendar();
}

#define MAP_DTM(dtm) case dtm: s = #dtm;

CString FormatDTM(UINT message)
{
	CString s("<unknown>");
	switch (message)
	{
		MAP_DTM(DTM_GETSYSTEMTIME)
			MAP_DTM(DTM_SETSYSTEMTIME)
			MAP_DTM(DTM_GETRANGE)
			MAP_DTM(DTM_SETRANGE)
			MAP_DTM(DTM_SETFORMAT)
			MAP_DTM(DTM_SETMCCOLOR)
			MAP_DTM(DTM_GETMCCOLOR)
			MAP_DTM(DTM_GETMONTHCAL)
			MAP_DTM(DTM_SETMCFONT)
			MAP_DTM(DTM_GETMCFONT)
	};
	return s;
}

LRESULT CFlatDateTimeCtrl::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// if a recreate message is pending, then we won't have created 
	// the edit control etc yet, so deal with it now
	if (m_pEdit == NULL)
	{
		MSG msg;
		if (PeekMessage(&msg, m_hWnd, DTCEM_RECREATE, DTCEM_RECREATE, PM_REMOVE))
		{
			DispatchMessage(&msg);
			ASSERT(m_pEdit != NULL);
			ASSERT(m_pBtn != NULL);
		}
	}
	switch (message)
	{
	case WM_SETTEXT:
	case WM_GETTEXT:
	case WM_GETTEXTLENGTH:
		{
			ASSERT(m_pEdit != NULL);
			return m_pEdit->SendMessage(message, wParam, lParam);
		}
		break;
		
	case WM_SETFONT:
		{
			ASSERT(m_pEdit != NULL);
			ASSERT(m_pBtn != NULL);
			m_pEdit->SendMessage(WM_SETFONT, wParam, lParam);
			
			CFont font;
			font.CreatePointFont(100, _T("Marlett"));
			HFONT hFont = (HFONT)font.Detach();
			m_pBtn->SendMessage(WM_SETFONT, (WPARAM)hFont, lParam);
		}
		break;
		
	case WM_COMMAND:
		{
			// send notifications from the edit control to the parent
			if (LOWORD(wParam) == ID_EDIT)
			{
				CWnd* pParent = GetParent();
				if (pParent != NULL)
					return pParent->SendMessage(WM_COMMAND, MAKEWPARAM(GetDlgCtrlID(), HIWORD(wParam)), (LPARAM)GetSafeHwnd());
			}
		}
		break;
		
	case DTM_GETSYSTEMTIME:
		{
			// get the time from the current edit text
			// and return whether it's valid
			CString sDate;
			ASSERT(m_pEdit != NULL);
			m_pEdit->GetWindowText(sDate);
			if (sDate.IsEmpty())
				return GDT_NONE;
			else
			{
				LPSYSTEMTIME lpst = (LPSYSTEMTIME)lParam;
				ASSERT(lpst != NULL);
				COleDateTime date;
				date.ParseDateTime(sDate);
				ASSERT(date.GetStatus() == COleDateTime::valid);
				date.GetAsSystemTime(*lpst);
				return GDT_VALID;
			}
		}
		break;
		
	case DTM_SETSYSTEMTIME:
		{
			// set the control's time to the time specified
			ASSERT(m_pEdit != NULL);
			if (wParam == GDT_NONE)
				m_pEdit->SetWindowText(_T(""));
			else if (wParam == GDT_VALID)
			{
				if (lParam == 0)
					return FALSE;
				LPSYSTEMTIME lpst = (LPSYSTEMTIME)lParam;
				COleDateTime date(*lpst);
				if (date.GetStatus() != COleDateTime::valid)
					return FALSE;
				CString sDate = date.Format(VAR_DATEVALUEONLY);
				m_pEdit->SetWindowText(sDate);
			}
			else
				return FALSE;
			return TRUE;
		}
		break;
		
	case DTM_GETMONTHCAL:
		{
			if (m_pCalWnd != NULL)
			{
				CMonthCalCtrl* pCal = m_pCalWnd->GetMonthCalCtrl();
				if (pCal != NULL)
					return (LRESULT)pCal->m_hWnd;
			}
			return (LRESULT)NULL;
		}
		break;
		
	case DTM_SETMCFONT:
		{
			m_hMCFont = (HFONT)wParam;
			BOOL bRedraw = (BOOL)lParam;
			if (m_pCalWnd == NULL)
				return 0;
			CMonthCalCtrl* pCal = m_pCalWnd->GetMonthCalCtrl();
			if (pCal == NULL)
				return 0;
			CFont* pFont = CFont::FromHandle(m_hMCFont);
			pCal->SetFont(pFont, bRedraw);
		}
		break;
		
	case DTM_GETMCFONT:
		{
			if (m_pCalWnd == NULL)
				return (LRESULT)m_hMCFont;
			CMonthCalCtrl* pCal = m_pCalWnd->GetMonthCalCtrl();
			if (pCal == NULL)
				return (LRESULT)m_hMCFont;
			CFont* pFont = pCal->GetFont();
			return (LRESULT)pFont->m_hObject;
		}
		break;
		
	case DTM_SETMCCOLOR:
		{
			// set the colour accordingly
			int nIndex = (int)wParam;
			ASSERT(nIndex >= 0 && nIndex < 6);
			COLORREF crOld = m_acrMonthCal[nIndex];
			m_acrMonthCal[nIndex] = (COLORREF)lParam;
			// if the cal ctrl is present, set its colours
			if (m_pCalWnd != NULL)
			{
				CMonthCalCtrl* pCal = m_pCalWnd->GetMonthCalCtrl();
				if (pCal != NULL)
					return (LRESULT)pCal->SetColor(nIndex, m_acrMonthCal[nIndex]);
			}
			return (LRESULT)crOld;
		}
		break;
		
	case DTM_GETMCCOLOR:
		{
			// get the colour accordingly
			int nIndex = (int)wParam;
			ASSERT(nIndex >= 0 && nIndex < 6);
			// if the cal ctrl is present, get its colours
			if (m_pCalWnd != NULL)
			{
				CMonthCalCtrl* pCal = m_pCalWnd->GetMonthCalCtrl();
				if (pCal != NULL)
					return (LRESULT)pCal->GetColor(nIndex);
			}
			return (LRESULT)m_acrMonthCal[nIndex];
		}
		break;
		
	case DTM_SETRANGE:
		{
			int nFlags = (int)wParam;
			LPSYSTEMTIME ast = (LPSYSTEMTIME)lParam;
			delete m_pDateMin;
			delete m_pDateMax;
			if (ast != NULL)
			{
				if (nFlags & GDTR_MIN)
					m_pDateMin = new COleDateTime(ast[0]);
				if (nFlags & GDTR_MAX)
					m_pDateMax = new COleDateTime(ast[1]);
			}
			// if we're showing calendar control, apply to it now
			if (m_pCalWnd != NULL)
			{
				CMonthCalCtrl* pCal = m_pCalWnd->GetMonthCalCtrl();
				if (pCal != NULL)
					pCal->SendMessage(DTM_SETRANGE, wParam, lParam);
			}
			return 0;
		}
		break;
		
	case DTM_GETRANGE:
		{
			int nFlags = 0;
			LPSYSTEMTIME ast = (LPSYSTEMTIME)lParam;
			if (ast != NULL)
			{
				if (m_pDateMin != NULL)
				{
					m_pDateMin->GetAsSystemTime(ast[0]);
					nFlags |= GDTR_MIN;
				}
				if (m_pDateMax != NULL)
				{
					m_pDateMax->GetAsSystemTime(ast[1]);
					nFlags |= GDTR_MAX;
				}
			}
			return nFlags;
		}
		break;
		
	case DTM_SETFORMAT:
		TRACE(_T("Got DTM: %s\n"), FormatDTM(message));
		ASSERT(FALSE);  // not supported
		AfxThrowNotSupportedException();
		break;
		
  }
  return CDateTimeCtrl::WindowProc(message, wParam, lParam);
}

void CFlatDateTimeCtrl::PreSubclassWindow() 
{
	CDateTimeCtrl::PreSubclassWindow();
	
	// if we were created explicitly then everything is hunky-dory
	// else we need to destroy the datetimectrl and create our own stuff
	if (m_bInCreate)
		return;
	
	PostMessage(DTCEM_RECREATE);
}

LONG CFlatDateTimeCtrl::OnRecreate(WPARAM wParam, LPARAM lParam)
{
	// we come in here if we've been subclassed, so we can destroy
	// the existing control, and create our own version
	CWnd* pParentWnd = GetParent();
	if (pParentWnd == NULL)
		pParentWnd = GetDesktopWindow();
	
	CWnd* pWndFocus = CWnd::GetFocus();
	BOOL bFocus = (pWndFocus == this);
	
	// get current attributes
	DWORD dwStyle = GetStyle();
	DWORD dwStyleEx = GetExStyle();
	CRect rc;
	GetWindowRect(&rc);
	pParentWnd->ScreenToClient(&rc);	// map to client co-ords
	UINT nID = GetDlgCtrlID();
	CFont* pFont = GetFont();
	CWnd* pWndAfter = GetNextWindow(GW_HWNDPREV);
	
	if (s_xpstyle.IsAppXPStyled() && m_nBtnImageID != 0)
		dwStyle |= WS_BORDER;
	
	DestroyWindow();
	m_hWnd = NULL;
	
	m_bInCreate = TRUE;
	
	if (! CWnd::CreateEx(dwStyleEx, DATETIMEPICK_CLASS, NULL, dwStyle, rc, pParentWnd, nID))
		return -1;
	// re-apply attributes
	if (pFont == NULL)
		pFont = pParentWnd->GetFont();
	SetFont(pFont);
	
	// re-set focus
	if (bFocus)
		SetFocus();
	
	// position correctly in z-order
	SetWindowPos(pWndAfter == NULL ? &CWnd::wndBottom : pWndAfter, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	
	return 0;
}

// returns whether the date passed is valid
// if NULL is passed, then the date in the edit control is used
BOOL CFlatDateTimeCtrl::IsValidDate(LPCTSTR lpszDate)
{
	CString sDate = lpszDate;
	if (sDate.IsEmpty())
		GetWindowText(sDate);
	COleDateTime date;
	return date.ParseDateTime(sDate);
}

// set whether the user can only enter chars that are valid
void CFlatDateTimeCtrl::SetValidCharsOnly(BOOL bValidCharsOnly)
{
	if (m_pEdit != NULL)
		m_pEdit->SetValidCharsOnly(bValidCharsOnly);
}

// returns whether the user can only enter valid chars into the edit control
BOOL CFlatDateTimeCtrl::GetValidCharsOnly()
{
	if (m_pEdit != NULL)
		return m_pEdit->GetValidCharsOnly();
	return FALSE;
}

// sets the chars that are valid for the user to type into the edit control
// if NULL is specified, then the default chars are used (0-9 and current 
// user's locale's date separator). If the user changes the locale settings 
// then the control will automatically pick this up and use the new separator.
void CFlatDateTimeCtrl::SetValidChars(LPCTSTR lpszValidChars)
{
	if (m_pEdit != NULL)
		m_pEdit->SetValidChars(lpszValidChars);
}

// returns the chars that are valid for the user to type into the edit control
CString CFlatDateTimeCtrl::GetValidChars()
{
	if (m_pEdit != NULL)
		return m_pEdit->GetValidChars();
	return "";
}

void CFlatDateTimeCtrl::SetAllowUpDownKeys(BOOL bAllow)
{
	if (m_pEdit != NULL)
		m_pEdit->SetAllowUpDownKeys(bAllow);
}

BOOL CFlatDateTimeCtrl::GetAllowUpDownKeys()
{
	if (m_pEdit != NULL)
		return m_pEdit->GetAllowUpDownKeys();
	return FALSE;
}

BOOL CFlatDateTimeCtrl::SetButtonImageID(UINT nID)
{
	m_nBtnImageID = nID;
	
	if (m_pBtn != NULL && ::IsWindow(m_pBtn->m_hWnd))
	{
		if (nID == 0)
		{
			m_pBtn->ModifyStyle(BS_BITMAP | BS_CENTER, 0);
			HBITMAP hbmp = m_pBtn->SetBitmap(NULL);
			if (hbmp != NULL)
				DeleteObject(hbmp);
			if (s_xpstyle.IsAppXPStyled())
				ModifyStyle(WS_BORDER, 0, SWP_FRAMECHANGED);
		}
		else
		{
			CBitmap bmp;
			if (! bmp.LoadBitmap(m_nBtnImageID))
				return FALSE;
			m_pBtn->ModifyStyle(0, BS_BITMAP | BS_CENTER);
			m_pBtn->SetBitmap((HBITMAP)bmp.GetSafeHandle());
			bmp.Detach();
			if (s_xpstyle.IsAppXPStyled())
				ModifyStyle(0, WS_BORDER, SWP_FRAMECHANGED);
		}
	}
	return TRUE;
}

void CFlatDateTimeCtrl::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	CDateTimeCtrl::OnNcCalcSize(bCalcValidRects, lpncsp);
	// if using XP styles, and showing a bitmap on the button, 
	// make the client rect bigger, as the border is greedy, 
	// else we won't fit the button in
	if (GetButtonImageID() != 0 && s_xpstyle.IsAppXPStyled())
		InflateRect(&(lpncsp->rgrc[0]), 2, 2);
}

void CFlatDateTimeCtrlEditCtrl::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	CEdit::OnNcCalcSize(bCalcValidRects, lpncsp);
	// if using XP styles, and showing a bitmap on the button, 
	// compensate for the fact that we've made the client rect 
	// of the date control bigger to fit the button in
	CFlatDateTimeCtrl* pDate = DYNAMIC_DOWNCAST(CFlatDateTimeCtrl, GetParent());
	if (pDate != NULL && pDate->GetButtonImageID() != 0 && s_xpstyle.IsAppXPStyled())
		InflateRect(&(lpncsp->rgrc[0]), -2, -2);
}

void CFlatDateTimeCtrl::Parse()
{
	CString str, strDay, strMonth, strYear;
	GetWindowText(str);

	m_bEmpty = str.IsEmpty();
	if (((str.GetLength() == 2) || (str.GetLength() == 4)) && (str.Find('.') == -1))
	{
		int iYear = atol(str);
		if (iYear < 100)
		{
			if (iYear + 2000 > COleDateTime::GetCurrentTime().GetYear())
				iYear += 1900;
			else
				iYear += 2000;
		}
		if ((iYear > 100) && (iYear < 1000))
		{
			m_date.SetStatus(COleDateTime::null);
			m_date.m_dt = 0.0;
			return;
		}

		m_date = COleDateTime(iYear, 1, 1, 0, 0, 1); // 1 ��? ��������, ��? ����������?? ������ ��?
		SetTime(m_date);
		return;
	}

	int index = str.Find('.');
	if (index > 0)
	{
		strDay = str.Left(index);
		int index2 = str.Find('.', index + 1);
		if (index2 > 0)
		{
			strMonth = str.Mid(index + 1, index2 - index - 1);
			strYear = str.Mid(index2 + 1);
			int iYear = atol(strYear);
			if (iYear < 100)
			{
				if (iYear + 2000 > COleDateTime::GetCurrentTime().GetYear())
					iYear += 1900;
				else
					iYear += 2000;
			}

			if ((iYear > 1800) && (m_date.SetDate(iYear, atol(strMonth), atol(strDay)) == 0))
			{
				SetTime(m_date);
				return;
			}
		}
	}

	if ((str.GetLength() == 6) || (str.GetLength() == 8))
	{
		strDay = str.Left(2);
		strMonth = str.Mid(2, 2);
		int iYear;
		if (str.GetLength() == 6)
		{
			strYear = str.Mid(4, 2);
			iYear = atol(strYear);
			if (iYear + 2000 > COleDateTime::GetCurrentTime().GetYear())
				iYear += 1900;
			else
				iYear += 2000;
		}
		else
		{
			strYear = str.Mid(4, 4);
			iYear = atol(strYear);
		}
		m_date.SetDate(iYear, atol(strMonth), atol(strDay));
		SetTime(m_date);
		return;
	}
	
	m_date.SetStatus(COleDateTime::null);
	m_date.m_dt = 0.0;
}

BOOL CFlatDateTimeCtrl::IsValid() const
{
	if ((m_date.GetStatus() == COleDateTime::valid))
		return TRUE;
	if ((m_date.GetStatus() == COleDateTime::null) && m_bEmpty)
		return TRUE;

	return FALSE;
}

void CFlatDateTimeCtrl::SetEmpty()
{
	m_bUpdate = FALSE;
	SetWindowText(_T(""));
	m_date.SetStatus(COleDateTime::null);
	m_date.m_dt = 0.0;
	m_bEmpty = TRUE;
	m_bUpdate = TRUE;
}

void CFlatDateTimeCtrl::SetInitDate(COleDateTime& date)
{
	m_dtInitItem = date;
	SetTime(date);
}
*/











/*
CFlatDateTimeCtrl::CFlatDateTimeCtrl()
{
	m_bLBtnDown	= FALSE;
	m_bPainted	= FALSE;
	m_bHasFocus	= FALSE;
	m_bAutoComp = TRUE;
	m_clrBtnHilite  = COLOR_BTN_HILIGHT;//::GetSysColor(COLOR_BTNHILIGHT);
	m_clrBtnShadow  = COLOR_BTN_SHADOW;//::GetSysColor(COLOR_BTNSHADOW);
	m_clrBtnFace    = COLOR_BTN_FATS;//::GetSysColor(COLOR_BTNFACE);
//	m_clrBorder		= COLOR_BORDER;
	m_clrBkg		= RGB(255,255,255);


	m_nOffset		= ::GetSystemMetrics(SM_CXHTHUMB);
}

CFlatDateTimeCtrl::~CFlatDateTimeCtrl()
{
}


IMPLEMENT_DYNAMIC(CFlatDateTimeCtrl, CWnd)

BEGIN_MESSAGE_MAP(CFlatDateTimeCtrl, CDateTimeCtrl)
	//{{AFX_MSG_MAP(CFlatDateTimeCtrl)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	ON_WM_NCPAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrl operations
void CFlatDateTimeCtrl::SetBkgColor(COLORREF BkgColor)
{
	m_clrBkg = BkgColor;
	Invalidate();
}

/////////////////////////////////////////////////////////////////////////////
// CFlatDateTimeCtrl message handlers
void CFlatDateTimeCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	CDateTimeCtrl::OnMouseMove(nFlags, point);
}

void CFlatDateTimeCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_bLBtnDown = TRUE;
	CDateTimeCtrl::OnLButtonDown(nFlags, point);
	Invalidate();
}

void CFlatDateTimeCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_bLBtnDown = FALSE;
	Invalidate();
	CDateTimeCtrl::OnLButtonUp(nFlags, point);
}

void CFlatDateTimeCtrl::OnPaint() 
{
//	ModifyStyleEx (WS_EX_STATICEDGE,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW);
//		0, SWP_FRAMECHANGED);
	Default();
	DrawCombo( normal, RGB(123,56,165),RGB(123,56,165)); // COLOR_CTRL_BORDER, COLOR_CTRL_BORDER );
}

void CFlatDateTimeCtrl::DrawCombo(STATE eState, COLORREF clrTopLeft, COLORREF clrBottomRight)
{
	CRect rcItem;
	GetClientRect(&rcItem);

	CDC* pDC = GetDC();

	// Cover up dark 3D shadow.
	pDC->Draw3dRect(rcItem, clrTopLeft, clrBottomRight);
	rcItem.DeflateRect(1,1);

	pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );


	
	if (!IsWindowEnabled()) {
		ReleaseDC(pDC);
		return;
	}

	switch (eState)
	{
	case normal:

		rcItem.left = rcItem.right-m_nOffset+1;
		rcItem.right = rcItem.left+1;
		pDC->Draw3dRect( rcItem, m_clrBtnHilite, m_clrBtnHilite );
		break;


	}

	ReleaseDC(pDC);
}

void CFlatDateTimeCtrl::OnEraseBkgnd(CDC* pDC)
{
	CRect rcItem;

	GetClientRect(&rcItem);
	pDC->FillSolidRect(&rcItem, m_clrBkg);
}

void CFlatDateTimeCtrl::OnNcPaint()
{
}

*/