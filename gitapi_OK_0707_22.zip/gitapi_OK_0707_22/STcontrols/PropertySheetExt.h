#if !defined(AFX_PROPERTYSHEETEXT_H__09085C81_B3F5_11D5_A8B1_444553540000__INCLUDED_)
#define AFX_PROPERTYSHEETEXT_H__09085C81_B3F5_11D5_A8B1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropertySheetEx.h : header file
// 2001.9.cyber.sukim

#include <afxdlgs.h>
#include "TabCtrlExt.h"

#define		TC_SELECT		1

/////////////////////////////////////////////////////////////////////////////
// CPropertySheetExt

class AFX_EXT_CLASS CPropertySheetExt : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropertySheetExt)

// Construction
public:
	CPropertySheetExt();
	CPropertySheetExt(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertySheetEx)
	//}}AFX_VIRTUAL
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
public:
	virtual ~CPropertySheetExt();
	virtual BOOL OnInitDialog(); 

	void	 SetColours(COLORREF BkgColour);
	COLORREF GetColours();

public:
	COLORREF GetTabColor(int index = TC_SELECT);
	void SetTabColors(COLORREF selected);
	CTabCtrlExt	m_TabCtrlExt;
	COLORREF	m_crBkgColour;

	int			m_nCurrentTab;

	// Generated message map functions
protected:
	//{{AFX_MSG(CPropertySheetEx)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
//	afx_msg void OnSelChange(WPARAM wParam, LPARAM lParam);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	COLORREF m_crTabSelected;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYSHEETEXT_H__09085C81_B3F5_11D5_A8B1_444553540000__INCLUDED_)
