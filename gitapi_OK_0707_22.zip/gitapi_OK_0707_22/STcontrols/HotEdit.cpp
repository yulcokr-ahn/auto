// HotEdit.cpp : implementation file
//

#include "stdafx.h"
#include "HotEdit.h"
//#include "../TR/hrefer.h"
#include "../Include\hrefer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHotEdit

CHotEdit::CHotEdit()
{
	m_clr3DFATS = GetSysColor(COLOR_3DFACE);
	m_clr3DLight = GetSysColor(COLOR_3DLIGHT);
	m_clr3DHilight = GetSysColor(COLOR_3DHILIGHT);
	m_clr3DShadow = GetSysColor(COLOR_3DSHADOW);
	m_clr3DDkShadow = GetSysColor(COLOR_3DDKSHADOW);

	m_fGotFocus = false;
	m_fTimerSet = false;

	m_hbr1 = CreateSolidBrush( RGB(255,255,255/*199,226,226*/));
	m_hbr2 = CreateSolidBrush( COLOR_CTRL_BORDER );
}

CHotEdit::~CHotEdit()
{
	DeleteObject(m_hbr1);
	DeleteObject(m_hbr2);
}


BEGIN_MESSAGE_MAP(CHotEdit, CEdit)
	//{{AFX_MSG_MAP(CHotEdit)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_NCMOUSEMOVE()
	ON_WM_SYSCOLORCHANGE()
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_LBUTTONDOWN()
	ON_CONTROL_REFLECT(EN_SETFOCUS, OnSetfocus)
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHotEdit message handlers

void CHotEdit::OnPaint() 
{
	// call the default message handler to repaint the text etc.
	Default();

	// now redraw the border
	if (m_fGotFocus) {
		DrawBorder();
	} else {
		DrawBorder(false);
	}
}

void CHotEdit::OnSetFocus(CWnd* pOldWnd) 
{
	CEdit::OnSetFocus(pOldWnd);
	
	// set internal flag and redraw border
	m_fGotFocus = true;
	DrawBorder();
}

void CHotEdit::OnKillFocus(CWnd* pNewWnd) 
{
	CEdit::OnKillFocus(pNewWnd);

	// set internal flag and redraw border
//	m_fGotFocus = false;
//	DrawBorder(false);
}

void CHotEdit::OnMouseMove(UINT nFlags, CPoint point) 
{
	// no point setting the timer if we already have focus, the border will be drawn all the time if
	// we have focus
//	if (!m_fGotFocus) {
		// if the timer isn't already set, set it.
//		if (!m_fTimerSet) {
//			DrawBorder();
//			SetTimer(1, 10, NULL);
//			m_fTimerSet = true;
//		}
//	}

	CEdit::OnMouseMove(nFlags, point);
}

// The timer is used to periodically check whether the mouse cursor is within
// this control. Once it isn't, the timer is killed
void CHotEdit::OnTimer(UINT nIDEvent) 
{
	POINT pt;
	GetCursorPos(&pt);
	CRect rcItem;
	GetWindowRect(&rcItem);

	// if the mouse cursor within the control?
	if(!rcItem.PtInRect(pt)) {
/*		KillTimer(1);

		m_fTimerSet = false;

		if (!m_fGotFocus) {
//			DrawBorder(false);
			DrawBorder(true);
		}*/
		return;
	}

	CEdit::OnTimer(nIDEvent);
}

// Scroll bars are actually in the non-client area of the window
// so we want to check for movement here too
void CHotEdit::OnNcMouseMove(UINT nHitTest, CPoint point) 
{
//	if (!m_fTimerSet) {
		DrawBorder();
//		SetTimer(1, 10, NULL);
//		m_fTimerSet = true;
//	}
	
	CEdit::OnNcMouseMove(nHitTest, point);
}

// When the user has changed the system colours we want to
// update the member variables accordingly
void CHotEdit::OnSysColorChange() 
{
	CEdit::OnSysColorChange();
	
	m_clr3DFATS = GetSysColor(COLOR_3DFACE);
	m_clr3DLight = GetSysColor(COLOR_3DLIGHT);
	m_clr3DHilight = GetSysColor(COLOR_3DHILIGHT);
	m_clr3DShadow = GetSysColor(COLOR_3DSHADOW);
	m_clr3DDkShadow = GetSysColor(COLOR_3DDKSHADOW);
}

// This is the guts of this control. It draws the border of the control
// as flat when the control is not XPX_ACTIVE. When the control becomes XPX_ACTIVE
// the border is drawn according to the styles applied to it
// If the control is disabled, the border is drawn irrespective of whether
// the control is hot or not.
void CHotEdit::DrawBorder(bool fHot)
{
	CRect rcItem;
	DWORD dwExStyle = GetExStyle();
	CDC* pDC = GetDC();
	COLORREF clrBlack;
	int nBorderWidth = 0;
	int nLoop;

	GetWindowRect(&rcItem);
	ScreenToClient(&rcItem);

	clrBlack = RGB(0, 0, 0);

	if (!IsWindowEnabled()) {
		fHot = true;
	}

	pDC->SetBkColor( COLOR_CTRL_BORDER );
	pDC->SetTextColor( RGB(0,0,0) );

	if (dwExStyle & WS_EX_DLGMODALFRAME) {
		nBorderWidth += 3;
	}
	if (dwExStyle & WS_EX_CLIENTEDGE) {
		nBorderWidth += 2;
	}
	if (dwExStyle & WS_EX_STATICEDGE && !(dwExStyle & WS_EX_DLGMODALFRAME)) {
		nBorderWidth ++;
	}

	// blank the border
	for (nLoop = 0; nLoop < nBorderWidth; nLoop++) {
		if(nLoop == 0)
			pDC->Draw3dRect(rcItem, COLOR_CTRL_BORDER, COLOR_CTRL_BORDER);
		else
			pDC->Draw3dRect(rcItem, RGB(255,255,255), RGB(255,255,255));
		rcItem.DeflateRect(1, 1);
	}
	rcItem.InflateRect(1, 1);

/*	if (fHot) {
		if (dwExStyle & WS_EX_CLIENTEDGE) {
			pDC->Draw3dRect(rcItem, m_clr3DDkShadow, m_clr3DLight);
			rcItem.InflateRect(1, 1);
			pDC->Draw3dRect(rcItem, m_clr3DShadow, m_clr3DHilight);
			rcItem.InflateRect(1, 1);
		}

		if (dwExStyle & WS_EX_STATICEDGE && !(dwExStyle & WS_EX_DLGMODALFRAME)) {
			pDC->Draw3dRect(rcItem, m_clr3DShadow, m_clr3DHilight);
			rcItem.InflateRect(1, 1);
		}

		if (dwExStyle & WS_EX_DLGMODALFRAME) {
			pDC->Draw3dRect(rcItem, m_clr3DFATS, m_clr3DFATS);
			rcItem.InflateRect(1, 1);
			pDC->Draw3dRect(rcItem, m_clr3DHilight, m_clr3DShadow);
			rcItem.InflateRect(1, 1);
			pDC->Draw3dRect(rcItem, m_clr3DLight, m_clr3DDkShadow);
		}
	}
*/
	ReleaseDC(pDC);
}
//#include "resource.h"
//HBRUSH CHotEdit::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
HBRUSH CHotEdit::CtlColor(CDC* pDC, UINT nCtlColor) 
{
//	HBRUSH hbr = CEdit::OnCtlColor(pDC, pWnd, nCtlColor);
	HBRUSH hbr = NULL;
	
	if( nCtlColor == CTLCOLOR_STATIC )
	{
		pDC->SetBkColor( RGB(255,255,255/*199,226,226*/) );
		pDC->SetTextColor( RGB(0,0,0) );

		return  m_hbr1;
	}
	if( nCtlColor == CTLCOLOR_EDIT )
	{
		pDC->SetBkColor( RGB(255,255,255/*208,252,205*/) );
		pDC->SetTextColor( RGB(0,0,0) );

		return  m_hbr1;
	}
//	TRACE("%d %d %d\n", nCtlColor, IDC_EDITTITLE);
	return  hbr;
}

void CHotEdit::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(GetFocus() != this)
	{
		SetFocus();
	}
	else CEdit::OnLButtonDown(nFlags, point);
}

void CHotEdit::OnSetfocus() 
{
	// TODO: Add your control notification handler code here
	SetSel(0, -1);
}

void CHotEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if(nChar == '+')
	{
		//ȭ���ȣ �Է�â���� ��Ŀ���̵�
		AfxGetMainWnd()->SendMessage(WM_KEYDOWN_ADD, 0, 0);
		return;
	}
	CEdit::OnChar(nChar, nRepCnt, nFlags);
}
