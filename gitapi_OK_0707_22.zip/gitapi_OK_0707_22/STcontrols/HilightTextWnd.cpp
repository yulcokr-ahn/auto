//
#include "stdafx.h"
#include "HilightTextWnd.h"
#include "resource.h"
#include <Winnls.h>     //2003.9.25 IsDBCSLeadByte �Լ����� include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAX_LL 1024
#define MIN_X 5
#define MIN_Y 2
#define HANGLE_WIDTH CharDX+4 //2003.9.5(��) �α�
#define COMMENT_COLOR RGB(0,200,0)
#define KEYWORD_COLOR RGB(0,51,250)
#define USER_COLOR RGB(220,0,40)
#define OPERATOR_COLOR RGB(128,128,128)
#define NUM_COLOR RGB(0,153,255)
#define NORMAL_COLOR RGB(0,0,0)
//#define KEYWORD_COLOR RGB(0,40,250)
//#define USER_COLOR RGB(220,0,40)
//#define OPERATOR_COLOR RGB(153,153,153)
//#define NUM_COLOR RGB(255,102,0)

BOOL AUTO_TAB = TRUE;

/////////////////////////////////////////////////////////////////////////////
// CHilightTextWnd

CHilightTextWnd::CHilightTextWnd(CWnd * parent, CRect & rect,
	int nID, CString &keywordsFile, BOOL caseSensitive)
{
	AfxInitRichEdit();
	
	m_pParent = parent;
	m_pColorize = new Colorize(keywordsFile, caseSensitive);
	m_bCaseSensitive = caseSensitive;
	m_crBorder = COLOR_BORDER;
	m_nLeftMargin = 10;

	//DWORD dwStyle = WS_CHILD|WS_BORDER|WS_VSCROLL|WS_HSCROLL|WS_VISIBLE|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL|ES_WANTRETURN|ES_NOHIDESEL|ES_SUNKEN;
	DWORD dwStyle = WS_CHILD|WS_VSCROLL|WS_HSCROLL|WS_VISIBLE|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL|ES_WANTRETURN|ES_NOHIDESEL;
	CRichEditCtrl::Create(dwStyle, rect, parent, nID);

	UINT	uiSize			= sizeof(CHARFORMAT);
	DWORD	dwMask			= CFM_COLOR | CFM_FACE | CFM_SIZE;
	LONG	lHeight			= 180;	// 9 point => 180 * (1/20)

	m_cfText.cbSize			= uiSize;
	m_cfText.dwMask			= dwMask;
	m_cfText.dwEffects		= 0;
	m_cfText.yHeight		= lHeight;
	m_cfText.crTextColor	= RGB(0, 0, 0);
	strcpy(m_cfText.szFaceName,	_T("����ü"));

	Clear();
	SetDefaultCharFormat(m_cfText);

	//SetSel(0, 0);
	//SetWordCharFormat(m_cfText);
	m_pColorize->m_pEditor = this;

	m_hIMC = ImmGetContext(this->GetSafeHwnd());  //2003.9.4(��) �α�
}

CHilightTextWnd::~CHilightTextWnd()
{
	ImmReleaseContext(this->GetSafeHwnd(), m_hIMC); //2003.9.4(��) �α�
	delete m_pColorize;
}

BEGIN_MESSAGE_MAP(CHilightTextWnd, CRichEditCtrl)
	//{{AFX_MSG_MAP(CHilightTextWnd)
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
	ON_WM_CREATE()
	ON_WM_CONTEXTMENU()
	ON_WM_GETDLGCODE()
	ON_WM_NCPAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

Colorize::Colorize(CString &keywordsFile, BOOL caseSensitive)
{
	m_bCaseSensitive = caseSensitive;
	LoadKeyWords(keywordsFile);
}

Colorize::~Colorize()
{
}

void Colorize::SetSelColor(CString strSel, int nCurIndex, COLORREF crSel, BOOL bReplace/* = FALSE*/) 
{
	int nStartChar = m_pEditor->GetStartChar()+nCurIndex;
	m_pEditor->SetSel(nStartChar, nStartChar+strSel.GetLength());
	
	CHARFORMAT	cfText = m_pEditor->GetCharFormat();
	cfText.crTextColor = crSel;
	m_pEditor->SetWordCharFormat(cfText);
	if (bReplace)
		m_pEditor->ReplaceSel(strSel);
}

void Colorize::SetLineColors(CString &pString, CTypedPtrArray<CPtrArray, void*> &pColors) 
{
	CString word, op;
	long i,j,k,l,s,e;
	BOOL remline;

	//test for a remark line
	m_strLine = pString;
	word = pString;
	word.TrimLeft();
	word.TrimRight();
	word = word.Left(1);
	if(word.CompareNoCase("#") == 0)
	{
		//set the line to all comment color
		for(i=0; i<pString.GetLength(); i++)
		{
			pColors.SetAtGrow(i, (void*)(COMMENT_COLOR));
		}
		
		SetSelColor(m_strLine, 0, COMMENT_COLOR);
		j = pString.GetLength();
	}
	else
	{
		//set the line to all black
		k = 0;
		j = pString.GetLength();
		for(i=0; i<j; i++)
		{
			pColors.SetAtGrow(i,(void*)(NORMAL_COLOR));
		}

		SetSelColor(m_strLine, 0, NORMAL_COLOR);

		while(k<j)
		{
			word.Empty();
			while((k<j) && (IsWhiteSpace(pString.GetAt(k))))
			{
				k++;
			}
			s = k;		
			
			while((k<j) && (!IsWhiteSpace(pString.GetAt(k))))
			{
				if(IsOperatorChar(pString.GetAt(k)))    //  ������ 2003.9.1(��) �α�
				{
					if(k>0)
					{
						if(!IsOperatorChar(pString.GetAt(k-1)) && !IsNumChar(pString.GetAt(k-1)))
						{
							int i=1, nCnt=0;
							CString tmp;

							while((k-i) >= 0 && !IsWhiteSpace(pString.GetAt(k-i)) && !IsOperatorChar(pString.GetAt(k-i)) && !IsNumChar(pString.GetAt(k-i)))
							{								
								nCnt++;
								i++;
							}
							i--;
							while(i)
							{
								tmp = tmp + pString.GetAt(k-i);
								i--;
							}

							if(IsKeyWord(tmp))
							{
								l = 0;
								
								for(i=k-tmp.GetLength(); i<k; i++)
								{
									pString.SetAt(i,tmp.GetAt(l));
									l++;
									pColors[i] = (void*)(KEYWORD_COLOR);
									SetSelColor((CString)pString.GetAt(i), i, KEYWORD_COLOR, TRUE);
								}
							}
							else if(IsSmartWord(tmp))
							{
								l = 0;
								for(i=k-tmp.GetLength(); i<k; i++)
								{
									pString.SetAt(i,tmp.GetAt(l));
									l++;					
									pColors[i] = (void*)(USER_COLOR);
									SetSelColor((CString)pString.GetAt(i), i, USER_COLOR, TRUE);
								}
							}
							else if(IsOperator(tmp))
							{
								l = 0;
								for(i=k-tmp.GetLength(); i<k; i++)
								{
									pString.SetAt(i, tmp.GetAt(l));
									l++;
									pColors[i] = (void*)(OPERATOR_COLOR);
									SetSelColor((CString)pString.GetAt(i), i, OPERATOR_COLOR);
								}
							}			
							
							pString.SetAt(k, pString.GetAt(k));
							pColors[k] = (void*)(OPERATOR_COLOR);
							SetSelColor((CString)pString.GetAt(k), k, OPERATOR_COLOR);
							k++;
							word.Empty();
							break;
						}						
						else
						{
							pString.SetAt(k, pString.GetAt(k));
							pColors[k] = (void*)(OPERATOR_COLOR);
							SetSelColor((CString)pString.GetAt(k), k, OPERATOR_COLOR);
							k++;
							s=k;
						}
					}
					else
					{
						pString.SetAt(k, pString.GetAt(k));
						pColors[k] = (void*)(OPERATOR_COLOR);
						SetSelColor((CString)pString.GetAt(k), k, OPERATOR_COLOR);
						k++;
						s=k;
					}
				}
				
				else if(IsNumChar(pString.GetAt(k)))    // ���� 2003.9.1(��) �α�
				{
					if(k>6)    //6�̻��϶�
					{
						CString strTmp;
						for(int m=k-7;m<k;m++)
							strTmp=strTmp+pString.GetAt(m);
						strTmp.TrimLeft();
						strTmp.TrimRight();

						if((strTmp.CompareNoCase("bhtotal") == 0 && pString.GetAt(k)=='5')
							|| (strTmp.CompareNoCase("shtotal") == 0 && pString.GetAt(k)=='5') ) 
						{
							if(!strTmp.CompareNoCase("bhtotal"))
								strTmp = "BHTotal";
							else
								strTmp = "SHTotal";

							pString.SetAt(k-7, strTmp[0]);
							pColors[k-7] = (void*)(USER_COLOR);
							pString.SetAt(k-6, strTmp[1]);
							pColors[k-6] = (void*)(USER_COLOR);
							pString.SetAt(k-5, strTmp[2]);
							pColors[k-5] = (void*)(USER_COLOR);
							pString.SetAt(k-4, strTmp[3]);
							pColors[k-4] = (void*)(USER_COLOR);
							pString.SetAt(k-3, strTmp[4]);
							pColors[k-3] = (void*)(USER_COLOR);
							pString.SetAt(k-2, strTmp[5]);
							pColors[k-2] = (void*)(USER_COLOR);
							pString.SetAt(k-1, strTmp[6]);
							pColors[k-1] = (void*)(USER_COLOR);
							pString.SetAt(k, pString.GetAt(k));
							pColors[k] = (void*)(USER_COLOR);
							
							strTmp = pString.GetAt(k) + strTmp;
							SetSelColor(strTmp, k-7, USER_COLOR);
							k++;
							s=k;							
						}
						else
						{
							CString strTmp;
							for(int m=k-4;m<k;m++)
								strTmp=strTmp+pString.GetAt(m);
							strTmp.TrimLeft();
							strTmp.TrimRight();
							if(strTmp.CompareNoCase("log1") == 0 && pString.GetAt(k)=='0') 
							{
								strTmp = "Log1";
								pString.SetAt(k-4, strTmp[0]);
								pColors[k-4] = (void*)(USER_COLOR);
								pString.SetAt(k-3, strTmp[1]);
								pColors[k-3] = (void*)(USER_COLOR);
								pString.SetAt(k-2, strTmp[2]);
								pColors[k-2] = (void*)(USER_COLOR);
								pString.SetAt(k-1, strTmp[3]);
								pColors[k-1] = (void*)(USER_COLOR);
								pString.SetAt(k, pString.GetAt(k));
								pColors[k] = (void*)(USER_COLOR);
	
								strTmp = pString.GetAt(k) + strTmp;
								SetSelColor(strTmp, k-4, USER_COLOR);
								k++;
								s=k;							
							}
							else
							{
								if(!IsWhiteSpace(pString.GetAt(k-1)))
								{
									if(IsOperatorChar(pString.GetAt(k-1)))
									{
										pString.SetAt(k, pString.GetAt(k));
										pColors[k] = (void*)(NUM_COLOR);
										SetSelColor((CString)pString.GetAt(k), k, NUM_COLOR);
										k++;
										s=k;
									}
									else
									{
										pString.SetAt(k, pString.GetAt(k));
										pColors[k] = pColors[k-1];
										SetSelColor((CString)pString.GetAt(k), k, (COLORREF)pColors[k-1]);
										k++;
										s=k;
									}
								}
								else
								{
									pString.SetAt(k, pString.GetAt(k));
									pColors[k] = (void*)(NUM_COLOR);
									SetSelColor((CString)pString.GetAt(k), k, NUM_COLOR);
									k++;
									s=k;
								}
							}							
						}					
						
					}
					else if (k>3 && k<=6)  //3���� ũ�� 6�����϶�
					{
						CString strTmp;
						for(int m=k-4;m<k;m++)
							strTmp=strTmp+pString.GetAt(m);
						strTmp.TrimLeft();
						strTmp.TrimRight();
						if(strTmp.CompareNoCase("log1") == 0 && pString.GetAt(k)=='0') 
						{
							strTmp = "Log1";
							pString.SetAt(k-4, strTmp[0]);
							pColors[k-4] = (void*)(USER_COLOR);
							pString.SetAt(k-3, strTmp[1]);
							pColors[k-3] = (void*)(USER_COLOR);
							pString.SetAt(k-2, strTmp[2]);
							pColors[k-2] = (void*)(USER_COLOR);
							pString.SetAt(k-1, strTmp[3]);
							pColors[k-1] = (void*)(USER_COLOR);
							pString.SetAt(k, pString.GetAt(k));
							pColors[k] = (void*)(USER_COLOR);
	
							strTmp = pString.GetAt(k) + strTmp;
							SetSelColor(strTmp, k-4, USER_COLOR);
							k++;
							s=k;							
						}
						else
						{
							if(!IsWhiteSpace(pString.GetAt(k-1)))
							{
								if(IsOperatorChar(pString.GetAt(k-1)))
								{
									pString.SetAt(k, pString.GetAt(k));
									pColors[k] = (void*)(NUM_COLOR);
									SetSelColor((CString)pString.GetAt(k), k, NUM_COLOR);
									k++;
									s=k;
								}
								else
								{
									pString.SetAt(k, pString.GetAt(k));
									pColors[k] = pColors[k-1];
									SetSelColor((CString)pString.GetAt(k), k, (COLORREF)pColors[k-1]);
									k++;
									s=k;
								}
							}
							else
							{
								pString.SetAt(k, pString.GetAt(k));
								pColors[k] = (void*)(NUM_COLOR);
								SetSelColor((CString)pString.GetAt(k), k, NUM_COLOR);
								k++;
								s=k;
							}
						}
					}
					
					else if(k>0 && k<=3)
					{
						if(!IsWhiteSpace(pString.GetAt(k-1)))
						{
							if(IsOperatorChar(pString.GetAt(k-1)))
							{
								pString.SetAt(k, pString.GetAt(k));
								pColors[k] = (void*)(NUM_COLOR);
								SetSelColor((CString)pString.GetAt(k), k, NUM_COLOR);
								k++;
								s=k;
							}
							else
							{
								pString.SetAt(k, pString.GetAt(k));
								pColors[k] = pColors[k-1];
								SetSelColor((CString)pString.GetAt(k), k, (COLORREF)pColors[k-1]);
								k++;
								s=k;
							}
						}
						else
						{
							pString.SetAt(k, pString.GetAt(k));
							pColors[k] = (void*)(NUM_COLOR);
							SetSelColor((CString)pString.GetAt(k), k, NUM_COLOR);
							k++;
							s=k;
						}						
					}
					else
					{
						pString.SetAt(k, pString.GetAt(k));
						pColors[k] = (void*)(NUM_COLOR);
						SetSelColor((CString)pString.GetAt(k), k, NUM_COLOR);
						k++;
						s=k;
					}
				}

				//======================================================
				else   // �׳� ����
				{
					
					int count = 0;

					int temp = k-1;					
					while(temp >= 0)
					{
						if(IsNumChar(pString.GetAt(temp)))
						{
							pColors[temp] = (void*)(NORMAL_COLOR);
							SetSelColor((CString)pString.GetAt(temp), temp, NORMAL_COLOR);
							temp--;
						}						
						else
							break;												
					}
					word = word + pString.GetAt(k);
					k++;					
				}
			}
			e = k;
			word.TrimLeft();
			word.TrimRight();
			if(IsKeyWord(word))
			{
				l = 0;
				for(i=s; i<e; i++)
				{
					pString.SetAt(i,word.GetAt(l));
					l++;
					pColors[i] = (void*)(KEYWORD_COLOR);						
					SetSelColor((CString)pString.GetAt(i), i, KEYWORD_COLOR, TRUE);
				}
			}
			else if(IsSmartWord(word))
			{
				l = 0;
				for(i=s; i<e; i++)
				{
					pString.SetAt(i,word.GetAt(l));
					l++;					
					pColors[i] = (void*)(USER_COLOR);
					SetSelColor((CString)pString.GetAt(i), i, USER_COLOR, TRUE);
				}
			}
			//2003.8.29(��) �α� ------------------------------
			else if(IsOperator(word))
			{
				l = 0;
				for(i=s; i<e; i++)
				{
					pString.SetAt(i, word.GetAt(l));
					l++;
					pColors[i] = (void*)(OPERATOR_COLOR);
					SetSelColor((CString)pString.GetAt(i), i, OPERATOR_COLOR);
				}
			}			
			//---------------------------------------------------
		}
	}

	//count up the number of single quote characters to see if
	//the tail end of the line is a comment line
	remline = FALSE;
	for(i=0; i<j; i++)
	{
		if(pString.GetAt(i) == 35)   //'#'���� - �ּ�ó��
		{
			remline = !remline;
			l = i;
		}
	}
	if(remline)
	{
		for(i=l; i<j; i++)
		{
			pColors.SetAtGrow(i,(void*)(COMMENT_COLOR));
		}
	}
}

BOOL Colorize::IsWhiteSpace(char pTest)
{
	//if(pTest < 65)	return TRUE;
	if(pTest < 65)  //2003.8.29(��) �α�
	{
		if(pTest == 33 || pTest == 37 || pTest == 42 || pTest == 43 || pTest == 45 || pTest == 46 ||  
			pTest == 47 || pTest == 58 || pTest == 60 || pTest == 61 || pTest == 62)   //������
			return FALSE;
		else if(pTest > 47 && pTest < 58)    //����
			return FALSE;
		else
			return TRUE;
	}
	
	return FALSE;
}

BOOL Colorize::IsOperatorChar(char pTest)   //2003.9.1(��) �α� 
{
	
	if(pTest == 33 || pTest == 37 || pTest == 42 || pTest == 43 || pTest == 45 || pTest == 47 ||
			pTest == 58 || pTest == 60 || pTest == 61 || pTest == 62)
		return TRUE;
	
	
	return FALSE;
}

BOOL Colorize::IsNumChar(char pTest)   //2003.9.1(��) �α� 
{
	if((pTest > 47 && pTest < 58) || pTest == 46 )
		return TRUE;
		
	return FALSE;
}

BOOL Colorize::IsKeyWord(CString & pTest)
{
	POSITION p;
	CString key;
	p = KeyWords.GetHeadPosition();
	while(p)
	{
		key = KeyWords.GetNext(p);
		if(m_bCaseSensitive)
		{
			if(pTest.Compare(key) == 0)
			{
				pTest = key;
				return TRUE;
			}
		}
		else
		{
			if(pTest.CompareNoCase(key) == 0)
			{
				pTest = key;
				return TRUE;
			}
		}
	}
	return FALSE;
}


BOOL Colorize::IsOperator(CString & pTest)    //2003.8.29(��) �α� 
{
	POSITION p;
	CString key;
	p = Operators.GetHeadPosition();
	while(p)
	{
		key = Operators.GetNext(p);
		
		if(pTest.CompareNoCase(key) == 0)
		{
			pTest = key;
			return TRUE;
		}
	}
	return FALSE;
}

BOOL Colorize::IsSmartWord(CString & pTest)
{
	POSITION p;
	CString key;
	p = SmartWords.GetHeadPosition();
	while(p)
	{
		key = SmartWords.GetNext(p);
		if(m_bCaseSensitive)
		{
			if(pTest.Compare(key) == 0)
			{
				pTest = key;
				return TRUE;
			}
		}
		else
		{
			if(pTest.CompareNoCase(key) == 0)
			{
				pTest = key;
				return TRUE;
			}
		}
	}
	return FALSE;
}

BOOL Colorize::IsTabPlusWord(CString & pTest)
{
	POSITION p;
	CString key;
	p = TabPlusWords.GetHeadPosition();
	while(p)
	{
		key = TabPlusWords.GetNext(p);
		if(m_bCaseSensitive)
		{
			if(pTest.Compare(key) == 0)
			{
				pTest = key;
				return TRUE;
			}
		}
		else
		{
			if(pTest.CompareNoCase(key) == 0)
			{
				pTest = key;
				return TRUE;
			}
		}
	}
	return FALSE;
}

BOOL Colorize::IsTabMinusWord(CString & pTest)
{
	POSITION p;
	CString key;
	p = TabMinusWords.GetHeadPosition();
	while(p)
	{
		key = TabMinusWords.GetNext(p);
		if(m_bCaseSensitive)
		{
			if(pTest.Compare(key) == 0)
			{
				pTest = key;
				return TRUE;
			}
		}
		else
		{
			if(pTest.CompareNoCase(key) == 0)
			{
				pTest = key;
				return TRUE;
			}
		}
	}
	return FALSE;
}

void Colorize::LoadKeyWords(CString &keywordsFile)
{
	FILE * infile;
	char buffer[512];
	CString inifile = keywordsFile;
	if(infile = fopen(inifile,"rb"))
	{
		while(!feof(infile))
		{
			fscanf(infile,"%s",buffer);
			if(buffer[0] == '+') //tab plus keyword
			{
				TabPlusWords.AddTail(buffer+1);
			}
			else if(buffer[0] == '-') //tab minus keyword
			{
				TabMinusWords.AddTail(buffer+1);
			}
			else if(buffer[0] == '&') //smartedit keyword
			{
				//2003.10.6  =======================
				CString strTmp;
				strTmp.GetBuffer(sizeof(buffer));
				strTmp = buffer;
				strTmp.ReleaseBuffer();

				if(strTmp.Find("=") < 0)
					SmartWords.AddTail(buffer+1);
				else
				{
					strTmp.Remove('&');
					strTmp.Remove('=');
					SmartWords.AddTail(strTmp);
				}
				//===================================

				//SmartWords.AddTail(buffer+1);				
				
			}
			else if(buffer[0] == '^') //2003.8.29(��) �α� operator keyword    
			{
				Operators.AddTail(buffer+1);
			}
			else//visual basic keyword
			{
				KeyWords.AddTail(buffer);
			}
		}
		fclose(infile);
	}
}

void CHilightTextWnd::ReLoadKeyWords(CString &keywordsFile)
{
	m_pColorize->KeyWords.RemoveAll();
	m_pColorize->SmartWords.RemoveAll();
	m_pColorize->TabPlusWords.RemoveAll();
	m_pColorize->TabMinusWords.RemoveAll();
	m_pColorize->Operators.RemoveAll();

	m_pColorize->LoadKeyWords(keywordsFile);
}

void CHilightTextWnd::DoCopy()
{
}

void CHilightTextWnd::DoPaste()
{
	int nLineCount = GetLineCount();

	for (int i = 0; i < nLineCount; i++)
	{
		ParseLine(i);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CHilightTextWnd message handlers

BOOL CHilightTextWnd::ValidateKey(UINT nChar)
{
	if (nChar == 16) return FALSE; //ignore all shift keys
	if (nChar == VK_PROCESSKEY || (nChar >= VK_PRIOR && nChar <= VK_DOWN) || 
		(nChar >= VK_SHIFT && nChar < VK_ESCAPE) ||
		(nChar >= VK_F1 && nChar <= VK_SCROLL) 
		) return FALSE;
	
	return TRUE;
}

void CHilightTextWnd::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	int ctrl = GetKeyState(VK_CONTROL);
	if(ctrl & 0xf0 ) //control key down
	{
		switch(nChar)
		{
		case 'Z': // undo
			{
			}
			break;
		case 'X': // Cut
			{
			}
			break;
		case 'C': // Copy
			{
			}
			break;
		case 'V': // Paste
			{
				//CRichEditCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
			    COleDataObject obj;
			    if (obj.AttachClipboard())
				{
					HGLOBAL hmem = obj.GetGlobalData(CF_TEXT);
					CMemFile sf((BYTE*) ::GlobalLock(hmem), ::GlobalSize(hmem));
					LPSTR szBuffer = new char[::GlobalSize(hmem)];
					if (!szBuffer)
						break;

					sf.Read(szBuffer, ::GlobalSize(hmem));
					::GlobalUnlock(hmem);
					CString strText = szBuffer;
					delete szBuffer;

					ReplaceSel(strText);
				}
				DoPaste();
			}
			return;//break;
		case 'A': // Select All
			{
			}
		default:
			break;
		}
	}

	CRichEditCtrl::OnKeyDown(nChar, nRepCnt, nFlags);

	if (m_nFirstVisibleLine != GetFirstVisibleLine())
	{
		m_nFirstVisibleLine = GetFirstVisibleLine();
		OnNcPaint();
	}

	m_bHanBegin = ((char)nChar & 0x80);

	if (!ValidateKey(nChar)) return;

	m_pParent->SendMessage(WM_FORMULACHANGED, 0, (LPARAM)(BOOL)GetModify());
}

void CHilightTextWnd::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	CRichEditCtrl::OnKeyUp(nChar, nRepCnt, nFlags);

	if (!ValidateKey(nChar)) return;

	if (GetModify())
		if (!m_bHanBegin)
			ParseLine(-1);
}

int CHilightTextWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}

void CHilightTextWnd::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	// TODO: Add your message handler code here
	CMenu popupmenu, *m_pMenu;
	popupmenu.LoadMenu(IDR_HILIGHTTEXT_POPUPMENU);	

	m_pMenu = popupmenu.GetSubMenu(0);
	int cmd = m_pMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RETURNCMD, point.x, point.y, this, NULL);
	switch (cmd)
	{
	case ID_POPUP_UNDO:
		Undo();
		break;
	case ID_POPUP_CUT:
		Cut();
		break;
	case ID_POPUP_COPY:
		Copy();
		break;
	case ID_POPUP_PASTE:
		Paste();
		break;
	case ID_POPUP_DEL:
		ReplaceSel("", TRUE);
		break;
	case ID_POPUP_SELLECTALL:
		SetSel(0, -1);
		break;
	}
}

void CHilightTextWnd::InsertText(LPCTSTR lpszString)
{
	ReplaceSel(lpszString);
	ParseLine();
	m_pParent->SendMessage(WM_FORMULACHANGED, 0, (LPARAM)(BOOL)GetModify());		
}

void CHilightTextWnd::SetText(LPCTSTR lpszString)
{
	SetWindowText(lpszString);
}

void CHilightTextWnd::ParseLine(int nLineIndex)
{
	if(nLineIndex == -1)
	{
		nLineIndex = LineFromChar(LineIndex(nLineIndex));
	}

	SetRedraw(FALSE);
	CString strOrg, strLineText, strTemp;
	int nLineLength = LineLength(LineIndex(nLineIndex));
	int nRead = GetLine(nLineIndex, strLineText.GetBuffer(nLineLength + 3), nLineLength+1);
	strLineText.ReleaseBuffer(nRead);
	//strLineText.SpanExcluding(_T("\n"));
	strOrg = strLineText;

	CHARRANGE crCurrent;
	GetSel(crCurrent);
	int nStartIndex	= LineIndex(nLineIndex);
	int nSelStart	= nStartIndex;
	//int nSelEnd;

	m_nStartChar = nSelStart;

	CTypedPtrArray<CPtrArray, void*> pColors;
	m_pColorize->SetLineColors(strLineText, pColors);
	/*
	SetSel(nStartIndex, nStartIndex + strOrg.GetLength());
	strLineText += "\0";
	//ReplaceSel(strLineText);

	//for(int i = 0; i < strLineText.GetLength(); i++)	
	int i = 0;
	while (i < strLineText.GetLength())	
	{
		nSelStart = nStartIndex + i; 

		for(int j = i; j < strLineText.GetLength(); j++)
		{
			nSelEnd	= nStartIndex + j;
			if (pColors[i] != pColors[j]) break;
		}

		m_cfText.crTextColor = (COLORREF)(pColors[i]);
		SetSel(nSelStart, nSelEnd);
		SetWordCharFormat(m_cfText);
		i = j;
	}
	*/
	SetRedraw(TRUE);
	Invalidate();//FALSE);
	SetSel(crCurrent);
}

UINT CHilightTextWnd::OnGetDlgCode() 
{
	return (UINT)DLGC_WANTALLKEYS;
}

void CHilightTextWnd::OnNcPaint() 
{
	Default();

	CWindowDC dc(this);
	CRect rcWindow, rcLeftMargin;
	GetWindowRect(&rcWindow);
	rcWindow -= rcWindow.TopLeft();
/*
	rcLeftMargin = rcWindow;
	InflateRect(&rcLeftMargin, -1, -1);
	
	int nFirstVisibleLine = GetFirstVisibleLine()+1;
	CString strLineNum;

	strLineNum.Format("%d", GetLineCount());
	CSize size = dc.GetTextExtent(strLineNum);

	if (m_nLeftMargin != size.cx)
		SetWindowPos(NULL, 0,0,0,0, SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE|SWP_FRAMECHANGED);
	
	m_nLeftMargin = size.cx;
	int nLineHeight = size.cy;

	rcLeftMargin.right = rcLeftMargin.left + m_nLeftMargin;

	int nVisibleLineCount = (int)(rcWindow.Height() / nLineHeight);
	if (nVisibleLineCount > GetLineCount()) nVisibleLineCount = GetLineCount();

	dc.FillSolidRect(rcLeftMargin, RGB(192, 192, 192));
	dc.SetBkMode(TRANSPARENT);

	for (int i = nFirstVisibleLine; i < nFirstVisibleLine+nVisibleLineCount; i++)
	{
		strLineNum.Format("%d", i);
		dc.DrawText(strLineNum, rcLeftMargin, DT_RIGHT|DT_SINGLELINE);
		rcLeftMargin.top += size.cy;

		if (i > GetLineCount()) break;
	}
*/
	CPen penBorder(PS_SOLID, 1, m_crBorder);
	CPen* pOldPen = dc.SelectObject(&penBorder);
	dc.SelectObject(GetStockObject(NULL_BRUSH));
	dc.Rectangle(rcWindow);
	dc.SelectObject(pOldPen);
	penBorder.DeleteObject();
}

void CHilightTextWnd::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	InflateRect(&lpncsp->rgrc[0], -1, -1);
/*
	CString strLineNum;
	strLineNum.Format("%d", GetLineCount());
	CDC *pDC = GetDC();
	m_nLeftMargin = pDC->GetTextExtent(strLineNum).cx;
	ReleaseDC(pDC);

	lpncsp->rgrc[0].left += m_nLeftMargin;
*/
	CRichEditCtrl::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void CHilightTextWnd::SetWindowText(LPCTSTR lpszString)
{
	CRichEditCtrl::SetWindowText(""); // ��ũ�ѹٸ� �ν��ϱ� ���� �ʱ�ȭ �۾�
	
	DWORD dwStyle = GetStyle();
	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, (dwStyle & ~ WS_VISIBLE));

	CString strText = lpszString;
	strText += "\n";
	CRichEditCtrl::SetWindowText(strText);

	if (dwStyle & WS_VISIBLE)
		SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	//OnNcPaint();

	int nLineCount = GetLineCount();

	for (int i = 0; i < nLineCount; i++)
	{
		ParseLine(i);
	}

	Invalidate();
	SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOZORDER | SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED | SWP_NOACTIVATE);
}

void CHilightTextWnd::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CRichEditCtrl::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CHilightTextWnd::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CRichEditCtrl::OnVScroll(nSBCode, nPos, pScrollBar);
/*
	int nScrollLine = 0;

	switch(nSBCode) 
	{
	case SB_LINEUP:
		nScrollLine = -1;
		break;
	case SB_LINEDOWN :
		nScrollLine = 1;
		break;
	case SB_PAGEUP :
		nScrollLine = -GetVisibleLineCount();
		break;
	case SB_PAGEDOWN :
		nScrollLine = GetVisibleLineCount();
		break;
	case SB_THUMBTRACK:
	case SB_THUMBPOSITION:
		{
			SCROLLINFO SI;
			SI.cbSize = sizeof(SI);
			SI.fMask = SIF_ALL;
			GetScrollInfo(SB_VERT, &SI);
			if (SI.nTrackPos <= 0) nScrollLine = 0;
			else if (SI.nTrackPos >= GetLineCount()) nScrollLine = GetLineCount();
			else nScrollLine = SI.nTrackPos;
		}
		break;
	case SB_BOTTOM :
		nScrollLine = GetLineCount();
		break;
	case SB_TOP :
		nScrollLine = 0;
		break;
	default:
		break;
	}

	LineScroll(nScrollLine);
	OnNcPaint();
*/
}

int CHilightTextWnd::GetVisibleLineCount() 
{
	CDC *pDC = GetDC();
	CRect rcWindow;
	GetWindowRect(&rcWindow);
	rcWindow -= rcWindow.TopLeft();
	CSize size = pDC->GetTextExtent("Wg");
	ReleaseDC(pDC);

	return (int)(rcWindow.Height() / size.cy);
}