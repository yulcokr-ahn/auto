#pragma once


class CGravatar : public CStatic
{
public:


	void SetEmail(const CString& strEmail);
	BOOL LoadGravatarImage();
	void Clear();

protected:
	CString m_strEmailHash;
	CImage  m_image; // �̹��� �����
	CString GetGravatarURL();
	CString HashEmail(const CString& strEmail);

	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};
