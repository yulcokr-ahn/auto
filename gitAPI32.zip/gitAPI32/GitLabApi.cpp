#include "stdafx.h"
#include "gitAPI32.h"
#include "GitLabApi.h"

CGitLabApi::CGitLabApi() //const utility::string_t& baseUrl) : m_client(baseUrl)
{
}

void LogWideStringChunks(const std::wstring& wstr)
{
	const int chunkSize = 1000;
	int len = (int)wstr.length();
	for (int i = 0; i < len; i += chunkSize)
	{
		CStringW chunk(wstr.substr(i, chunkSize).c_str());
		TRACE(L"%s", chunk.GetString());
	}
	TRACE(L"\n");
}


pplx::task<void> CGitLabApi::HttpGetGitLabList()
{
	http_client client( U("http:/127.0.0.1")); ///api/v4/projects/1/repository/tree"));

	return client.request(methods::GET)
		.then([](http_response response) -> pplx::task<std::wstring>
	{
		std::wostringstream stream;
		stream << L"AContent Type: " << response.headers().content_type() << std::endl;
		stream << L"Content Length: " << response.headers().content_length() << L" bytes" << std::endl;
		CStringW info(stream.str().c_str());

		TRACE(L"HttpGetAsync() =======================\r\n" );
		TRACE(L"HttpGetAsync() info=[%s]\r\n", info.GetString());

		return response.extract_string();
	})
		.then([](pplx::task<std::wstring> previousTask)
	{
		try
		{
			std::wstring result = previousTask.get();
			LogWideStringChunks(result);
		}
		catch (const std::exception& ex)
		{
			CStringA err(ex.what());
			TRACE("HTTP ERROR: %s\n", err.GetString());
		}
	});
}


void CGitLabApi::HandleJsonArray(const json::value& jsonVal)
{
	if (!jsonVal.is_array())	{
		std::wcout << L"JSON is not an array." << std::endl;	return;
	}
	// JSON ���ڿ� ���� (�迭 ����)
	const utility::string_t json_str; // = U(R"([{"id": 1, "name": "Alice"},{"id": 2, "name": "Bob"},{"id": 3, "name": "Charlie"}])");
	try
	{
		web::json::value json_val = jsonVal; //web::json::value::parse(json_str);
		if (json_val.is_array())
		{
			size_t arr_size = json_val.size();
			for (size_t i = 0; i < arr_size; ++i)
			{
				web::json::value item = json_val[i];	// �� ��Ұ� ��ü���� Ȯ��
				if (item.is_object())	{
					int id = item[U("id")].as_integer();
					utility::string_t name = item[U("name")].as_string();	// ��� (wide char -> narrow char ��ȯ)
					std::wcout << L"id: " << id << L", name: " << name << std::endl;
				}
			}
		}
		else
		{
			std::cout << "JSON value is not an array." << std::endl;
		}
	}
	catch (const std::exception& e)
	{
		std::cerr << "Exception while parsing JSON: " << e.what() << std::endl;
	}



}
