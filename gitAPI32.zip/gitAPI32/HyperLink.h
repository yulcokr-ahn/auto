#pragma once
class CHyperLink : public CStatic
{
public:
	CHyperLink();
	void SetURL(const CString& strURL);

protected:
	CString m_strURL;
	CFont   m_font;
	HCURSOR m_hCursor;

	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);

	DECLARE_MESSAGE_MAP()
};

