﻿Visual Studio 2010
cpprestsdk (REST API 연동 가능)
AppendCommitToList() commit 히스트리 업데이타 하고
크릭시 OnClickLoglist() 해당 정보를 조회후  외부 Diff 툴은 TortoiseGitMerge.exe 	
실행 비교 검증 코드를 작성 해줘

				{ "diff" : ""@@ -0" } 
				{ "new_path" : "CommitDlg.cpp" }
				{ "old_path" : "CommitDlg.cpp" }
				{ "a_mode" : "0" }
				{ "b_mode" : "100644" }
				{ "new_file" : "true" }
				{ "renamed_file" : "false" }
				{ "deleted_file" : "false" }
				{ "generated_file" : "null" }

http://127.0.0.1/api/v4/projects/root%2Fhtsmts/repository/commits


void CHistory::AppendCommitToList(CString nm ,const web::json::value& commit)
{
	int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), short_id);
	m_LogList.SetItemText(nItem, 1, author_name);
	m_LogList.SetItemText(nItem, 2, parsedTime); //m_LogList.SetItemText(nItem, 2, authored_date);
	m_LogList.SetItemText(nItem, 3, title);
	if( nm.GetLength() > 0)
	m_LogList.SetItemText(nItem, 4, nm);
}

void CHistory::OnClickLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	*pResult = 0;
}



// History.cpp : 구현 파일
//

#include "stdafx.h"
#include "gitAPI32.h"
#include "History.h"
#include "afxdialogex.h"
#include "GitLabApi.h"


BOOL CHistory::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.

	//m_LogList.ModifyStyle(0, LVS_REPORT);
	// Grid 칼럼 설정
	m_LogList.InsertColumn(0, _T("Short ID"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(1, _T("Author"), LVCFMT_LEFT, 120);
	m_LogList.InsertColumn(2, _T("Date"), LVCFMT_LEFT, 150);
	m_LogList.InsertColumn(3, _T("Title"), LVCFMT_LEFT, 300);
	m_LogList.InsertColumn(4, _T("file"), LVCFMT_LEFT, 200);
	m_LogList.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

//////1.다운로드  /////////////////////////////////////////////////////////////
	json::value Outjson;
/*
	std::vector<CString> files= theApp.m_RGA.GitLab_GetRepositoryTree2(Outjson);
	theApp.m_RGA.TraceJson5(__FUNCTION__, Outjson);
	try
	{
		size_t len = files.size();  // 오래된 버전에서는 size() 제공
		for (size_t i = 0; i < len; ++i)
		{
			TRACE("OnInitDialog(%d)    name=[%s] \r\n",i , files[i] );
			CString sbranch= "Master";
			CString rawPath =files[i]; // UrlEncode((CString)files[i]);
			theApp.m_RGA.DownloadGitlabFile( CString(g_tPROJECTPATH.c_str()) , rawPath , sbranch,CString(g_tPRIVATE_TOKEN.c_str())  );
		}
	}
	catch ( const std::exception &e )
	{
		printf("Error exception:%s\n", e.what());
	}
	getchar();
*/

/*
/////2.OK 커밋 파일 올리기 ////////////////////////////////////////////////////////////////////////////////
	std::string projectId = g_tPROJECTPATH; //"your_project_id"; // 예: "123456" CString(g_tPROJECTPATH.c_str());
	std::string branch = "main";
	std::string filePath = "GitLabApi.obj";
	std::string commitMessage = "Add new file bin2 ";
	commitFileToGitLab(projectId, branch, filePath, commitMessage, (string)privateToken);
*/
////커밋 내용 가져 오기 


	g_Outjson=  web::json::value::object(); //초기화
	std::vector<CString> files2= theApp.m_RGA.get_commits_and_files(g_Outjson); //.wait();
	theApp.m_RGA.TraceJson5(__FUNCTION__, g_Outjson);

	web::json::value jsonCommits = g_Outjson; //TraceJson5[U("get_commits_and_files")];  // 람다 결과
	LoadCommits(files2,jsonCommits);

	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

CString ParseISO8601DateTime(const CString& isoString) // 예: "2025-06-10T14:40:23.000+00:00"
{
	CString result;
	int tPos = isoString.Find('T');
	if (tPos == -1)
		return isoString; // 형식이 이상하면 원문 반환
	CString datePart = isoString.Left(tPos);                  // "2025-06-10"
	CString timePart = isoString.Mid(tPos + 1);               // "14:40:23.000+00:00"
	int dotPos = timePart.Find('.'); // 시간 끝 위치를 잘라내기 ('.' 또는 '+' 또는 'Z'까지)
	if (dotPos == -1)
		dotPos = timePart.Find('+');
	if (dotPos == -1)
		dotPos = timePart.Find('Z');
	if (dotPos != -1)
		timePart = timePart.Left(dotPos);                     // "14:40:23"
	result.Format(_T("%s %s"), datePart, timePart);           // "2025-06-10 14:40:23"
	return result;
}
/*
[CHistory::OnInitDialog][TraceJson5] Record 4:
{ "id" : "b2dfb6ade51f4945066e09f124a3efe4652a6d96" }
{ "short_id" : "b2dfb6ad" }
{ "created_at" : "2025-06-12T17:59:41.000+00:00" }
{ "parent_ids" : "["3e62de451267381bff63ec9e9ddcf9834ffe5132"]" }
{ "title" : "dfgbfdbdh" }
{ "message" : "dfgbfdbdh" }
{ "author_name" : "Administrator" }
{ "author_email" : "gitlab_admin_7d831e@example.com" }
{ "authored_date" : "2025-06-12T17:59:41.000+00:00" }
{ "committer_name" : "Administrator" }
{ "committer_email" : "gitlab_admin_7d831e@example.com" }
{ "committed_date" : "2025-06-12T17:59:41.000+00:00" }
{ "trailers" : "{" }
*/
void CHistory::AppendCommitToList(CString nm ,const web::json::value& commit)
{
	if (!commit.is_object()) return;
	CString id , short_id(""), created_at,parent_ids,title(""), message, author_name(""),author_email,authored_date,committer_name,committer_email, committed_date("");
	if (commit.has_field(L"id"))
		id = commit[L"id"].as_string().c_str();
	if (commit.has_field(L"short_id"))
		short_id = commit[L"short_id"].as_string().c_str();
	if (commit.has_field(L"created_at"))
		created_at = commit[L"created_at"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
	if (commit.has_field(L"title"))
		title = commit[L"title"].as_string().c_str();
	if (commit.has_field(L"message"))
		message = commit[L"message"].as_string().c_str();
	if (commit.has_field(L"author_name"))
		author_name = commit[L"author_name"].as_string().c_str();
	if (commit.has_field(L"author_email"))
		author_email = commit[L"author_email"].as_string().c_str();
	if (commit.has_field(L"authored_date"))
		authored_date = commit[L"authored_date"].as_string().c_str();
	if (commit.has_field(L"committer_name"))
		committer_name = commit[L"committer_name"].as_string().c_str();
	if (commit.has_field(L"committer_email"))
		committer_email = commit[L"committer_email"].as_string().c_str();
	if (commit.has_field(L"committed_date"))
		committed_date = commit[L"committed_date"].as_string().c_str();
	CString parsedTime = ParseISO8601DateTime(authored_date);
	int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), short_id);
	m_LogList.SetItemText(nItem, 1, author_name);
	m_LogList.SetItemText(nItem, 2, parsedTime); //m_LogList.SetItemText(nItem, 2, authored_date);
	m_LogList.SetItemText(nItem, 3, title);
	if( nm.GetLength() > 0)
	m_LogList.SetItemText(nItem, 4, nm);
}

void CHistory::LoadCommits( std::vector<CString> &fi ,const json::value& commitsArray)
{
	if (!commitsArray.is_array())
		return;
	CString file;
	size_t length = commitsArray.size();  // 배열 길이 가져오기
	for (size_t i = 0; i < length; ++i)
	{
		if (i < fi.size() )
			file = fi[i];
		else
			file = "";
		json::value item = commitsArray[i];
		if (item.is_object())
		{
			AppendCommitToList(file, item);  // 각 커밋을 처리
		}
	}
}


CHistory::CHistory(CWnd* pParent )	: CDialogEx(CHistory::IDD, pParent) {
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}
void CHistory::DoDataExchange(CDataExchange* pDX){
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LOGLIST, m_LogList);
/*
	DDX_Control(pDX, IDC_LOGMSG, m_ChangedFileListCtrl);
	DDX_Control(pDX, IDC_PROGRESS, m_LogProgress);
	DDX_Control(pDX, IDC_SPLITTERTOP, m_wndSplitter1);
	DDX_Control(pDX, IDC_SPLITTERBOTTOM, m_wndSplitter2);
	DDX_Text(pDX, IDC_SEARCHEDIT, m_sFilterText);
	DDX_Control(pDX, IDC_DATEFROM, m_DateFrom);
	DDX_Control(pDX, IDC_DATETO, m_DateTo);
	DDX_Control(pDX, IDC_LOG_JUMPTYPE, m_JumpType);
	DDX_Control(pDX, IDC_LOG_JUMPUP, m_JumpUp);
	DDX_Control(pDX, IDC_LOG_JUMPDOWN, m_JumpDown);
	DDX_Text(pDX, IDC_LOGINFO, m_sLogInfo);
	DDX_Check(pDX, IDC_LOG_ALLBRANCH,m_bAllBranch);
	DDX_Check(pDX, IDC_WHOLE_PROJECT, m_bWholeProject);
	DDX_Control(pDX, IDC_WALKBEHAVIOUR, m_ctrlWalkBehavior);
	DDX_Control(pDX, IDC_VIEW, m_ctrlView);
	DDX_Control(pDX, IDC_SEARCHEDIT, m_cFilter);
	DDX_Control(pDX, IDC_STATIC_REF, m_staticRef);
	DDX_Control(pDX, IDC_PIC_AUTHOR, m_gravatar);
	DDX_Control(pDX, IDC_FILTER, m_cFileFilter);
*/
}
BEGIN_MESSAGE_MAP(CHistory, CDialogEx)
//	ON_WM_SYSCOMMAND()
//	ON_WM_PAINT()
//	ON_WM_QUERYDRAGICON()
//	ON_BN_CLICKED(IDOK, &CHistory::OnBnClickedOk)
	ON_NOTIFY(NM_CLICK, IDC_LOGLIST, &CHistory::OnClickLoglist)
	ON_NOTIFY(NM_DBLCLK, IDC_LOGLIST, &CHistory::OnDblclkLoglist)
END_MESSAGE_MAP()
void CHistory::OnSysCommand(UINT nID, LPARAM lParam) {
	if ((nID & 0xFFF0) == IDM_ABOUTBOX) {
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else {
		CDialogEx::OnSysCommand(nID, lParam);
	}
}
void CHistory::OnPaint()
{
	if (IsIconic()) {
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else {
		CDialogEx::OnPaint();
	}
}
HCURSOR CHistory::OnQueryDragIcon(){
	return static_cast<HCURSOR>(m_hIcon);
}
void CHistory::OnBnClickedOk()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CDialogEx::OnOK();
}




CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD){
}
void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialogEx::DoDataExchange(pDX);
}
BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


//CString privateToken =_T("glpat-qYj17RdNrDxAWKqvt16o"); // ← 실제 토큰으로 교체
//CString projectPath = _T("root%2Fhtsmts");
//CString projectID_Path  = _T("root%2Fhtsmts");
//CString Content_Type =_T("application/json");
//CString apiUrl(_T("http://127.0.0.1"));	
/*
CString downloadUrl;
downloadUrl.Format(_T("http://localhost/api/v4/projects/%s/repository/files/%s/raw."),projectPath, rawPath); //	downloadUrl.Format(_T("http://localhost/api/v4/projects/%s/repository/files/%s/raw?ref=%s"),projectPath, rawPath, branch);
CStringA apiUrlA = downloadUrl; // ANSI 문자열
std::wstring apiUrlW;
int len = MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, NULL, 0);
if (len > 0) {	wchar_t* buf = new wchar_t[len];
MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, buf, len);
apiUrlW = buf;	delete[] buf;
}
*/
/*
CString apiUrl2;	
apiUrl2.Format(_T("/api/v4/projects/%s/repository/tree"), projectID_Path);
CStringA apiUrlB = apiUrl2; // ANSI 문자열
std::wstring apiUrlW2;
int len2 = MultiByteToWideChar(CP_ACP, 0, apiUrlB.GetString(), -1, NULL, 0);
if (len2 > 0) {	wchar_t* buf2 = new wchar_t[len2];
MultiByteToWideChar(CP_ACP, 0, apiUrlB.GetString(), -1, buf2, len2);
apiUrlW2 = buf2;	delete[] buf2;
}
*/

/*
CStringA apiUrlA = apiUrl; // ANSI 문자열
std::wstring apiUrlW;
int len = MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, NULL, 0);
if (len > 0) {	wchar_t* buf = new wchar_t[len];
MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, buf, len);
apiUrlW = buf;	delete[] buf;
}
*/
//CString privateToken = _T("glpat-qYj17RdNrDxAWKqvt16o"); // 실제 토큰으로 교체
//utility::string_t g_tPROJECTID = U("root");
//utility::string_t g_tPROJECTPATH = U("htsmts");
//CString projectID_Path  = _T("root%2Fhtsmts");
//CString Content_Type =_T("application/json");
//std::string apiUrl = "http://localhost/api/v4/projects/" + projectId + "/repository/commits";
/*
ref_name	브랜치 이름 (예: main, master)
	path	특정 파일 또는 폴더 경로의 커밋만
	since	ISO 8601 포맷 시작일자 (2024-01-01T00:00:00Z)
	until	끝나는 일자
	author	작성자 필터
	per_page	페이지당 커밋 수 (기본 20, 최대 100)
	page	페이지 번호

ref_name=main	git log main
	path=src/index.js	git log -- src/index.js
	since=2024-01-01	git log --since="2024-01-01"
	until=2024-05-01	git log --until="2024-05-01"
	author=홍길동	git log --author="홍길동"
	per_page=10	git log -n 10



	1. 브랜치 기준 커밋:
	git log origin/main --oneline

	2. 특정 경로에 대한 커밋:
	git log -- path/to/file

	3. 기간 필터링:
	git log --since="2024-01-01" --until="2024-05-26"

	4. JSON 스타일 출력 (파싱용):
	git log --pretty=format:'{"hash":"%H","author":"%an","date":"%ad","message":"%s"},'




	🔄 GitLab REST API vs Git 명령어 비교
	목적	                GitLab REST API	Git CLI
	원격 저장소 커밋 보기	✅ 가능	        ❌ (로컬 복제 필요)
	특정 브랜치 커밋 보기	✅ ref_name	    ✅ git log 브랜치명
	특정 파일 커밋 보기	    ✅ path=	    ✅ git log -- path
	날짜 필터링	            ✅ since, until	✅ --since, --until
	작성자 필터	            ✅ author	    ✅ --author
*/
//커피원가 120원 사기를 궁리중
/*
int get_commits_and_files()
{
	// GitLab 설정
	utility::string_t base_url = U("https://localhost.com/api/v4");
	utility::string_t project_id =  U("root%2Fhtsmts");  // 예: "12345678"
	utility::string_t g_tPRIVATE_TOKEN = U("glpat-qYj17RdNrDxAWKqvt16o"); // GitLab Personal Access Token
	// API 요청 URL 구성
	utility::string_t request_url = base_url + U("/projects/") + uri::encode_data_string(project_id) + U("/repository/commits");

	// HTTP 클라이언트
	http_client client(request_url);
	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);

	try
	{
		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{
			json::value json_response = response.extract_json().get();

			if (json_response.is_array())
			{
				size_t len = json_response.size();

				for (size_t i = 0; i < len; ++i)
				{
					json::value commit = json_response[i];

					if (commit.has_field(U("id")) && commit.has_field(U("title")))
					{
						utility::string_t commit_id = commit[U("id")].as_string();
						utility::string_t commit_title = commit[U("title")].as_string();


						CString id2(commit[U("id")].as_string().c_str());
						CString message2(commit[U("title")].as_string().c_str());
						TRACE("get_commits_and_files(%d)  id=[%s]  message=[%s] \r\n",i ,id2, message2 );


						// 변경된 파일 보기
						utility::string_t diff_url = base_url + U("/projects/") + uri::encode_data_string(project_id)+ U("/repository/commits/") + commit_id + U("/diff");

						http_client diff_client(diff_url);
						http_request diff_request(methods::GET);
						diff_request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);

						http_response diff_response = diff_client.request(diff_request).get();
						if (diff_response.status_code() == status_codes::OK)
						{
							json::value diff_json = diff_response.extract_json().get();
							if (diff_json.is_array())
							{
								size_t diff_len = diff_json.size();
								for (size_t j = 0; j < diff_len; ++j)
								{
									json::value diff_item = diff_json[j];
									if (diff_item.has_field(U("new_path")))
									{
										utility::string_t file_path = diff_item[U("new_path")].as_string();
										//std::wcout << L"  - " << file_path << std::endl;



										CString file_path2(diff_item[U("new_path")].as_string().c_str());
										TRACE("  - %s \r\n",file_path2);


									}
								}
							}
						}
						else
						{
							std::wcout << L"  [Error] Diff 실패: " << diff_response.status_code() << std::endl;
						}
					}
				}
			}
		}
		else
		{
			std::wcout << L"[Error] HTTP 실패: " << response.status_code() << std::endl;
		}
	}
	catch (const std::exception& ex)
	{
		std::wcout << L"[예외 발생] " << ex.what() << std::endl;
	}

	return 0;
}
*/
/*
void commitFileToGitLab(const std::string& projectId,
	const std::string& branch,
	const std::string& filePath,
	const std::string& commitMessage,
	const std::string& privateToken) {
		// GitLab API URL 구성
		std::string apiUrl = "http://localhost/api/v4/projects/" + projectId + "/repository/commits";

		// 파일 내용 읽기
		std::string fileContent = readFileContent(filePath);

		// JSON 요청 본문 구성
		json::value requestBody;
		requestBody[U("branch")] = json::value::string(utility::conversions::to_string_t(branch));
		requestBody[U("commit_message")] = json::value::string(utility::conversions::to_string_t(commitMessage));

		// actions 배열 구성
		json::value action;
		action[U("action")] = json::value::string(U("create"));
		action[U("file_path")] = json::value::string(utility::conversions::to_string_t(filePath));
		action[U("content")] = json::value::string(utility::conversions::to_string_t(fileContent));

		json::value actions = json::value::array();
		actions[0] = action;
		requestBody[U("actions")] = actions;


		// HTTP 클라이언트 및 요청 설정
		http_client client(utility::conversions::to_string_t(apiUrl));
		http_request request(methods::POST);
		request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t(privateToken));
		request.headers().add(U("Content-Type"), U("application/json"));
		request.set_body(requestBody);

		client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>> {
			if (response.status_code() == status_codes::OK || response.status_code() == status_codes::Created) {
				std::wcout << L"✅ 커밋이 성공적으로 생성되었습니다." << std::endl;
			} else {
				std::wcout << L"❌ 커밋 실패. 상태 코드: " << response.status_code() << std::endl;
			}

			return response.extract_vector(); // 이 반환 타입이 반드시 맞아야 함

		}).then([](std::vector<unsigned char> data) {
			std::wcout << L"🔍 데이터 크기: " << data.size() << L" 바이트" << std::endl;
		}).wait();

/*
		client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>>
		{
			if (response.status_code() == status_codes::Created)		{
					std::wcout << L"✅ 커밋이 성공적으로 생성되었습니다." << std::endl;
				return response.extract_vector(); // 바이너리 데이터 추출
			}
			else
			{
				std::wcout << L"❌ 커밋 생성 실패. 상태 코드: " << response.status_code() << std::endl;
				response.extract_string().then([](utility::string_t body) {
					std::wcout << L"응답 본문: " << body << std::endl;
				}).wait();
				return response.extract_vector(); // 바이너리 데이터 추출
			}
		})
			.then([=](pplx::task<std::vector<unsigned char>> previousTask)
		{
			try
			{
				std::vector<unsigned char> fileData = previousTask.get();
				if (!fileData.empty())
				{
					std::ofstream outFile(filePath, std::ios::binary);
					outFile.write((const char*)fileData.data(), fileData.size());
					outFile.close();
					std::wcout << L"파일 저장 완료." << std::endl;
				}
				else
				{
					std::wcout << L"다운로드된 데이터가 비어 있습니다." << std::endl;
				}
			}
			catch (const std::exception& e)
			{
				std::cerr << "예외 발생: " << e.what() << std::endl;
			}
		})
			.wait(); // VS2010에서는 반드시 wait() 호출 필요 (비동기 동기화)

}
*/
/*
git clone http://root:glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr%2BWxvqrFY%3D@127.0.0.1/root/htspro.git
curl -X POST http://127.0.0.1/api/v4/projects -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro2\"}"
curl -X POST http://127.0.0.1/api/v4/projects -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro\"}"
curl -X POST http://127.0.0.1/api/v4/projects -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro\"}"
//root: BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=
//git clone http://root:BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=@127.0.0.1/root/htspro.git
curl -X POST -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro\"}" http://127.0.0.1/api/v4/projects
curl -X POST -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro\"}" http://root:glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr%2BWxvqrFY%3D@127.0.0.1/root/htspro.git
@echo off
	set TOKEN=glpat-여기에_당신의_토큰_입력
	set PROJECT_NAME=htspro
	set API_URL=http://127.0.0.1/api/v4/projects
curl -X POST ^
	-H "PRIVATE-TOKEN: %TOKEN%" ^
	-H "Content-Type: application/json" ^
	-d "{\"name\": \"%PROJECT_NAME%\"}" ^
	%API_URL%
	pause
*/


// History.cpp : 구현 파일입니다.
//
/*
#include "stdafx.h"
#include "gitAPI32.h"
#include "History.h"
#include "afxdialogex.h"


// CHistory 대화 상자입니다.

IMPLEMENT_DYNAMIC(CHistory, CDialogEx)

CHistory::CHistory(CWnd* pParent )
	: CDialogEx(CHistory::IDD, pParent)
{

}

CHistory::~CHistory()
{
}

void CHistory::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CHistory, CDialogEx)
END_MESSAGE_MAP()


// CHistory 메시지 처리기입니다.
*/



void CHistory::OnClickLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	*pResult = 0;
}


void CHistory::OnDblclkLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	*pResult = 0;
}
