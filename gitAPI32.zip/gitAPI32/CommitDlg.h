
#pragma once
#include <afxcmn.h>
#include <afxwin.h>
#include "Resource.h"
class CCommitDlg : public CDialog
{
	DECLARE_DYNAMIC(CCommitDlg)

public:
	CCommitDlg(CWnd* pParent = NULL);
	virtual ~CCommitDlg();

	enum { IDD = IDD_COMMITDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	DECLARE_MESSAGE_MAP()

public:
	CEdit m_logMsgCtrl; // CRichEditCtrl m_logMsgCtrl; // Rich Edit Control ����
	CString m_strCommitMsg;      // Ŀ�� �޽��� ����� ���
	CString m_strBugID;
	CString m_strAuthor;
	BOOL m_bNewBranch;
	CString m_strNewBranchName;

	CString m_projectID;
	CString m_accessToken;
	CListCtrl m_fileList;

	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedRefresh();
	void RefreshFileList();
	BOOL CommitToGitLab();
};
