// HyperLink.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "gitAPI32.h"
#include "HyperLink.h"

BEGIN_MESSAGE_MAP(CHyperLink, CStatic)
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
END_MESSAGE_MAP()

CHyperLink::CHyperLink()
{
	m_hCursor = AfxGetApp()->LoadStandardCursor(IDC_HAND);
}

void CHyperLink::SetURL(const CString& strURL)
{
	m_strURL = strURL;
}

void CHyperLink::OnLButtonDown(UINT, CPoint)
{
	ShellExecute(NULL, _T("open"), m_strURL, NULL, NULL, SW_SHOWNORMAL);
}

BOOL CHyperLink::OnSetCursor(CWnd*, UINT, UINT)
{
	::SetCursor(m_hCursor);
	return TRUE;
}
