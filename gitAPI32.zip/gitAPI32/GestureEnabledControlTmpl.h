#pragma once

#include <afxwin.h>
#include <windows.h>
#include <winuser.h> // GESTUREINFO ��

//template <class T>
class CGestureEnabledControlTmpl //: public T
{
public:
	CGestureEnabledControlTmpl() {}
	virtual ~CGestureEnabledControlTmpl() {}

protected:
//	afx_msg BOOL OnGestureNotify(UINT dwFlags, CPoint ptTouch);
//	afx_msg LRESULT OnGesture(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};
/*
template <class T>

BEGIN_MESSAGE_MAP(CGestureEnabledControlTmpl<T>, T)
	ON_MESSAGE(WM_GESTURE, &CGestureEnabledControlTmpl<T>::OnGesture)
	ON_MESSAGE(WM_GESTURENOTIFY, &CGestureEnabledControlTmpl<T>::OnGestureNotify)
END_MESSAGE_MAP()
*/
/*
BOOL CGestureEnabledControlTmpl::OnGestureNotify(UINT dwFlags, CPoint ptTouch)
{
	// ��ġ ����ó �غ� �޽��� ���� ó�� (�ʿ�� ����)
	return FALSE;
}


LRESULT CGestureEnabledControlTmpl::OnGesture(WPARAM wParam, LPARAM lParam)
{
	GESTUREINFO gi = { sizeof(GESTUREINFO) };
	if (GetGestureInfo((HGESTUREINFO)lParam, &gi))
	{
		switch (gi.dwID)
		{
		case GID_ZOOM:
			// Ȯ��/��� ó��
			break;
		case GID_PAN:
			// �̵� ó��
			break;
		case GID_ROTATE:
			// ȸ�� ó��
			break;
		case GID_TWOFINGERTAP:
			// �� �հ��� �� ó��
			break;
		case GID_PRESSANDTAP:
			// ������ �� ó��
			break;
		default:
			break;
		}

		CloseGestureInfoHandle((HGESTUREINFO)lParam);
	}
	return 0;
}
*/