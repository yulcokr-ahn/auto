﻿#include "stdafx.h"
#include "CommitDlg.h"
#include "afxdialogex.h"
#include "RestGitApi.h"
#include "gitAPI32.h"


IMPLEMENT_DYNAMIC(CCommitDlg, CDialog)

	CCommitDlg::CCommitDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCommitDlg::IDD, pParent), m_bNewBranch(FALSE)
{
}

CCommitDlg::~CCommitDlg() { }

void CCommitDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LOGMSG, m_logMsgCtrl); //DDX_Text(pDX, IDC_LOGMESSAGE, m_strCommitMsg);
	DDX_Text(pDX, IDC_BUGID, m_strBugID);
	DDX_Text(pDX, IDC_COMMIT_AUTHORDATA, m_strAuthor);
	DDX_Check(pDX, IDC_CHECK_NEWBRANCH, m_bNewBranch);
	DDX_Text(pDX, IDC_NEWBRANCH, m_strNewBranchName);
	DDX_Control(pDX, IDC_FILELIST, m_fileList);

	if (pDX->m_bSaveAndValidate) 
	{
		m_logMsgCtrl.GetWindowText(m_strCommitMsg);
	}
	else 
	{
		m_logMsgCtrl.SetWindowText(m_strCommitMsg);
	}
}

BEGIN_MESSAGE_MAP(CCommitDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CCommitDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_REFRESH, &CCommitDlg::OnBnClickedRefresh)
END_MESSAGE_MAP()

BOOL CCommitDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	AfxInitRichEdit2();
	m_logMsgCtrl.SetFont(&CFont()); 
	m_logMsgCtrl.SendMessage(EM_EXLIMITTEXT, 0, (LPARAM)4000); 
	SetWindowText(_T("Commit!!!!!!!!"));

	m_fileList.SetExtendedStyle(LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT);
	m_fileList.InsertColumn(0, _T("파일 경로"), LVCFMT_LEFT, 300);

	RefreshFileList();

	// git diff 명령 실행
	CString gitDiffOutput;
	CString cmd;
	CString gitDir = "D:\\gittest\\htsmts";
	cmd.Format("cd /d \"%s\" && git.exe diff", CStringA(gitDir));
	FILE* pipe = _popen(cmd, "r");
	if (pipe)
	{
		char buffer[128];
		std::string result;
		while (fgets(buffer, sizeof(buffer), pipe) != nullptr)
		{
			result += buffer;
		}
		_pclose(pipe);
		// 멀티바이트 -> CString 변환 (유니코드 빌드 기준)
		gitDiffOutput = CString(CA2W(result.c_str()));
	}

	// 파싱
	std::vector<GitDiffLine2> parsedLines = theApp.m_RGA.ParseGitDiffOutput(gitDiffOutput);
	// 출력
	for (size_t i = 0; i < parsedLines.size(); ++i)
	{
		const GitDiffLine2 & line = parsedLines[i];
		TRACE(_T("Line type: %d, Content: %s\n"), line.type, line.content);
	}

	return TRUE;
}

void CCommitDlg::OnBnClickedRefresh()
{
	RefreshFileList();
}

void CCommitDlg::RefreshFileList()
{
	m_fileList.DeleteAllItems();
	CStringArray arr;
	arr.Add(_T("CommitDlg.cpp"));	
	for (int i = 0; i < arr.GetSize(); i++)
		m_fileList.InsertItem(i, arr[i]);

	bool m_bCommitMessageOnly = TRUE;

	const int nListItems = m_fileList.GetItemCount();
	for (int i = 0; i < nListItems && m_bCommitMessageOnly; ++i)
	{
		CString filePath = m_fileList.GetItemText(i, 0);
		bool dirty = false;
		CString cmd, output;

		char buffer[1024] = {0};
		CString gitDir = "D:\\gittest\\htsmts";
		cmd.Format("cd /d \"%s\" && git.exe diff", CStringA(gitDir));
		FILE* fp = _popen(cmd, "r");
		if (fp) {
			theApp.m_RGA.parse_git_diff_output(fp);
			_pclose(fp);
		} else {
			MessageBox("git 명령 실행 실패", "오류", MB_ICONERROR);
		}
		dirty = CString(buffer);
		if (dirty)
		{
			CString message;
			message.Format("파일 %s 에 변경 사항이 있습니다. 커밋하시겠습니까?", filePath);
			const int result = 1;
//			const int result = CMessageBox::Show(m_hWnd, message, IDS_APPNAME, 1, IDI_QUESTION, IDS_PROGRS_CMD_COMMIT, IDS_MSGBOX_IGNORE, IDS_MSGBOX_CANCEL);
			if (result == 1)
			{
				CString cmdCommit;
				cmdCommit.Format("/command:commit /path:\"%s\"", filePath);
//				CAppUtils::RunTortoiseGitProc(cmdCommit);
				return;
			}
			else if (result == 2)
				continue;
			else
				return;
		}
	}

}


void CCommitDlg::OnBnClickedOk()
{
	UpdateData(TRUE);
	if (m_strCommitMsg.IsEmpty()) {
		AfxMessageBox(_T("커밋 메시지를 입력하세요."));
		return;
	}
	/*
	if (!CommitToGitLab()) {
		AfxMessageBox(_T("커밋 실패"));
		return;
	}
	AfxMessageBox(_T("커밋 성공"));
*/
	CommitToGitLab();
	OnOK();
}


// WinMain 또는 호출 위치
BOOL CCommitDlg::CommitToGitLab()
{
	theApp.m_RGA.CompareGitLabCommitWithWorkingTree();
	return 0;
}

