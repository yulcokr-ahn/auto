﻿
// History.cpp : 구현 파일
//

#include "stdafx.h"
#include "gitAPI32.h"
#include "History.h"
#include "afxdialogex.h"
#include "GitLabApi.h"


CHistory::CHistory(CWnd* pParent )	: CDialogEx(CHistory::IDD, pParent) {
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}
void CHistory::DoDataExchange(CDataExchange* pDX){
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LOGLIST, m_LogList);
/*
	DDX_Control(pDX, IDC_LOGMSG, m_ChangedFileListCtrl);
	DDX_Control(pDX, IDC_PROGRESS, m_LogProgress);
	DDX_Control(pDX, IDC_SPLITTERTOP, m_wndSplitter1);
	DDX_Control(pDX, IDC_SPLITTERBOTTOM, m_wndSplitter2);
	DDX_Text(pDX, IDC_SEARCHEDIT, m_sFilterText);
	DDX_Control(pDX, IDC_DATEFROM, m_DateFrom);
	DDX_Control(pDX, IDC_DATETO, m_DateTo);
	DDX_Control(pDX, IDC_LOG_JUMPTYPE, m_JumpType);
	DDX_Control(pDX, IDC_LOG_JUMPUP, m_JumpUp);
	DDX_Control(pDX, IDC_LOG_JUMPDOWN, m_JumpDown);
	DDX_Text(pDX, IDC_LOGINFO, m_sLogInfo);
	DDX_Check(pDX, IDC_LOG_ALLBRANCH,m_bAllBranch);
	DDX_Check(pDX, IDC_WHOLE_PROJECT, m_bWholeProject);
	DDX_Control(pDX, IDC_WALKBEHAVIOUR, m_ctrlWalkBehavior);
	DDX_Control(pDX, IDC_VIEW, m_ctrlView);
	DDX_Control(pDX, IDC_SEARCHEDIT, m_cFilter);
	DDX_Control(pDX, IDC_STATIC_REF, m_staticRef);
	DDX_Control(pDX, IDC_PIC_AUTHOR, m_gravatar);
	DDX_Control(pDX, IDC_FILTER, m_cFileFilter);
*/
}
BEGIN_MESSAGE_MAP(CHistory, CDialogEx)
//	ON_WM_SYSCOMMAND()
//	ON_WM_PAINT()
//	ON_WM_QUERYDRAGICON()
//	ON_BN_CLICKED(IDOK, &CHistory::OnBnClickedOk)
	ON_NOTIFY(NM_CLICK, IDC_LOGLIST, &CHistory::OnClickLoglist)
	ON_NOTIFY(NM_DBLCLK, IDC_LOGLIST, &CHistory::OnDblclkLoglist)
END_MESSAGE_MAP()
void CHistory::OnSysCommand(UINT nID, LPARAM lParam) {
	if ((nID & 0xFFF0) == IDM_ABOUTBOX) {
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else {
		CDialogEx::OnSysCommand(nID, lParam);
	}
}
void CHistory::OnPaint()
{
	if (IsIconic()) {
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else {
		CDialogEx::OnPaint();
	}
}
HCURSOR CHistory::OnQueryDragIcon(){
	return static_cast<HCURSOR>(m_hIcon);
}
void CHistory::OnBnClickedOk()
{
	CDialogEx::OnOK();
}
BOOL CHistory::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.
	m_LogList.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);



	Lastcommit();
//	HistoryCommits();

	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

// commit 메세지 작성
void CHistory::SetCommitMakePush_Test()
{
	std::string branch = "main";
	std::string filePath = "GitLabApi.obj";
	std::string commitMessage = "Add new file bin2 ";
	theApp.m_RGA.commitFileToGitLab(branch, filePath, commitMessage);
}

CString ExtractNewContentFromDiff(const CString& diff)
{
	CString result;
	CStringArray lines;
	int pos = 0;
	CString line;
	while ((line = diff.Tokenize(_T("\n"), pos)) != _T(""))
	{
		if (line.Left(1) == _T("+") && !line.Left(2).Compare(_T("++"))) // "+", not "+++" (diff metadata)
			result += line.Mid(1) + _T("\n");
	}
	return result;
}
CString ParseISO8601DateTime(const CString& isoString) // 예: "2025-06-10T14:40:23.000+00:00"
{
	CString result;
	int tPos = isoString.Find('T');
	if (tPos == -1)
		return isoString; // 형식이 이상하면 원문 반환
	CString datePart = isoString.Left(tPos);                  // "2025-06-10"
	CString timePart = isoString.Mid(tPos + 1);               // "14:40:23.000+00:00"
	int dotPos = timePart.Find('.'); // 시간 끝 위치를 잘라내기 ('.' 또는 '+' 또는 'Z'까지)
	if (dotPos == -1)
		dotPos = timePart.Find('+');
	if (dotPos == -1)
		dotPos = timePart.Find('Z');
	if (dotPos != -1)
		timePart = timePart.Left(dotPos);                     // "14:40:23"
	result.Format(_T("%s %s"), datePart, timePart);           // "2025-06-10 14:40:23"
	return result;
}
/*
[CHistory::OnInitDialog][TraceJson5] Record 4:
{ "id" : "b2dfb6ade51f4945066e09f124a3efe4652a6d96" }
{ "short_id" : "b2dfb6ad" }
{ "created_at" : "2025-06-12T17:59:41.000+00:00" }
{ "parent_ids" : "["3e62de451267381bff63ec9e9ddcf9834ffe5132"]" }
{ "title" : "dfgbfdbdh" }
{ "message" : "dfgbfdbdh" }
{ "author_name" : "Administrator" }
{ "author_email" : "gitlab_admin_7d831e@example.com" }
{ "authored_date" : "2025-06-12T17:59:41.000+00:00" }
{ "committer_name" : "Administrator" }
{ "committer_email" : "gitlab_admin_7d831e@example.com" }
{ "committed_date" : "2025-06-12T17:59:41.000+00:00" }
{ "trailers" : "{" }
*/
void CHistory::AppendHistoryCommit(CString nm ,const web::json::value& commit)
{
	if (!commit.is_object()) return;
	CString id , short_id(""), created_at,parent_ids,title(""), message, author_name(""),author_email,authored_date,committer_name,committer_email, committed_date("");
	if (commit.has_field(L"id"))
		id = commit[L"id"].as_string().c_str();
	if (commit.has_field(L"short_id"))
		short_id = commit[L"short_id"].as_string().c_str();
	if (commit.has_field(L"created_at"))
		created_at = commit[L"created_at"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
	if (commit.has_field(L"title"))
		title = commit[L"title"].as_string().c_str();
	if (commit.has_field(L"message"))
		message = commit[L"message"].as_string().c_str();
	if (commit.has_field(L"author_name"))
		author_name = commit[L"author_name"].as_string().c_str();
	if (commit.has_field(L"author_email"))
		author_email = commit[L"author_email"].as_string().c_str();
	if (commit.has_field(L"authored_date"))
		authored_date = commit[L"authored_date"].as_string().c_str();
	if (commit.has_field(L"committer_name"))
		committer_name = commit[L"committer_name"].as_string().c_str();
	if (commit.has_field(L"committer_email"))
		committer_email = commit[L"committer_email"].as_string().c_str();
	if (commit.has_field(L"committed_date"))
		committed_date = commit[L"committed_date"].as_string().c_str();
	CString parsedTime = ParseISO8601DateTime(authored_date);
	int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), short_id);
	m_LogList.SetItemText(nItem, 1, author_name);
	m_LogList.SetItemText(nItem, 2, parsedTime); //m_LogList.SetItemText(nItem, 2, authored_date);
	m_LogList.SetItemText(nItem, 3, title);
	if( nm.GetLength() > 0)
	m_LogList.SetItemText(nItem, 4, nm);

	m_CommitHistory.push_back(commit); // row index와 매칭됨
}
/*
{ "id" : "5ee8b393ad1bba251b005ea0d5d8b02792dbdad1" }
{ "name" : "README.md" }
{ "type" : "blob" }
{ "path" : "README.md" }
{ "mode" : "100644" }
*/
void CHistory::AppendLastCommit(CString nm ,const web::json::value& commit)
{
	if (!commit.is_object()) return;
	CString id , short_id(""), created_at,parent_ids,title(""), message, author_name(""),author_email,authored_date,committer_name,committer_email, committed_date("");
	if (commit.has_field(L"id"))
		id = commit[L"id"].as_string().c_str();
	
	if (commit.has_field(L"short_id"))
		short_id = commit[L"short_id"].as_string().c_str();
	if (commit.has_field(L"created_at"))
		created_at = commit[L"created_at"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
	if (commit.has_field(L"title"))
		title = commit[L"title"].as_string().c_str();
	if (commit.has_field(L"message"))
		message = commit[L"message"].as_string().c_str();
	if (commit.has_field(L"author_name"))
		author_name = commit[L"author_name"].as_string().c_str();
	if (commit.has_field(L"author_email"))
		author_email = commit[L"author_email"].as_string().c_str();
	if (commit.has_field(L"authored_date"))
		authored_date = commit[L"authored_date"].as_string().c_str();
	if (commit.has_field(L"committer_name"))
		committer_name = commit[L"committer_name"].as_string().c_str();
	if (commit.has_field(L"committer_email"))
		committer_email = commit[L"committer_email"].as_string().c_str();
	if (commit.has_field(L"committed_date"))
		committed_date = commit[L"committed_date"].as_string().c_str();
	CString parsedTime = ParseISO8601DateTime(authored_date);
	int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), short_id);
	m_LogList.SetItemText(nItem, 1, author_name);
	m_LogList.SetItemText(nItem, 2, parsedTime); //m_LogList.SetItemText(nItem, 2, authored_date);
	m_LogList.SetItemText(nItem, 3, title);
	if( nm.GetLength() > 0)
		m_LogList.SetItemText(nItem, 4, nm);

	m_CommitHistory.push_back(commit); // row index와 매칭됨
}
//파일 목록 List Commit
void CHistory::Lastcommit()
{	
	m_LogList.DeleteAllItems();
	m_LogList.InsertColumn(0, _T("ID"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(1, _T("File Name"), LVCFMT_LEFT, 120);
	m_LogList.InsertColumn(2, _T("Last Commit"), LVCFMT_LEFT, 150);
	m_LogList.InsertColumn(3, _T("Last Update"), LVCFMT_LEFT, 300);
	m_LogList.InsertColumn(4, _T("Last Commit Message"), LVCFMT_LEFT, 200);

	std::vector<TR_LASTcommit> files;

	g_Outjson=  web::json::value::object(); 
	std::vector<CString> fi= theApp.m_RGA.GitLab_GetRepositoryTree2(g_Outjson);
	size_t length = g_Outjson.size();  // 배열 길이 가져오기
	for (size_t i = 0; i < length; ++i)
	{
		json::value item = g_Outjson[i];
		if (item.is_object())
		{
			CString id , name(""), type ,path, mode("");
			if (item.has_field(L"id"))		id   = item[L"id"].as_string().c_str();
			if (item.has_field(L"name"))	name = item[L"name"].as_string().c_str();
			if (item.has_field(L"type"))	type = item[L"type"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
			if (item.has_field(L"path"))	path = item[L"path"].as_string().c_str();
			if (item.has_field(L"mode"))	mode = item[L"mode"].as_string().c_str();
		//	theApp.m_RGA.fetch_commit_for_file(id);			
			TR_LASTcommit Tr;
			Tr.id   = item[U("id")  ].as_string().c_str();
			Tr.path = item[U("path")].as_string().c_str();
			Tr.name = item[U("name")].as_string().c_str();
			files.push_back(Tr);
		}
	}

	for (size_t j = 0; j < files.size(); ++j) {
		json::value commitsArray;
		theApp.m_RGA.getcommitLast(files[j],commitsArray);
	}

	for (size_t h = 0; h < files.size(); ++h) {
		int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), CString(files[h].id.c_str()));
		m_LogList.SetItemText(nItem, 1, CString(files[h].name.c_str()));
		m_LogList.SetItemText(nItem, 2, CString(files[h].last_commit_message.c_str())); //m_LogList.SetItemText(nItem, 2, authored_date);
		m_LogList.SetItemText(nItem, 3, CString(files[h].last_commit_date.c_str()));
		m_LogList.SetItemText(nItem, 4, CString(files[h].path.c_str()));
	}




}
// 파일 목록 List Download
void CHistory::GetFilesListDownList_Test()
{
	json::value Outjson;
	std::vector<CString> files= theApp.m_RGA.GitLab_GetRepositoryTree2(Outjson);
	theApp.m_RGA.TraceJson5(__FUNCTION__, Outjson);
	try
	{
		size_t len = files.size();  // 오래된 버전에서는 size() 제공
		for (size_t i = 0; i < len; ++i)
		{
			TRACE("OnInitDialog(%d)    name=[%s] \r\n",i , files[i] );
			CString sbranch= "Master";
			CString rawPath =files[i]; // UrlEncode((CString)files[i]);
			theApp.m_RGA.DownloadGitlabFile( CString(g_tPROJECTPATH.c_str()) , rawPath , sbranch,CString(g_tPRIVATE_TOKEN.c_str())  );
		}
	}
	catch ( const std::exception &e )	{
		printf("Error exception:%s\n", e.what());
	}
}

void CHistory::HistoryCommits()
{
	m_LogList.DeleteAllItems();
	m_LogList.InsertColumn(0, _T("Short ID"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(1, _T("Author"), LVCFMT_LEFT, 120);
	m_LogList.InsertColumn(2, _T("Date"), LVCFMT_LEFT, 150);
	m_LogList.InsertColumn(3, _T("Title"), LVCFMT_LEFT, 300);
	m_LogList.InsertColumn(4, _T("file"), LVCFMT_LEFT, 200);

	g_Outjson=  web::json::value::object(); //초기화 web::json::value Outjson;

	json::value& commitsArray = g_Outjson;
	std::vector<CString> fi= theApp.m_RGA.get_commits_and_files(g_Outjson); // get_commits_and_files(g_Outjson); 
	theApp.m_RGA.TraceJson5(__FUNCTION__, commitsArray);

	if (!commitsArray.is_array())
		return;
	CString file;
	size_t length = commitsArray.size();  // 배열 길이 가져오기
	for (size_t i = 0; i < length; ++i)
	{
		if (i < fi.size() )
			file = fi[i];
		else
			file = "";
		json::value item = commitsArray[i];
		if (item.is_object())
		{
			AppendHistoryCommit(file, item);  // 각 커밋을 처리
		}
	}
}
/*
//GET https://gitlab.com/api/v4/projects/:id/repository/commits/:sha/diff
[
{
	"old_path": "src/main.cpp",
		"new_path": "src/main.cpp",
		"a_mode": "100644",
		"b_mode": "100644",
		"new_file": false,
		"renamed_file": false,
		"deleted_file": false,
		"diff": "@@ -1,6 +1,7 @@\n #include <iostream>\n+#include <vector>\n int main() {\n   std::cout << \"Hello\";\n }"
},
...
]
*/
void CHistory::OnClickLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;
	int nIndex = pNMItemActivate->iItem;
	if(nIndex <0) return; 
	CString short_id = m_LogList.GetItemText(nIndex,0);
	if (short_id.IsEmpty()) return;

	utility::string_t  commitid = utility::conversions::to_string_t((LPCTSTR)short_id);
	m_CommitHistory.clear();
	json::value diffjson;
	theApp.m_RGA.GetDiffFromGitLab(commitid, diffjson); 
//	theApp.m_RGA.TraceJson5(__FUNCTION__, diffjson);

	if (!diffjson.is_array())
		return;
	size_t length = diffjson.size();  // 배열 길이 가져오기
	for (size_t i = 0; i < length; ++i)
	{
		json::value commit = diffjson[i];
		if (commit.is_object())
		{
			m_CommitHistory.push_back(commit); // row index와 매칭됨
		}
	}
	if (m_CommitHistory.size()==0)
		return;

	const web::json::value& commit = m_CommitHistory[0];
	if (!commit.has_field(U("diff")))
		return;

	const web::json::value& diffItem = commit; //commit[U("diff")];
	size_t diffCount = diffItem.size();

//	for (size_t index = 0; index < diffCount; ++index)
	{
//		const web::json::value& diffItem = diffArray[index];

		CString oldPath, newPath, diffText;

		if (diffItem.has_field(U("old_path")) && !diffItem[U("old_path")].is_null())
			oldPath = CString(diffItem[U("old_path")].as_string().c_str());

		if (diffItem.has_field(U("new_path")) && !diffItem[U("new_path")].is_null())
			newPath = CString(diffItem[U("new_path")].as_string().c_str());

		if (diffItem.has_field(U("diff")) && !diffItem[U("diff")].is_null())
			diffText = CString(diffItem[U("diff")].as_string().c_str());

		TRACE(L"[diff %d] old: %s, new: %s\n", 0, oldPath, newPath);

		CString safeOld = oldPath; safeOld.Replace(_T("\\"), _T("_")); safeOld.Replace(_T("/"), _T("_"));
		CString safeNew = newPath; safeNew.Replace(_T("\\"), _T("_")); safeNew.Replace(_T("/"), _T("_"));

		CString tempOldFile = WriteTempFile(_T("old_") + safeOld, _T("")); // 기존 파일 내용 없음
		CString tempNewFile = WriteTempFile(_T("new_") + safeNew, ExtractNewContentFromDiff(diffText));

		CString exePath = _T("C:\\Program Files\\TortoiseGit\\bin\\TortoiseGitMerge.exe");
		CString cmd;
		cmd.Format(_T("\"%s\" /base:\"%s\" /mine:\"%s\""), exePath, tempOldFile, tempNewFile);

		STARTUPINFO si = { sizeof(si) };
		PROCESS_INFORMATION pi;
		if (CreateProcess(NULL, cmd.GetBuffer(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
			CloseHandle(pi.hProcess);
			CloseHandle(pi.hThread);
		} else {
			TRACE(L"CreateProcess 실패: %s\n", cmd);
		}
	}
}


CString CHistory::WriteTempFile(const CString& filename, const CString& content)
{
	CString tempPath;
	GetTempPath(MAX_PATH, tempPath.GetBuffer(MAX_PATH));
	tempPath.ReleaseBuffer();

	CString fullPath = tempPath + filename;
	CStdioFile file;
	if (file.Open(fullPath, CFile::modeCreate | CFile::modeWrite | CFile::typeText))
	{
		file.WriteString(content);
		file.Close();
	}
	return fullPath;
}

CString CHistory::ExtractNewContentFromDiff(const CString& diff)
{
	CString result;
	CStringArray lines;
	int pos = 0;
	CString line;

	while ((line = diff.Tokenize(_T("\n"), pos)) != _T(""))
	{
		if (line.Left(1) == _T("+") && line.Left(3) != _T("+++"))
			result += line.Mid(1) + _T("\n");
	}
	return result;
}

void CHistory::OnDblclkLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	*pResult = 0;
}














/*
// 🔧 설정 값: 아래 항목을 실제 값으로 교체하세요
const utility::string_t GITLAB_URL = U("https://gitlab.com");         // GitLab 서버 주소
const utility::string_t PRIVATE_TOKEN = U("your_access_token_here");  // GitLab Access Token
const utility::string_t PROJECT_ID = U("12345678");                   // 프로젝트 ID
const utility::string_t BRANCH = U("main");                           // 브랜치명

// 🔹 파일 목록 요청
pplx::task<std::vector<TR_LASTcommit>> get_repository_files() 
{
	std::vector<TR_LASTcommit> result;
	http_client client(GITLAB_URL);

	uri_builder builder(U("/api/v4/projects/"));
	builder.append(PROJECT_ID);
	builder.append_path(U("repository/tree"));
	builder.append_query(U("ref"), BRANCH);
	builder.append_query(U("recursive"), U("true"));

	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), PRIVATE_TOKEN);
	request.set_request_uri(builder.to_uri());

	return client.request(request).then([&result](http_response response) -> pplx::task<json::value> {
		if (response.status_code() != status_codes::OK)
			throw std::runtime_error("Failed to fetch file list");
		return response.extract_json();
	})
	.then([&result](json::value json_response) 
	{
		json::value& arr= json_response;
		if(json_response.size())
		{
			for (size_t i = 0; i < arr.size(); ++i) {
				auto item = arr[i];
				if (item[U("type")].as_string() != U("blob")) continue;

				TR_LASTcommit file;
				file.path = item[U("path")].as_string();
				file.name = item[U("name")].as_string();
				result.push_back(file);
			}
		}
		return result;
	});
}

// 🔹 각 파일의 마지막 커밋 정보 가져오기
pplx::task<void> getcommitLast(TR_LASTcommit& file, json::value& commit) 
{
	http_client client(GITLAB_URL);
	uri_builder builder(U("/api/v4/projects/"));
	builder.append(PROJECT_ID);
	builder.append_path(U("repository/commits"));
	builder.append_query(U("path"), file.path);
	builder.append_query(U("ref_name"), BRANCH);
	builder.append_query(U("per_page"), U("1"));

	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), PRIVATE_TOKEN);
	request.set_request_uri(builder.to_uri());

	return client.request(request).then([&file](http_response response) -> pplx::task<json::value> {
		if (response.status_code() != status_codes::OK)
			return pplx::task_from_result(json::value());
		return response.extract_json();
	}).then([&file](json::value json_response) 
	{
		if(json_response.size())
		{
			json::value& commit= json_response;
			file.last_commit_id = commit[U("id")].as_string();
			file.last_commit_date = commit[U("committed_date")].as_string();
			file.last_commit_message = commit[U("message")].as_string();
		}
	});
}

// 🔹 메인 함수
int tmain() {
	try {
		std::wcout << L"[1] Getting file list..." << std::endl;
		auto files_task = get_repository_files();

		std::vector<TR_LASTcommit> files = files_task.get();

		std::wcout << L"[2] Fetching last commits for " << files.size() << " files..." << std::endl;
		std::vector<pplx::task<void>> commit_tasks;

		for (size_t i = 0; i < files.size(); ++i) {
			commit_tasks.push_back(get_Last_commits(files[i]));
		}

		// 모든 커밋 요청 완료 대기
		pplx::when_all(commit_tasks.begin(), commit_tasks.end()).wait();

		std::wcout << L"[3] Output:\n";
		for (size_t i = 0; i < files.size(); ++i) {
			std::wcout << L"- ID: " << files[i].path
				<< L"\n  File Name: " << files[i].name
				<< L"\n  Last Commit: " << files[i].last_commit_id
				<< L"\n  Last Update: " << files[i].last_commit_date
				<< L"\n  Last Commit Message: " << files[i].last_commit_message
				<< L"\n" << std::endl;
		}
	}
	catch (const std::exception& e) {
		std::cerr << "[Error] " << e.what() << std::endl;
	}

	return 0;
}

*/
/*
ref_name	브랜치 이름 (예: main, master)
	path	특정 파일 또는 폴더 경로의 커밋만
	since	ISO 8601 포맷 시작일자 (2024-01-01T00:00:00Z)
	until	끝나는 일자
	author	작성자 필터
	per_page	페이지당 커밋 수 (기본 20, 최대 100)
	page	페이지 번호

ref_name=main	git log main
	path=src/index.js	git log -- src/index.js
	since=2024-01-01	git log --since="2024-01-01"
	until=2024-05-01	git log --until="2024-05-01"
	author=홍길동	git log --author="홍길동"
	per_page=10	git log -n 10



	1. 브랜치 기준 커밋:
	git log origin/main --oneline

	2. 특정 경로에 대한 커밋:
	git log -- path/to/file

	3. 기간 필터링:
	git log --since="2024-01-01" --until="2024-05-26"

	4. JSON 스타일 출력 (파싱용):
	git log --pretty=format:'{"hash":"%H","author":"%an","date":"%ad","message":"%s"},'




	🔄 GitLab REST API vs Git 명령어 비교
	목적	                GitLab REST API	Git CLI
	원격 저장소 커밋 보기	✅ 가능	        ❌ (로컬 복제 필요)
	특정 브랜치 커밋 보기	✅ ref_name	    ✅ git log 브랜치명
	특정 파일 커밋 보기	    ✅ path=	    ✅ git log -- path
	날짜 필터링	            ✅ since, until	✅ --since, --until
	작성자 필터	            ✅ author	    ✅ --author
*/
CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD){
}
void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialogEx::DoDataExchange(pDX);
}
BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()
