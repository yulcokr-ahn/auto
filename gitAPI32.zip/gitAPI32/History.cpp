﻿
#include "stdafx.h"
#include "gitAPI32.h"
#include "History.h"
#include "afxdialogex.h"
#include "GitLabApi.h"


CString GetRunTimePath()	{
	char buff[MAX_PATH]= { 0 };		int i=0;
	::GetModuleFileName(AfxGetInstanceHandle(), buff, 255);		for(i=strlen(buff)-1; i>=0 && buff[i]!='\\'; i--);	buff[i]=0;	
	return CString(buff);
}
CString ExtractNewContentFromDiff(const CString& diff)
{
	CString result;
	CStringArray lines;
	int pos = 0;
	CString line;
	while ((line = diff.Tokenize(_T("\n"), pos)) != _T(""))
	{
		if (line.Left(1) == _T("+") && !line.Left(2).Compare(_T("++"))) // "+", not "+++" (diff metadata)
			result += line.Mid(1) + _T("\n");
	}
	return result;
}
CString ParseISO8601DateTime(const CString& isoString) // 예: "2025-06-10T14:40:23.000+00:00"
{
	CString result;
	int tPos = isoString.Find('T');
	if (tPos == -1)
		return isoString; // 형식이 이상하면 원문 반환
	CString datePart = isoString.Left(tPos);                  // "2025-06-10"
	CString timePart = isoString.Mid(tPos + 1);               // "14:40:23.000+00:00"
	int dotPos = timePart.Find('.'); // 시간 끝 위치를 잘라내기 ('.' 또는 '+' 또는 'Z'까지)
	if (dotPos == -1)
		dotPos = timePart.Find('+');
	if (dotPos == -1)
		dotPos = timePart.Find('Z');
	if (dotPos != -1)
		timePart = timePart.Left(dotPos);                     // "14:40:23"
	result.Format(_T("%s %s"), datePart, timePart);           // "2025-06-10 14:40:23"
	return result;
}
CHistory::CHistory(CWnd* pParent )	: CSkinedDialog(CHistory::IDD, pParent)  , m_brushDlgBk(RGB(0,0,0))           // 다이얼로그 배경 검정
	, m_brushCtrlBk(RGB(40,40,40))       
{

}
void CHistory::DoDataExchange(CDataExchange* pDX){
	CSkinedDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LOGLIST, m_LogList);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);

#if 0
	DDX_Control(pDX, IDC_LOGMSG, m_ChangedFileListCtrl);
	DDX_Control(pDX, IDC_PROGRESS, m_LogProgress);
	DDX_Control(pDX, IDC_SPLITTERTOP, m_wndSplitter1);
	DDX_Control(pDX, IDC_SPLITTERBOTTOM, m_wndSplitter2);
	DDX_Text(pDX, IDC_SEARCHEDIT, m_sFilterText);
	DDX_Control(pDX, IDC_DATEFROM, m_DateFrom);
	DDX_Control(pDX, IDC_DATETO, m_DateTo);
	DDX_Check(pDX, IDC_LOG_ALLBRANCH,m_bAllBranch);
	DDX_Check(pDX, IDC_WHOLE_PROJECT, m_bWholeProject);
	DDX_Text(pDX, IDC_LOGINFO, m_sLogInfo);
	DDX_Control(pDX, IDC_LOG_JUMPTYPE, m_JumpType);
	DDX_Control(pDX, IDC_LOG_JUMPUP, m_JumpUp);
	DDX_Control(pDX, IDC_STATIC_REF, m_staticRef);
	DDX_Control(pDX, IDC_PIC_AUTHOR, m_gravatar);
	DDX_Control(pDX, IDC_LOG_JUMPDOWN, m_JumpDown);
	DDX_Control(pDX, IDC_WALKBEHAVIOUR, m_ctrlWalkBehavior);
	DDX_Control(pDX, IDC_VIEW, m_ctrlView);
	DDX_Control(pDX, IDC_SEARCHEDIT, m_cFilter);
	DDX_Control(pDX, IDC_FILTER, m_cFileFilter);
	DDX_Control(pDX, IDC_REFRESH, m_btnRefresh);
	DDX_Control(pDX, IDHELP, m_btnHelp);
	DDX_Control(pDX, IDC_STATBUTTON, m_btnSTATBUTTON);
#endif


}
BEGIN_MESSAGE_MAP(CHistory, CSkinedDialog)
	ON_NOTIFY(NM_CLICK, IDC_LOGLIST, &CHistory::OnClickLoglist)
	ON_NOTIFY(NM_DBLCLK, IDC_LOGLIST, &CHistory::OnDblclkLoglist)
	ON_WM_SIZE()
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LOGLIST, &CHistory::OnLvnItemchangedLoglist)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()
void CHistory::OnSysCommand(UINT nID, LPARAM lParam) {
	if ((nID & 0xFFF0) == IDM_ABOUTBOX) {
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else {
		CSkinedDialog::OnSysCommand(nID, lParam);
	}
}
void CHistory::OnPaint()
{
	if (IsIconic()) {
		CPaintDC dc(this); 
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else {
		CSkinedDialog::OnPaint();
	}
}
HCURSOR CHistory::OnQueryDragIcon(){
	return static_cast<HCURSOR>(m_hIcon);
}
void CHistory::OnBnClickedOk()
{
	CSkinedDialog::OnOK();
}
BOOL CHistory::OnInitDialog()
{
	CSkinedDialog::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			
	SetIcon(m_hIcon, FALSE);		

	CRgn rgn;
	CRect rc;
	GetWindowRect(&rc);	
	
	rc.OffsetRect(-rc.TopLeft()); // 좌표 보정
	rgn.CreateRoundRectRgn(rc.left, rc.top, rc.right, rc.bottom, 20, 20);
	SetWindowRgn(rgn, TRUE);

	m_btnOK.ModifyStyle(0, BS_OWNERDRAW);
	m_btnCancel.ModifyStyle(0, BS_OWNERDRAW);

#if 0
	m_btnRefresh.ModifyStyle(0, BS_OWNERDRAW);
	m_btnHelp.ModifyStyle(0, BS_OWNERDRAW);
	m_btnSTATBUTTON.ModifyStyle(0, BS_OWNERDRAW);
	m_JumpUp.SetShade(SHS_STANDARD);
	m_JumpDown.SetShade(SHS_STANDARD);
	m_btnOK.SetShade(SHS_STANDARD);
	m_btnCancel.SetShade(SHS_STANDARD);
	m_btnRefresh.SetShade(SHS_STANDARD);
	m_btnHelp.SetShade(SHS_STANDARD);
	m_btnSTATBUTTON.SetShade(SHS_STANDARD);
#endif


	Lastcommit();
//	HistoryCommits();
	return TRUE;  
}


void CHistory::OnSize(UINT t,int cx,int cy)
{
	CSkinedDialog::OnSize(t,cx,cy);
}

// commit 메세지 작성
void CHistory::SetCommitMakePush_Test()
{
	std::string branch = "main";
	std::string filePath = "GitLabApi.obj";
	std::string commitMessage = "Add new file bin2 ";
	theApp.m_RGA.commitFileToGitLab(branch, filePath, commitMessage);
}



void CHistory::AppendHistoryCommit(CString nm ,const web::json::value& commit)
{
	if (!commit.is_object()) return;
	CString id , short_id(""), created_at,parent_ids,title(""), message, author_name(""),author_email,authored_date,committer_name,committer_email, committed_date("");
	if (commit.has_field(L"id"))					id				= commit[L"id"].as_string().c_str();
	if (commit.has_field(L"short_id"))				short_id		= commit[L"short_id"].as_string().c_str();
	if (commit.has_field(L"created_at"))			created_at		= commit[L"created_at"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
	if (commit.has_field(L"title"))					title			= commit[L"title"].as_string().c_str();
	if (commit.has_field(L"message"))				message			= commit[L"message"].as_string().c_str();
	if (commit.has_field(L"author_name"))			author_name		= commit[L"author_name"].as_string().c_str();
	if (commit.has_field(L"author_email"))			author_email	= commit[L"author_email"].as_string().c_str();
	if (commit.has_field(L"authored_date"))			authored_date	= commit[L"authored_date"].as_string().c_str();
	if (commit.has_field(L"committer_name"))		committer_name	= commit[L"committer_name"].as_string().c_str();
	if (commit.has_field(L"committer_email"))		committer_email = commit[L"committer_email"].as_string().c_str();
	if (commit.has_field(L"committed_date"))		committed_date	= commit[L"committed_date"].as_string().c_str();
	CString parsedTime = ParseISO8601DateTime(authored_date);
	int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), short_id);
	m_LogList.SetItemText(nItem, 1, author_name);
	m_LogList.SetItemText(nItem, 2, parsedTime); 
	m_LogList.SetItemText(nItem, 3, title);
	if( nm.GetLength() > 0)
	m_LogList.SetItemText(nItem, 4, nm);
	m_CommitHistory.push_back(commit); // row index와 매칭됨
}
/*
{ "id" : "5ee8b393ad1bba251b005ea0d5d8b02792dbdad1" }
{ "name" : "README.md" }
{ "type" : "blob" }
{ "path" : "README.md" }
{ "mode" : "100644" }
*/
void CHistory::AppendLastCommit(CString nm ,const web::json::value& commit)
{
	if (!commit.is_object()) return;
	CString id , short_id(""), created_at,parent_ids,title(""), message, author_name(""),author_email,authored_date,committer_name,committer_email, committed_date("");
	if (commit.has_field(L"id"))				id				= commit[L"id"].as_string().c_str();	
	if (commit.has_field(L"short_id"))			short_id		= commit[L"short_id"].as_string().c_str();
	if (commit.has_field(L"created_at"))		created_at		= commit[L"created_at"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
	if (commit.has_field(L"title"))				title			= commit[L"title"].as_string().c_str();
	if (commit.has_field(L"message"))			message			= commit[L"message"].as_string().c_str();
	if (commit.has_field(L"author_name"))		author_name		= commit[L"author_name"].as_string().c_str();
	if (commit.has_field(L"author_email"))		author_email	= commit[L"author_email"].as_string().c_str();
	if (commit.has_field(L"authored_date"))		authored_date	= commit[L"authored_date"].as_string().c_str();
	if (commit.has_field(L"committer_name"))	committer_name	= commit[L"committer_name"].as_string().c_str();
	if (commit.has_field(L"committer_email"))	committer_email = commit[L"committer_email"].as_string().c_str();
	if (commit.has_field(L"committed_date"))	committed_date	= commit[L"committed_date"].as_string().c_str();
	CString parsedTime = ParseISO8601DateTime(authored_date);
	int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), short_id);
	m_LogList.SetItemText(nItem, 1, author_name);
	m_LogList.SetItemText(nItem, 2, parsedTime); 
	m_LogList.SetItemText(nItem, 3, title);
	if( nm.GetLength() > 0)
		m_LogList.SetItemText(nItem, 4, nm);
	m_CommitHistory.push_back(commit); // row index와 매칭됨
}

// 파일 목록 List Commit std::vector<TR_LASTcommit>    m_fileLast;
void CHistory::Lastcommit()
{	
	m_mapMode = 1;
	m_fileLast.clear();

	if(m_LogList.GetSafeHwnd()==NULL) return;
	m_LogList.DeleteAllItems();
	m_LogList.InsertColumn(0, _T("ID"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(1, _T("File Name"), LVCFMT_LEFT, 120);
	m_LogList.InsertColumn(2, _T("Last Commit"), LVCFMT_LEFT, 150);
	m_LogList.InsertColumn(3, _T("Last Update"), LVCFMT_LEFT, 300);
	m_LogList.InsertColumn(4, _T("Last Commit Message"), LVCFMT_LEFT, 200);
	
	g_Outjson=  web::json::value::object(); 
	std::vector<CString> fi= theApp.m_RGA.GitLab_GetRepositoryTree2(g_Outjson);
	size_t length = g_Outjson.size();  // 배열 길이 가져오기
	for (size_t i = 0; i < length; ++i)
	{
		json::value item = g_Outjson[i];
		if (item.is_object())
		{
			CString id , name(""), type ,path, mode("");
			if (item.has_field(L"id"))		id   = item[L"id"].as_string().c_str();
			if (item.has_field(L"name"))	name = item[L"name"].as_string().c_str();
			if (item.has_field(L"type"))	type = item[L"type"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
			if (item.has_field(L"path"))	path = item[L"path"].as_string().c_str();
			if (item.has_field(L"mode"))	mode = item[L"mode"].as_string().c_str();

			TR_LASTcommit Tr;
			Tr.id   = item[U("id")  ].as_string().c_str();
			Tr.path = item[U("path")].as_string().c_str();
			Tr.name = item[U("name")].as_string().c_str();
			m_fileLast.push_back(Tr);
		}
	}

	for (size_t j = 0; j < m_fileLast.size(); ++j) {
		json::value commitsArray;
		theApp.m_RGA.getcommitLast(m_fileLast[j],commitsArray);
	}

	for (size_t h = 0; h < m_fileLast.size(); ++h) {
		int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), CString(m_fileLast[h].id.c_str()));
		m_LogList.SetItemText(nItem, 1, CString(m_fileLast[h].name.c_str()));
		m_LogList.SetItemText(nItem, 2, CString(m_fileLast[h].last_commit_message.c_str())); 
		m_LogList.SetItemText(nItem, 3, CString(m_fileLast[h].last_commit_date.c_str()));
		m_LogList.SetItemText(nItem, 4, CString(m_fileLast[h].path.c_str()));
		m_LogList.SetItemData(nItem, h);
	}
}

//수정 파일 History 가져 오기  // std::vector<TR_HISTORYcommit> m_fileHist;
void CHistory::HistoryCommits()   
{
	m_mapMode = 2;
	m_fileHist.clear();
	m_LogList.DeleteAllItems();
	m_LogList.InsertColumn(0, _T("Short ID"), LVCFMT_LEFT, 0);
	m_LogList.InsertColumn(1, _T("Revision"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(2, _T("Action"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(3, _T("Author"), LVCFMT_LEFT, 120);
	m_LogList.InsertColumn(4, _T("Date"), LVCFMT_LEFT, 150);
	m_LogList.InsertColumn(5, _T("Message"), LVCFMT_LEFT, 350);
	m_LogList.InsertColumn(6, _T("file"), LVCFMT_LEFT, 10);
	json::value Outjson;
	utility::string_t path =U("changelog.md");


	theApp.m_RGA.getcommitHistory( path, m_fileHist, Outjson);
	size_t length = m_fileHist.size();  // 배열 길이 가져오기
	for (size_t i = 0; i < length; ++i)
	{
		int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(),CString(m_fileHist[i].id.c_str()));
		m_LogList.SetItemText(nItem, 1, CString( m_fileHist[i].committer_email.c_str()));
		m_LogList.SetItemText(nItem, 2, CString( m_fileHist[i].committed_date.c_str())); 
		m_LogList.SetItemText(nItem, 3, CString( m_fileHist[i].message.c_str()));
		m_LogList.SetItemData(nItem, i);
	}
}

// 파일 목록 List Download
void CHistory::GetFilesListDownList_Test()
{
	json::value Outjson;
	std::vector<CString> files= theApp.m_RGA.GitLab_GetRepositoryTree2(Outjson);
	theApp.m_RGA.TraceJson5(__FUNCTION__, Outjson);
	try
	{
		size_t len = files.size();  // 오래된 버전에서는 size() 제공
		for (size_t i = 0; i < len; ++i)
		{
			TRACE("OnInitDialog(%d)    name=[%s] \r\n",i , files[i] );
			CString sbranch= "Master";
			CString rawPath =files[i]; // UrlEncode((CString)files[i]);
			theApp.m_RGA.DownloadGitlabFile( CString(g_tPROJECTPATH.c_str()) , rawPath , sbranch,CString(g_tPRIVATE_TOKEN.c_str())  );
		}
	}
	catch ( const std::exception &e )	{
		printf("Error exception:%s\n", e.what());
	}
}

void CHistory::OnClickLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;
	int nIndex = pNMItemActivate->iItem;
	if (nIndex < 0 ) return; // 최소 2개 이상 커밋 필요
	int nPos = m_LogList.GetItemData(nIndex);
	
	CString short_id_new;
	CString short_id_old;
	if(m_mapMode==1 && nPos >=0 && m_fileLast.size() > 0 )
	{
		TR_LASTcommit *pL = &m_fileLast[nPos];
		if(pL)
		{
			short_id_new = m_LogList.GetItemText(nIndex, 0);		// 최신 커밋
			short_id_old =(CString) pL->parent_ids.c_str();		// 직전 커밋
		}
	}
	else if(m_mapMode==2 && nPos >=0 && m_fileHist.size() > 0 )
	{
		TR_HISTORYcommit *pH = &m_fileHist[nPos];
		if(pH)
		{
			short_id_new = m_LogList.GetItemText(nIndex, 0);    // 최신 커밋
			short_id_old =(CString) pH->parent_ids[0].c_str();	// 직전 커밋
		}
	}
	if (short_id_new.IsEmpty() || short_id_old.IsEmpty()) return;

	std::vector<json::value> diffOld, diffNew;
//Compare
	theApp.m_RGA.GetDiffCompareGitLab( utility::conversions::to_string_t((LPCTSTR) short_id_old ),utility::conversions::to_string_t((LPCTSTR) short_id_new) ,diffOld,  diffNew  );
//Diff
//	theApp.m_RGA.GetDiffFromGitLab( utility::conversions::to_string_t((LPCTSTR)short_id_new), diffNew);
//	theApp.m_RGA.GetDiffFromGitLab( utility::conversions::to_string_t((LPCTSTR)short_id_old), diffOld);

	if (diffNew.empty() || diffOld.empty()) return;	// 일단 첫 번째 diff 항목을 비교 대상으로 사용
	const auto& newDiff = diffNew[0];
	const auto& oldDiff = diffOld[0];

	CString newPath = CString(newDiff[U("new_path")].as_string().c_str());
	CString oldPath = CString(oldDiff[U("old_path")].as_string().c_str());

	CString newDiffText = CString(newDiff[U("diff")].as_string().c_str());
	CString oldDiffText =""; // CString(oldDiff[U("diff")].as_string().c_str());

	TRACE(L"비교 대상 file: %s vs %s\n", oldPath, newPath);
	TRACE(L"비교 대상 text: %s vs %s\n", newDiffText, oldDiffText);

	CString safeNew = newPath; safeNew.Replace(_T("\\"), _T("_")); safeNew.Replace(_T("/"), _T("_"));
	CString safeOld = oldPath; safeOld.Replace(_T("\\"), _T("_")); safeOld.Replace(_T("/"), _T("_"));

	CString tempNewFile = WriteTempFile(_T("new_") + safeNew, ExtractNewContentFromDiff(newDiffText));
	CString tempOldFile = WriteTempFile(_T("old_") + safeOld, ExtractNewContentFromDiff(oldDiffText));

	CString exePath =GetRunTimePath()+"\\TortoiseGitMerge.exe";
	CString cmd;	cmd.Format(_T("\"%s\" /base:\"%s\" /mine:\"%s\""), exePath, tempNewFile , tempOldFile );

	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	if (CreateProcess(NULL, cmd.GetBuffer(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	} else {
		TRACE(L"CreateProcess 실패: %s\n", cmd);
	}	
}

// diff
CString CHistory::ExtractNewContentFromDiff(const CString& diff)
{
	CString result;
	CStringArray lines;
	int pos = 0;
	CString line;
	while ((line = diff.Tokenize(_T("\n"), pos)) != _T(""))
	{
		if (line.Left(1) == _T("+") && line.Left(3) != _T("+++"))
			result += line.Mid(1) + _T("\n");
	}
	return result;
}
// diff
CString CHistory::WriteTempFile(const CString& filename, const CString& content)
{
	CString tempPath;
	GetTempPath(MAX_PATH, tempPath.GetBuffer(MAX_PATH));
	tempPath.ReleaseBuffer();
	CString fullPath = tempPath + filename;
	CStdioFile file;
	if (file.Open(fullPath, CFile::modeCreate | CFile::modeWrite | CFile::typeText))
	{
		file.WriteString(content);
		file.Close();
	}
	return fullPath;
}

void CHistory::OnDblclkLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;
}
void CHistory::OnLvnItemchangedLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	*pResult = 0;
}

BOOL CHistory::OnEraseBkgnd(CDC* pDC)
{
	CRect r;
	GetClientRect(&r);
	pDC->FillSolidRect(&r, RGB(24, 24, 24));  // GitHub 다크 테마 배경
	return TRUE;

	return CSkinedDialog::OnEraseBkgnd(pDC);
}













/*
ref_name	브랜치 이름 (예: main, master)
	path	특정 파일 또는 폴더 경로의 커밋만
	since	ISO 8601 포맷 시작일자 (2024-01-01T00:00:00Z)
	until	끝나는 일자
	author	작성자 필터
	per_page	페이지당 커밋 수 (기본 20, 최대 100)
	page	페이지 번호

ref_name=main	git log main
	path=src/index.js	git log -- src/index.js
	since=2024-01-01	git log --since="2024-01-01"
	until=2024-05-01	git log --until="2024-05-01"
	author=홍길동	git log --author="홍길동"
	per_page=10	git log -n 10
	1. 브랜치 기준 커밋:
	git log origin/main --oneline

	2. 특정 경로에 대한 커밋:
	git log -- path/to/file

	3. 기간 필터링:
	git log --since="2024-01-01" --until="2024-05-26"

	4. JSON 스타일 출력 (파싱용):
	git log --pretty=format:'{"hash":"%H","author":"%an","date":"%ad","message":"%s"},'

	🔄 GitLab REST API vs Git 명령어 비교
	목적	                GitLab REST API	Git CLI
	원격 저장소 커밋 보기	✅ 가능	        ❌ (로컬 복제 필요)
	특정 브랜치 커밋 보기	✅ ref_name	    ✅ git log 브랜치명
	특정 파일 커밋 보기	    ✅ path=	    ✅ git log -- path
	날짜 필터링	            ✅ since, until	✅ --since, --until
	작성자 필터	            ✅ author	    ✅ --author
*/
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD){
}
void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
}
BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

