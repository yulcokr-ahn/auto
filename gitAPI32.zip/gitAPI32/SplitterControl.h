#pragma once

class CSplitterControl : public CStatic
{
public:
	enum SPLITTYPE { SPS_VERTICAL, SPS_HORIZONTAL };

	CSplitterControl();
	virtual ~CSplitterControl();

	void SetSplitType(SPLITTYPE type);
	void SetMinSize(int size); // �ּ� ũ�� ����
	void SetTargetWnd(CWnd* pWnd1, CWnd* pWnd2);

protected:
	SPLITTYPE       m_nSplitType;
	BOOL            m_bDragging;
	int             m_nMinSize;
	CWnd*           m_pWnd1;
	CWnd*           m_pWnd2;
	CPoint          m_ptStart;
	CRect           m_rcOld;

	void DrawLine(CDC* pDC, int x, int y);
	void MoveWindowByMouse();
	void ChangeCursor();

	DECLARE_MESSAGE_MAP()
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
};
