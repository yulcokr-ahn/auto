// MenuButton.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "gitAPI32.h"
#include "MenuButton.h"

CMenuButton::CMenuButton()
{
	m_hMenu = nullptr;
	m_nDefaultItem = 0;
}

CMenuButton::~CMenuButton() {}

void CMenuButton::SetMenu(HMENU hMenu)
{
	m_hMenu = hMenu;
}

void CMenuButton::SetMenu(UINT nMenuID)
{
	m_hMenu = ::LoadMenu(AfxGetInstanceHandle(), MAKEINTRESOURCE(nMenuID));
}

void CMenuButton::SetDefaultItem(UINT nItemID)
{
	m_nDefaultItem = nItemID;
}

BEGIN_MESSAGE_MAP(CMenuButton, CButton)
	ON_CONTROL_REFLECT(BN_CLICKED, OnClicked)
END_MESSAGE_MAP()

void CMenuButton::OnClicked()
{
	OnClickedInternal();
}

BOOL CMenuButton::OnClickedInternal()
{
	if (!m_hMenu)
		return FALSE;

	// �޴� ���� (���� ��ȣ)
	HMENU hPopup = ::GetSubMenu(m_hMenu, 0);
	if (!hPopup)
		return FALSE;

	CRect rc;
	GetWindowRect(&rc);
	::TrackPopupMenu(hPopup, TPM_LEFTALIGN | TPM_TOPALIGN, rc.left, rc.bottom, 0, GetParent()->GetSafeHwnd(), nullptr);
	return TRUE;
}

void CMenuButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC dc;
	dc.Attach(lpDrawItemStruct->hDC);

	CRect rc = lpDrawItemStruct->rcItem;
	dc.FillSolidRect(&rc, ::GetSysColor(COLOR_BTNFACE));

	UINT state = lpDrawItemStruct->itemState;
	CString strText;
	GetWindowText(strText);

	if (state & ODS_SELECTED)
		dc.DrawEdge(&rc, EDGE_SUNKEN, BF_RECT);
	else
		dc.DrawEdge(&rc, EDGE_RAISED, BF_RECT);

	dc.SetBkMode(TRANSPARENT);
	dc.DrawText(strText, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	dc.Detach();
}

