#include "StdAfx.h"
#include "GestureEnabledControlTmpl.h"


template <class T>
BEGIN_MESSAGE_MAP(CGestureEnabledControlTmpl<T>, T)
	ON_MESSAGE(WM_GESTURE, &CGestureEnabledControlTmpl<T>::OnGesture)
	ON_MESSAGE(WM_GESTURENOTIFY, &CGestureEnabledControlTmpl<T>::OnGestureNotify)
END_MESSAGE_MAP()

template <class T>
BOOL CGestureEnabledControlTmpl<T>::OnGestureNotify(UINT dwFlags, CPoint ptTouch)
{
	// ����ó ���� ���� ����
	return FALSE; // �⺻ ó��
}

template <class T>
LRESULT CGestureEnabledControlTmpl<T>::OnGesture(WPARAM wParam, LPARAM lParam)
{
	GESTUREINFO gi = { sizeof(GESTUREINFO) };
	if (GetGestureInfo((HGESTUREINFO)lParam, &gi))
	{
		switch (gi.dwID)
		{
		case GID_ZOOM:
			// Ȯ��/��� ���� ó��
			break;
		case GID_PAN:
			// ��ũ�� ó��
			break;
		default:
			break;
		}
		CloseGestureInfoHandle((HGESTUREINFO)lParam);
	}
	return 0;
}
