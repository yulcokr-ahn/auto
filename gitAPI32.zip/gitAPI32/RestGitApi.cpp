﻿#include "StdAfx.h"
#include "RestGitApi.h"
#include <sstream>
#include <sstream>
json::value g_Outjson; // 람다용
template <typename T> std::string to_string_2010(T value)	{ std::ostringstream oss;	oss << value;	return oss.str();	}

struct JsonPair {	std::string key;	std::string value;	};
std::string trim(const std::string& s) {
	size_t a = s.find_first_not_of(" \t\r\n");
	size_t b = s.find_last_not_of(" \t\r\n");
	if (a == std::string::npos) return "";
	return s.substr(a, b - a + 1); // 공백 제거 유틸
}
bool parsePair(const std::string& token, JsonPair& out) { 
	size_t colon = token.find(':'); 
	if (colon == std::string::npos) return false;
	std::string k = trim(token.substr(0, colon));
	std::string v = trim(token.substr(colon + 1));	// 따옴표 제거
	if (k.size() >= 2 && k.front() == '"' && k.back() == '"')		k = k.substr(1, k.size() - 2);
	if (v.size() >= 2 && v.front() == '"' && v.back() == '"')		v = v.substr(1, v.size() - 2);
	out.key = k;
	out.value = v;
	return true; // "키":"값" 쌍 파싱 (따옴표는 제거됨)
}
void parseJsonArray(const std::string& jsonStr,	std::vector<std::vector<JsonPair>>& outRecords) {
		size_t start = jsonStr.find('[');
		size_t end = jsonStr.rfind(']');
		if (start == std::string::npos || end == std::string::npos || end <= start)
			return;
		std::string body = jsonStr.substr(start + 1, end - start - 1);
		std::stringstream ss(body);
		std::string itemStr;
		// 간단하게 '},{' 로 분리
		while (std::getline(ss, itemStr, '}')) {
			size_t pos = itemStr.find('{');
			if (pos != std::string::npos)
				itemStr = itemStr.substr(pos + 1);
			if (itemStr.empty())
				continue;
			// 다시 trailing comma 제거
			if (itemStr.back() == ',')
				itemStr.pop_back();
			// 각 오브젝트 안에서 키-값 파싱
			std::vector<JsonPair> row;
			std::stringstream itemSS(itemStr);
			std::string token;
			while (std::getline(itemSS, token, ',')) {
				JsonPair p;
				if (parsePair(token, p))
					row.push_back(p);
			}
			if (!row.empty())
				outRecords.push_back(row);
			// '}' 뒤의 ',' 없애주기
			char delim = ss.peek();
			if (delim == ',') ss.get();
		}
}
void traceRecords(const char* context, const std::vector<std::vector<JsonPair>>& records) {
	for (size_t r = 0; r < records.size(); ++r) {
		TRACE("\n[%s][TraceJson5] Record %u:\n",context, (unsigned)r);		// 명시적인 반복자 사용
		const std::vector<JsonPair>& row = records[r];
		for (std::vector<JsonPair>::const_iterator it = row.begin(); it != row.end(); ++it)
		{
			const JsonPair& p = *it;
			TRACE("  { \"%s\" : \"%s\" }\n", p.key.c_str(), p.value.c_str());
		}
	}
}
void TraceLambda(const char* context, const web::json::value& val, int indent = 0) //람다(lambda) //람다 방식 접근 가능 
{
	CStringA tabs(' ', indent * 2);
	std::string narrowStr = utility::conversions::to_utf8string(val.to_string());
	TRACE("[%s][TraceJson5] JSON full to_string=%s\n", context, narrowStr.c_str());
	std::vector<std::vector<JsonPair>> records;
	parseJsonArray(narrowStr, records);
	traceRecords(context ,records);
}
void CRestGitApi::TraceJson5(const char* context, const web::json::value& val, int indent) {
	CStringA tabs(' ', indent * 2);
	std::string narrowStr = utility::conversions::to_utf8string(val.to_string());
	TRACE("[%s][TraceJson5] JSON full to_string=%s\n", context, narrowStr.c_str());
	std::vector<std::vector<JsonPair>> records;
	parseJsonArray(narrowStr, records);
	traceRecords(context ,records);
}
void CRestGitApi::logHead(http_client & cli, http_request &rq)
{
	// URI 정보 분해
	uri request_uri = cli.base_uri();
	utility::string_t t_scheme    = request_uri.scheme();
	utility::string_t t_host      = request_uri.host();
	utility::string_t t_user_info = request_uri.user_info();
	utility::string_t t_path      = uri::decode(request_uri.path());
	utility::string_t t_query     = request_uri.query();
	utility::string_t t_fragment  = request_uri.fragment();
	CString info;
	info += _T("logHead() ===== URI 구성 =====\n");
	info += _T("m_Scheme:    ")     + CString(t_scheme.c_str()   ) + _T("\n");
	info += _T("m_Host:      ")     + CString(t_host.c_str()     ) + _T("\n");
	info += _T("m_Path:      ")     + CString(t_path.c_str()     ) + _T("\n");
	info += _T("m_User Info: ")		+ CString(t_user_info.c_str()) + _T("\n");
	info += _T("m_Query:     ")     + CString(t_query.c_str()    ) + _T("\n");
	info += _T("m_Fragment:  ")     + CString(t_fragment.c_str() ) + _T("\n");
	info += _T("logHead() ===== ▶ 헤더 목록 =====\n");
	TRACE(info);   
	info="";
	utility::string_t t_rq     = uri::decode(rq.to_string()); // .request_uri();
	utility::string_t t_meth   = rq.method();
	info += _T("rq methods:    ")     + CString(t_meth.c_str() ) + _T("\n");
	info += _T("rq full string:")     + CString(t_rq.c_str()   ) + _T("\n");
	TRACE(info);
	const auto& headers = rq.headers();
	for (auto it = headers.begin(); it != headers.end(); ++it)
	{
		CStringA key(it->first.c_str());
		CStringA val(it->second.c_str());
		TRACE("logHead() headers  - %s: %s\n", key.GetString(), val.GetString());
	}
}
CRestGitApi::CRestGitApi(void) { }
CRestGitApi::~CRestGitApi(void) { }
std::vector<GitDiffLine2> CRestGitApi::ParseGitDiffOutput(const CString& output) //사용안함
{
	std::vector<GitDiffLine2> lines;
	std::istringstream input((LPCSTR)output);
	std::string lineStr;
	while (std::getline(input, lineStr))
	{
		GitDiffLine2 line;
		if (lineStr.find("diff --git"	) == 0) line.type = GitDiffLine2::FileHeader;
		else if (lineStr.find("index "	) == 0) line.type = GitDiffLine2::Index;
		else if (lineStr.find("---"		) == 0) line.type = GitDiffLine2::OldFile;
		else if (lineStr.find("+++"		) == 0) line.type = GitDiffLine2::NewFile;
		else if (lineStr.find("@@"		) == 0) line.type = GitDiffLine2::HunkHeader;
		else if (lineStr.find("+"		) == 0) line.type = GitDiffLine2::Added;
		else if (lineStr.find("-"		) == 0) line.type = GitDiffLine2::Removed;
		else	                                line.type = GitDiffLine2::Context;
		line.content = lineStr.c_str();  // std::wstring → CString
		lines.push_back(line);
	}
	return lines;
}
CString CRestGitApi::DetermineGitAction(TCHAR statusCode) //사용안함
{
	switch (statusCode)	{
	case 'A': return _T("create");
	case 'M':
	case 'R': // renamed
	case 'C': return _T("update"); // copied
	case 'D': return _T("delete");
	default:  return _T(""); // 알 수 없음
	}
}
bool CRestGitApi::starts_with(const std::string& str, const std::string& prefix) {	return str.size() >= prefix.size() && str.compare(0, prefix.size(), prefix) == 0; }
void CRestGitApi::parse_file_paths(const std::string& line) {	TRACE(_T("[파일 변경 시작]: %hs\n"), line.c_str()); }
void CRestGitApi::parse_index_info(const std::string& line) {	TRACE(_T("[인덱스 정보]: %hs\n"), line.c_str()); }
std::string CRestGitApi::parse_file(const std::string& line) {	std::string filepath = line.substr(line.find_last_of(' ') + 1);	TRACE(_T("[파일]: %hs\n"), filepath.c_str());	return filepath; }
void CRestGitApi::parse_hunk_header(const std::string& line) {	TRACE(_T("[청크 헤더]: %hs\n"), line.c_str()); }
void CRestGitApi::parse_git_diff_output(FILE* fp)  //사용안함 
{
	char buffer[1024];
	std::string line;
	std::string old_file, new_file;
	while (fgets(buffer, sizeof(buffer), fp)) {
		line = buffer;
		// 개행 제거
		if (!line.empty() && line[line.length() - 1] == '\n')
			line.erase(line.length() - 1);
		if (starts_with(line, "diff --git")) {
			parse_file_paths(line);
		} else if (starts_with(line, "index")) {
			parse_index_info(line);
		} else if (starts_with(line, "---")) {
			old_file = parse_file(line);
		} else if (starts_with(line, "+++")) {
			new_file = parse_file(line);
		} else if (starts_with(line, "@@")) {
			parse_hunk_header(line);
		} else if (starts_with(line, "-")) {
			TRACE(_T("삭제된 라인: %hs\n"), line.c_str());
		} else if (starts_with(line, "+")) {
			TRACE(_T("추가된 라인: %hs\n"), line.c_str());
		} else {
			TRACE(_T("  변경 없음: %hs\n"), line.c_str());
		}
	}
}
CString CRestGitApi::UrlEncode(CString str) {
	CString encoded;
	for (int i = 0; i < str.GetLength(); ++i) {
		TCHAR ch = str[i];
		if (_istalnum(ch) || ch == _T('-') || ch == _T('_') || ch == _T('.') || ch == _T('~')) {
			encoded += ch;
		} else {
			CString hex;
			hex.Format(_T("%%%02X"), (BYTE)ch);
			encoded += hex;
		}
	}
	return encoded;
}
// file 디버그용 출력 함수
void CRestGitApi::DownloadGitlabFile(const CString& projectPath, const CString filePath, const CString& branch, const CString& privateToken)
{
	CString rawPath = UrlEncode(filePath);
	CString sDOWNPATH = CString(g_tDOWNPATH.c_str());
	http_client client(g_tHOST_URL);
	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t((LPCTSTR)privateToken));

	client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>>
	{
		if (response.status_code() == status_codes::OK)		{
			std::wcout << L"다운로드 성공" << std::endl;
			return response.extract_vector(); // 바이너리 데이터 추출
		}
		else
		{
			std::wcout << L"다운로드 실패: " << response.status_code() << std::endl;
			return response.extract_vector(); // 바이너리 데이터 추출
		}
	})
	.then([=](pplx::task<std::vector<unsigned char>> previousTask)
	{
		try
		{
			std::vector<unsigned char> fileData = previousTask.get();
			if (!fileData.empty())
			{
				std::ofstream outFile(sDOWNPATH+filePath, std::ios::binary);
				outFile.write((const char*)fileData.data(), fileData.size());
				outFile.close();
				std::wcout << L"파일 저장 완료." << std::endl;
			}
			else
			{
				std::wcout << L"다운로드된 데이터가 비어 있습니다." << std::endl;
			}
		}
		catch (const std::exception& e)
		{
			std::cerr << "예외 발생: " << e.what() << std::endl;
		}
	})
		.wait(); // VS2010에서는 반드시 wait() 호출 필요 (비동기 동기화)
}


//file 목록 조회
std::vector<CString> CRestGitApi::GitLab_GetRepositoryTree2(json::value &Outjson)
{
	std::vector<CString> fileList;
	try
	{
		http_client client( g_tHOST_URL);
		// API 경로 구성: 
		uri_builder builder(g_tAPI_URL);
		utility::string_t path = g_tPROJECTID; path.append(U("/"));	path.append(g_tPROJECTPATH);
		builder.append(uri::encode_data_string(path));
		builder.append_path(U("repository/tree"));
		// 요청 객체 생성
		http_request request(methods::GET);
		request.set_request_uri(builder.to_string()); 
		// 헤더 추가
		request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
		request.headers().add(U("Content-Type") , g_tContent_Type ); // X

		logHead(client, request);
		http_response response = client.request(request).get();

		if (response.status_code() == status_codes::OK)
		{	
			web::json::value jsonVal = response.extract_json().get();
			Outjson = jsonVal;
			TraceLambda("GitLab_GetRepositoryTree2() diff_client", jsonVal);

			if (jsonVal.type() == web::json::value::Array) // 구형 버전에서는 type 검사 필요
			{
				size_t len = jsonVal.size();  // 오래된 버전에서는 size() 제공
				for (size_t i = 0; i < len; ++i)
				{
					web::json::value item = jsonVal[i];
					if (item.has_field(U("name")))
					{
						CString name(item[U("name")].as_string().c_str());
						fileList.push_back(name);
						TRACE("GitLab_GetRepositoryTree2(%2d)    name=[%s] \r\n",i , name );
					}
				}
			}
		}
	}
	catch (const std::exception& e)
	{
		AfxMessageBox(CString(L"예외 발생: ") + CString(CA2W(e.what())));
	}
	
	return fileList;
}

void CRestGitApi::GetDiffFromGitLab(const utility::string_t& commitSha, json::value &Outjson)
{
	web::http::client::http_client client(g_tHOST_URL+g_tAPI_URL);
	utility::string_t path =  uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH ) +
		U("/repository/commits/") + commitSha + U("/diff");

	web::http::http_request request(web::http::methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN); 
	request.set_request_uri(path);

	logHead(client, request);

	http_response diff_response = client.request(request).get();
	if (diff_response.status_code() == status_codes::OK)	
	{
		json::value jsonArray = diff_response.extract_json().get();
		TraceLambda("GetDiffFromGitLab(람다X) diff_client", jsonArray);
		Outjson = jsonArray;

		if (jsonArray.is_array())
		{
			size_t diffCount = jsonArray.size();
			for (size_t i = 0; i < diffCount; ++i)
			{
				const auto& diffItem = jsonArray[i];
				CString oldPath, newPath, diffText;

				if (diffItem.has_field(U("old_path")) && !diffItem[U("old_path")].is_null())
					oldPath = CString(diffItem[U("old_path")].as_string().c_str());

				if (diffItem.has_field(U("new_path")) && !diffItem[U("new_path")].is_null())
					newPath = CString(diffItem[U("new_path")].as_string().c_str());

				if (diffItem.has_field(U("diff")) && !diffItem[U("diff")].is_null())
					diffText = CString(diffItem[U("diff")].as_string().c_str());

				TRACE(L"[diff %d] old: %s, new: %s\n", i, oldPath, newPath);
			}
		}
	}	
}

// 파일 내용을 문자열로 읽어오는 함수
std::string CRestGitApi::readFileContent(const std::string& filePath) {
	std::ifstream fileStream(filePath.c_str(), std::ios::in | std::ios::binary);
	std::ostringstream contentStream;
	contentStream << fileStream.rdbuf();
	return contentStream.str();
}
std::string CRestGitApi::base64_encode(const std::vector<unsigned char>& data) {
	static const char base64_chars[] ="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	std::string result;
	size_t i = 0;
	unsigned char char_array_3[3];
	unsigned char char_array_4[4];

	for (size_t pos = 0; pos < data.size(); ++pos) {
		char_array_3[i++] = data[pos];
		if (i == 3) {
			char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
			char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
			char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
			char_array_4[3] = char_array_3[2] & 0x3f;

			for (i = 0; i < 4; i++)
				result += base64_chars[char_array_4[i]];
			i = 0;
		}
	}

	if (i) {
		for (size_t j = i; j < 3; j++)
			char_array_3[j] = '\0';

		char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
		char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
		char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
		char_array_4[3] = char_array_3[2] & 0x3f;

		for (size_t j = 0; j < i + 1; j++)
			result += base64_chars[char_array_4[j]];

		while (i++ < 3)
			result += '=';
	}

	return result;
}

// 이진 파일 읽기 후 base64 인코딩 //utility::conversions::to_base64(fileStream.rdbuf());
std::string CRestGitApi::readBinaryFileBase64(const std::string& filePath) {
	std::ifstream fileStream(filePath.c_str(), std::ios::in | std::ios::binary);
	std::vector<unsigned char> buffer((std::istreambuf_iterator<char>(fileStream)), std::istreambuf_iterator<char>());
	auto encoded = base64_encode(buffer) ; 
	return utility::conversions::to_utf8string(encoded);
}
// commit file push
void CRestGitApi::commitFileToGitLab(const std::string& branch,	const std::string& filePath, const std::string& commitMessage)
{
	string_t apiUrl = utility::conversions::to_string_t(g_tHOST_URL+g_tAPI_URL) +  utility::conversions::to_string_t(g_tPROJECTID) + utility::conversions::to_string_t("/repository/commits");

	// base64로 인코딩된 파일 내용
	std::string encodedContent = readBinaryFileBase64(filePath);

	// JSON 요청 구성
	json::value requestBody;
	requestBody[U("branch")] = json::value::string(utility::conversions::to_string_t(branch));
	requestBody[U("commit_message")] = json::value::string(utility::conversions::to_string_t(commitMessage));

	json::value action;
	action[U("action")] = json::value::string(U("create"));
	action[U("file_path")] = json::value::string(utility::conversions::to_string_t(filePath));
	action[U("content")] = json::value::string(utility::conversions::to_string_t(encodedContent));
	action[U("encoding")] = json::value::string(U("base64")); // 중요한 부분

	json::value actions = json::value::array();
	actions[0] = action;
	requestBody[U("actions")] = actions;

	// HTTP 요청
	http_client client(utility::conversions::to_string_t(apiUrl));
	http_request request(methods::POST);
	request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t(g_tPRIVATE_TOKEN));
	request.headers().add(U("Content-Type"), U("application/json"));
	request.set_body(requestBody);


	client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>> {
		if (response.status_code() == status_codes::OK || response.status_code() == status_codes::Created) {
			std::wcout << L"✅ 커밋이 성공적으로 생성되었습니다." << std::endl;
		} else {
			std::wcout << L"❌ 커밋 실패. 상태 코드: " << response.status_code() << std::endl;
		}

		return response.extract_vector(); // 이 반환 타입이 반드시 맞아야 함

	}).then([](std::vector<unsigned char> data) {
		std::wcout << L"🔍 데이터 크기: " << data.size() << L" 바이트" << std::endl;
	}).wait();

}

/*
	[get_commits_and_files(람다X) diff_client][TraceJson5] Record 0:
	{ "diff" : ""@@ -0" }
	{ "new_path" : "CommitDlg.cpp" }
	{ "old_path" : "CommitDlg.cpp" }
	{ "a_mode" : "0" }
	{ "b_mode" : "100644" }
	{ "new_file" : "true" }
	{ "renamed_file" : "false" }
	{ "deleted_file" : "false" }
	{ "generated_file" : "null" }
*/
//commit 최근 목록 조회
std::vector<CString> CRestGitApi::get_commits_and_files(json::value &Outjson)
{
	std::vector<CString> fileList;
	try
	{
		http_client client(g_tHOST_URL+g_tAPI_URL); 

		uri_builder builder; //2025.06.14 중복 (U("projects/"));
		builder.append(uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH ))
			.append(U("repository/commits"))
			.append_query(U("ref_name"), g_BRANCH)
			.append_query(U("per_page"), U("30"));

		http_request request(methods::GET);
		request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
		request.set_request_uri(builder.to_uri());

		logHead(client, request);

		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{	
			//	logHead(client);
			web::json::value jsonVal = response.extract_json().get();
			Outjson = jsonVal;
			TraceLambda("get_commits_and_files(람다X)", jsonVal);
			TRACE("get_commits_and_files() get commits jsonVal=[%s] \r\n", jsonVal.to_string().c_str());

			std::vector<utility::string_t> commit_ids;
			std::vector<utility::string_t> commit_tit;
			size_t length = jsonVal.size();
			for (size_t i = 0; i < length; ++i)
			{
				json::value item = jsonVal[i];
				if (item.has_field(U("id")) && item.has_field(U("title")))
				{
					utility::string_t id    = item[U("id")   ].as_string();
					utility::string_t title = item[U("title")].as_string();
					commit_ids.push_back(id);
					commit_tit.push_back(title);
				}
			}
			// commit diff 중첩된 요청들을 순차적으로 처리
			for (size_t i = 0; i < commit_ids.size(); ++i)
			{
				utility::string_t id       = commit_ids[i];
				utility::string_t title    = commit_tit[i];
				utility::string_t diff_url = g_tHOST_URL+g_tAPI_URL + uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH )	+ 
											U("/repository/commits/") + id + U("/diff"); // 2025.06.14 중복  U("projects/")+

				http_client diff_client(diff_url); 
				uri_builder diff_builder;
				diff_builder.append(U(""));

				http_request diff_request(methods::GET);
				diff_request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);	
				diff_request.set_request_uri(diff_builder.to_uri());

logHead(diff_client, diff_request);

				http_response diff_response = diff_client.request(diff_request).get();

				if (diff_response.status_code() == status_codes::OK)	{
					json::value diff_json = diff_response.extract_json().get();
					TraceLambda("get_commits_and_files(람다X) diff_client", diff_json);

					if (diff_json.is_array())	{
						size_t diff_len = diff_json.size();
						for (size_t j = 0; j < diff_len; ++j)	{
							json::value file = diff_json[j];
							if (file.has_field(U("new_path")))	{
								utility::string_t file_path = file[U("new_path")].as_string();						//	std::wcout << L"    - " << file_path << std::endl;

								TRACE("get_commits_and_files(%d)  id=[%s]  message=[%s] file_path2[%s] \r\n",
									i, CString(id.c_str()), CString(title.c_str()) ,CString(file_path.c_str()) );
	
									CString name(file[U("new_path")].as_string().c_str());
									fileList.push_back(name);
									TRACE("GitLab_GetRepositoryTree2(%2d)    name=[%s] \r\n",i , name );			

							}
						}
					}
				}
				else	{
					std::wcout << L"[Error] Diff fetch failed for commit: " << id << std::endl;
				}
				TRACE("get_commits_and_files(람다X)  diff_url [%s]\r\n", CString(diff_url.c_str()) );
			}
		}
	}
	catch (const std::exception& e)
	{
		AfxMessageBox(CString(L"예외 발생: ") + CString(CA2W(e.what())));
	}
	return fileList;
}

// 🔹 각 파일의 마지막 커밋 정보 가져오기
json::value CRestGitApi::getcommitLast(TR_LASTcommit& fi, json::value& commit) 
{
	try
	{
		http_client client(g_tHOST_URL+g_tAPI_URL); 

		uri_builder builder; 
		builder.append(uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH ))
			.append(U("repository/commits"))
			.append_query(U("path"), fi.path)
			.append_query(U("ref_name"), g_BRANCH)
			.append_query(U("per_page"), U("1"));

		http_request request(methods::GET);
		request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
		request.set_request_uri(builder.to_uri());

		logHead(client, request);

		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{	
			web::json::value jsonVal = response.extract_json().get();
			commit = jsonVal;
			TraceLambda("getcommitLast()", commit);
			TRACE("getcommitLast() get commits jsonVal=[%s] \r\n", jsonVal.to_string().c_str());
			size_t length = jsonVal.size();
			for (size_t i = 0; i < length; ++i)
			{
				json::value item = jsonVal[i];
				if (item.has_field(U("id") ))
				{
					fi.id = item[U("id")].as_string();
					fi.last_commit_date = item[U("committed_date")].as_string();
					fi.last_commit_message = item[U("message")].as_string();
				}
			}

		}
	}
	catch (const std::exception& e)
	{
		AfxMessageBox(CString(L"예외 발생: ") + CString(CA2W(e.what())));
	}
	return commit;

}





//utility::string_t WEB_url_B= U("http://127.0.0.1/root/htsmts/-/commit/c0f71f5d5ee2d198df20a2e94ab64dd225f21ac6");  //g_tHOST_URL+g_tAPI_URL + U("projects/")+ uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH )	+ U("/repository/commits/") + id + U("/diff");//				http_client diff_client(diff_url_B);

void CRestGitApi::LogWideStringChunks(const std::wstring& wstr)
{
	const int chunkSize = 1000;
	int len = (int)wstr.length();
	for (int i = 0; i < len; i += chunkSize)
	{
		CStringW chunk(wstr.substr(i, chunkSize).c_str());
		TRACE(L"%s", chunk.GetString());
	}
	TRACE(L"\n");
}

void CRestGitApi::TraceJson1(const web::json::value& jsonVal)
{
	utility::string_t jsonText =  jsonVal.to_string();  
	std::string narrowStr = utility::conversions::to_utf8string(jsonText);
	TRACE("[TraceJson1] JSON = %s\n", narrowStr.c_str());  //	std::wcout << L"TraceJson() 원본 JSON:\n" << jsonText << std::endl; 	// wide console 출력

	if (!jsonVal.is_array()) {
		TRACE("[TraceJson1](0)  JSON is not an array.\r\n");
		std::wcout << L"JSON is not an array." << std::endl;
		return;
	}

	try
	{
		size_t arr_size = jsonVal.size();
		TRACE("[TraceJson1](size) arr_size=(%2d)\r\n", static_cast<int>(arr_size));

		for (size_t i = 0; i < arr_size; ++i)
		{
			web::json::value item = jsonVal[i];

			if (item.is_object())
			{
				int id = -1;
				utility::string_t name = U("<no name>");

				if (item.has_field(U("id"))) {
					web::json::value idValue = item[U("id")];
					if (idValue.is_number())
						id = idValue.as_integer();  // 정수로 처리
				}

				if (item.has_field(U("name"))) {
					web::json::value nameValue = item[U("name")];
					if (nameValue.is_string())
						name = nameValue.as_string();
				}

				TRACE("[TraceJson1](for) id=(%2d) name=[%ls]\r\n", i, name.c_str());
			}
			else {
				TRACE("[TraceJson1](for) item is not an object.\r\n");
			}
		}
	}
	catch (const web::json::json_exception& e)
	{
		std::wcerr << L"JSON Exception: " << utility::conversions::to_string_t(e.what()) << std::endl;
	}
	catch (const std::exception& e)
	{
		std::wcerr << L"Exception: " << utility::conversions::to_string_t(e.what()) << std::endl;
	}
}


void CRestGitApi::TraceJson2(const web::json::value& jsonVal)
{
	try
	{
		// JSON 문자열 출력
		utility::string_t jsonText = jsonVal.to_string();

		// wide console 출력
		std::wcout << L"TraceJson() 원본 JSON:\n" << jsonText << std::endl;

		// TRACE 출력을 위한 변환
		std::string narrowStr = utility::conversions::to_utf8string(jsonText);
		TRACE("[TraceJson2] JSON = %s\n", narrowStr.c_str());

		// 이하 JSON 배열 처리
		if (!jsonVal.is_array()) {
			TRACE("[TraceJson2] is not array.\n");
			return;
		}

		size_t arr_size = jsonVal.size();
		TRACE("[TraceJson2] array size = %u\n", (unsigned)arr_size);

		for (size_t i = 0; i < arr_size; ++i)
		{
			web::json::value item = jsonVal[i];
			if (item.is_object())
			{
				utility::string_t name = item.has_field(U("name")) ? item[U("name")].as_string() : U("(no name)");
				utility::string_t id   = item.has_field(U("id"))   ? item[U("id")].as_string()   : U("(no id)");
				std::wcout << L"id: " << id << L", name: " << name << std::endl;
				TRACE("[TraceJson2](for) id=(%2d) name=[%ls]\r\n", i, name.c_str());

			}
		}
	}
	catch (const web::json::json_exception& e)
	{
		std::wcerr << L"JSON 예외: " << utility::conversions::to_string_t(e.what()) << std::endl;
	}
}


/* 람다방식은 = 접근불가 메모리가 모두 0 값을 반환한다
pplx::task<void> CRestGitApi::get_commits_and_files(json::value &Outjson)
{
	http_client client(g_tHOST_URL+g_tAPI_URL); 

	uri_builder builder; //2025.06.14 중복 (U("projects/"));
	builder.append(uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH ))
		.append(U("repository/commits"))
		.append_query(U("ref_name"), U("main"))
		.append_query(U("per_page"), U("5"));

	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
	request.set_request_uri(builder.to_uri());
	logHead(client, request);
	return client.request(request).then([&Outjson](http_response response)
	{
		if (response.status_code() != status_codes::OK)
		{
			std::wcout << L"[Error] Get commits failed.\n";
			return;
		}	
		json::value jsonVal = response.extract_json().get();
		g_Outjson=jsonVal;
		Outjson=jsonVal;
		TraceLambda("get_commits_and_files(람다)", jsonVal);
		TRACE("get_commits_and_files() get commits jsonVal=[%s] \r\n", jsonVal.to_string().c_str());
		std::vector<utility::string_t> commit_ids;
		std::vector<utility::string_t> commit_tit;
		size_t length = jsonVal.size();
		for (size_t i = 0; i < length; ++i)
		{
			json::value item = jsonVal[i];
			if (item.has_field(U("id")) && item.has_field(U("title")))
			{
				utility::string_t id    = item[U("id")   ].as_string();
				utility::string_t title = item[U("title")].as_string();
				commit_ids.push_back(id);
				commit_tit.push_back(title);
			}
		}
		// commit diff 중첩된 요청들을 순차적으로 처리
		for (size_t i = 0; i < commit_ids.size(); ++i)
		{
			utility::string_t id       = commit_ids[i];
			utility::string_t title    = commit_tit[i];
			utility::string_t diff_url = g_tHOST_URL+g_tAPI_URL + U("projects/")+ uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH )
				+ U("/repository/commits/") + id + U("/diff");
			http_client diff_client(diff_url);
			http_request diff_request(methods::GET);
			diff_request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
			// 주의: 비동기 결과를 기다리는 버전 (VS2010에서는 간단히 get 사용)
			http_response diff_response = diff_client.request(diff_request).get();
			if (diff_response.status_code() == status_codes::OK)	{
				json::value diff_json = diff_response.extract_json().get();
				if (diff_json.is_array())	{
					size_t diff_len = diff_json.size();
					for (size_t j = 0; j < diff_len; ++j)	{
						json::value file = diff_json[j];
						if (file.has_field(U("new_path")))	{
							utility::string_t file_path = file[U("new_path")].as_string();						//	std::wcout << L"    - " << file_path << std::endl;

							TRACE("get_commits_and_files(%d)  id=[%s]  message=[%s] file_path2[%s] \r\n",
								i, CString(id.c_str()), CString(title.c_str()) ,CString(file_path.c_str()) );
						}
					}
				}
			}
			else	{
				std::wcout << L"[Error] Diff fetch failed for commit: " << id << std::endl;
			}
			TRACE("get_commits_and_files()  diff_url [%s]\r\n", CString(diff_url.c_str()) );
		}
	}	
	);
}
*/

/*
void CRestGitApi::TraceJson3(const web::json::value& jsonVal)
{
	try
	{
		// 전체 JSON 문자열 출력
		std::string narrowStr = utility::conversions::to_utf8string(jsonVal.to_string());
		TRACE("[TraceJson3] JSON full dump= %s\n", narrowStr.c_str());

		if (!jsonVal.is_array()) {
			TRACE("[TraceJson3] JSON is not an array.\n");
			return;
		}

		size_t arr_size = jsonVal.size();
		TRACE("[TraceJson3] Array size = %u\n", static_cast<unsigned>(arr_size));

		for (size_t i = 0; i < arr_size; ++i)
		{
			const web::json::value& item = jsonVal[i];
			if (item.is_object())
			{
				TRACE("[TraceJson3][Item %u]\n", static_cast<unsigned>(i));

				// 이 버전에서는 키 목록을 얻는 함수가 없으므로
				// 미리 키를 알고 있어야 하며, 예시는 "id", "name", "type" 세 가지 키만 꺼내는 방식
				const utility::string_t keys[] = { U("id"), U("name"), U("type"), U("path"), U("mode") };

				for (int k = 0; k < sizeof(keys) / sizeof(keys[0]); ++k)
				{
					utility::string_t key = keys[k];

					if (item.has_field(key))
					{
						const web::json::value& val = item[key];

						std::string keyStr = utility::conversions::to_utf8string(key);
						std::string valueStr;

						if (val.is_string())
							valueStr = utility::conversions::to_utf8string(val.as_string());
						else if (val.is_number())
							valueStr = to_string_2010(val.as_double());
						else if (val.is_boolean())
							valueStr = val.as_bool() ? "true" : "false";
						else if (val.is_null())
							valueStr = "null";
						else
							valueStr = "[complex type]";

						TRACE("   %s = %s\n", keyStr.c_str(), valueStr.c_str());
					}
					else
					{
						TRACE("   key '%s' not found.\n", utility::conversions::to_utf8string(key).c_str());
					}
				}
			}
			else
			{
				TRACE("[TraceJson3] Warning: item[%u] is not an object.\n", static_cast<unsigned>(i));
			}
		}
	}
	catch (const web::json::json_exception& e)
	{
		std::string err = utility::conversions::to_utf8string(e.what());
		TRACE("[TraceJson3] JSON exception: %s\n", err.c_str());
	}
}
*/

#pragma comment(lib, "urlmon.lib")

// GitLab의 파일을 다운로드
bool CRestGitApi::DownloadFileFromGitLab(const CString& url, const CString& outputPath)
{
	HRESULT hr = URLDownloadToFile(NULL, url, outputPath, 0, NULL);
	return SUCCEEDED(hr);
}

// 로컬 파일 복사
bool CRestGitApi::CopyWorkingTreeFile(const CString& sourcePath, const CString& destPath)
{
	return CopyFile(sourcePath, destPath, FALSE);
}

// TortoiseGitMerge 실행
void CRestGitApi::LaunchDiffTool(const CString& fileFromGitLab, const CString& fileFromWorking)
{
	CString toolPath = "TortoiseGitMerge.exe";

	CString cmdLine;
	cmdLine.Format("\"%s\" /base:\"%s\" /mine:\"%s\" /label1:\"Windows1.xaml.cs : 6bc22ff7\" /label2:\"Windows1.xaml.cs : Working Tree\"",
		toolPath, fileFromGitLab, fileFromWorking);

	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi = {};

	BOOL success = CreateProcess(
		NULL,
		cmdLine.GetBuffer(),
		NULL, NULL,
		FALSE,
		0,
		NULL,
		NULL,
		&si,
		&pi
		);

	if (!success)
	{
		std::wcerr << "TortoiseGitMerge 실행 실패 (오류 코드: " << GetLastError() << ")\n";
	}
	else
	{
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
	}
}

// 전체 비교 함수
void CRestGitApi::CompareGitLabCommitWithWorkingTree()
{
	// 🔁 여기에 실제 Raw GitLab 파일 주소 입력하세요
//	CString gitlabRawUrl = "http://127.0.0.1%2api%2v4%2projects%2root%2Fhtsmts%2repository%2files%2Windows1.xaml.cs%2raw";

	CString project = _T("root%2Fhtsmts");  // URL 인코딩된 프로젝트 경로
	CString filePath = _T("Window1.xaml.cs"); // 파일명만 있는 경우 인코딩 불필요
	CString commitSha = _T("051d2a04"); // 또는 master 같은 브랜치명
	CString gitlabRawUrl;
	gitlabRawUrl.Format(
		_T("http://127.0.0.1/api/v4/projects/%s/repository/files/%s/raw?ref=%s"),
		project,
		filePath,
		commitSha
		);

	// 🔁 여기에 로컬 실제 파일 경로 입력하세요
	CString localFilePath = "D:\\gittest\\htsmts\\Window1.xaml.cs";

	// 임시 경로 생성
	TCHAR tempPath[MAX_PATH];
	GetTempPath(MAX_PATH, tempPath);
	sprintf(tempPath,"D:\\gittest\\htsmts");

	CString fileFromGitLab =localFilePath; // CString(tempPath) + "\\GitLab_Windows1.cs";
	CString fileFromWorking = localFilePath; //CString(tempPath) + "\\Local_Windows1.cs";




#if 0
	// GitLab 파일 다운로드
	if (!DownloadFileFromGitLab(gitlabRawUrl, fileFromGitLab))
	{
		std::wcerr << "[오류] GitLab 커밋 파일 다운로드 실패!\n";
		return;
	}

	// 로컬 파일 복사
	if (!CopyWorkingTreeFile(localFilePath, fileFromWorking))
	{
		std::wcerr << "[오류] 로컬 Working Tree 파일 복사 실패!\n";
		return;
	}
#endif
	// TortoiseGitMerge로 비교
	LaunchDiffTool(fileFromGitLab, fileFromWorking);
}




void TraceJson6(const char* context, const web::json::value& val, int indent = 0)
{
	std::string narrowStr = utility::conversions::to_utf8string(val.to_string());
	TRACE("[%s][TraceJson6] JSON full to_string=%s\n", context, narrowStr.c_str());

	CStringA tabs(' ', indent * 2);

	if (val.is_null())
	{
		TRACE("[%s][TraceJson6] %s[null]\n",context, tabs);
	}
	else if (val.is_boolean())
	{
		TRACE("[%s][TraceJson6] %s[bool] %s\n",context, tabs, val.as_bool() ? "true" : "false");
	}
	else if (val.is_number())
	{
		TRACE("[%s][TraceJson6] %s[double] %f\n",context,to_string_2010(val.as_double()) );
	}
	else if (val.is_string())
	{
		CStringA s(val.as_string().c_str());
		TRACE("[%s][TraceJson6] %s[string] %s\n", context,tabs, s);
	}
	else if (val.is_array())
	{
		size_t size = val.size();
		TRACE("[%s][TraceJson6] %s[array] size = %u\n",context, tabs, (unsigned)size);
		for (size_t i = 0; i < size; ++i)
		{
			CStringA idx; idx.Format("%s[%u]:", tabs, (unsigned)i);
			const web::json::value& item = val[i];
			TRACE("[%s][TraceJson66] %s\n",context, idx);
			TraceJson6(context, item, indent + 1);
		}
	}
	else
	{
		// 추측: object 타입. VC++2010에서는 직접적인 루프 불가 -> field_names()로 돌파
		TRACE("[%s] %s[object]\n", context, tabs);

		if (val.is_object())
		{
			TRACE("[%s] %s[object]\n", context, tabs);

			// 미리 알고 있는 키 목록을 배열로 정의
			const utility::string_t keys[] = {
				U("id"), U("name"), U("type"), U("path"), U("mode"), U("anotherKey")
			};

			for (size_t k = 0; k < _countof(keys); ++k)
			{
				const utility::string_t& key = keys[k];
				if (val.has_field(key))
				{
#ifdef _UNICODE
					CStringA keyA(CW2A(key.c_str()));
#else
					CStringA keyA(key.c_str());
#endif
					const web::json::value& sub = val[key];

					TRACE("[%s] %s%s:\n", context, tabs, keyA);
					TraceJson6(context, sub, indent + 1);
				}
			}
		}

	}
}




void TraceJson4(const char* callerName, const web::json::value& jsonVal)
{
	try
	{
		// 전체 JSON 문자열 출력
		std::string narrowStr = utility::conversions::to_utf8string(jsonVal.to_string());
		TRACE("[%s][TraceJson3] JSON full to_string=%s\n", callerName, narrowStr.c_str());

		if (!jsonVal.is_array()) {
			TRACE("[%s][TraceJson3] JSON is not an array.\n", callerName);
			return;
		}

		size_t arr_size = jsonVal.size();
		TRACE("[%s][TraceJson3] Array size = %u\n", callerName, static_cast<unsigned>(arr_size));

		for (size_t i = 0; i < arr_size; ++i)
		{
			const web::json::value& item = jsonVal[i];
			if (item.is_object())
			{
				TRACE("[%s][Item %u]\n", callerName, static_cast<unsigned>(i));

				const utility::string_t keys[] = { U("id"), U("name"), U("type"), U("path"), U("mode") };

				for (int k = 0; k < sizeof(keys) / sizeof(keys[0]); ++k)
				{
					utility::string_t key = keys[k];

					if (item.has_field(key))
					{
						const web::json::value& val = item[key];

						std::string keyStr = utility::conversions::to_utf8string(key);
						std::string valueStr;

						if (val.is_string())
							valueStr = utility::conversions::to_utf8string(val.as_string());
						else if (val.is_number())
							valueStr = to_string_2010(val.as_double());
						else if (val.is_boolean())
							valueStr = val.as_bool() ? "true" : "false";
						else if (val.is_null())
							valueStr = "null";
						else
							valueStr = "[complex type]";

						TRACE("[%s]   %-6s = %s\n", callerName, keyStr.c_str(), valueStr.c_str());
					}
					else
					{
						TRACE("[%s]   key '%s' not found.\n", callerName, utility::conversions::to_utf8string(key).c_str());
					}
				}
			}
			else
			{
				TRACE("[%s][TraceJson3] Warning: item[%u] is not an object.\n", callerName, static_cast<unsigned>(i));
			}
		}
	}
	catch (const web::json::json_exception& e)
	{
		std::string err = utility::conversions::to_utf8string(e.what());
		TRACE("[%s][TraceJson3] JSON exception: %s\n", callerName, err.c_str());
	}
}

void CRestGitApi::TraceJson3(const char* callerName, const web::json::value& jsonVal)
{
	try
	{
		// 전체 JSON 문자열 출력
		std::string narrowStr = utility::conversions::to_utf8string(jsonVal.to_string());
		TRACE("[%s][TraceJson3] JSON full to_string=%s\n", callerName, narrowStr.c_str());

		if (!jsonVal.is_array()) {
			TRACE("[%s][TraceJson3] JSON is not an array.\n", callerName);
			return;
		}

		size_t arr_size = jsonVal.size();
		TRACE("[%s][TraceJson3] Array size = %u\n", callerName, static_cast<unsigned>(arr_size));

		for (size_t i = 0; i < arr_size; ++i)
		{
			const web::json::value& item = jsonVal[i];
			if (item.is_object())
			{
				TRACE("[%s][Item %u]\n", callerName, static_cast<unsigned>(i));

				const utility::string_t keys[] = { U("id"), U("name"), U("type"), U("path"), U("mode") };

				for (int k = 0; k < sizeof(keys) / sizeof(keys[0]); ++k)
				{
					utility::string_t key = keys[k];

					if (item.has_field(key))
					{
						const web::json::value& val = item[key];

						std::string keyStr = utility::conversions::to_utf8string(key);
						std::string valueStr;

						if (val.is_string())
							valueStr = utility::conversions::to_utf8string(val.as_string());
						else if (val.is_number())
							valueStr = to_string_2010(val.as_double());
						else if (val.is_boolean())
							valueStr = val.as_bool() ? "true" : "false";
						else if (val.is_null())
							valueStr = "null";
						else
							valueStr = "[complex type]";

						TRACE("[%s]   %-6s = %s\n", callerName, keyStr.c_str(), valueStr.c_str());
					}
					else
					{
						TRACE("[%s]   key '%s' not found.\n", callerName, utility::conversions::to_utf8string(key).c_str());
					}
				}
			}
			else
			{
				TRACE("[%s][TraceJson3] Warning: item[%u] is not an object.\n", callerName, static_cast<unsigned>(i));
			}
		}
	}
	catch (const web::json::json_exception& e)
	{
		std::string err = utility::conversions::to_utf8string(e.what());
		TRACE("[%s][TraceJson3] JSON exception: %s\n", callerName, err.c_str());
	}
}


/*
	utility::string_t diff_url =g_tHOST_URL+g_tAPI_URL + web::http::uri::encode_data_string( utility::conversions::to_string_t(  g_tPROJECTID+U("/")+g_tPROJECTPATH ) ) +
		U("/repository/commits/") + commitSha + U("/diff");
	http_client client( diff_url );   
	uri_builder diff_builder;
	diff_builder.append(U(" "));
	http_request request(http::methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);	
	request.set_request_uri(diff_builder.to_uri());
*/
/*
	web::http::client::http_client client(U("https://gitlab.com/api/v4"));
	// 예: /projects/:id/repository/commits/:sha/diff
	utility::string_t path = U("/projects/") + web::http::uri::encode_data_string(projectId) +
		U("/repository/commits/") + commitSha + U("/diff");

	web::http::http_request request(web::http::methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), U("your_access_token")); // GitLab 토큰
	request.set_request_uri(path);

	client.request(request)
		.then([](web::http::http_response response) {
			if (response.status_code() == web::http::status_codes::OK) {
				return response.extract_json();
			} else {
				throw std::runtime_error("GitLab API 호출 실패");
			}
	})
*/

/*
			// commit diff 중첩된 요청들을 순차적으로 처리
			for (size_t i = 0; i < commit_ids.size(); ++i)
			{
				utility::string_t id       = commit_ids[i];
				utility::string_t title    = commit_tit[i];
				utility::string_t diff_url = g_tHOST_URL+g_tAPI_URL + uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH )	+ 
											U("/repository/commits/") + id + U("/diff"); // 2025.06.14 중복  U("projects/")+

				http_client diff_client(diff_url); 
				uri_builder diff_builder;
				diff_builder.append(U(""));

				http_request diff_request(methods::GET);
				diff_request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);	
				diff_request.set_request_uri(diff_builder.to_uri());

logHead(diff_client, diff_request);

				http_response diff_response = diff_client.request(diff_request).get();

				if (diff_response.status_code() == status_codes::OK)	{
					json::value diff_json = diff_response.extract_json().get();
					TraceLambda("get_commits_and_files(람다X) diff_client", diff_json);

					if (diff_json.is_array())	{
						size_t diff_len = diff_json.size();
						for (size_t j = 0; j < diff_len; ++j)	{
							json::value file = diff_json[j];
							if (file.has_field(U("new_path")))	{
								utility::string_t file_path = file[U("new_path")].as_string();						//	std::wcout << L"    - " << file_path << std::endl;

								TRACE("get_commits_and_files(%d)  id=[%s]  message=[%s] file_path2[%s] \r\n",
									i, CString(id.c_str()), CString(title.c_str()) ,CString(file_path.c_str()) );
	
									CString name(file[U("new_path")].as_string().c_str());
									fileList.push_back(name);
									TRACE("GitLab_GetRepositoryTree2(%2d)    name=[%s] \r\n",i , name );			

							}
						}
					}
				}
				else	{
					std::wcout << L"[Error] Diff fetch failed for commit: " << id << std::endl;
				}
				TRACE("get_commits_and_files(람다X)  diff_url [%s]\r\n", CString(diff_url.c_str()) );
			}
*/

/*
BOOL CCommitDlg::CommitToGitLab()
{
	try {
		http_client client(U("http://127.0.0.1/api/v4"));

		json::value root;
		CString branch = m_bNewBranch ? m_strNewBranchName : _T("main");
		CString commitMsg = m_strCommitMsg;
		if (!m_strBugID.IsEmpty()) {
			commitMsg += _T(" (") + m_strBugID + _T(")");
		}

		wchar_t* buf;
		std::wstring utf8branch; int len = MultiByteToWideChar(CP_ACP, 0, branch.GetString(), -1, NULL, 0);
		if (len > 0) 
		{	
			buf = new wchar_t[len];	MultiByteToWideChar(CP_ACP, 0, branch.GetString(), -1, buf, len);	utf8branch = buf;	delete[] buf;
		}

		std::wstring utf8commitMsg;		len = MultiByteToWideChar(CP_ACP, 0, commitMsg.GetString(), -1, NULL, 0);
		if (len > 0) 
		{	
			buf = new wchar_t[len];		MultiByteToWideChar(CP_ACP, 0, commitMsg.GetString(), -1, buf, len);	utf8commitMsg = buf;	delete[] buf;
		}

		std::wstring utf8strAuthor;		len = MultiByteToWideChar(CP_ACP, 0, m_strAuthor.GetString(), -1, NULL, 0);
		if (len > 0) 
		{	
			buf = new wchar_t[len];	MultiByteToWideChar(CP_ACP, 0, m_strAuthor.GetString(), -1, buf, len);	utf8strAuthor = buf;	delete[] buf;
		}
		root[U("branch")] = json::value::string(utility::conversions::to_string_t(utf8branch));	
		root[U("commit_message")] = json::value::string(utility::conversions::to_string_t(utf8commitMsg));
		if (!m_strAuthor.IsEmpty())
			root[U("author_name")] = json::value::string(utility::conversions::to_string_t(utf8strAuthor));	

		json::value actions = json::value::array();
		int count = m_fileList.GetItemCount();
		int idx = 0;
		for (int i = 0; i < count; ++i) {
			if (m_fileList.GetCheck(i)) 
			{
				CString filePath = m_fileList.GetItemText(i, 0);
				std::wstring utf8filePath;	len = MultiByteToWideChar(CP_ACP, 0, filePath.GetString(), -1, NULL, 0);
				if (len > 0) 
				{	
					buf = new wchar_t[len];	MultiByteToWideChar(CP_ACP, 0, filePath.GetString(), -1, buf, len);	utf8filePath = buf;	delete[] buf;
				}
				json::value act;
				act[U("action")]    = json::value::string(utility::conversions::to_string_t(U("update")));	
		//		act[U("action")]    = json::value::string(utility::conversions::to_string_t(U("create")));	

				utility::string_t tfilePath = utf8filePath;
				act[U("file_path")] = json::value::string(utility::conversions::to_string_t(tfilePath));	
				act[U("content")]   = json::value::string(utility::conversions::to_string_t(U("자동 커밋된 내용입니다."))); 

				actions[idx++] = act;
			}
		}

		root[U("actions")] = actions;

		// 요청 URL
		CString url;
		url.Format(_T("/projects/%s/repository/commits"), m_projectID);
		CStringA apiUrlA = url; // ANSI 문자열
		std::wstring apiUrlW;	len = MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, NULL, 0);
		if (len > 0) 
		{	
			wchar_t* buf1 = new wchar_t[len];	MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, buf1, len);		apiUrlW = buf1;	delete[] buf1;
		}

		http_request request(methods::POST);	
		request.set_request_uri(utility::conversions::to_string_t(apiUrlW));
		request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t((LPCTSTR)m_accessToken));
		request.headers().add(U("Content-Type"), U("application/json"));
		request.set_body(root);	//request.set_body(root.serialize());

		http_response response = client.request(request).get();	// 동기 방식 호출 (2010에서는 async task 안됨)
		if (response.status_code() == status_codes::Created) {
			return TRUE;
		}
		else {
			std::wcout << L"에러: " << response.status_code() << std::endl;
			std::wcout << L"❌ 커밋 실패. 상태 코드: " << response.status_code() << std::endl;
		}
	}
	catch (const std::exception& ex) {
		AfxMessageBox(CString("예외 발생: ") + CString(ex.what()));
	}
	return FALSE;
}

*/
