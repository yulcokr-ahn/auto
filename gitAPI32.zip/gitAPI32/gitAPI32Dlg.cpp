﻿
// gitAPI32Dlg.cpp : 구현 파일
//

#include "stdafx.h"
#include "gitAPI32.h"
#include "gitAPI32Dlg.h"
#include "afxdialogex.h"
#include "GitLabApi.h"

#include <wininet.h>
#pragma comment(lib, "wininet.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//2010 ver 옵션 c++ 추가 include  D:\gitlab\cpprestsdk-1.2.0\Release\include		//git clone https://github.com/surinkim/cpprestsdk-1.2.0
#include <cpprest/http_client.h>
#include <cpprest/filestream.h>
#include <cpprest/json.h>
//#include <cpprest/base64.h>  // base64 인코딩을 위해 필요

#include <iostream>
#include <afx.h>  // CString, TRACE
#include <atlstr.h>  // CString

using namespace std;
using namespace web;
using namespace web::http;
using namespace web::http::client;
using namespace utility;     // string_t 정의
using namespace web::json;   // json::value
using namespace utility;                    // Common utilities like string conversions
using namespace concurrency::streams;       // Asynchronous streams
using namespace pplx;

CString UrlEncode(CString str) {
	CString encoded;
	for (int i = 0; i < str.GetLength(); ++i) {
		TCHAR ch = str[i];
		if (_istalnum(ch) || ch == _T('-') || ch == _T('_') || ch == _T('.') || ch == _T('~')) {
			encoded += ch;
		} else {
			CString hex;
			hex.Format(_T("%%%02X"), (BYTE)ch);
			encoded += hex;
		}
	}
	return encoded;
}


// 디버그용 출력 함수
void DownloadGitlabFile(const CString& projectPath, const CString filePath, const CString& branch, const CString& privateToken)
{
	CString rawPath = UrlEncode(filePath);

	CString downloadUrl;
	downloadUrl.Format(_T("http://localhost/api/v4/projects/%s/repository/files/%s/raw."),projectPath, rawPath); //	downloadUrl.Format(_T("http://localhost/api/v4/projects/%s/repository/files/%s/raw?ref=%s"),projectPath, rawPath, branch);
	CStringA apiUrlA = downloadUrl; // ANSI 문자열
	std::wstring apiUrlW;
	int len = MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, NULL, 0);
	if (len > 0) {	wchar_t* buf = new wchar_t[len];
	MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, buf, len);
	apiUrlW = buf;	delete[] buf;
	}

	http_client client(apiUrlW);
	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t((LPCTSTR)privateToken));

	client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>>
	{
		if (response.status_code() == status_codes::OK)		{
			std::wcout << L"다운로드 성공" << std::endl;
			return response.extract_vector(); // 바이너리 데이터 추출
		}
		else
		{
			std::wcout << L"다운로드 실패: " << response.status_code() << std::endl;
			return response.extract_vector(); // 바이너리 데이터 추출
		}
	})
		.then([=](pplx::task<std::vector<unsigned char>> previousTask)
	{
		try
		{
			std::vector<unsigned char> fileData = previousTask.get();
			if (!fileData.empty())
			{
				std::ofstream outFile(filePath, std::ios::binary);
				outFile.write((const char*)fileData.data(), fileData.size());
				outFile.close();
				std::wcout << L"파일 저장 완료." << std::endl;
			}
			else
			{
				std::wcout << L"다운로드된 데이터가 비어 있습니다." << std::endl;
			}
		}
		catch (const std::exception& e)
		{
			std::cerr << "예외 발생: " << e.what() << std::endl;
		}
	})
		.wait(); // VS2010에서는 반드시 wait() 호출 필요 (비동기 동기화)
}
// 목록
std::vector<CString> GitLab_GetRepositoryTree2()
{
	std::vector<CString> fileList;
	CString privateToken = _T("glpat-qYj17RdNrDxAWKqvt16o"); // 실제 토큰으로 교체
	utility::string_t projectID = U("root");
	utility::string_t projectPath = U("htsmts");
	CString projectID_Path  = _T("root%2Fhtsmts");
	CString Content_Type =_T("application/json");
	CString apiUrl;	
	apiUrl.Format(_T("http://127.0.0.1"));
	CStringA apiUrlA = apiUrl; // ANSI 문자열
	std::wstring apiUrlW;
	int len = MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, NULL, 0);
	if (len > 0) {	wchar_t* buf = new wchar_t[len];
	MultiByteToWideChar(CP_ACP, 0, apiUrlA.GetString(), -1, buf, len);
	apiUrlW = buf;	delete[] buf;
	}

	CString apiUrl2;	
	apiUrl2.Format(_T("/api/v4/projects/%s/repository/tree"), projectID_Path);
	CStringA apiUrlB = apiUrl2; // ANSI 문자열
	std::wstring apiUrlW2;
	int len2 = MultiByteToWideChar(CP_ACP, 0, apiUrlB.GetString(), -1, NULL, 0);
	if (len2 > 0) {	wchar_t* buf2 = new wchar_t[len2];
	MultiByteToWideChar(CP_ACP, 0, apiUrlB.GetString(), -1, buf2, len2);
	apiUrlW2 = buf2;	delete[] buf2;
	}

	try
	{
		http_client client(apiUrlW);
		// API 경로 구성: 
		uri_builder builder(U("/api/v4/projects/"));

		utility::string_t path = projectID.append(U("/"));	path.append(projectPath);
		builder.append(uri::encode_data_string(path));
		builder.append_path(U("repository/tree"));
		// 요청 객체 생성
		http_request request(methods::GET);
		request.set_request_uri(builder.to_string()); // O	//	request.set_request_uri(builder.to_uri());  // O
		// 헤더 추가
		request.headers().add(U("PRIVATE-TOKEN"), (privateToken) ); // <-- GitLab 토큰 입력
		request.headers().add(U("Content-Type") , (Content_Type) ); // X
		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{	
			// URI 정보 분해
			uri request_uri = client.base_uri();
			utility::string_t t_scheme    = request_uri.scheme();
			utility::string_t t_host      = request_uri.host();
			utility::string_t t_user_info = request_uri.user_info();
			utility::string_t t_path      = request_uri.path();
			utility::string_t t_query     = request_uri.query();
			utility::string_t t_fragment  = request_uri.fragment();
			CString info;
			info += _T("===== URI 구성 =====\n");
			info += _T("m_Scheme: ")    + CString(t_scheme.c_str()   ) + _T("\n");
			info += _T("m_Host: ")      + CString(t_host.c_str()     ) + _T("\n");
			info += _T("m_User Info: ") + CString(t_user_info.c_str()) + _T("\n");
			info += _T("m_Path: ")      + CString(t_path.c_str()     ) + _T("\n");
			info += _T("m_Query: ")     + CString(t_query.c_str()    ) + _T("\n");
			info += _T("m_Fragment: ")  + CString(t_fragment.c_str() ) 
				+ _T("\n\n");
			info += _T("===== JSON 내용 =====\n");
			TRACE(info);
			web::json::value jsonVal = response.extract_json().get();
			if (jsonVal.type() == web::json::value::Array) // 구형 버전에서는 type 검사 필요
			{
				size_t len = jsonVal.size();  // 오래된 버전에서는 size() 제공
				for (size_t i = 0; i < len; ++i)
				{
					web::json::value item = jsonVal[i];
					if (item.has_field(U("name")))
					{
						CString name(item[U("name")].as_string().c_str());
						fileList.push_back(name);
						TRACE("GitLab_GetRepositoryTree2(%d)    name=[%s] \r\n",i , name );
					}
				}
			}
		}
	}
	catch (const std::exception& e)
	{
		AfxMessageBox(CString(L"예외 발생: ") + CString(CA2W(e.what())));
	}

	return fileList;
}




// 파일 내용을 문자열로 읽어오는 함수
std::string readFileContent(const std::string& filePath) {
	std::ifstream fileStream(filePath.c_str(), std::ios::in | std::ios::binary);
	std::ostringstream contentStream;
	contentStream << fileStream.rdbuf();
	return contentStream.str();
}


std::string base64_encode(const std::vector<unsigned char>& data) {
	static const char base64_chars[] ="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	std::string result;
	size_t i = 0;
	unsigned char char_array_3[3];
	unsigned char char_array_4[4];

	for (size_t pos = 0; pos < data.size(); ++pos) {
		char_array_3[i++] = data[pos];
		if (i == 3) {
			char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
			char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
			char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
			char_array_4[3] = char_array_3[2] & 0x3f;

			for (i = 0; i < 4; i++)
				result += base64_chars[char_array_4[i]];
			i = 0;
		}
	}

	if (i) {
		for (size_t j = i; j < 3; j++)
			char_array_3[j] = '\0';

		char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
		char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
		char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
		char_array_4[3] = char_array_3[2] & 0x3f;

		for (size_t j = 0; j < i + 1; j++)
			result += base64_chars[char_array_4[j]];

		while (i++ < 3)
			result += '=';
	}

	return result;
}

// 이진 파일 읽기 후 base64 인코딩 //utility::conversions::to_base64(fileStream.rdbuf());
std::string readBinaryFileBase64(const std::string& filePath) {
	std::ifstream fileStream(filePath.c_str(), std::ios::in | std::ios::binary);
	std::vector<unsigned char> buffer((std::istreambuf_iterator<char>(fileStream)), std::istreambuf_iterator<char>());
	auto encoded = base64_encode(buffer) ; 
	return utility::conversions::to_utf8string(encoded);
}


void commitFileToGitLab(const std::string& projectId,
	const std::string& branch,
	const std::string& filePath,
	const std::string& commitMessage,
	const std::string& privateToken) {
		std::string apiUrl = "http://localhost/api/v4/projects/" + projectId + "/repository/commits";

		// base64로 인코딩된 파일 내용
		std::string encodedContent = readBinaryFileBase64(filePath);

		// JSON 요청 구성
		json::value requestBody;
		requestBody[U("branch")] = json::value::string(utility::conversions::to_string_t(branch));
		requestBody[U("commit_message")] = json::value::string(utility::conversions::to_string_t(commitMessage));

		json::value action;
		action[U("action")] = json::value::string(U("create"));
		action[U("file_path")] = json::value::string(utility::conversions::to_string_t(filePath));
		action[U("content")] = json::value::string(utility::conversions::to_string_t(encodedContent));
		action[U("encoding")] = json::value::string(U("base64")); // 중요한 부분

		json::value actions = json::value::array();
		actions[0] = action;
		requestBody[U("actions")] = actions;

		// HTTP 요청
		http_client client(utility::conversions::to_string_t(apiUrl));
		http_request request(methods::POST);
		request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t(privateToken));
		request.headers().add(U("Content-Type"), U("application/json"));
		request.set_body(requestBody);


		client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>> {
			if (response.status_code() == status_codes::OK || response.status_code() == status_codes::Created) {
				std::wcout << L"✅ 커밋이 성공적으로 생성되었습니다." << std::endl;
			} else {
				std::wcout << L"❌ 커밋 실패. 상태 코드: " << response.status_code() << std::endl;
			}

			return response.extract_vector(); // 이 반환 타입이 반드시 맞아야 함

		}).then([](std::vector<unsigned char> data) {
			std::wcout << L"🔍 데이터 크기: " << data.size() << L" 바이트" << std::endl;
		}).wait();

}


//CString privateToken = _T("glpat-qYj17RdNrDxAWKqvt16o"); // 실제 토큰으로 교체
//utility::string_t projectID = U("root");
//utility::string_t projectPath = U("htsmts");
//CString projectID_Path  = _T("root%2Fhtsmts");
//CString Content_Type =_T("application/json");
//std::string apiUrl = "http://localhost/api/v4/projects/" + projectId + "/repository/commits";
/*
ref_name	브랜치 이름 (예: main, master)
	path	특정 파일 또는 폴더 경로의 커밋만
	since	ISO 8601 포맷 시작일자 (2024-01-01T00:00:00Z)
	until	끝나는 일자
	author	작성자 필터
	per_page	페이지당 커밋 수 (기본 20, 최대 100)
	page	페이지 번호

ref_name=main	git log main
	path=src/index.js	git log -- src/index.js
	since=2024-01-01	git log --since="2024-01-01"
	until=2024-05-01	git log --until="2024-05-01"
	author=홍길동	git log --author="홍길동"
	per_page=10	git log -n 10



	1. 브랜치 기준 커밋:
	git log origin/main --oneline

	2. 특정 경로에 대한 커밋:
	git log -- path/to/file

	3. 기간 필터링:
	git log --since="2024-01-01" --until="2024-05-26"

	4. JSON 스타일 출력 (파싱용):
	git log --pretty=format:'{"hash":"%H","author":"%an","date":"%ad","message":"%s"},'




	🔄 GitLab REST API vs Git 명령어 비교
	목적	                GitLab REST API	Git CLI
	원격 저장소 커밋 보기	✅ 가능	        ❌ (로컬 복제 필요)
	특정 브랜치 커밋 보기	✅ ref_name	    ✅ git log 브랜치명
	특정 파일 커밋 보기	    ✅ path=	    ✅ git log -- path
	날짜 필터링	            ✅ since, until	✅ --since, --until
	작성자 필터	            ✅ author	    ✅ --author
*/
//커피원가 120원 사기를 궁리중
//한국 이미지 추락 국제사기 가능한 나라가 국제사기단 이제명 vs 헌법 : 내란 수괴 3대 두목 김_정은 짐로저스 이재명 이게 내란있다 U N 위반
const utility::string_t GITLAB_API_URL = U("http://localhost/api/v4/");
const utility::string_t PROJECT_ID  = U("root%2Fhtsmts"); // 또는 URL 인코딩된 경로 (예: user%2Fmyrepo)
const utility::string_t PROJECT_ID2  = U("root/htsmts"); //encode_data_string(PROJECT_ID2)
const utility::string_t PRIVATE_TOKEN = U("glpat-qYj17RdNrDxAWKqvt16o"); // 실제 토큰으로 교체 // U("your_gitlab_private_token");

//diff_url [projects/root%2Fhtsmts/repository/commits?ref_name=main&per_page=5]
pplx::task<void> get_commits_and_files()
{
	http_client client(GITLAB_API_URL);

	uri_builder builder(U("projects/"));
	builder.append(PROJECT_ID)
		.append(U("repository/commits"))
		.append_query(U("ref_name"), U("main"))
		.append_query(U("per_page"), U("5"));

	TRACE("  diff_url [%s]\r\n", CString(builder.to_uri().to_string().c_str()) );

	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), PRIVATE_TOKEN);
	request.set_request_uri(builder.to_uri());

	return client.request(request).then([](http_response response)
	{
		if (response.status_code() != status_codes::OK)
		{
			std::wcout << L"[Error] Get commits failed.\n";
			return;
		}

		web::json::value jsonVal = response.extract_json().get();
		TRACE("get commits jsonVal=[%s] \r\n", jsonVal.to_string().c_str());

		std::vector<utility::string_t> commit_ids;
		std::vector<utility::string_t> commit_tit;
		size_t length = jsonVal.size();
		for (size_t i = 0; i < length; ++i)
		{
			json::value item = jsonVal[i];
			if (item.has_field(U("id")) && item.has_field(U("title")))
			{
				utility::string_t id    = item[U("id")   ].as_string();
				utility::string_t title = item[U("title")].as_string();	// CString id2(id.c_str());	CString message2(title.c_str()); TRACE("get_commits_and_files(%d)  id=[%s]  message=[%s] \r\n", i, id2, message2);
				commit_ids.push_back(id);
				commit_tit.push_back(title);
			}
		}

		// 중첩된 요청들을 순차적으로 처리
		for (size_t i = 0; i < commit_ids.size(); ++i)
		{
			utility::string_t id       = commit_ids[i];
			utility::string_t title    = commit_tit[i];
			utility::string_t diff_url = GITLAB_API_URL + U("projects/")+ uri::encode_data_string(PROJECT_ID2)
				+ U("/repository/commits/") + id + U("/diff");

			http_client diff_client(diff_url);
			http_request diff_request(methods::GET);
			diff_request.headers().add(U("PRIVATE-TOKEN"), PRIVATE_TOKEN);

			// 주의: 비동기 결과를 기다리는 버전 (VS2010에서는 간단히 get 사용)
			http_response diff_response = diff_client.request(diff_request).get();
			if (diff_response.status_code() == status_codes::OK)	{
				json::value diff_json = diff_response.extract_json().get();
				if (diff_json.is_array())	{
					size_t diff_len = diff_json.size();
					for (size_t j = 0; j < diff_len; ++j)	{
						json::value file = diff_json[j];
						if (file.has_field(U("new_path")))	{
							utility::string_t file_path = file[U("new_path")].as_string();						//	std::wcout << L"    - " << file_path << std::endl;
							
							TRACE("get_commits_and_files(%d)  id=[%s]  message=[%s] file_path2[%s] \r\n",
								i, CString(id.c_str()), CString(title.c_str()) ,CString(file_path.c_str()) );
						}
					}
				}
			}
			else	{
				std::wcout << L"[Error] Diff fetch failed for commit: " << id << std::endl;
			}
			TRACE("  diff_url [%s]\r\n", CString(diff_url.c_str()) );
		}
	});
}


/*
int get_commits_and_files()
{
	// GitLab 설정
	utility::string_t base_url = U("https://localhost.com/api/v4");
	utility::string_t project_id =  U("root%2Fhtsmts");  // 예: "12345678"
	utility::string_t private_token = U("glpat-qYj17RdNrDxAWKqvt16o"); // GitLab Personal Access Token
	// API 요청 URL 구성
	utility::string_t request_url = base_url + U("/projects/") + uri::encode_data_string(project_id) + U("/repository/commits");

	// HTTP 클라이언트
	http_client client(request_url);
	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), private_token);

	try
	{
		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{
			json::value json_response = response.extract_json().get();

			if (json_response.is_array())
			{
				size_t len = json_response.size();

				for (size_t i = 0; i < len; ++i)
				{
					json::value commit = json_response[i];

					if (commit.has_field(U("id")) && commit.has_field(U("title")))
					{
						utility::string_t commit_id = commit[U("id")].as_string();
						utility::string_t commit_title = commit[U("title")].as_string();


						CString id2(commit[U("id")].as_string().c_str());
						CString message2(commit[U("title")].as_string().c_str());
						TRACE("get_commits_and_files(%d)  id=[%s]  message=[%s] \r\n",i ,id2, message2 );


						// 변경된 파일 보기
						utility::string_t diff_url = base_url + U("/projects/") + uri::encode_data_string(project_id)+ U("/repository/commits/") + commit_id + U("/diff");

						http_client diff_client(diff_url);
						http_request diff_request(methods::GET);
						diff_request.headers().add(U("PRIVATE-TOKEN"), private_token);

						http_response diff_response = diff_client.request(diff_request).get();
						if (diff_response.status_code() == status_codes::OK)
						{
							json::value diff_json = diff_response.extract_json().get();
							if (diff_json.is_array())
							{
								size_t diff_len = diff_json.size();
								for (size_t j = 0; j < diff_len; ++j)
								{
									json::value diff_item = diff_json[j];
									if (diff_item.has_field(U("new_path")))
									{
										utility::string_t file_path = diff_item[U("new_path")].as_string();
										//std::wcout << L"  - " << file_path << std::endl;



										CString file_path2(diff_item[U("new_path")].as_string().c_str());
										TRACE("  - %s \r\n",file_path2);


									}
								}
							}
						}
						else
						{
							std::wcout << L"  [Error] Diff 실패: " << diff_response.status_code() << std::endl;
						}
					}
				}
			}
		}
		else
		{
			std::wcout << L"[Error] HTTP 실패: " << response.status_code() << std::endl;
		}
	}
	catch (const std::exception& ex)
	{
		std::wcout << L"[예외 발생] " << ex.what() << std::endl;
	}

	return 0;
}
*/
/*
void commitFileToGitLab(const std::string& projectId,
	const std::string& branch,
	const std::string& filePath,
	const std::string& commitMessage,
	const std::string& privateToken) {
		// GitLab API URL 구성
		std::string apiUrl = "http://localhost/api/v4/projects/" + projectId + "/repository/commits";

		// 파일 내용 읽기
		std::string fileContent = readFileContent(filePath);

		// JSON 요청 본문 구성
		json::value requestBody;
		requestBody[U("branch")] = json::value::string(utility::conversions::to_string_t(branch));
		requestBody[U("commit_message")] = json::value::string(utility::conversions::to_string_t(commitMessage));

		// actions 배열 구성
		json::value action;
		action[U("action")] = json::value::string(U("create"));
		action[U("file_path")] = json::value::string(utility::conversions::to_string_t(filePath));
		action[U("content")] = json::value::string(utility::conversions::to_string_t(fileContent));

		json::value actions = json::value::array();
		actions[0] = action;
		requestBody[U("actions")] = actions;


		// HTTP 클라이언트 및 요청 설정
		http_client client(utility::conversions::to_string_t(apiUrl));
		http_request request(methods::POST);
		request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t(privateToken));
		request.headers().add(U("Content-Type"), U("application/json"));
		request.set_body(requestBody);

		client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>> {
			if (response.status_code() == status_codes::OK || response.status_code() == status_codes::Created) {
				std::wcout << L"✅ 커밋이 성공적으로 생성되었습니다." << std::endl;
			} else {
				std::wcout << L"❌ 커밋 실패. 상태 코드: " << response.status_code() << std::endl;
			}

			return response.extract_vector(); // 이 반환 타입이 반드시 맞아야 함

		}).then([](std::vector<unsigned char> data) {
			std::wcout << L"🔍 데이터 크기: " << data.size() << L" 바이트" << std::endl;
		}).wait();

/*
		client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>>
		{
			if (response.status_code() == status_codes::Created)		{
					std::wcout << L"✅ 커밋이 성공적으로 생성되었습니다." << std::endl;
				return response.extract_vector(); // 바이너리 데이터 추출
			}
			else
			{
				std::wcout << L"❌ 커밋 생성 실패. 상태 코드: " << response.status_code() << std::endl;
				response.extract_string().then([](utility::string_t body) {
					std::wcout << L"응답 본문: " << body << std::endl;
				}).wait();
				return response.extract_vector(); // 바이너리 데이터 추출
			}
		})
			.then([=](pplx::task<std::vector<unsigned char>> previousTask)
		{
			try
			{
				std::vector<unsigned char> fileData = previousTask.get();
				if (!fileData.empty())
				{
					std::ofstream outFile(filePath, std::ios::binary);
					outFile.write((const char*)fileData.data(), fileData.size());
					outFile.close();
					std::wcout << L"파일 저장 완료." << std::endl;
				}
				else
				{
					std::wcout << L"다운로드된 데이터가 비어 있습니다." << std::endl;
				}
			}
			catch (const std::exception& e)
			{
				std::cerr << "예외 발생: " << e.what() << std::endl;
			}
		})
			.wait(); // VS2010에서는 반드시 wait() 호출 필요 (비동기 동기화)

}
*/
/*
git clone http://root:glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr%2BWxvqrFY%3D@127.0.0.1/root/htspro.git
curl -X POST http://127.0.0.1/api/v4/projects -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro2\"}"
curl -X POST http://127.0.0.1/api/v4/projects -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro\"}"
curl -X POST http://127.0.0.1/api/v4/projects -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro\"}"
//root: BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=
//git clone http://root:BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=@127.0.0.1/root/htspro.git
curl -X POST -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro\"}" http://127.0.0.1/api/v4/projects
curl -X POST -H "PRIVATE-TOKEN: glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr+WxvqrFY=" -H "Content-Type: application/json" -d "{\"name\": \"htspro\"}" http://root:glpat-BjEL4m8MD9JQ9Cl7ydtYNvUGcgRxUuQz1pr%2BWxvqrFY%3D@127.0.0.1/root/htspro.git
@echo off
	set TOKEN=glpat-여기에_당신의_토큰_입력
	set PROJECT_NAME=htspro
	set API_URL=http://127.0.0.1/api/v4/projects
curl -X POST ^
	-H "PRIVATE-TOKEN: %TOKEN%" ^
	-H "Content-Type: application/json" ^
	-d "{\"name\": \"%PROJECT_NAME%\"}" ^
	%API_URL%
	pause
*/


BOOL CgitAPI32Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.

//////1.다운로드  /////////////////////////////////////////////////////////////
	CString privateToken =_T("glpat-qYj17RdNrDxAWKqvt16o"); // ← 실제 토큰으로 교체
	CString projectPath = _T("root%2Fhtsmts");
	std::vector<CString> files= GitLab_GetRepositoryTree2();
	try
	{
		size_t len = files.size();  // 오래된 버전에서는 size() 제공
		for (size_t i = 0; i < len; ++i)
		{
			TRACE("OnInitDialog(%d)    name=[%s] \r\n",i , files[i] );
			CString sbranch= "Master";
			CString rawPath =files[i]; // UrlEncode((CString)files[i]);
			DownloadGitlabFile( projectPath , rawPath , sbranch, privateToken );
		}
	}
	catch ( const std::exception &e )
	{
		printf("Error exception:%s\n", e.what());
	}
	getchar();
/*
/////2.OK 커밋 파일 올리기 ////////////////////////////////////////////////////////////////////////////////
	std::string projectId = projectPath; //"your_project_id"; // 예: "123456"
	std::string branch = "main";
	std::string filePath = "GitLabApi.obj";
	std::string commitMessage = "Add new file bin2 ";
	commitFileToGitLab(projectId, branch, filePath, commitMessage, (string)privateToken);
*/
////커밋 내용 가져 오기 
	get_commits_and_files(); //.wait();




	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}



std::vector<CString>  ParseGitlabFileList(const CStringA& json)
{
	std::vector<CString> files;
	return files;
}

std::vector<CString> getJsonArray(const web::json::value& jsonVal)
{
	std::vector<CString> files;
	return files;
}

std::vector<CString> getJsonArray2(const web::json::value& jsonVal)
{
	std::vector<CString> result;
	return result;
}

CStringA HttpGet(const CString& url, const CString& privateToken) {
	CStringA response;
	return response;
}

void SaveToFileA(const CString& filePath, const CStringA& data)
{
}
int download() {

	return 0;
}

pplx::task<void> GitLab_GetRepositoryTree()
{
	pplx::task<void> mm;
	return mm;
}


CgitAPI32Dlg::CgitAPI32Dlg(CWnd* pParent )	: CDialogEx(CgitAPI32Dlg::IDD, pParent) {
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}
void CgitAPI32Dlg::DoDataExchange(CDataExchange* pDX){
	CDialogEx::DoDataExchange(pDX);
}
BEGIN_MESSAGE_MAP(CgitAPI32Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
END_MESSAGE_MAP()
void CgitAPI32Dlg::OnSysCommand(UINT nID, LPARAM lParam) {
	if ((nID & 0xFFF0) == IDM_ABOUTBOX) {
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else {
		CDialogEx::OnSysCommand(nID, lParam);
	}
}
void CgitAPI32Dlg::OnPaint()
{
	if (IsIconic()) {
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else {
		CDialogEx::OnPaint();
	}
}
HCURSOR CgitAPI32Dlg::OnQueryDragIcon(){
	return static_cast<HCURSOR>(m_hIcon);
}
CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD){
}
void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialogEx::DoDataExchange(pDX);
}
BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()
