// SplitterControl.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "gitAPI32.h"
#include "SplitterControl.h"



CSplitterControl::CSplitterControl()
{
	m_bDragging = FALSE;
	m_nSplitType = SPS_VERTICAL;
	m_nMinSize = 30;
	m_pWnd1 = m_pWnd2 = nullptr;
}

CSplitterControl::~CSplitterControl() {}

void CSplitterControl::SetSplitType(SPLITTYPE type) { m_nSplitType = type; }

void CSplitterControl::SetMinSize(int size) { m_nMinSize = size; }

void CSplitterControl::SetTargetWnd(CWnd* pWnd1, CWnd* pWnd2)
{
	m_pWnd1 = pWnd1;
	m_pWnd2 = pWnd2;
}

void CSplitterControl::DrawLine(CDC* pDC, int x, int y)
{
	CRect rect;
	GetParent()->GetClientRect(rect);
	if (m_nSplitType == SPS_VERTICAL)
		pDC->PatBlt(x, rect.top, 1, rect.Height(), PATINVERT);
	else
		pDC->PatBlt(rect.left, y, rect.Width(), 1, PATINVERT);
}

void CSplitterControl::MoveWindowByMouse()
{
	CClientDC dc(GetParent());
	CBrush* pOldBrush = (CBrush*)dc.SelectStockObject(NULL_BRUSH);
	dc.PatBlt(0, 0, 0, 0, PATINVERT);

	GetParent()->ScreenToClient(&m_ptStart);
	CPoint pt;
	GetCursorPos(&pt);
	GetParent()->ScreenToClient(&pt);

	int delta = (m_nSplitType == SPS_VERTICAL) ? pt.x - m_ptStart.x : pt.y - m_ptStart.y;

	if (m_nSplitType == SPS_VERTICAL)
	{
		CRect rect1, rect2;
		m_pWnd1->GetWindowRect(&rect1);
		m_pWnd2->GetWindowRect(&rect2);
		GetParent()->ScreenToClient(&rect1);
		GetParent()->ScreenToClient(&rect2);

		rect1.right += delta;
		rect2.left += delta;

		if (rect1.Width() > m_nMinSize && rect2.Width() > m_nMinSize)
		{
			m_pWnd1->MoveWindow(&rect1);
			m_pWnd2->MoveWindow(&rect2);
		}
	}
	else
	{
		// Horizontal splitter ����
	}
}

void CSplitterControl::ChangeCursor()
{
	if (m_nSplitType == SPS_VERTICAL)
		::SetCursor(::LoadCursor(nullptr, IDC_SIZEWE));
	else
		::SetCursor(::LoadCursor(nullptr, IDC_SIZENS));
}

BEGIN_MESSAGE_MAP(CSplitterControl, CStatic)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_SETCURSOR()
END_MESSAGE_MAP()

void CSplitterControl::OnLButtonDown(UINT nFlags, CPoint point)
{
	SetCapture();
	m_bDragging = TRUE;
	ClientToScreen(&point);
	m_ptStart = point;
	CStatic::OnLButtonDown(nFlags, point);
}

void CSplitterControl::OnMouseMove(UINT nFlags, CPoint point)
{
	if (m_bDragging)
	{
		MoveWindowByMouse();
	}
	else
	{
		ChangeCursor();
	}
	CStatic::OnMouseMove(nFlags, point);
}

void CSplitterControl::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (m_bDragging)
	{
		ReleaseCapture();
		m_bDragging = FALSE;
	}
	CStatic::OnLButtonUp(nFlags, point);
}

BOOL CSplitterControl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	ChangeCursor();
	return TRUE;
}
