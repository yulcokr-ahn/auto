#pragma once

#include "xSTShadeButton.h"	//#include "../STcontrols/xShadeButton.h"
#include "../STcontrols/HotEdit.h"
#include "SkinedDialog.h"	//#include "../STcontrols/SkinedDialog.h"
#include "../STcontrols/MyColorListCtrl.h"
#include "../STGrid/STgridCtrl.h"

#define OLD_GRID_MODE 1

struct DiffStats {
	int addedLines;
	int deletedLines;
	int modifiedPairs ;
	int pureAdded;
	int pureDeleted;
};

class  CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	// �����Դϴ�.
protected:
	DECLARE_MESSAGE_MAP()
};

// CHistory ��ȭ ����
class  CHistory : public CSkinedDialog //CSkinedDialog
{
	// �����Դϴ�.
public:
	CHistory(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.

	// ��ȭ ���� �������Դϴ�.IDD_LOGMESSAGE
	enum { IDD = IDD_GITAPI32_DIALOG }; //IDD_GITAPI32_DIALOG

#if OLD_GRID_MODE
	CListCtrl                     m_LogList;                // �α� ���
#else
	CSTgridCtrl m_loglistGrid;
#endif
	void SetGridInit_loglistGrid(int nMODE,string strTR);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.


	// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	afx_msg void OnBnClickedOk();
	afx_msg void OnClickLoglist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDblclkLoglist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnSize(UINT nType, int cx, int cy);

	DECLARE_MESSAGE_MAP()
public:
	std::vector<web::json::value> m_CommitHistory; // �� row�� ��Ī�Ǵ� Ŀ�� json


	std::vector<TR_LASTcommit>    m_fileLast;
	std::vector<TR_HISTORYcommit> m_fileHist;
	int m_mapMode ; // 1= m_fileLast , 2= m_fileHist 

	CFont m_fontMain;
	CBrush m_brushDlgBk;
	CBrush m_brushCtrlBk;

	CxSTShadeButton m_btnOK;
	CxSTShadeButton m_btnCancel;
	CxSTShadeButton m_btnRefresh;
	CxSTShadeButton m_btnHelp;
	CxSTShadeButton m_btnSTATBUTTON;

	CString WriteTXT(CString FileName, CString dataTxt);

	// ���� ��� List Download
	void GetFilesListDownList_Test();
	void SetCommitMakePush_Test();

	void AppendHistoryCommit(CString nm ,const web::json::value& commit);
	void AppendLastCommit(CString nm, const web::json::value& commit);
	void Lastcommit(); 

	std::vector<CString> m_filesList;
	void HistoryCommits(CString strFile);


	CString ExtractNewContentFromDiff(const CString& diff);
	CString ExtractNewContentFromCompare(const CString& diff);
	DiffStats ParseDiffStatistics(const CString& diff);
	CString WriteTempFile(const CString& filename, const CString& content);


	afx_msg void OnLvnItemchangedLoglist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnBnClickedCommitMake();
};
