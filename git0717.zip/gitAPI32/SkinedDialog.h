#if !defined(AFX_SKINEDDIALOG_H__61B2E5EF_9A5A_42EB_9378_A245039855FD__INCLUDED_)
#define AFX_SKINEDDIALOG_H__61B2E5EF_9A5A_42EB_9378_A245039855FD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SkinedDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSkinedDialog window

#ifdef _AFXEXT
	#ifndef _EXPORTCONTROLS
		#undef AFX_EXT_CLASS
		#undef AFX_EXT_API
		#undef AFX_EXT_DATA
		#define AFX_EXT_CLASS AFX_CLASS_IMPORT
		#define AFX_EXT_API AFX_API_IMPORT
		#define AFX_EXT_DATA AFX_DATA_IMPORT
	#endif
#endif


class AFX_EXT_CLASS CSkinedDialog : public CDialog
{
// Construction
public:
	CSkinedDialog( LPCTSTR lpszTemplateName, CWnd* pParentWnd = NULL );   // standard constructor
	CSkinedDialog( UINT nIDTemplate, CWnd* pParentWnd = NULL );

// SKIN_C 7
	CBrush m_brushDlgBk;
	CBrush m_brushCtrlBk;
//X	CBrush m_brushYellow;

public:

// Operations
public:
	void LoadBitmaps();
	void SetTransParent(BOOL bOnOff);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSkinedDialog)
	//}}AFX_VIRTUAL

// Implementation
public:

	// Generated message map functions
protected:
	//{{AFX_MSG(CSkinedDialog)
	afx_msg BOOL PreCreateWindow(CREATESTRUCT& cs);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnNcPaint();
	afx_msg BOOL OnNcActivate(BOOL bActive);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnChildActivate();
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnClose();
	afx_msg LRESULT OnSetText(WPARAM wParam, LPARAM lParam); //(WPARAM wParam, LPCTSTR lpszString);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor); //2025.06.27 skin
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void PaintFrameBorder();
	void UpdateButtons(UINT nHitTest);
	void CalcButtonsRect();
	void PaintButtons(CDC *pDC);
	void PaintIcon(CDC *pDC);
	void PaintText(CDC *pDC);
	void GetFrameSize(CSize &szFrame);
	void GetCaptionRect(CRect &rcCaption);
	void PaintBackground(CDC *pDC);

	BOOL			m_bActive;
	BOOL			m_bTransparent;
	int				m_nTPRatio;

	CBitmap			m_bmCaptionOn;
	CBitmap			m_bmCaptionOff;

	CBitmap			m_bmButton[7][2];
	CRect			m_rcButton[7];
	CRect			m_rcCaption;
	CRect			m_rcSysMenu;
	CRect			m_rcText;
	
	HICON			m_hIcon;

	BOOL			m_bIsButton[6];

	BOOL			m_bLButtonDown;

	CString			m_strText;





};

/////////////////////////////////////////////////////////////////////////////

#ifdef _AFXEXT
	#ifndef _EXPORTCONTROLS
		#undef AFX_EXT_CLASS
		#undef AFX_EXT_API
		#undef AFX_EXT_DATA
		#define AFX_EXT_CLASS AFX_CLASS_EXPORT
		#define AFX_EXT_API AFX_API_EXPORT
		#define AFX_EXT_DATA AFX_DATA_EXPORT
	#endif
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SKINEDDIALOG_H__61B2E5EF_9A5A_42EB_9378_A245039855FD__INCLUDED_)
