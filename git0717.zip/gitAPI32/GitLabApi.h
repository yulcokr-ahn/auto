#pragma once

#include <cpprest/http_client.h>
#include <cpprest/json.h>
#include <pplx/pplxtasks.h>
#include <iostream>

using namespace web;
using namespace web::http;
using namespace web::http::client;
using namespace pplx;

void LogWideStringChunks(const std::wstring& wstr);

class CGitLabApi
{
public:

	CGitLabApi(); //const utility::string_t& baseUrl);
	task<void> HttpGetGitLabList();

private:
//	http_client m_client;

	void HandleJsonArray(const json::value& jsonVal);
};
