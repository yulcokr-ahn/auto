// SkinedDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Resource.h"
#include "SkinedDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define HT_EX_TRANSPARENT	30

#define WS_EX_LAYERED 0x00080000
#define LWA_ALPHA     0x00000002

#define DEF_TPRATIO		50	//extern HINSTANCE	g_hInstance;		// global Instance
#define SKIN_FRAME_CAP_H 26

//SKIN_C 7
CSkinedDialog::CSkinedDialog( LPCTSTR lpszTemplateName, CWnd *pParentWnd ) :
CDialog(lpszTemplateName, pParentWnd) 
, m_brushDlgBk(RGB(0,0,0)) , m_brushCtrlBk(RGB(40,40,40))       // ��Ʈ�� ��� ��ο� ȸ�� 
{
#if 0
	for (int i=0; i<7; i++)
	{
		m_bIsButton[i] = FALSE;
		m_rcButton[i] = CRect(0, 0, 0, 0);
	}
	m_bIsButton[SB_HELP] = TRUE;
	m_bIsButton[SB_CLOSE] = TRUE;

	OSVERSIONINFO osinfo;
	osinfo.dwOSVersionInfoSize = sizeof(osinfo);
	GetVersionEx(&osinfo);

	if(osinfo.dwPlatformId != VER_PLATFORM_WIN32_WINDOWS)
		m_bIsButton[SB_TRANSPARENT] = TRUE;
#endif
	// X m_brushYellow.CreateSolidBrush(RGB(60, 60, 60));

}

CSkinedDialog::CSkinedDialog( UINT nIDTemplate, CWnd *pParentWnd ) :
	CDialog(nIDTemplate, pParentWnd)
, m_brushDlgBk(RGB(0,0,0)) , m_brushCtrlBk(RGB(40,40,40))       // ��Ʈ�� ��� ��ο� ȸ�� 
{
	for (int i=0; i<7; i++)
	{
		m_bIsButton[i] = FALSE;
		m_rcButton[i] = CRect(0, 0, 0, 0);
	}
	m_bIsButton[SB_HELP] = TRUE;
	m_bIsButton[SB_CLOSE] = TRUE;

	OSVERSIONINFO osinfo;
	osinfo.dwOSVersionInfoSize = sizeof(osinfo);
	GetVersionEx(&osinfo);

	if(osinfo.dwPlatformId != VER_PLATFORM_WIN32_WINDOWS)
		m_bIsButton[SB_TRANSPARENT] = TRUE;


	// X m_brushYellow.CreateSolidBrush(RGB(60, 60, 60));

}

BEGIN_MESSAGE_MAP(CSkinedDialog, CDialog)
	//{{AFX_MSG_MAP(CSkinedDialog)
	ON_WM_CREATE()
	ON_WM_ACTIVATE()
	ON_WM_NCPAINT()
	ON_WM_NCACTIVATE()
	ON_WM_NCHITTEST()
	ON_WM_NCCALCSIZE()
	ON_WM_CHILDACTIVATE()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_NCLBUTTONUP()
	ON_WM_LBUTTONUP()
	ON_WM_SIZE()
	ON_WM_CLOSE()
	ON_MESSAGE(WM_SETTEXT, OnSetText)

	ON_WM_CTLCOLOR()

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/*
#define CTLCOLOR_MSGBOX         0
#define CTLCOLOR_EDIT           1
#define CTLCOLOR_LISTBOX        2
#define CTLCOLOR_BTN            3
#define CTLCOLOR_DLG            4
#define CTLCOLOR_SCROLLBAR      5
#define CTLCOLOR_STATIC         6
#define CTLCOLOR_MAX            7
*/
/*
HBRUSH CSkinedDialog::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// ����: Ư�� ��Ʈ�� ��� ����
	if (nCtlColor == CTLCOLOR_EDIT) {
		pDC->SetBkColor(RGB(74, 74, 74));
		pDC->SetTextColor(RGB(170, 170, 170));
		return m_brushYellow; // SKIN_C 3
	}
	if (nCtlColor == CTLCOLOR_STATIC) {
		pDC->SetBkColor(RGB(44, 44, 44));
		pDC->SetTextColor(RGB(170, 170, 170));
		return m_brushYellow;  //SKIN_C 2
	}
	return hbr;
}
*/
//SKIN_C 7
HBRUSH CSkinedDialog::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	pDC->SetTextColor(RGB(255, 255, 255));  // �� ����
	pDC->SetBkMode(TRANSPARENT);
	switch (nCtlColor)
	{
	case CTLCOLOR_DLG:
		return m_brushDlgBk;
	case CTLCOLOR_STATIC:			// X		pDC->SetBkColor(RGB(44, 44, 44));
		pDC->SetTextColor(RGB(230, 230, 230));
		return m_brushCtrlBk;		// m_brushYellow X;  //SKIN_C 2
	case CTLCOLOR_EDIT:
	case CTLCOLOR_LISTBOX:
		return m_brushCtrlBk;
	case CTLCOLOR_BTN:
		return m_brushCtrlBk;
	default:
		return CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	}
}


BOOL CSkinedDialog::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style &= ~(WS_CAPTION | WS_BORDER);
	return CDialog::PreCreateWindow(cs);
}


int CSkinedDialog::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{

	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	DWORD dwStyle = GetStyle();
	dwStyle &= ~WS_BORDER;
	dwStyle |= WS_CAPTION;
	SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	m_hIcon = (HICON)LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetWindowLong(m_hWnd, GCL_HICONSM, (LONG)m_hIcon);
	SetWindowLong(m_hWnd, GCL_HICON, (LONG)m_hIcon);

	GetWindowText(m_strText);

	LoadBitmaps();

	m_bTransparent = FALSE;
	m_nTPRatio = DEF_TPRATIO;

	CRect rc;
	GetWindowRect(&rc);
	int nCaptionY = GetSystemMetrics(SM_CYCAPTION);
//	rc.right -= 3;
	rc.bottom -= (nCaptionY - SKIN_FRAME_CAP_H);




	SetWindowPos(NULL, rc.left, rc.top, rc.Width(), rc.Height(), SWP_NOZORDER | SWP_NOACTIVATE);
	return 0;
}

void CSkinedDialog::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CDialog::OnActivate(nState, pWndOther, bMinimized);
	
	switch(nState)
	{
	case WA_INACTIVE:
		OnNcActivate(FALSE);
		break;
	case WA_ACTIVE:
	case WA_CLICKACTIVE:
		OnNcActivate(TRUE);
		break;
	}
}

void CSkinedDialog::OnNcPaint() 
{
	if(m_strText.GetLength() == 0)
		CWnd::GetWindowText(m_strText);

	PaintFrameBorder();
	
	CDC *pDC = GetWindowDC();
	CRect rcWindow;
	GetWindowRect(&rcWindow);

	CDC dcCaption;
	dcCaption.CreateCompatibleDC(pDC);

	CBitmap bmCaption;
	bmCaption.CreateCompatibleBitmap(pDC, m_rcCaption.Width(), m_rcCaption.Height());
	CBitmap* pOldBitmap = dcCaption.SelectObject(&bmCaption);

	PaintBackground(&dcCaption);
	PaintIcon(&dcCaption);
	PaintText(&dcCaption);
	PaintButtons(&dcCaption);
	
	pDC->BitBlt(m_rcCaption.left, m_rcCaption.top, m_rcCaption.Width(), m_rcCaption.Height(), &dcCaption, 0, 0, SRCCOPY);
	dcCaption.SelectObject(pOldBitmap);

	bmCaption.DeleteObject();
	dcCaption.DeleteDC();	
	ReleaseDC(pDC);
}

BOOL CSkinedDialog::OnNcActivate(BOOL bActive) 
{
	m_bActive = bActive;
	OnNcPaint();

	return TRUE;
}

void CSkinedDialog::PaintBackground(CDC *pDC)
{
	CBrush brPattern;

	CDC memDC;
	memDC.CreateCompatibleDC(pDC);
	if (m_bActive)
		memDC.SelectObject(&m_bmCaptionOn);
	else
		memDC.SelectObject(&m_bmCaptionOff);

	CRect rcCaption;
	GetCaptionRect(rcCaption);
	rcCaption -= rcCaption.TopLeft();
	
	pDC->StretchBlt(rcCaption.left, rcCaption.top, rcCaption.Width(), rcCaption.Height(), &memDC, 0, 0, 1, rcCaption.Height(), SRCCOPY);
}

void CSkinedDialog::GetCaptionRect(CRect &rcCaption)
{
	CSize szFrame;

	GetWindowRect(&rcCaption);
	rcCaption -= rcCaption.TopLeft();
	rcCaption.DeflateRect(1, 1);
	rcCaption.bottom = rcCaption.top + SKIN_FRAME_CAP_H;
}

void CSkinedDialog::GetFrameSize(CSize &szFrame)
{
	////////////
	// �������� Frame ũ�⸦ ���Ѵ�.
	//
	DWORD dwStyle = GetStyle();
	szFrame = (dwStyle & WS_THICKFRAME) ?
		CSize(GetSystemMetrics(SM_CXSIZEFRAME),
			   GetSystemMetrics(SM_CYSIZEFRAME)) :
		CSize(GetSystemMetrics(SM_CXFIXEDFRAME),
				GetSystemMetrics(SM_CYFIXEDFRAME));
}

void CSkinedDialog::PaintText(CDC *pDC)
{
	CPoint pt;
	CRect rcCaption, rcDrawText;
	GetCaptionRect(rcCaption);

	HFONT hOldFont = (HFONT)::SelectObject(pDC->GetSafeHdc(), (HFONT)::GetStockObject(DEFAULT_GUI_FONT));

	CSize szTextExtent = pDC->GetTextExtent(m_strText);
	
	pt.x = m_rcText.left;
	pt.y = (m_rcText.Height() - szTextExtent.cy) >> 1;

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(GetSysColor(COLOR_CAPTIONTEXT));

	pDC->TextOut(pt.x, pt.y, m_strText);

	::SelectObject(pDC->GetSafeHdc(), hOldFont);
}

void CSkinedDialog::PaintButtons(CDC *pDC)
{
	CRect rcBtn;
	CDC		dcBtn;
	dcBtn.CreateCompatibleDC(pDC);
	// Close ��ư�� �׸���.
	rcBtn = m_rcButton[SB_CLOSE];
	rcBtn -= m_rcCaption.TopLeft();

	dcBtn.SelectObject(m_bmButton[SB_CLOSE][0]);
	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	// ����ȭ ��ư�� �׸���.
	if(m_bIsButton[SB_TRANSPARENT])
	{
		rcBtn = m_rcButton[SB_TRANSPARENT];
		rcBtn -= m_rcCaption.TopLeft();

		dcBtn.SelectObject(m_bmButton[SB_TRANSPARENT][0]);
		pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);
	}
	
	// ���򸻹�ư�� �׸���.
	rcBtn = m_rcButton[SB_HELP];
	rcBtn -= m_rcCaption.TopLeft();

	dcBtn.SelectObject(m_bmButton[SB_HELP][0]);
	pDC->BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	dcBtn.DeleteDC();
}

void CSkinedDialog::PaintIcon(CDC *pDC)
{
	CRect rc(0, 0, 16, 16);
	rc.OffsetRect(2,0);

	DrawIconEx(pDC->m_hDC, rc.left, rc.top, 
			m_hIcon,
			rc.Width(), rc.Height(), 0, NULL, DI_NORMAL);
}

LRESULT CSkinedDialog::OnNcHitTest(CPoint point) 
{
	UINT uHitTest;

	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	//DWORD dwStyle = GetStyle();

	point -= rcWindow.TopLeft();
	
	if (m_rcSysMenu.PtInRect(point))
		uHitTest = HTSYSMENU;
	else if (m_rcButton[SB_CLOSE].PtInRect(point))
		uHitTest = HTCLOSE;
	else if (m_rcButton[SB_HELP].PtInRect(point))
		uHitTest = HTHELP;
	else if (m_rcButton[SB_TRANSPARENT].PtInRect(point))
		uHitTest = HT_EX_TRANSPARENT;
	else if (rcCaption.PtInRect(point))
		uHitTest = HTCAPTION;
	else
		uHitTest = CDialog::OnNcHitTest(point);

	return uHitTest;
}

void CSkinedDialog::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	CRect rcCaption;
	GetCaptionRect(rcCaption);

	if (!IsZoomed())
	{
		InflateRect(&lpncsp->rgrc[0], 2, 2);

		int nCaptionY = GetSystemMetrics(SM_CYCAPTION);
		lpncsp->rgrc[0].top -= (nCaptionY - SKIN_FRAME_CAP_H);

		GetCaptionRect(m_rcCaption);

		int cxIcon = GetSystemMetrics(SM_CXSIZE);
		CRect rc(0, 0, cxIcon, GetSystemMetrics(SM_CYSIZE));
		rc.DeflateRect(0,1);
		rc.left += 2;

		m_rcSysMenu = rc;
		CSize szFrame;
		GetFrameSize(szFrame);

		m_rcSysMenu += szFrame;

		m_rcText.left = m_rcSysMenu.right + 2;
		m_rcText.top = m_rcCaption.top + 1;
		m_rcText.bottom = m_rcCaption.bottom - 1;
		m_rcText.right = m_rcCaption.right - 1;

		CalcButtonsRect();		// ��ư�� ������ ����Ѵ�.
	}
	
	CDialog::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void CSkinedDialog::OnChildActivate() 
{
	CDialog::OnChildActivate();
}

void CSkinedDialog::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	rcCaption -= rcWindow.TopLeft();

	CWindowDC dc(this);
	CDC dcCaption;
	CBitmap bmCaption;

	switch(nHitTest)
	{
	case HTCLOSE:
	case HT_EX_TRANSPARENT:
	case HTHELP:
		m_bLButtonDown = TRUE;
		break;
	case HTCAPTION:
		SetFocus();
		SendMessage(WM_SYSCOMMAND, 0x0000F012, 0x0);
		break;
	default:
		CDialog::OnNcLButtonDown(nHitTest, point);
	}
	OnNcPaint();
	UpdateButtons(nHitTest);
}

void CSkinedDialog::OnNcLButtonUp(UINT nHitTest, CPoint point) 
{
	CRect rcCaption, rcWindow;
	GetCaptionRect(rcCaption);
	GetWindowRect(rcWindow);

	rcCaption -= rcWindow.TopLeft();

	CWindowDC dc(this);
	CDC dcCaption;
	CBitmap bmCaption;

	m_bLButtonDown = FALSE;
	UpdateButtons(nHitTest);

	switch(nHitTest)
	{
	case HTCLOSE:
		SendMessage(WM_SYSCOMMAND, (WPARAM)SC_CLOSE);
		return;
	case HT_EX_TRANSPARENT:
		m_bTransparent = !m_bTransparent;
		SetTransParent(m_bTransparent);
		break;
	default:
		CDialog::OnNcLButtonUp(nHitTest, point);
	}
}

void CSkinedDialog::CalcButtonsRect()
{
	CRect rcTmp;

	DWORD dwStyle = GetStyle();
	
	// �����ư
	rcTmp.right = m_rcCaption.right -2;
	rcTmp.left = rcTmp.right - 14;
	rcTmp.top = m_rcCaption.top + 3;
	rcTmp.bottom = rcTmp.top + 13;

	m_rcButton[SB_CLOSE] = rcTmp;

	BOOL bGroup = FALSE;

	if (m_bIsButton[SB_TRANSPARENT])
	{
		rcTmp.right = rcTmp.left;
		if (!bGroup)
			rcTmp.right -= 2;

		rcTmp.left = rcTmp.right - 14;
		m_rcButton[SB_TRANSPARENT] = rcTmp;
	}

	if (m_bIsButton[SB_HELP])
	{
		rcTmp.right = rcTmp.left - 2;
		rcTmp.left = rcTmp.right - 14;

		m_rcButton[SB_HELP] = rcTmp;
	}

	m_rcText.right = rcTmp.left - 2;
}

void CSkinedDialog::LoadBitmaps()
{
	m_bmCaptionOn.LoadBitmap(IDB_SKIN_CAPTIONON);
	m_bmCaptionOff.LoadBitmap(IDB_SKIN_CAPTIONOFF);

	m_bmButton[SB_HELP][0].LoadBitmap(IDB_HELP_UP);
	m_bmButton[SB_HELP][1].LoadBitmap(IDB_HELP_DOWN);

	if(m_bIsButton[SB_TRANSPARENT])
	{
		m_bmButton[SB_TRANSPARENT][0].LoadBitmap(IDB_TRANS_UP);
		m_bmButton[SB_TRANSPARENT][1].LoadBitmap(IDB_TRANS_DOWN);
	}

	m_bmButton[SB_CLOSE][0].LoadBitmap(IDB_CLOSE_UP);
	m_bmButton[SB_CLOSE][1].LoadBitmap(IDB_CLOSE_DOWN);

}

void CSkinedDialog::OnLButtonUp(UINT nFlags, CPoint point) 
{
	OnNcPaint();
	
	CDialog::OnLButtonUp(nFlags, point);
}

void CSkinedDialog::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);	
	SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOZORDER | SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED | SWP_NOACTIVATE);
}

void CSkinedDialog::UpdateButtons(UINT nHitTest)
{
	CWindowDC dc(this);
	
	CRect rcBtn;
	// Close ��ư�� �׸���.
	rcBtn = m_rcButton[SB_CLOSE];

	CDC dcBtn;
	dcBtn.CreateCompatibleDC(&dc);

	if (nHitTest == HTCLOSE && m_bLButtonDown)
		dcBtn.SelectObject(m_bmButton[SB_CLOSE][1]);
	else
		dcBtn.SelectObject(m_bmButton[SB_CLOSE][0]);

	dc.BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	// ����ȭ ��ư�� �׸���.
	if(m_bIsButton[SB_TRANSPARENT])
	{
		rcBtn = m_rcButton[SB_TRANSPARENT];

		if (nHitTest == HT_EX_TRANSPARENT && m_bLButtonDown)
			dcBtn.SelectObject(m_bmButton[SB_TRANSPARENT][1]);
		else
			dcBtn.SelectObject(m_bmButton[SB_TRANSPARENT][0]);

		dc.BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);
	}

	// ���򸻹�ư�� �׸���.
	rcBtn = m_rcButton[SB_HELP];

	if (nHitTest == HTHELP && m_bLButtonDown)
		dcBtn.SelectObject(m_bmButton[SB_HELP][1]);
	else
		dcBtn.SelectObject(m_bmButton[SB_HELP][0]);

	dc.BitBlt(rcBtn.left, rcBtn.top, rcBtn.Width(), rcBtn.Height(), &dcBtn, 0, 0, SRCCOPY);

	dcBtn.DeleteDC();
}

void CSkinedDialog::OnClose() 
{
	for (int i=0; i<7; i++)
	{
		if(m_bIsButton[i])
		{
			for (int j=0; j<2; j++)
				m_bmButton[i][j].DeleteObject();
		}
	}
	DeleteObject(m_hIcon);
	CDialog::OnClose();
}

void CSkinedDialog::PaintFrameBorder()
{
	CWindowDC	dc(this);
	CRect		rcWindow,rcBoard;
	GetWindowRect(&rcWindow);
	rcWindow -= rcWindow.TopLeft();
	rcBoard = rcWindow;
	rcBoard.top = SKIN_FRAME_CAP_H;

	CPen penBord(PS_SOLID, 21, RGB(60,60,60)); //SKIN_C 4
	CPen* pOldPen = dc.SelectObject(&penBord);
	dc.SelectObject(GetStockObject(NULL_BRUSH));
	dc.Rectangle(rcBoard);
	dc.SelectObject(pOldPen);
	penBord.DeleteObject();

	CPen penWin(PS_SOLID, 1, RGB(0,0,0));
	pOldPen = dc.SelectObject(&penWin);
	dc.SelectObject(GetStockObject(NULL_BRUSH));
	dc.Rectangle(rcWindow);
	dc.SelectObject(pOldPen);
	penWin.DeleteObject();

}


void CSkinedDialog::SetTransParent(BOOL bOnOff)
{
	OSVERSIONINFO osinfo;
	osinfo.dwOSVersionInfoSize = sizeof(osinfo);
	GetVersionEx(&osinfo);

	if(osinfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
		return;

	typedef BOOL(WINAPI *SLWA)(HWND, COLORREF, BYTE, DWORD);
	SLWA pSetLayeredWindowAttributes = NULL;
	HINSTANCE hmodUSER32 = LoadLibrary("USER32.DLL");
	pSetLayeredWindowAttributes = (SLWA)GetProcAddress(hmodUSER32,"SetLayeredWindowAttributes");
	HWND hwnd = this->m_hWnd; 

	if(bOnOff)
	{
		SetWindowLong(hwnd, GWL_EXSTYLE,GetWindowLong(hwnd, GWL_EXSTYLE) | WS_EX_LAYERED);
		pSetLayeredWindowAttributes(hwnd, 0, (BYTE)(255*((float)m_nTPRatio/100.)), LWA_ALPHA);
	}
	else
		SetWindowLong(hwnd, GWL_EXSTYLE,GetWindowLong(hwnd, GWL_EXSTYLE) & ~WS_EX_LAYERED);
}

LRESULT CSkinedDialog::OnSetText(WPARAM wParam, LPARAM lParam)
{
	LPCTSTR lpszString = (LPCTSTR) lParam; //   (WPARAM wParam, LPARAM lParam)

	m_strText = lpszString;
	OnNcPaint();
	return 0;
}
