﻿
#include "stdafx.h"
#include "gitAPI32.h"
#include "History.h"
#include "afxdialogex.h"
#include "GitLabApi.h"
#include "CommitDlg.h"

extern HINSTANCE g_hInstance_MAIN; 

CString GetRunTimePath()	{
	char buff[MAX_PATH]= { 0 };		int i=0;
	::GetModuleFileName(AfxGetResourceHandle(), buff, 255);		for(i=strlen(buff)-1; i>=0 && buff[i]!='\\'; i--);	buff[i]=0;	
	return CString(buff);
}
CString ExtractNewContentFromDiff(const CString& diff)
{
	CString result;
	CStringArray lines;
	int pos = 0;
	CString line;
	while ((line = diff.Tokenize(_T("\n"), pos)) != _T(""))
	{
		if (line.Left(1) == _T("+") && !line.Left(2).Compare(_T("++"))) // "+", not "+++" (diff metadata)
			result += line.Mid(1) + _T("\n");
	}
	return result;
}
CString ParseISO8601DateTime(const CString& isoString) // 예: "2025-06-10T14:40:23.000+00:00"
{
	CString result;
	int tPos = isoString.Find('T');
	if (tPos == -1)
		return isoString; // 형식이 이상하면 원문 반환
	CString datePart = isoString.Left(tPos);                  // "2025-06-10"
	CString timePart = isoString.Mid(tPos + 1);               // "14:40:23.000+00:00"
	int dotPos = timePart.Find('.'); // 시간 끝 위치를 잘라내기 ('.' 또는 '+' 또는 'Z'까지)
	if (dotPos == -1)
		dotPos = timePart.Find('+');
	if (dotPos == -1)
		dotPos = timePart.Find('Z');
	if (dotPos != -1)
		timePart = timePart.Left(dotPos);                     // "14:40:23"
	result.Format(_T("%s %s"), datePart, timePart);           // "2025-06-10 14:40:23"
	return result;
}
CHistory::CHistory(CWnd* pParent )	: CSkinedDialog(CHistory::IDD, pParent)  , m_brushDlgBk(RGB(0,0,0))           // 다이얼로그 배경 검정
	, m_brushCtrlBk(RGB(40,40,40))       
{

}
void CHistory::DoDataExchange(CDataExchange* pDX){
	CSkinedDialog::DoDataExchange(pDX);
#if OLD_GRID_MODE
	DDX_Control(pDX, IDC_LOGLIST, m_LogList);
#else
//	DDX_Control(pDX, IDC_LOGLIST, m_loglistGrid);
#endif
	


	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_PROGRESS, m_ctrlProgress);

#if 0
	DDX_Control(pDX, IDC_LOGMSG, m_ChangedFileListCtrl);
	DDX_Control(pDX, IDC_SPLITTERTOP, m_wndSplitter1);
	DDX_Control(pDX, IDC_SPLITTERBOTTOM, m_wndSplitter2);
	DDX_Text(pDX, IDC_SEARCHEDIT, m_sFilterText);
	DDX_Control(pDX, IDC_DATEFROM, m_DateFrom);
	DDX_Control(pDX, IDC_DATETO, m_DateTo);
	DDX_Check(pDX, IDC_LOG_ALLBRANCH,m_bAllBranch);
	DDX_Check(pDX, IDC_WHOLE_PROJECT, m_bWholeProject);
	DDX_Text(pDX, IDC_LOGINFO, m_sLogInfo);
	DDX_Control(pDX, IDC_LOG_JUMPTYPE, m_JumpType);
	DDX_Control(pDX, IDC_LOG_JUMPUP, m_JumpUp);
	DDX_Control(pDX, IDC_STATIC_REF, m_staticRef);
	DDX_Control(pDX, IDC_PIC_AUTHOR, m_gravatar);
	DDX_Control(pDX, IDC_LOG_JUMPDOWN, m_JumpDown);
	DDX_Control(pDX, IDC_WALKBEHAVIOUR, m_ctrlWalkBehavior);
	DDX_Control(pDX, IDC_VIEW, m_ctrlView);
	DDX_Control(pDX, IDC_SEARCHEDIT, m_cFilter);
	DDX_Control(pDX, IDC_FILTER, m_cFileFilter);
	DDX_Control(pDX, IDC_REFRESH, m_btnRefresh);
	DDX_Control(pDX, IDHELP, m_btnHelp);
	DDX_Control(pDX, IDC_STATBUTTON, m_btnSTATBUTTON);
#endif


}
BEGIN_MESSAGE_MAP(CHistory, CSkinedDialog)
	ON_NOTIFY(NM_DBLCLK, IDC_LOGLIST, &CHistory::OnDblclkLoglist)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED(IBUT_COMMIT_MAKE, &CHistory::OnBnClickedCommitMake)
	ON_EN_CHANGE(IDC_COMMIT_AUTHORDATA, &CHistory::OnEnChangeCommitAuthordata)

    ON_WM_CLOSE()
END_MESSAGE_MAP()

void CHistory::OnDestroy()
{
	CDialog::OnDestroy();
	delete this; // 메모리 해제
}
void CHistory::OnCancel()
{
	PostQuitMessage(0); // 프로그램 종료
}
void CHistory::OnClose()
{
	// X 버튼 클릭 시 프로그램 전체 종료
	PostQuitMessage(0);
	CDialog::OnClose();
}

void CHistory::OnSysCommand(UINT nID, LPARAM lParam) {
	if ((nID & 0xFFF0) == IDM_ABOUTBOX) {
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else {
		CSkinedDialog::OnSysCommand(nID, lParam);
	}
}
void CHistory::OnPaint()
{
	if (IsIconic()) {
		CPaintDC dc(this); 
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else {
		CSkinedDialog::OnPaint();
	}
}
HCURSOR CHistory::OnQueryDragIcon(){
	return static_cast<HCURSOR>(m_hIcon);
}
void CHistory::OnBnClickedOk()
{
	CSkinedDialog::OnOK();
}
BOOL CHistory::OnInitDialog()
{
	CSkinedDialog::OnInitDialog();

AfxSetResourceHandle(::GetModuleHandle("STGrid.dll"));

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	SetIcon(m_hIcon, TRUE);			
	SetIcon(m_hIcon, FALSE);		
	CRgn rgn;
	CRect rc;
	GetWindowRect(&rc);	
	rc.OffsetRect(-rc.TopLeft()); // 좌표 보정
	rgn.CreateRoundRectRgn(rc.left, rc.top, rc.right, rc.bottom, 20, 20);
	SetWindowRgn(rgn, TRUE);
	m_btnOK.ModifyStyle(0, BS_OWNERDRAW);
	m_btnCancel.ModifyStyle(0, BS_OWNERDRAW);
	m_btnOK.SetShade(SHS_STANDARD);
	m_btnCancel.SetShade(SHS_STANDARD);

#if OLD_GRID_MODE
	DWORD dwStyle = m_LogList.GetExtendedStyle();
	m_LogList.SetExtendedStyle(dwStyle | LVS_EX_FULLROWSELECT);
#else
	SetGridInit_loglistGrid(4,string("M004") );
	m_loglistGrid.DeleteNonFixedRows();
#endif


//2025.10-18	SetCommitMakePush_Test();

//	HistoryCommits( "CommitDlg.cpp" );	

	const int b =  SW_NORMAL ;
	this->m_ctrlProgress.ShowWindow(b);
	this->m_ctrlProgress.SetPos(0);
Lastcommit();  
GetFilesListDownList_Test();
m_ctrlProgress.SetPos(100);

	return TRUE;  
}



/*

UINT CSyncDlg::ProgressThread()
{
	m_startTick = GetTickCount64();
	m_bDone = false;
	STRING_VECTOR list;
	CProgressDlg::RunCmdList(this, m_GitCmdList, list, true, nullptr, &this->m_bAbort, &this->m_Databuf);
	InterlockedExchange(&m_bBlock, FALSE);
	return 0;
}

LRESULT CSyncDlg::OnProgressUpdateUI(WPARAM wParam,LPARAM lParam)
{
	if (m_bWantToExit)
		return 0;
	if(wParam == MSG_PROGRESSDLG_START)
	{
		m_BufStart = 0;
		if (CRegDWORD(L"Software\\TortoiseGit\\DownloadAnimation", TRUE) == TRUE)
			m_ctrlAnimate.Play(0, UINT_MAX, UINT_MAX);
		this->m_ctrlProgress.SetPos(0);
		if (m_pTaskbarList)
		{
			m_pTaskbarList->SetProgressState(m_hWnd, TBPF_NORMAL);
			m_pTaskbarList->SetProgressValue(m_hWnd, 0, 100);
		}
	}

	if(wParam == MSG_PROGRESSDLG_END || wParam == MSG_PROGRESSDLG_FAILED)
	{
		ULONGLONG tickSpent = GetTickCount64() - m_startTick;
		CString strEndTime = CLoglistUtils::FormatDateAndTime(CTime::GetCurrentTime(), DATE_SHORTDATE, true, false);

		m_BufStart = 0;
		m_Databuf.m_critSec.Lock();
		m_Databuf.clear();
		m_Databuf.m_critSec.Unlock();

		m_bDone = true;
		m_ctrlAnimate.Stop();
		m_ctrlProgress.SetPos(100);
		//this->DialogEnableWindow(IDOK,TRUE);

		{
			CString text;
			m_ctrlCmdOut.GetWindowText(text);
			text.Remove('\r');
			if (static_cast<DWORD>(CRegStdDWORD(L"Software\\TortoiseGit\\StyleGitOutput", TRUE)) == TRUE)
				CAppUtils::StyleWarningsErrors(text, &m_ctrlCmdOut);
			CAppUtils::StyleURLs(text, &m_ctrlCmdOut);
		}

		auto exitCode = static_cast<DWORD>(lParam);
		if (exitCode)
		{
			if (m_pTaskbarList)
			{
				m_pTaskbarList->SetProgressState(m_hWnd, TBPF_ERROR);
				m_pTaskbarList->SetProgressValue(m_hWnd, 100, 100);
			}
			CString log;
			log.Format(IDS_PROC_PROGRESS_GITUNCLEANEXIT, exitCode);
			CString err;
			err.Format(L"\r\n\r\n%s (%I64u ms @ %s)\r\n", static_cast<LPCWSTR>(log), tickSpent, static_cast<LPCWSTR>(strEndTime));
			CProgressDlg::InsertColorText(this->m_ctrlCmdOut, err, RGB(255,0,0));
			if (CRegDWORD(L"Software\\TortoiseGit\\NoSounds", FALSE) == FALSE)
				PlaySound(reinterpret_cast<LPCWSTR>(SND_ALIAS_SYSTEMEXCLAMATION), nullptr, SND_ALIAS_ID | SND_ASYNC);
		}
		else
		{
			if (m_pTaskbarList)
				m_pTaskbarList->SetProgressState(m_hWnd, TBPF_NOPROGRESS);
			CString temp;
			temp.LoadString(IDS_SUCCESS);
			CString log;
			log.Format(L"\r\n%s (%I64u ms @ %s)\r\n", static_cast<LPCWSTR>(temp), tickSpent, static_cast<LPCWSTR>(strEndTime));
			CProgressDlg::InsertColorText(this->m_ctrlCmdOut, log, RGB(0,0,255));
		}
		m_GitCmdStatus = exitCode;

		//if(wParam == MSG_PROGRESSDLG_END)
		RunPostAction();
	}

	if(lParam != 0)
		ParserCmdOutput(static_cast<char>(lParam));
	else
	{
		m_Databuf.m_critSec.Lock();
		for (size_t i = m_BufStart; i < m_Databuf.size(); ++i)
		{
			char c = m_Databuf[m_BufStart];
			++m_BufStart;
			m_Databuf.m_critSec.Unlock();
			ParserCmdOutput(c);

			m_Databuf.m_critSec.Lock();
		}

		if (m_BufStart > 1000)
		{
			m_Databuf.erase(m_Databuf.cbegin(), m_Databuf.cbegin() + m_BufStart);
			m_BufStart = 0;
		}
		m_Databuf.m_critSec.Unlock();
	}

	return 0;
}

*/

const TCHAR crlf[] = _T("\r\n");
static const char *crlfs[] =
{
	"\x0d\x0a",			
	"\x0a\x0d",			//	UNIX style
	"\x0a"				//	Macintosh style
};
enum CRLFSTYLE
{
	CRLF_STYLE_AUTOMATIC	= -1,
	CRLF_STYLE_DOS			= 0,
	CRLF_STYLE_UNIX			= 1,
	CRLF_STYLE_MAC			= 2
};
#define	CHAR_ALIGN					16
#define	ALIGN_BUF_SIZE(size)		((size) / CHAR_ALIGN) * CHAR_ALIGN + CHAR_ALIGN;
#define	UNDO_BUF_SIZE				1024
#define	COL_COUNT_M001		14
#define	COL_COUNT_M002		11
#define	COL_COUNT_M003		23
#define COL_COUNT_M004      18 

BOOL CSTgridCtrl::Create(const RECT& rect, CWnd* pParentWnd, UINT nID, HINSTANCE hInstance, DWORD dwStyle)
{

	CString className = AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW);
	CWnd::CreateEx(0, className, _T("STGridCtrl"), dwStyle,rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, pParentWnd->GetSafeHwnd(), (HMENU)nID);
	TRACE("CSTgridCtrl::Create() this[0x%x], HWND[0x%x]  hInstance[0x%x]\r\n", this, this->GetSafeHwnd() , hInstance);
	TRY
	{
		m_arRowHeights.SetSize(m_nRows);    // initialize row heights
		m_arColWidths.SetSize(m_nCols);     // initialize column widths
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		return FALSE;
	}
	END_CATCH

	int i;
	for (i = 0; i < m_nRows; i++)
		m_arRowHeights[i] = m_cellDefault.GetHeight();
	for (i = 0; i < m_nCols; i++)
	{
		m_arColWidths[i] = m_cellDefault.GetWidth();
	}
#if 0
	m_IssueTip.Create(this);
	m_IssueTip.SetDelayTime(TTDT_INITIAL, 10);
	m_IssueTip.AddTool(this, "");
	m_IssueTip.Activate(TRUE);
#endif

	return TRUE;
}
BOOL CSTgridCtrl::RegisterWindowClass()
{
	WNDCLASS wndcls;
	HINSTANCE hInst = AfxGetInstanceHandle();	
	if (!(::GetClassInfo(hInst, STgridCTRL_CLASSNAME, &wndcls)))
	{
		wndcls.style            = CS_DBLCLKS ; //| CS_HREDRAW | CS_VREDRAW;
		wndcls.lpfnWndProc      = ::DefWindowProc;
		wndcls.cbClsExtra       = wndcls.cbWndExtra = 0;
		wndcls.hInstance        = hInst;
		wndcls.hIcon            = NULL;
#ifndef _WIN32_WCE_NO_CURSOR
		wndcls.hCursor          = AfxGetApp()->LoadStandardCursor(IDC_ARROW);
#else
		wndcls.hCursor          = 0;
#endif
		wndcls.hbrBackground    = (HBRUSH) (COLOR_3DFACE + 1);
		wndcls.lpszMenuName     = NULL;
		wndcls.lpszClassName    = STgridCTRL_CLASSNAME;

		if (!AfxRegisterClass(&wndcls))
		{
			AfxThrowResourceException();
			return FALSE;
		}
	}

	return TRUE;
}

void CHistory::SetGridInit_loglistGrid(int nMODE, string strTR)
{
	AfxSetResourceHandle(GetSTGridInstanceHandle());	HINSTANCE hInstance_History =AfxGetResourceHandle();
	CWnd* pGridPlaceholder = GetDlgItem(IDC_LOGLIST);
	if (!pGridPlaceholder)	{
		AfxMessageBox(_T("IDC_LOGLIST 컨트롤을 찾을 수 없습니다."));
		return;
	}
	CRect rect;
	pGridPlaceholder->GetWindowRect(&rect);
	ScreenToClient(&rect);

#if OLD_GRID_MODE
#else

	DWORD dwStyle = WS_CHILD|WS_BORDER|WS_VISIBLE;
	if(m_loglistGrid.Create(CRect(1,10,900,400), this, IDC_LOGLIST, hInstance_History,dwStyle) == NULL)		AfxThrowMemoryException();
	CString Log;
	char cTitle1[COL_COUNT_M004][50] = {"ID",   "ScreenID",	"ScreenName","Author",	"Date",	"Message",	"유형"  ,"주문량",	"주문가",	"체결량",	"체결가",	"미체결",	"상태",	"주문T"   , "체결T"   , "Brick" , "로직ID" , "G ID"};
	int nTitle[COL_COUNT_M004] =       { 0     ,   91       ,   141       ,  71  ,    231 ,   495       ,  45      ,40      ,   40    ,   40       ,   40      ,    40      ,  40          , 40     , 40     ,30      ,  40   ,      30 }; 
	//	m_loglistGrid.DeleteAllItems(); 
	m_loglistGrid.SetAlternateDraw(TRUE);
	m_loglistGrid.SetAlternateColor(RGB(42,70,78)); 
	m_loglistGrid.SetAlternateRowCount(5);
	m_loglistGrid.SetDefCellHeight(17); 
	m_loglistGrid.SetColumnResize(TRUE);
	m_loglistGrid.SetSTgridLines(GVL_VERT);
	m_loglistGrid.SetRowCount(1);
	m_loglistGrid.SetFixedRowCount(1);
	m_loglistGrid.SetFixedColumnCount(0);
	m_loglistGrid.EnableColumnHide();
	m_loglistGrid.SetFrameFocusCell(TRUE);
	m_loglistGrid.SetTrackFocusCell(FALSE);
	m_loglistGrid.SetListMode(TRUE);
	m_loglistGrid.SetColumnCount(COL_COUNT_M004);
	int i=0;
	for ( i = 0; i < COL_COUNT_M004; i++) 
	{
		m_loglistGrid.SetItemFormat(0, i, DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		m_loglistGrid.SetItemText(0, i, cTitle1[i]);
		m_loglistGrid.SetColumnWidth(i, nTitle[i]);
	}
	m_loglistGrid.SetCompareFunction(CSTgridCtrl::pfnCellNumericCompare);
	m_loglistGrid.SetHeaderSort(TRUE);
	m_loglistGrid.SetSortColumn(0);

#endif
}



void CHistory::OnSize(UINT t,int cx,int cy)
{
	CSkinedDialog::OnSize(t,cx,cy);
}

void CHistory::AppendHistoryCommit(CString nm ,const web::json::value& commit)
{
	if (!commit.is_object()) return;
	CString id , short_id(""), created_at,parent_ids,title(""), message, author_name(""),author_email,authored_date,committer_name,committer_email, committed_date("");
	if (commit.has_field(L"id"))					id				= commit[L"id"].as_string().c_str();
	if (commit.has_field(L"short_id"))				short_id		= commit[L"short_id"].as_string().c_str();
	if (commit.has_field(L"created_at"))			created_at		= commit[L"created_at"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
	if (commit.has_field(L"title"))					title			= commit[L"title"].as_string().c_str();
	if (commit.has_field(L"message"))				message			= commit[L"message"].as_string().c_str();
	if (commit.has_field(L"author_name"))			author_name		= commit[L"author_name"].as_string().c_str();
	if (commit.has_field(L"author_email"))			author_email	= commit[L"author_email"].as_string().c_str();
	if (commit.has_field(L"authored_date"))			authored_date	= commit[L"authored_date"].as_string().c_str();
	if (commit.has_field(L"committer_name"))		committer_name	= commit[L"committer_name"].as_string().c_str();
	if (commit.has_field(L"committer_email"))		committer_email = commit[L"committer_email"].as_string().c_str();
	if (commit.has_field(L"committed_date"))		committed_date	= commit[L"committed_date"].as_string().c_str();
	CString parsedTime = ParseISO8601DateTime(authored_date);

#if OLD_GRID_MODE
	int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), short_id);
	m_LogList.SetItemText(nItem, 1, author_name);
	m_LogList.SetItemText(nItem, 2, parsedTime); 
	m_LogList.SetItemText(nItem, 3, title);
	if( nm.GetLength() > 0)
		m_LogList.SetItemText(nItem, 4, nm);
	m_CommitHistory.push_back(commit); // row index와 매칭됨
#else

#endif
}



/*
{ "id" : "5ee8b393ad1bba251b005ea0d5d8b02792dbdad1" }
{ "name" : "README.md" }
{ "type" : "blob" }
{ "path" : "README.md" }
{ "mode" : "100644" }
*/
#if OLD_GRID_MODE
void CHistory::AppendLastCommit(CString nm ,const web::json::value& commit)
{
	if (!commit.is_object()) return;
	CString id , short_id(""), created_at,parent_ids,title(""), message, author_name(""),author_email,authored_date,committer_name,committer_email, committed_date("");
	if (commit.has_field(L"id"))				id				= commit[L"id"].as_string().c_str();	
	if (commit.has_field(L"short_id"))			short_id		= commit[L"short_id"].as_string().c_str();
	if (commit.has_field(L"created_at"))		created_at		= commit[L"created_at"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
	if (commit.has_field(L"title"))				title			= commit[L"title"].as_string().c_str();
	if (commit.has_field(L"message"))			message			= commit[L"message"].as_string().c_str();
	if (commit.has_field(L"author_name"))		author_name		= commit[L"author_name"].as_string().c_str();
	if (commit.has_field(L"author_email"))		author_email	= commit[L"author_email"].as_string().c_str();
	if (commit.has_field(L"authored_date"))		authored_date	= commit[L"authored_date"].as_string().c_str();
	if (commit.has_field(L"committer_name"))	committer_name	= commit[L"committer_name"].as_string().c_str();
	if (commit.has_field(L"committer_email"))	committer_email = commit[L"committer_email"].as_string().c_str();
	if (commit.has_field(L"committed_date"))	committed_date	= commit[L"committed_date"].as_string().c_str();
	CString parsedTime = ParseISO8601DateTime(authored_date);
	int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), short_id);
	m_LogList.SetItemText(nItem, 1, author_name);
	m_LogList.SetItemText(nItem, 2, parsedTime); 
	m_LogList.SetItemText(nItem, 3, title);
	if( nm.GetLength() > 0)
		m_LogList.SetItemText(nItem, 4, nm);
	m_CommitHistory.push_back(commit); // row index와 매칭됨
}
#else
void CHistory::AppendLastCommit(CString nm ,const web::json::value& commit)
{
	if (!commit.is_object()) return;
	CString id , short_id(""), created_at,parent_ids,title(""), message, author_name(""),author_email,authored_date,committer_name,committer_email, committed_date("");
	if (commit.has_field(L"id"))				id				= commit[L"id"].as_string().c_str();	
	if (commit.has_field(L"short_id"))			short_id		= commit[L"short_id"].as_string().c_str();
	if (commit.has_field(L"created_at"))		created_at		= commit[L"created_at"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
	if (commit.has_field(L"title"))				title			= commit[L"title"].as_string().c_str();
	if (commit.has_field(L"message"))			message			= commit[L"message"].as_string().c_str();
	if (commit.has_field(L"author_name"))		author_name		= commit[L"author_name"].as_string().c_str();
	if (commit.has_field(L"author_email"))		author_email	= commit[L"author_email"].as_string().c_str();
	if (commit.has_field(L"authored_date"))		authored_date	= commit[L"authored_date"].as_string().c_str();
	if (commit.has_field(L"committer_name"))	committer_name	= commit[L"committer_name"].as_string().c_str();
	if (commit.has_field(L"committer_email"))	committer_email = commit[L"committer_email"].as_string().c_str();
	if (commit.has_field(L"committed_date"))	committed_date	= commit[L"committed_date"].as_string().c_str();
	CString parsedTime = ParseISO8601DateTime(authored_date);

}
#endif



std::wstring makeCommitMessage(const std::wstring& screenName, const std::wstring& content) {
	return L"~@" + screenName + L"\n" + content;
}
//std::wstring commitMsg = makeCommitMessage(L"주식현재가", L"AAPL 현재가: 230.15");
/////////////////////////////
// 커밋 메시지에서 "~@화면명" 
/////////////////////////////
void parseCommitMessage(const std::wstring& fullMsg, std::wstring& outScreenName, std::wstring& outContent) {
	size_t tagPos = fullMsg.find(L"~@");
	if (tagPos != std::wstring::npos) {
		size_t newline = fullMsg.find(L'\n', tagPos);
		if (newline != std::wstring::npos) {
			outScreenName = fullMsg.substr(tagPos + 2, newline - (tagPos + 2));
			outContent = fullMsg.substr(newline + 1);
		} else {
			outScreenName = fullMsg.substr(tagPos + 2);
			outContent = L"";
		}
	} else {
		outScreenName = L"";
		outContent = fullMsg;
	}
}
// 파일 목록 List Commit std::vector<TR_LASTcommit>    m_fileLast;
#if OLD_GRID_MODE
void CHistory::Lastcommit()
{	
	m_mapMode = 1;
	m_fileLast.clear();
	if(m_LogList.GetSafeHwnd()==NULL) return;
	m_LogList.DeleteAllItems();
	m_LogList.InsertColumn(0, _T("ID"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(1, _T("File Name"), LVCFMT_LEFT, 120);
	m_LogList.InsertColumn(2, _T("Last Commit"), LVCFMT_LEFT, 150);
	m_LogList.InsertColumn(3, _T("Last Update"), LVCFMT_LEFT, 300);
	m_LogList.InsertColumn(4, _T("Last Commit Message"), LVCFMT_LEFT, 200);
	m_LogList.InsertColumn(5, _T("Last Update"), LVCFMT_LEFT, 300);
	m_LogList.InsertColumn(6, _T("Last Commit Message"), LVCFMT_LEFT, 200);
	g_Outjson=  web::json::value::object(); 
	std::vector<CString> fi= theApp.m_RGA.GitLab_GetRepositoryTree2(g_Outjson);
	size_t length = g_Outjson.size();  // 배열 길이 가져오기
	for (size_t i = 0; i < length; ++i)
	{
		json::value item = g_Outjson[i];
		if (item.is_object())
		{
			CString id , name(""), type ,path, mode("");
			if (item.has_field(L"id"))		id   = item[L"id"].as_string().c_str();
			if (item.has_field(L"name"))	name = item[L"name"].as_string().c_str();
			if (item.has_field(L"type"))	type = item[L"type"].as_string().c_str();	//if (commit.has_field(L"parent_ids"))	parent_ids = commit[L"parent_ids"].as_string().c_str();
			if (item.has_field(L"path"))	path = item[L"path"].as_string().c_str();
			if (item.has_field(L"mode"))	mode = item[L"mode"].as_string().c_str();
			TR_LASTcommit Tr;
			Tr.id   = item[U("id")  ].as_string().c_str();
			Tr.path = item[U("path")].as_string().c_str();
			Tr.name = item[U("name")].as_string().c_str();
			m_fileLast.push_back(Tr);
		}
	}
	for (size_t j = 0; j < m_fileLast.size(); ++j) {
		json::value commitsArray;
		theApp.m_RGA.getcommitLast(m_fileLast[j],commitsArray);	}
	for (size_t h = 0; h < m_fileLast.size(); ++h) {
		int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(), CString(m_fileLast[h].id.c_str()));
		m_LogList.SetItemText(nItem, 1, CString(m_fileLast[h].name.c_str()));
		m_LogList.SetItemText(nItem, 2, CString(m_fileLast[h].last_commit_message.c_str())); 
		m_LogList.SetItemText(nItem, 3, CString(m_fileLast[h].last_commit_date.c_str()));
		m_LogList.SetItemText(nItem, 4, CString(m_fileLast[h].path.c_str()));
		m_LogList.SetItemData(nItem, h);
		utility::string_t ADD_message(U("~@주식현재가"));
		m_fileLast[h].last_commit_message.append(ADD_message);
		CString fullMsg = CString(m_fileLast[h].last_commit_message.c_str());
		std::wstring screenName, content;
		parseCommitMessage(m_fileLast[h].last_commit_message, screenName, content);	// 화면명은 컬럼 1에, 내용은 컬럼 2에 출력
		m_LogList.SetItemText(nItem, 5, CString(screenName.c_str())); // 예: "주식현재가"
		m_LogList.SetItemText(nItem, 6, CString(content.c_str()));    // 예: "AAPL 현재가: 230.15"
	}
}
#else
void CHistory::Lastcommit()
{	
	m_mapMode = 1;
	m_fileLast.clear();

}

#endif


// 간단한 URL 인코딩 함수 (필요 시)
std::string URLEncode(const std::string &str)
{
	std::string encoded;
	char hex[] = "0123456789ABCDEF";

	for (size_t i = 0; i < str.length(); ++i)
	{
		unsigned char c = (unsigned char)str[i];
		if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~')
		{
			encoded += c;
		}
		else if (c == ' ')
		{
			encoded += '+';
		}
		else
		{
			encoded += '%';
			encoded += hex[c >> 4];
			encoded += hex[c & 15];
		}
	}
	return encoded;
}
/*
// 파일 목록 List Download [ ^@
void CHistory::GetFilesListDownList_Test()
{
	json::value Outjson;
	m_filesList= theApp.m_RGA.GitLab_GetRepositoryTree2(Outjson);
	theApp.m_RGA.TRACE_JSON(__FUNCTION__, Outjson);
	try
	{
		size_t len = m_filesList.size();  // 오래된 버전에서는 size() 제공
		for (size_t i = 0; i < len; ++i)
		{
			TRACE("CHistory::GetFilesListDownList_Test(%d)    name=[%s] \r\n",i , m_filesList[i] );
			CString sbranch= "Master";
			CString rawPath =m_filesList[i];								// UrlEncode((CString)files[i]);
			theApp.m_RGA.DownloadGitlabFile( CString(g_tPROJECTPATH.c_str()) , rawPath , sbranch,CString(g_tPRIVATE_TOKEN.c_str())  );

	this->m_ctrlProgress.SetPos((i/len)*100);


		}
	}
	catch ( const std::exception &e )	{
		printf("Error exception:%s\n", e.what());
	}
}
*/
/*
#include <afxwin.h>
#include <fstream>
#include "cpprest/http_client.h"

using namespace web;
using namespace web::http;
using namespace web::http::client;
*/

// ---------------------------------------------
// 단일 스레드에서 순차 다운로드 수행 함수
// ---------------------------------------------
UINT AFX_CDECL Thread_DownloadAllFiles(LPVOID pParam)
{
	CHistory* pHistory = (CHistory*)pParam;
	if (!pHistory)
		return 0;

	try
	{
		json::value Outjson;
		pHistory->m_filesList = theApp.m_RGA.GitLab_GetRepositoryTree2(Outjson);
	//	theApp.m_RGA.TRACE_JSON(L"Thread_DownloadAllFiles", Outjson);

		size_t len = pHistory->m_filesList.size();
		for (size_t i = 0; i < len; ++i)
		{
			CString fileName = pHistory->m_filesList[i];
			CString sbranch = _T("master");

			TRACE("[단일스레드] (%d/%d) 다운로드 시작: %s\n", (int)i + 1, (int)len, (LPCTSTR)fileName);

			theApp.m_RGA.DownloadGitlabFile(
				CString(g_tPROJECTPATH.c_str()),
				fileName,
				sbranch,
				CString(g_tPRIVATE_TOKEN.c_str())
				);

			// 진행률 표시 (0~100%)
			int percent = (int)(((double)(i + 1) / len) * 100.0);
			pHistory->m_ctrlProgress.SetPos(percent);

			Sleep(100); // UI 갱신 여유 (optional)
		}

		AfxMessageBox("모든 파일 다운로드 완료되었습니다.");
	}
	catch (const std::exception& e)
	{
		CString msg;
	//	msg.Format("예외 발생: %S", e.what());
		AfxMessageBox(msg);
	}

	return 0;
}

// ---------------------------------------------
// 메인 호출부 (UI 이벤트 함수)
// ---------------------------------------------
void CHistory::GetFilesListDownList_Test()
{
	// 백그라운드 스레드로 단일 다운로드 실행
	AfxBeginThread(Thread_DownloadAllFiles, this);
}


CString CUrlEncode(CString str) {
	CString encoded;
	for (int i = 0; i < str.GetLength(); ++i) {
		TCHAR ch = str[i];
		if (_istalnum(ch) || ch == _T('-') || ch == _T('_') || ch == _T('.') || ch == _T('~')) {
			encoded += ch;
		} else {
			CString hex;
			hex.Format(_T("%%%02X"), (BYTE)ch);
			encoded += hex;
		}
	}
	return encoded;
}

//2025-08-07
inline std::wstring CStringToWString(const CString& str) {
	int len = MultiByteToWideChar(CP_ACP, 0, str, -1, nullptr, 0);
	if (len == 0) return L"";
	std::wstring result(len - 1, L'\0'); 
	MultiByteToWideChar(CP_ACP, 0, str, -1, &result[0], len);
	return result;
}

//		CString rawPath =m_filesList[0]; // CString("안율") + ".cpp";			
//		utility::string_t filepath = utility::conversions::to_string_t((LPCTSTR) rawPath); 

//2025-08-07
CString rawPath = CString("안율") + ".cpp";
std::wstring filepath	=	CStringToWString(rawPath);
utility::string_t utilPath = filepath;















#if OLD_GRID_MODE
void CHistory::HistoryCommits(CString strFile)   
{
	m_mapMode = 2;
	m_fileHist.clear();
	m_LogList.DeleteAllItems();
	m_LogList.InsertColumn(0, _T("Short ID"), LVCFMT_LEFT, 0);
	m_LogList.InsertColumn(1, _T("Message"), LVCFMT_LEFT, 350);
	m_LogList.InsertColumn(2, _T("Revision"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(3, _T("Action"), LVCFMT_LEFT, 100);
	m_LogList.InsertColumn(4, _T("Author"), LVCFMT_LEFT, 120);
	m_LogList.InsertColumn(5, _T("Date"), LVCFMT_LEFT, 150);
	m_LogList.InsertColumn(6, _T("file"), LVCFMT_LEFT, 10);
	json::value Outjson;

	if(m_filesList.size()==0)
	m_filesList.push_back(strFile);	

	if(m_filesList.size())
	{


//		CString rawPath =m_filesList[0]; // CString("안율") + ".cpp";			
//		utility::string_t filepath = utility::conversions::to_string_t((LPCTSTR) rawPath); 

//2025-08-07
		CString rawPath = CString("안율") + ".cpp";
		std::wstring filepath	=	CStringToWString(rawPath);
		utility::string_t utilPath = filepath;


		theApp.m_RGA.getcommitHistory( filepath, m_fileHist, Outjson);
		size_t length = m_fileHist.size();  
		for (size_t i = 0; i < length; ++i)
		{
			int nItem = m_LogList.InsertItem(m_LogList.GetItemCount(),CString(m_fileHist[i].short_id.c_str()));
			m_LogList.SetItemText(nItem, 1, CString( m_fileHist[i].message.c_str()));
			m_LogList.SetItemText(nItem, 2, CString( m_fileHist[i].committer_email.c_str()));
			m_LogList.SetItemText(nItem, 3, CString( m_fileHist[i].committed_date.c_str())); 
			m_LogList.SetItemData(nItem, i);
		}
	}
}
#else
void CHistory::HistoryCommits(CString strFile)   
{

}

#endif



void CHistory::OnLvnItemchangedLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	*pResult = 0;
}

void CHistory::OnClickLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;
}

void CHistory::OnDblclkLoglist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;
	int nIndex = pNMItemActivate->iItem;
TRACE("CHistory::OnDblclkLoglist(0) nIndex=[%d] \r\n",nIndex );
	if (nIndex < 0) return;
TRACE("CHistory::OnDblclkLoglist(1) nIndex=[%d] \r\n",nIndex );

	CString short_id_new;
	CString short_id_old;
#if OLD_GRID_MODE
	int nPos = m_LogList.GetItemData(nIndex);
	if (m_mapMode == 1 && nPos >= 0 && m_fileLast.size() > 0)	{
		TR_LASTcommit *pL = &m_fileLast[nPos];
		if (pL)	{
			short_id_new = m_LogList.GetItemText(nIndex, 0);  // 최신 커밋
			short_id_old = (CString)pL->parent_ids.c_str();   // 직전 커밋m_fileHist
		}
	}
	else if (m_mapMode == 2 && nPos >= 0 && m_fileHist.size() > 0)	{
		TR_HISTORYcommit *pH = &m_fileHist[nPos];
		if (pH)	{
			short_id_new = m_LogList.GetItemText(nIndex, 0);    
			if(pH->vParent_ids.size()==0)
			{
				short_id_old = short_id_new;
			}
			else
			{
				short_id_old = (CString)pH->vParent_ids[0].c_str(); 
			}
		}
	}
#else



#endif


	if (short_id_new.IsEmpty() || short_id_old.IsEmpty())	{
		short_id_old = short_id_new; 
	}
	std::vector<json::value> diffOld, diffNew;
//	theApp.m_RGA.GetDiffCompareGitLab(	utility::conversions::to_string_t((LPCTSTR)short_id_old),tility::conversions::to_string_t((LPCTSTR)short_id_new), diffOld, diffNew);

	if (diffNew.size()==0 && diffOld.size()==0) 
	{
		theApp.m_RGA.GetDiffFromGitLab( utility::conversions::to_string_t((LPCTSTR)short_id_new), diffNew);
		theApp.m_RGA.GetDiffFromGitLab( utility::conversions::to_string_t((LPCTSTR)short_id_old), diffOld);
	}
	else
	{
//		theApp.m_RGA.GetDiffCompareGitLab( utility::conversions::to_string_t((LPCTSTR) short_id_old ),utility::conversions::to_string_t((LPCTSTR) short_id_new) ,diffOld,  diffNew  );
	}

	CString sbranch			= "main";
	CString downPath_Hist	= "d:\\gittest\\";

	CString newPath ;
	CString oldPath ;
	if(diffNew.size())	{	const auto& newDiff = diffNew[0];	newPath = CString(newDiff[U("new_path")].as_string().c_str());	}
	if(diffOld.size())	{	const auto& oldDiff = diffOld[0];	oldPath = CString(oldDiff[U("old_path")].as_string().c_str());	}

	CString safeNew = newPath; safeNew.Replace(_T("\\"), _T("_")); safeNew.Replace(_T("/"), _T("_"));
	CString safeOld = oldPath; safeOld.Replace(_T("\\"), _T("_")); safeOld.Replace(_T("/"), _T("_"));

	CString write_NewTagFile =  "_new_"+short_id_new+"_"; //"_new_bab723ae_" 
	CString write_OldTagFile =  "_old_"+short_id_old+"_"; 
	CString tempNewFile = downPath_Hist +write_NewTagFile+ safeNew;
	CString tempOldFile = downPath_Hist +write_OldTagFile+ safeOld;
//	write_NewTagFile = ""; //이것 경로 지정 하면 바로 resp api 바로 저장 한다"
//	write_OldTagFile = ""; 

#if 0 // CString 방식 바이트가 늘어난다
	CString oldContentBuff_CString, newContentBuff_CString;
	theApp.m_RGA.DownloadGit_CStringBuff( CString(g_tPROJECTPATH.c_str()) , newPath ,write_NewTagFile, short_id_new, sbranch,CString(g_tPRIVATE_TOKEN.c_str())  ,newContentBuff_CString );
	theApp.m_RGA.DownloadGit_CStringBuff( CString(g_tPROJECTPATH.c_str()) , oldPath ,write_OldTagFile, short_id_old, sbranch,CString(g_tPRIVATE_TOKEN.c_str())  ,oldContentBuff_CString );
	if (oldContentBuff_CString.Compare(newContentBuff_CString) !=0)	{ AfxMessageBox(_T("파일 내용이 동일합니다. 변경된 내용이 없습니다.")); newContentBuff_CString+=_T(" \r\n");	}
	if(write_NewTagFile.GetLength()==0)	tempNewFile = WriteTXT(tempNewFile, newContentBuff_CString);
	if(write_OldTagFile.GetLength()==0)	tempOldFile = WriteTXT(tempOldFile, oldContentBuff_CString);
#else
	string oldContentBuff_string, newContentBuff_string;
//	theApp.m_RGA.DownloadGit_stringBuff( CString(g_tPROJECTPATH.c_str()) , newPath ,write_NewTagFile, short_id_new, sbranch,CString(g_tPRIVATE_TOKEN.c_str())  ,newContentBuff_string );
//	theApp.m_RGA.DownloadGit_stringBuff( CString(g_tPROJECTPATH.c_str()) , oldPath ,write_OldTagFile, short_id_old, sbranch,CString(g_tPRIVATE_TOKEN.c_str())  ,oldContentBuff_string );

	theApp.m_RGA.DownloadFileFromGitLab_JSON(
		L"root",                        // 🔧 프로젝트 경로 또는 ID
		newPath,              // 파일 경로
		short_id_new,                     // 브랜치명 또는 커밋 SHA
		tempNewFile              // 저장할 로컬 파일 경로
		);

	theApp.m_RGA.DownloadFileFromGitLab_JSON(
		L"root",                        // 🔧 프로젝트 경로 또는 ID
		oldPath,              // 파일 경로
		short_id_old,                     // 브랜치명 또는 커밋 SHA
		tempOldFile               // 저장할 로컬 파일 경로
		);


	if(write_NewTagFile.GetLength()==0)	tempNewFile = Write_string(tempNewFile, newContentBuff_string); 
	if(write_OldTagFile.GetLength()==0)	tempOldFile = Write_string(tempOldFile, oldContentBuff_string);
#endif

	CString exePath = GetRunTimePath() + _T("\\TortoiseGitMerge.exe");
	CString cmd;	cmd.Format(_T("\"%s\" /base:\"%s\" /mine:\"%s\""), exePath, tempOldFile, tempNewFile);
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	if (CreateProcess(NULL, cmd.GetBuffer(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) 
	{
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	}
	else	
	{
		TRACE(L"CreateProcess failed: %s\n", cmd);
	}
}





// ASCII 검사
bool IsASCII(const BYTE* buffer, DWORD size) {
	for (DWORD i = 0; i < size; ++i) {
		if (buffer[i] >= 0x80) return false;
	}
	return true;
}
// UTF-8 without BOM 검사
bool IsUTF8WithoutBOM(const BYTE* data, DWORD size) {
	DWORD i = 0;
	while (i < size) {
		BYTE ch = data[i];
		if (ch <= 0x7F) {
			i++;
		} else if ((ch & 0xE0) == 0xC0) {
			if (i + 1 >= size || (data[i + 1] & 0xC0) != 0x80)
				return false;
			i += 2;
		} else if ((ch & 0xF0) == 0xE0) {
			if (i + 2 >= size ||
				(data[i + 1] & 0xC0) != 0x80 ||
				(data[i + 2] & 0xC0) != 0x80)
				return false;
			i += 3;
		} else if ((ch & 0xF8) == 0xF0) {
			if (i + 3 >= size ||
				(data[i + 1] & 0xC0) != 0x80 ||
				(data[i + 2] & 0xC0) != 0x80 ||
				(data[i + 3] & 0xC0) != 0x80)
				return false;
			i += 4;
		} else {
			return false;
		}
	}
	return true;
}
// UTF-16 감지
EncodingType DetectUTF16(const BYTE* data, DWORD size) {
	if (size >= 2) {
		if (data[0] == 0xFF && data[1] == 0xFE)
			return ENCODING_UTF16_LE;
		if (data[0] == 0xFE && data[1] == 0xFF)
			return ENCODING_UTF16_BE;
	}
	return ENCODING_UNKNOWN;
}

// 인코딩 감지
EncodingType DetectEncoding(const BYTE* buffer, DWORD size) {
	if (size >= 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF)
		return ENCODING_UTF8_BOM;

	EncodingType utf16 = DetectUTF16(buffer, size);
	if (utf16 != ENCODING_UNKNOWN)
		return utf16;

	if (IsASCII(buffer, size))
		return ENCODING_ASCII;
	if (IsUTF8WithoutBOM(buffer, size))
		return ENCODING_UTF8_NO_BOM;

	return ENCODING_ANSI;
}
//한글 ?
std::string ConvertWStringToUTF8(const std::wstring& wstr) {
	if (wstr.empty()) return "";

	int sizeNeeded = WideCharToMultiByte(CP_UTF8, 0, wstr.data(), (int)wstr.length(), NULL, 0, NULL, NULL);
	if (sizeNeeded <= 0) return "";

	std::string result(sizeNeeded, 0);
	WideCharToMultiByte(CP_UTF8, 0, wstr.data(), (int)wstr.length(), &result[0], sizeNeeded, NULL, NULL);
	return result;
}

// 한글 ?
void SaveAsUTF8(const std::wstring& filename, const std::wstring& content) {
	std::string utf8Content = ConvertWStringToUTF8(content);

	std::ofstream file(filename.c_str(), std::ios::binary);
	if (file.is_open()) {
		unsigned char bom[] = { 0xEF, 0xBB, 0xBF };
		file.write(reinterpret_cast<const char*>(bom), 3);
		file.write(utf8Content.data(), utf8Content.size());
		file.close();
	}
}

//한글 ? 인코딩 감지 및 변환 저장
bool ConvertFileToUTF8( std::wstring filename) {
	HANDLE hFile = CreateFileW(filename.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	if (hFile == INVALID_HANDLE_VALUE) return false;

	DWORD fileSize = GetFileSize(hFile, NULL);
	if (fileSize == INVALID_FILE_SIZE || fileSize == 0) {
		CloseHandle(hFile);
		return false;
	}

	std::vector<BYTE> buffer(fileSize);
	DWORD bytesRead;
	ReadFile(hFile, &buffer[0], fileSize, &bytesRead, NULL);
	CloseHandle(hFile);

	EncodingType encoding = DetectEncoding(&buffer[0], fileSize);
	std::wstring wideText ;
	int wlen =0;


	switch (encoding) {
	case ENCODING_UTF8_BOM:
		// already UTF-8, skip
/*
		 wlen = MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)&buffer[0], fileSize, NULL, 0);
		if (wlen <= 0) return false;
		wideText.resize(wlen);
		MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)&buffer[0], fileSize, &wideText[0], wlen);
		SaveAsUTF8(filename, wideText);
*/
		return true;

	case ENCODING_UTF8_NO_BOM: {
		 wlen = MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)&buffer[0], fileSize, NULL, 0);
		if (wlen <= 0) return false;
		wideText.resize(wlen);
		MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)&buffer[0], fileSize, &wideText[0], wlen);
		break;
							   }

	case ENCODING_UTF16_LE: {
		wideText.assign((wchar_t*)&buffer[2], (fileSize - 2) / 2); // skip BOM
		break;
							}

	case ENCODING_UTF16_BE: {
		// swap bytes
		for (DWORD i = 2; i + 1 < fileSize; i += 2) {
			wchar_t ch = (buffer[i] << 8) | buffer[i + 1];
			wideText.push_back(ch);
		}
		break;
							}

	case ENCODING_ASCII:
	case ENCODING_ANSI: {
		 wlen = MultiByteToWideChar(949, 0, (LPCSTR)&buffer[0], fileSize, NULL, 0);
		if (wlen <= 0) return false;
		wideText.resize(wlen);
		MultiByteToWideChar(949, 0, (LPCSTR)&buffer[0], fileSize, &wideText[0], wlen);
		break;
						}

	default:
		return false;
	}

	SaveAsUTF8(filename, wideText);
	return true;
}


//한글 ?
std::wstring ConvertToWString(const char* str, UINT codePage = CP_ACP) {
	if (!str) return L"";
	int size = MultiByteToWideChar(codePage, 0, str, -1, NULL, 0);
	std::wstring result(size, 0);
	MultiByteToWideChar(codePage, 0, str, -1, &result[0], size);
	result.resize(size - 1); // Remove null terminator
	return result;
}

CString CHistory::WriteTXT(CString FileName, CString dataTxt)
{
	if (FileName.IsEmpty()) return _T("");
	CFile file;
	CFileException feError;
	if( file.Open( FileName, CFile::modeWrite | CFile::modeCreate, &feError ) )
	{
		int max = dataTxt.GetLength(); 
		file.Write(dataTxt.GetBuffer(),(unsigned int) max);	
		file.Close();
	}
	else
	{
		TCHAR	errBuff[256];
		feError.GetErrorMessage( errBuff, 256 );
		TRACE(errBuff);
	}
/* 한글 ?
#ifdef UNICODE
	std::wstring mm = FileName.GetString();
#else
	std::wstring mm = ConvertToWString(FileName.GetString()); // 아래 함수 참고
#endif
	ConvertFileToUTF8(mm);
*/
	return FileName;
}


CString CHistory::Write_string(CString FileName, string data)
{
	if (FileName.IsEmpty()) return _T("");
	std::ofstream outFile(FileName , std::ios::binary);
	outFile.write((const char*)data.data(), data.size());
	outFile.close();
	return FileName;
}

	// diff
CString CHistory::ExtractNewContentFromDiff(const CString& diff)
{
	CString result;
	CStringArray lines;
	int pos = 0;
	CString line;
	while ((line = diff.Tokenize(_T("\n"), pos)) != _T(""))
	{
		if (line.Left(1) == _T("+") && line.Left(3) != _T("+++"))
			result += line.Mid(1) + _T("\n");
	}
	return result;
}
CString CHistory::ExtractNewContentFromCompare(const CString& diff)
{
	CString result;
	int pos = 0;
	CString line;
	bool inHunk = false;

	while ((line = diff.Tokenize(_T("\n"), pos)) != _T(""))
	{
		if (line.Left(2) == _T("@@"))
		{
			inHunk = true;
			continue;  // @@ 줄 자체는 제외
		}
		if (!inHunk)
			continue;

		if (line.Left(1) == _T("-")) continue; // 삭제된 줄은 제외
		if (line.Left(1) == _T(" "))           // context 줄
			result += line.Mid(1) + _T("\n");
		else if (line.Left(1) == _T("+") && line.Left(3) != _T("+++"))
			result += line.Mid(1) + _T("\n");
	}
	return result;
}

/*
 수정 통계
	- 추가된 줄: 2
	- 삭제된 줄: 2
	- 수정된 줄 쌍: 1
	- 단순 추가: 1
	- 단순 삭제: 1

	DiffStats stats = ParseDiffStatistics(diff);
	CString msg;
	msg.Format(_T("수정 통계\n")
	_T("- 추가된 줄: %d\n")
	_T("- 삭제된 줄: %d\n")
	_T("- 수정된 줄 쌍: %d\n")
	_T("- 단순 추가: %d\n")
	_T("- 단순 삭제: %d\n"),
	stats.addedLines,
	stats.deletedLines,
	stats.modifiedPairs,
	stats.pureAdded,
	stats.pureDeleted);
	AfxMessageBox(msg);
*/
DiffStats CHistory::ParseDiffStatistics(const CString& diff)
{
	DiffStats stats;
	int pos = 0;
	CString line;
	CString lastDeleted;

	while ((line = diff.Tokenize(_T("\n"), pos)) != _T(""))
	{
		// --- 헤더 무시
		if (line.Left(3) == _T("---") || line.Left(3) == _T("+++"))
			continue;

		if (line.Left(1) == _T("-"))
		{
			stats.deletedLines++;
			lastDeleted = line.Mid(1);
		}
		else if (!lastDeleted.IsEmpty() && line.Left(1) == _T("+"))
		{
			// 삭제 → 추가 → 수정 쌍으로 간주
			stats.addedLines++;
			stats.modifiedPairs++;
			lastDeleted.Empty();  // 수정 쌍 처리 완료
		}
		else
		{
			if (!lastDeleted.IsEmpty()) {
				// 삭제 후 추가 없으면 순수 삭제로 간주
				stats.pureDeleted++;
				lastDeleted.Empty();
			}

			if (line.Left(1) == _T("+")) {
				stats.addedLines++;
				stats.pureAdded++;
			}
		}
	}

	// 마지막 줄이 삭제였지만 수정으로 이어지지 않았을 경우 처리
	if (!lastDeleted.IsEmpty())
		stats.pureDeleted++;

	return stats;
}
// diff
CString CHistory::WriteTempFile(const CString& filename, const CString& content)
{
	CString tempPath;
	GetTempPath(MAX_PATH, tempPath.GetBuffer(MAX_PATH));
	tempPath.ReleaseBuffer();
	CString fullPath = tempPath + filename;
	CStdioFile file;
	if (file.Open(fullPath, CFile::modeCreate | CFile::modeWrite | CFile::typeText))
	{
		file.WriteString(content);
		file.Close();
	}
	return fullPath;
}

BOOL CHistory::OnEraseBkgnd(CDC* pDC)
{
	CRect r;
	GetClientRect(&r);
	pDC->FillSolidRect(&r, RGB(44, 44, 44));  // GitHub 다크 테마 배경
	return TRUE;

	return CSkinedDialog::OnEraseBkgnd(pDC);
}


CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD){
}
void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
}
BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()












/*
ref_name	브랜치 이름 (예: main, master)
	path	특정 파일 또는 폴더 경로의 커밋만
	since	ISO 8601 포맷 시작일자 (2024-01-01T00:00:00Z)
	until	끝나는 일자
	author	작성자 필터
	per_page	페이지당 커밋 수 (기본 20, 최대 100)
	page	페이지 번호

ref_name=main	git log main
	path=src/index.js	git log -- src/index.js
	since=2024-01-01	git log --since="2024-01-01"
	until=2024-05-01	git log --until="2024-05-01"
	author=홍길동	git log --author="홍길동"
	per_page=10	git log -n 10
	1. 브랜치 기준 커밋:
	git log origin/main --oneline

	2. 특정 경로에 대한 커밋:
	git log -- path/to/file

	3. 기간 필터링:
	git log --since="2024-01-01" --until="2024-05-26"

	4. JSON 스타일 출력 (파싱용):
	git log --pretty=format:'{"hash":"%H","author":"%an","date":"%ad","message":"%s"},'

	🔄 GitLab REST API vs Git 명령어 비교
	목적	                GitLab REST API	Git CLI
	원격 저장소 커밋 보기	✅ 가능	        ❌ (로컬 복제 필요)
	특정 브랜치 커밋 보기	✅ ref_name	    ✅ git log 브랜치명
	특정 파일 커밋 보기	    ✅ path=	    ✅ git log -- path
	날짜 필터링	            ✅ since, until	✅ --since, --until
	작성자 필터	            ✅ author	    ✅ --author
*/
void CHistory::SetCommitMakePush_Test()	// commit 메세지 작성
{
	std::string tagCommit = "^@stock Current"; //주식현재가1";
	std::string branch = "main";
	std::string filePath = "D:\\gittest\\htsmts\\CommitDlg.cpp";
	std::string commitMessage = "Add new file bin2 "+ tagCommit;
	theApp.m_RGA.commitFileToGitLab(branch, filePath, commitMessage);
}

void CHistory::OnBnClickedCommitMake()
{
	CString short_id_new;
	int nIndex = m_LogList.GetSelectionMark();
	if(m_LogList.GetItemCount()<=0)
		return;


#if OLD_GRID_MODE
	int nPos = m_LogList.GetItemData(nIndex);
	if (m_mapMode == 2 && nPos >= 0 && m_fileHist.size() > 0)	
	{
		TR_HISTORYcommit *pH = &m_fileHist[nPos];
		if (pH)	{
			short_id_new = m_LogList.GetItemText(nIndex, 0);    
		}
	}

	json::value jsonResult;
	theApp.m_RGA.GetCommitStats(short_id_new , jsonResult);
	CString resultType	= theApp.m_RGA.GetJsonCheckCommitStats(jsonResult);
	TRACE("CHistory::OnBnClickedCommitMake() 판단 결과: %s\r\n", resultType);



#endif



/*
	ShowWindow(SW_HIDE);
	CCommitDlg dlg;  
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{

	}
	else if (nResponse == IDCANCEL)
	{

	}
*/
}



#include <windows.h>
#include <wininet.h>
#include <fstream>
#include <string>
#pragma comment(lib, "wininet.lib")
bool DownloadFileFromGitLab(const CString& host, const CString& project, const CString& filePath, const CString& commitHash, const CString& token, CString& outContent)
{
    HINTERNET hInternet = InternetOpen(_T("GitLabClient"), INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (!hInternet) return false;
    CStringA projectA  = CT2A(project);
    CStringA filePathA = CT2A(filePath);
    CStringA commitA   = CT2A(commitHash);
    CStringA tokenA    = CT2A(token);
    CStringA urlPath;
    urlPath.Format("/api/v4/projects/%s/repository/files/%s/raw?ref=%s", projectA.GetString(), filePathA.GetString(), commitA.GetString());
    HINTERNET hConnect = InternetConnectA(hInternet, CT2A(host), INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConnect)
    {
        InternetCloseHandle(hInternet);
        return false;
    }
    // HTTP 요청 준비
    const char* acceptTypes[] = { "*/*", NULL };
    HINTERNET hRequest = HttpOpenRequestA(hConnect, "GET", urlPath.GetString(), NULL, NULL, acceptTypes, INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
    if (!hRequest)
    {
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hInternet);
        return false;
    }
    // 인증 헤더 추가: "PRIVATE-TOKEN: {token}"
    CStringA authHeader;
	authHeader.Format("PRIVATE-TOKEN: %s\r\n", tokenA.GetString());
    BOOL sent = HttpAddRequestHeadersA(hRequest, authHeader.GetString(), -1, HTTP_ADDREQ_FLAG_ADD | HTTP_ADDREQ_FLAG_REPLACE);
    if (!sent)
    {
        InternetCloseHandle(hRequest);
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hInternet);
        return false;
    }
    // 요청 보내기
    BOOL result = HttpSendRequestA(hRequest, NULL, 0, NULL, 0);
    if (!result)
    {
        InternetCloseHandle(hRequest);
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hInternet);
        return false;
    }
    // 응답 상태 코드 확인
    DWORD statusCode = 0;
    DWORD statusSize = sizeof(statusCode);
    HttpQueryInfoA(hRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &statusCode, &statusSize, NULL);
    if (statusCode != 200)
    {
        InternetCloseHandle(hRequest);
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hInternet);
        return false;
    }
    // 응답 본문 읽기
    char buffer[4096];
    DWORD bytesRead = 0;
    std::string content;

    while (InternetReadFile(hRequest, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0)
    {
        content.append(buffer, bytesRead);
    }
    // UTF-8 -> CString 변환 (일반적으로 GitLab API는 UTF-8 응답)
    int len = MultiByteToWideChar(CP_UTF8, 0, content.c_str(), (int)content.length(), NULL, 0);
    if (len > 0)
    {
        wchar_t* wbuf = new wchar_t[len + 1];
        MultiByteToWideChar(CP_UTF8, 0, content.c_str(), (int)content.length(), wbuf, len);
        wbuf[len] = 0;
        outContent = wbuf;
        delete[] wbuf;
    }
    else
    {
        outContent = _T("");
    }
    InternetCloseHandle(hRequest);
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);

    return true;
}

void CHistory::OnEnChangeCommitAuthordata()
{
	
}
