﻿#pragma once
#include <afx.h>
#include <map>
#include <string>
#include <Windows.h>

// --------------------- 구조체 ---------------------
struct COMMIT_info12
{
	CString Date;
	CString FileName;
	CString Title;
	CString Author;
	CString msg;
	CString shortid;
};

typedef std::map<CString, COMMIT_info12> CommitMap;
std::map<CString, CommitMap> g_FileComMap12;      // 전체 commit map
std::map<CString, std::map<CString, UINT64>> g_Index; // fileKey -> commitHash -> offset

// --------------------- 보조 함수 ---------------------
BOOL ReadCString(HANDLE h, DWORD len, CString& out)
{
	out.Empty();
	if (len == 0) return TRUE;

	DWORD sz = len * sizeof(wchar_t);
	wchar_t* buf = (wchar_t*)malloc(sz);
	if (!buf) return FALSE;

	DWORD read = 0;
	if (!ReadFile(h, buf, sz, &read, NULL) || read != sz) {
		free(buf);
		return FALSE;
	}

	out.SetString(buf, len);
	free(buf);
	return TRUE;
}

// --------------------- 저장 ---------------------
BOOL CRestGitApi::SaveCommitTreeDB(LPCTSTR basePath)
{
	CString datPath = CString(basePath) + _T(".dat");
	CString idxPath = CString(basePath) + _T(".idx");

	HANDLE hDat = CreateFile(datPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hDat == INVALID_HANDLE_VALUE) return FALSE;

	HANDLE hIdx = CreateFile(idxPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hIdx == INVALID_HANDLE_VALUE) {
		CloseHandle(hDat);
		return FALSE;
	}

	LARGE_INTEGER offset;
	offset.QuadPart = 0;

	DWORD fileCount = (DWORD)g_FileComMap12.size();
	WriteFile(hIdx, &fileCount, sizeof(fileCount), NULL, NULL);

	for (auto itFile = g_FileComMap12.begin(); itFile != g_FileComMap12.end(); ++itFile)
	{
		const CString& fileKey = itFile->first;
		CommitMap& commitMap = itFile->second;

		DWORD keyLen = fileKey.GetLength();
		WriteFile(hIdx, &keyLen, sizeof(keyLen), NULL, NULL);
		WriteFile(hIdx, fileKey.GetString(), keyLen * sizeof(wchar_t), NULL, NULL);

		DWORD commitCount = (DWORD)commitMap.size();
		WriteFile(hIdx, &commitCount, sizeof(commitCount), NULL, NULL);

		for (auto itCommit = commitMap.begin(); itCommit != commitMap.end(); ++itCommit)
		{
			const CString& commitHash = itCommit->first;
			const COMMIT_info12& info = itCommit->second;

			DWORD hashLen = commitHash.GetLength();
			WriteFile(hIdx, &hashLen, sizeof(hashLen), NULL, NULL);
			WriteFile(hIdx, commitHash.GetString(), hashLen * sizeof(wchar_t), NULL, NULL);

			// 현재 .dat 파일 offset 기록
			offset.QuadPart = SetFilePointer(hDat, 0, NULL, FILE_CURRENT);
			WriteFile(hIdx, &offset.QuadPart, sizeof(offset.QuadPart), NULL, NULL);

			// ---------------- 데이터 블록 기록 ----------------
			auto writeStr = [&](const CString& s) {
				DWORD len = s.GetLength();
				WriteFile(hDat, &len, sizeof(len), NULL, NULL);
				WriteFile(hDat, s.GetString(), len * sizeof(wchar_t), NULL, NULL);
				offset.QuadPart += sizeof(len) + len * sizeof(wchar_t);
			};

			writeStr(info.Date);
			writeStr(info.FileName);
			writeStr(info.Title);
			writeStr(info.Author);
			writeStr(info.msg);
			writeStr(info.shortid);
		}
	}

	CloseHandle(hIdx);
	CloseHandle(hDat);
	return TRUE;
}

// --------------------- 인덱스 로드 ---------------------
BOOL CRestGitApi::LoadCommitIndex(LPCTSTR basePath)
{
	CString idxPath = CString(basePath) + _T(".idx");

	HANDLE hIdx = CreateFile(idxPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hIdx == INVALID_HANDLE_VALUE) return FALSE;

	g_Index.clear();

	DWORD fileCount = 0;
	ReadFile(hIdx, &fileCount, sizeof(fileCount), NULL, NULL);

	for (DWORD i = 0; i < fileCount; i++)
	{
		DWORD keyLen = 0;
		ReadFile(hIdx, &keyLen, sizeof(keyLen), NULL, NULL);

		CString fileKey;
		ReadCString(hIdx, keyLen, fileKey);

		DWORD commitCount = 0;
		ReadFile(hIdx, &commitCount, sizeof(commitCount), NULL, NULL);

		std::map<CString, UINT64> oneFileIdx;

		for (DWORD j = 0; j < commitCount; j++)
		{
			DWORD hashLen = 0;
			ReadFile(hIdx, &hashLen, sizeof(hashLen), NULL, NULL);

			CString commitHash;
			ReadCString(hIdx, hashLen, commitHash);

			UINT64 offset = 0;
			ReadFile(hIdx, &offset, sizeof(offset), NULL, NULL);

			oneFileIdx[commitHash] = offset;
		}

		g_Index[fileKey] = oneFileIdx;
	}

	CloseHandle(hIdx);
	return TRUE;
}

// --------------------- 필요 시 데이터 로드 ---------------------
BOOL CRestGitApi::ReadCommitData(LPCTSTR basePath,
	const CString& fileKey,
	const CString& commitHash,
	COMMIT_info12& out)
{
	CString datPath = CString(basePath) + _T(".dat");

	auto itFile = g_Index.find(fileKey);
	if (itFile == g_Index.end()) return FALSE;

	auto itCommit = itFile->second.find(commitHash);
	if (itCommit == itFile->second.end()) return FALSE;

	UINT64 offset = itCommit->second;

	HANDLE hDat = CreateFile(datPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hDat == INVALID_HANDLE_VALUE) return FALSE;

	LARGE_INTEGER li;
	li.QuadPart = offset;
	SetFilePointer(hDat, li.LowPart, &li.HighPart, FILE_BEGIN);

	auto readStr = [&](CString& s) {
		DWORD len = 0;
		ReadFile(hDat, &len, sizeof(len), NULL, NULL);
		ReadCString(hDat, len, s);
	};

	readStr(out.Date);
	readStr(out.FileName);
	readStr(out.Title);
	readStr(out.Author);
	readStr(out.msg);
	readStr(out.shortid);

	CloseHandle(hDat);
	return TRUE;
}







/*
#include "StdAfx.h"
#include "gitAPI32.h"
#include "RestGitApi.h"
#include <sstream>
#include <sstream>
#include <vector>
#include <string>




#include "stdafx.h"
#include <afx.h>
#include <map>
#include <vector>


typedef std::map<CString, COMMIT_info12> CommitMap; 
static std::map<CString, std::vector<COMMIT_IndexEntry> > g_CommitIndexMap;
static std::map<CString, CommitMap> g_FileComMap12;
static void WriteCStringToFile(CFile& file, const CString& s)
{
	DWORD len = (DWORD)s.GetLength();
	file.Write(&len, sizeof(len));
	if (len > 0)
		file.Write((LPCTSTR)s, (UINT)(len * sizeof(TCHAR)));
}

static void ReadCStringFromFile(CFile& file, CString& s)
{
	DWORD len = 0;
	file.Read(&len, sizeof(len));
	if (len > 0)
	{
		LPTSTR buf = s.GetBuffer(len);
		file.Read(buf, (UINT)(len * sizeof(TCHAR)));
		s.ReleaseBuffer(len);
	}
	else
	{
		s.Empty();
	}
}

BOOL SaveCommitDataFile(LPCTSTR lpszDataPath, const std::map<CString, CommitMap>& allData)
{
	if (!lpszDataPath) return FALSE;
	try
	{
		CFile file(lpszDataPath, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary);

		WORD tag = 0xBBCD;
		DWORD magic = 0x22345678;
		DWORD fileCount = (DWORD)allData.size();

		file.Write(&tag, sizeof(tag));
		file.Write(&magic, sizeof(magic));
		file.Write(&fileCount, sizeof(fileCount));

		for (std::map<CString, CommitMap>::const_iterator itFile = allData.begin(); itFile != allData.end(); ++itFile)
		{
			const CString& fileKey = itFile->first;
			const CommitMap& commits = itFile->second;

			// fileKey
			DWORD keyLen = (DWORD)fileKey.GetLength();
			file.Write(&keyLen, sizeof(keyLen));
			if (keyLen > 0) file.Write((LPCTSTR)fileKey, (UINT)(keyLen * sizeof(TCHAR)));

			// commit count
			DWORD commitCount = (DWORD)commits.size();
			file.Write(&commitCount, sizeof(commitCount));

			for (CommitMap::const_iterator itCommit = commits.begin(); itCommit != commits.end(); ++itCommit)
			{
				const CString& commitHash = itCommit->first;
				const COMMIT_info12& info = itCommit->second;

				// commitHash + fields
				WriteCStringToFile(file, commitHash);
				WriteCStringToFile(file, info.Date);
				WriteCStringToFile(file, info.FileName);
				WriteCStringToFile(file, info.Title);
				WriteCStringToFile(file, info.Author);
				WriteCStringToFile(file, info.msg);
				WriteCStringToFile(file, info.shortid);
			}
		}

		file.Close();
		TRACE(_T("SaveCommitDataFile: 저장 완료 (%s)\n"), lpszDataPath);
		return TRUE;
	}
	catch (CFileException* e)
	{
		TCHAR buf[256]; e->GetErrorMessage(buf, 256);
		TRACE(_T("SaveCommitDataFile 예외: %s\n"), buf);
		e->Delete();
		return FALSE;
	}
}

BOOL BuildAndSaveIndexFile(LPCTSTR lpszDataPath, LPCTSTR lpszIndexPath)
{
	if (!lpszDataPath || !lpszIndexPath) return FALSE;
	try
	{
		g_CommitIndexMap.clear();

		CFile dataFile(lpszDataPath, CFile::modeRead | CFile::typeBinary);
		CFile idxFile(lpszIndexPath, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary);

		// header 확인
		WORD tag = 0;
		DWORD magic = 0;
		dataFile.Read(&tag, sizeof(tag));
		dataFile.Read(&magic, sizeof(magic));
		if (tag != 0xBBCD || magic != 0x22345678)
		{
			TRACE(_T("BuildAndSaveIndexFile: 데이터 파일 포맷 오류\n"));
			dataFile.Close();
			idxFile.Close();
			return FALSE;
		}

		DWORD fileCount = 0;
		dataFile.Read(&fileCount, sizeof(fileCount));
		idxFile.Write(&fileCount, sizeof(fileCount));

		for (DWORD i = 0; i < fileCount; ++i)
		{
			// read fileKey
			DWORD keyLen = 0;
			dataFile.Read(&keyLen, sizeof(keyLen));
			CString fileKey;
			if (keyLen > 0)
			{
				LPTSTR keyBuf = fileKey.GetBuffer(keyLen);
				dataFile.Read(keyBuf, (UINT)(keyLen * sizeof(TCHAR)));
				fileKey.ReleaseBuffer(keyLen);
			}
			else fileKey.Empty();

			// read commitCount
			DWORD commitCount = 0;
			dataFile.Read(&commitCount, sizeof(commitCount));

			// write key & commitCount to idx file
			idxFile.Write(&keyLen, sizeof(keyLen));
			if (keyLen > 0) idxFile.Write((LPCTSTR)fileKey, (UINT)(keyLen * sizeof(TCHAR)));
			idxFile.Write(&commitCount, sizeof(commitCount));

			std::vector<COMMIT_IndexEntry> entries;
			entries.reserve(commitCount);

			for (DWORD j = 0; j < commitCount; ++j)
			{
				// commit block 시작 오프셋
				ULONGLONG startOffset = dataFile.GetPosition();

				// read commitHash first to store in index
				CString commitHash;
				ReadCStringFromFile(dataFile, commitHash);

				// skip the next 6 strings (Date, FileName, Title, Author, msg, shortid)
				for (int k = 0; k < 6; ++k)
				{
					DWORD len = 0;
					dataFile.Read(&len, sizeof(len));
					if (len > 0)
						dataFile.Seek((LONG)(len * sizeof(TCHAR)), CFile::current);
				}

				ULONGLONG endOffset = dataFile.GetPosition();
				DWORD blockSize = (DWORD)(endOffset - startOffset);

				// create index entry
				COMMIT_IndexEntry entry;
				entry.fileKey = fileKey;
				entry.commitHash = commitHash;
				entry.offset = startOffset;
				entry.blockSize = blockSize;
				entries.push_back(entry);

				// write index record to idx file
				DWORD hashLen = (DWORD)commitHash.GetLength();
				idxFile.Write(&hashLen, sizeof(hashLen));
				if (hashLen > 0) idxFile.Write((LPCTSTR)commitHash, (UINT)(hashLen * sizeof(TCHAR)));
				idxFile.Write(&entry.offset, sizeof(entry.offset));
				idxFile.Write(&entry.blockSize, sizeof(entry.blockSize));
			}

			g_CommitIndexMap[fileKey] = entries;
		}

		dataFile.Close();
		idxFile.Close();
		TRACE(_T("BuildAndSaveIndexFile: 인덱스 생성 완료 (%s)\n"), lpszIndexPath);
		return TRUE;
	}
	catch (CFileException* e)
	{
		TCHAR buf[256]; e->GetErrorMessage(buf, 256);
		TRACE(_T("BuildAndSaveIndexFile 예외: %s\n"), buf);
		e->Delete();
		return FALSE;
	}
}
BOOL LoadIndexFileToMemory(LPCTSTR lpszIndexPath)
{
	if (!lpszIndexPath) return FALSE;
	try
	{
		g_CommitIndexMap.clear();

		CFile idxFile(lpszIndexPath, CFile::modeRead | CFile::typeBinary);

		DWORD fileCount = 0;
		idxFile.Read(&fileCount, sizeof(fileCount));

		for (DWORD i = 0; i < fileCount; ++i)
		{
			DWORD keyLen = 0;
			idxFile.Read(&keyLen, sizeof(keyLen));
			CString fileKey;
			if (keyLen > 0)
			{
				LPTSTR keyBuf = fileKey.GetBuffer(keyLen);
				idxFile.Read(keyBuf, (UINT)(keyLen * sizeof(TCHAR)));
				fileKey.ReleaseBuffer(keyLen);
			}
			else fileKey.Empty();

			DWORD commitCount = 0;
			idxFile.Read(&commitCount, sizeof(commitCount));

			std::vector<COMMIT_IndexEntry> entries;
			entries.reserve(commitCount);

			for (DWORD j = 0; j < commitCount; ++j)
			{
				DWORD hashLen = 0;
				idxFile.Read(&hashLen, sizeof(hashLen));
				CString commitHash;
				if (hashLen > 0)
				{
					LPTSTR hbuf = commitHash.GetBuffer(hashLen);
					idxFile.Read(hbuf, (UINT)(hashLen * sizeof(TCHAR)));
					commitHash.ReleaseBuffer(hashLen);
				}
				else commitHash.Empty();

				ULONGLONG offset = 0;
				DWORD blockSize = 0;
				idxFile.Read(&offset, sizeof(offset));
				idxFile.Read(&blockSize, sizeof(blockSize));

				COMMIT_IndexEntry entry;
				entry.fileKey = fileKey;
				entry.commitHash = commitHash;
				entry.offset = offset;
				entry.blockSize = blockSize;
				entries.push_back(entry);
			}

			g_CommitIndexMap[fileKey] = entries;
		}

		idxFile.Close();
		TRACE(_T("LoadIndexFileToMemory: 인덱스 로드 완료 (%s)\n"), lpszIndexPath);
		return TRUE;
	}
	catch (CFileException* e)
	{
		TCHAR buf[256]; e->GetErrorMessage(buf, 256);
		TRACE(_T("LoadIndexFileToMemory 예외: %s\n"), buf);
		e->Delete();
		return FALSE;
	}
}
BOOL LoadCommitBlockFromData(LPCTSTR lpszDataPath, const CString& fileKey, const CString& commitHash, COMMIT_info12& outInfo)
{
	// find index vector
	std::map<CString, std::vector<COMMIT_IndexEntry> >::iterator it = g_CommitIndexMap.find(fileKey);
	if (it == g_CommitIndexMap.end())
		return FALSE;

	const std::vector<COMMIT_IndexEntry>& vec = it->second;
	// linear scan - can be optimized (e.g., unordered_map from hash->entry)
	for (size_t i = 0; i < vec.size(); ++i)
	{
		if (vec[i].commitHash.Compare(commitHash) == 0)
		{
			try
			{
				CFile dataFile(lpszDataPath, CFile::modeRead | CFile::typeBinary);
				// move to block offset
				dataFile.Seek((LONG)vec[i].offset, CFile::begin);

				// read the block fields in sequence
				CString chash, date, fname, title, author, msg, sid;
				ReadCStringFromFile(dataFile, chash);
				ReadCStringFromFile(dataFile, date);
				ReadCStringFromFile(dataFile, fname);
				ReadCStringFromFile(dataFile, title);
				ReadCStringFromFile(dataFile, author);
				ReadCStringFromFile(dataFile, msg);
				ReadCStringFromFile(dataFile, sid);

				outInfo.Date = date;
				outInfo.FileName = fname;
				outInfo.Title = title;
				outInfo.Author = author;
				outInfo.msg = msg;
				outInfo.shortid = sid;

				dataFile.Close();
				return TRUE;
			}
			catch (CFileException* e)
			{
				TCHAR buf[256]; e->GetErrorMessage(buf, 256);
				TRACE(_T("LoadCommitBlockFromData 예외: %s\n"), buf);
				e->Delete();
				return FALSE;
			}
		}
	}
	return FALSE;
}

static std::map<CString, std::map<CString, size_t> > g_IndexLookup;
void BuildFastLookupFromIndex()
{
	g_IndexLookup.clear();
	for (std::map<CString, std::vector<COMMIT_IndexEntry> >::iterator it = g_CommitIndexMap.begin(); it != g_CommitIndexMap.end(); ++it)
	{
		const CString& fk = it->first;
		const std::vector<COMMIT_IndexEntry>& vec = it->second;
		std::map<CString, size_t> m;
		for (size_t i = 0; i < vec.size(); ++i) m[ vec[i].commitHash ] = i;
		g_IndexLookup[fk] = m;
	}
}
*/