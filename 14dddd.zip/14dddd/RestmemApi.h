﻿#pragma once

#include <cpprest/http_client.h>
#include <cpprest/filestream.h>
#include <cpprest/json.h>

using namespace std;
using namespace web;
using namespace web::http;
using namespace web::http::client;
using namespace utility;					// string_t 정의
using namespace web::json;					// json::value
using namespace utility;                    // Common utilities like string conversions
using namespace concurrency::streams;       // Asynchronous streams
using namespace pplx;



/*
struct GitDiffLine	{
	CString line;	bool isAddition;	bool isDeletion;
};

struct GitDiffLine2	{
	enum LineType { FileHeader, Index, OldFile, NewFile, HunkHeader, Added, Removed, Context };
	LineType type;	CString content;
};
//Tr Last Commit 정보 
struct TR_HISTORYcommit {
	utility::string_t path;
	utility::string_t name;
	utility::string_t id;
	utility::string_t short_id;
	utility::string_t created_at;
	std::vector<utility::string_t> vParent_ids;
	utility::string_t title;
	utility::string_t message;
	utility::string_t author_name;
	utility::string_t author_email;
	utility::string_t authored_date;
	utility::string_t committer_name;
	utility::string_t committer_email;
	utility::string_t committed_date;
};
struct TR_LASTcommit {
	utility::string_t path;
	utility::string_t name;
	utility::string_t id;
	utility::string_t last_commit_date;
	utility::string_t last_commit_message;
	utility::string_t parent_ids; 
	CString commit_link;       // 기존
	CString commit_message;    // ✅ 새로 추가
	std::vector<TR_HISTORYcommit>  fileHist;
};
struct COMMIT_info12
{
	CString FileName;
	CString Title;
	CString Author;
	CString Date;
	CString msg;
	CString shortid;
};
struct COMMIT_Index
{
	CString fileKey;
	CString commitHash;
	ULONGLONG offset;
	UINT blockSize;
};

struct THREAD_COMPARM12
{
	int perPage;
	int pageNumber; // 초기 페이지 (1부터)
	web::json::value* pOutJsonAll;//	std::vector<json::value>* pOutJsonAll;
	CString sinceDate; // YYYY-MM-DDTHH:MM:SSZ
	CRITICAL_SECTION* pLock;
};

struct Thread_Parm12
{
	int idx;
	web::json::value commit;
	CString projectId;
	CString token;
};
class CHistory;
struct ThreadParamWithDate
{
	int idx;                     // 예: commit index
	json::value commit;           // commit JSON
	CString projectId;
	CString token;
	CHistory* pHistory;       // CHistory 객체 포인터
	CString lastCommitDate;   // 마지막으로 받은 커밋 날짜
};
// 타입 정의
typedef std::map<CString, COMMIT_info12> CommitMap;       // 파일별 커밋
typedef std::map<CString, CommitMap> FileCommitMap;   // 전체 파일 → CommitMap
// 전역 변수 extern 선언
extern FileCommitMap g_FileComMap12;
// http://192.168.0.2:20080/api/v4/projects/root%2Fhtsmts/repository/commits?path=20160316.G7014&ref_name=main&per_page=1
const utility::string_t g_tHOST_URL           = U("http://192.168.0.2:20080");	//U("http://192.168.0.7");
const utility::string_t g_tPRIVATE_TOKEN      = U("");							//U("glft-pNhh72t2GQ3KDwX18C4q");
const utility::string_t g_tAPI_URL            = U("/api/v4/projects");			//U("/api/v4/projects/");
const utility::string_t g_tPROJECTID          = U("root");
const utility::string_t g_tPROJECTPATH        = U("htsmts");
const utility::string_t g_BRANCH	          = U("main");
const utility::string_t g_tContent_Type       = U("application/json");
const utility::string_t g_tDOWNPATH           = U("D:/");

// 인코딩 유형
enum EncodingType {
	ENCODING_UTF8_BOM,
	ENCODING_UTF8_NO_BOM,
	ENCODING_ASCII,
	ENCODING_ANSI,
	ENCODING_UTF16_LE,
	ENCODING_UTF16_BE,
	ENCODING_UNKNOWN
};
enum FileChangeType 
{
	Unknown,
	Created,
	Updated,
	Deleted
};
extern json::value g_Outjson; 
class CRestGitApi
{
public:
	CRestGitApi(void);
	~CRestGitApi(void);
BOOL CRestGitApi::SaveCommitTreeWithIndex(LPCTSTR lpszPath)
BOOL CRestGitApi::LoadCommitIndexOnly(LPCTSTR lpszPath)
	BOOL CRestGitApi::LoadCommitByFileKey(LPCTSTR lpszPath, const CString& fileKey)
};
*/






#include "stdafx.h"
#include <afx.h>
#include <map>
#include <vector>

struct COMMIT_info12
{
	CString FileName;
	CString Title;
	CString Author;
	CString Date;
	CString msg;
	CString shortid;
};
typedef std::map<CString, COMMIT_info12> CommitMap; // commitHash -> info
struct COMMIT_IndexEntry
{
	CString fileKey;     // 파일 키 (경로 등)
	CString commitHash;  // commit hash
	ULONGLONG offset;    // data file 내 시작 오프셋 (바이트)
	DWORD blockSize;     // 블록 크기 (바이트)
};
	static std::map<CString, std::vector<COMMIT_IndexEntry> > g_CommitIndexMap;
	static std::map<CString, CommitMap> g_FileComMap12;
	static void WriteCStringToFile(CFile& file, const CString& s);
	static void ReadCStringFromFile(CFile& file, CString& s);
	BOOL SaveCommitDataFile(LPCTSTR lpszDataPath, const std::map<CString, CommitMap>& allData);
	BOOL BuildAndSaveIndexFile(LPCTSTR lpszDataPath, LPCTSTR lpszIndexPath);
	BOOL LoadIndexFileToMemory(LPCTSTR lpszIndexPath);
	BOOL LoadCommitBlockFromData(LPCTSTR lpszDataPath, const CString& fileKey, const CString& commitHash, COMMIT_info12& outInfo);
	static std::map<CString, std::map<CString, size_t> > g_IndexLookup;
	void BuildFastLookupFromIndex();
