// exceljs 불러오기
const ExcelJS = require("exceljs");

// 워크북 생성
const workbook = new ExcelJS.Workbook();
const sheet = workbook.addWorksheet("Styled");

// 샘플 데이터
const rows = [
  [ "열_키", "키명", "길이", "타입" ],
  [ 1, "DATA1", 11, 4 ],
  [ 2, "DATA2", 12, 8 ],
  [ 3, "DATA3", 13, 4 ],
  [ 4, "DATA4", 14, 8 ],
  [ 5, "DATA5", 15, 4 ]
];

// 행 추가 + 스타일 적용
rows.forEach((row, r) => {
  const newRow = sheet.addRow(row);

  newRow.eachCell((cell, c) => {
    // ✅ 헤더는 진한 회색
    if (r === 0) {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "CCCCCC" }
      };
    } else {
      // ✅ 홀수 행 흰색, 짝수 행 연회색
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: (r % 2 === 0) ? "FFFFFF" : "EEEEEE" }
      };
    }

    // ✅ 5열마다 굵은 검은색 세로선
    if ((c % 5) === 0) {
      cell.border = {
        ...cell.border,
        right: { style: "medium", color: { argb: "000000" } }
      };
    }

    // ✅ 5행마다 굵은 검은색 가로선
    if ((r % 5) === 0) {
      cell.border = {
        ...cell.border,
        bottom: { style: "medium", color: { argb: "000000" } }
      };
    }
  });
});

// 파일 저장
workbook.xlsx.writeFile("styled.xlsx").then(() => {
  console.log("✅ styled.xlsx 파일 생성 완료!");
});
