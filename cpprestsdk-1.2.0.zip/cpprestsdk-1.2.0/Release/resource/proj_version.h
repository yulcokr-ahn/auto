#include <vsversion_generated.h>

#define _CPPREST_RMJ VSVersionNumberMajor
#define _CPPREST_RMM VSVersionNumberMinor
#define _CPPREST_RUP BuildNumberMajor
#define _CPPREST_RBLD BuildNumberMinor
