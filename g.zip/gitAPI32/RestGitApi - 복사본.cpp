﻿#include "StdAfx.h"
#include "RestGitApi.h"
#include <sstream>
#include <sstream>

json::value g_Outjson; // 람다용
template <typename T> std::string to_string_2010(T value)	{ std::ostringstream oss;	oss << value;	return oss.str();	}
struct JsonPair {	std::string key;	std::string value;	};
//08.02
std::string trim(const std::string& s) {
	size_t a = s.find_first_not_of(" \t\r\n");
	size_t b = s.find_last_not_of(" \t\r\n");
	if (a == std::string::npos) return "";
	return s.substr(a, b - a + 1); // 공백 제거 유틸
}
//08.02
bool parsePair(const std::string& token, JsonPair& out) { 
	size_t colon = token.find(':'); 
	if (colon == std::string::npos) return false;
	std::string k = trim(token.substr(0, colon));
	std::string v = trim(token.substr(colon + 1));	// 따옴표 제거
	if (k.size() >= 2 && k.front() == '"' && k.back() == '"')		k = k.substr(1, k.size() - 2);
	if (v.size() >= 2 && v.front() == '"' && v.back() == '"')		v = v.substr(1, v.size() - 2);
	out.key = k;
	out.value = v;
	return true; // "키":"값" 쌍 파싱 (따옴표는 제거됨)
}
//08.02
void TRACE_jsonParse(const std::string jsonStr, std::vector<std::vector<JsonPair>>& outRecords) {
	size_t start = jsonStr.find('[');
	size_t end = jsonStr.rfind(']');
	if (start == std::string::npos || end == std::string::npos || end <= start)
	{
		start = jsonStr.find('{');
		end = jsonStr.rfind('}');
		if (start == std::string::npos || end == std::string::npos || end <= start)
			return;
	}
	std::string body = jsonStr.substr(start + 1, end - start - 1);
	if(body.size()==0)
		body = jsonStr;

	std::stringstream ss(body);
	std::string itemStr;
	
	while (std::getline(ss, itemStr, '}')) {	// 간단하게 '},{' 로 분리
		size_t pos = itemStr.find('{');
		if (pos != std::string::npos)
			itemStr = itemStr.substr(pos + 1);
		if (itemStr.empty())
			continue;
		
		if (itemStr.back() == ',') // 다시 trailing comma 제거
			itemStr.pop_back();
		
		std::vector<JsonPair> row;
		std::stringstream itemSS(itemStr); // 각 오브젝트 안에서 키-값 파싱
		std::string token;
		while (std::getline(itemSS, token, ',')) {
			JsonPair p;
			if (parsePair(token, p)) {
				
				if (p.key == "content")  //길이가 너무 커 256 고정 길이로  content 키면 스킵 2025.05.02
				{
					JsonPair tmp;
					tmp.key = p.key;
					if(p.value.size() > 250)
						tmp.value = string("고정길이 250--> : ")+ p.value.substr(0,250);
					else
						tmp.value = p.value;
					row.push_back(tmp);
					continue;
				}
				row.push_back(p);
			}
		}
		if (!row.empty())
			outRecords.push_back(row);
		// '}' 뒤의 ',' 없애주기
		char delim = ss.peek();
		if (delim == ',') ss.get();
	}
}
//08.02
void TRACE_jsonRecords(const char* context, const std::vector<std::vector<JsonPair>>& records) {
	for (size_t r = 0; r < records.size(); ++r) {
		TRACE("%s TRACE_JSON(예쁜 인쇄 Json) Record %u:\n",context, (unsigned)r);		
		const std::vector<JsonPair>& row = records[r];
		for (std::vector<JsonPair>::const_iterator it = row.begin(); it != row.end(); ++it)
		{
			const JsonPair& p = *it;
			TRACE("  { \"%s\" : \"%s\" }\n", p.key.c_str(), p.value.c_str());
		}
	}
}
//08.02
void CRestGitApi::TRACE_JSON(const char* context, const web::json::value& val, int indent) {
	utility::string_t ustr = val.to_string();  
	TRACE("%s=====================\r\n", context );
	TRACE("%s= size()    [%d]\r\n"		,context , ustr.size() );
	TRACE("%s=====================\r\n", context );
	CString cstr(ustr.c_str());				// 유니코드 문자열을 CString으로
	std::vector<std::vector<JsonPair>> records;
	TRACE_jsonParse(cstr.GetBuffer(), records);
	TRACE_jsonRecords(context ,records);
}


CRestGitApi::CRestGitApi(void) { }
CRestGitApi::~CRestGitApi(void) { }


CString CRestGitApi::UrlEncode(CString str) {
	CString encoded;
	for (int i = 0; i < str.GetLength(); ++i) {
		TCHAR ch = str[i];
		if (_istalnum(ch) || ch == _T('-') || ch == _T('_') || ch == _T('.') || ch == _T('~')) {
			encoded += ch;
		} else {
			CString hex;
			hex.Format(_T("%%%02X"), (BYTE)ch);
			encoded += hex;
		}
	}
	return encoded;
}

//08.02
//CCommitDlg 작성때 파일 변경 확인용 서버에 저장된것 로칼 비교용 08/02
int CRestGitApi::CompareFiles(const std::wstring& aFile, const std::wstring& bFile)
{
	std::ifstream f1(aFile.c_str(), std::ios::binary);
	std::ifstream f2(bFile.c_str(), std::ios::binary);
	if (!f1.is_open() || !f2.is_open())
		return -1;
	std::vector<std::string> aLines, bLines;
	std::string line;
	auto removeBom = [](std::string& str) {
		if (str.size() >= 3 &&
			(unsigned char)str[0] == 0xEF &&
			(unsigned char)str[1] == 0xBB &&
			(unsigned char)str[2] == 0xBF)
		{
			str = str.substr(3);
		}
	};
	while (std::getline(f1, line)) {
		removeBom(line);
		aLines.push_back(line);
	}
	while (std::getline(f2, line)) {
		removeBom(line);
		bLines.push_back(line);
	}
	int n = (int)aLines.size();
	int m = (int)bLines.size();
	std::vector<std::vector<int>> dp(n + 1, std::vector<int>(m + 1, 0));
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (aLines[i - 1] == bLines[j - 1])
				dp[i][j] = dp[i - 1][j - 1] + 1;
			else
				dp[i][j] = std::max(dp[i - 1][j], dp[i][j - 1]);

	int i = n, j = m;
	std::vector<std::string> diffLines;

	int added = 0;   // a파일 기준 추가 (a에 새로 생긴 라인)
	int deleted = 0; // a파일 기준 삭제 (a에서 사라진 라인)

	while (i > 0 || j > 0)
	{
		if (i > 0 && j > 0 && aLines[i - 1] == bLines[j - 1]) {
			diffLines.push_back(" " + aLines[i - 1]);
			--i; --j;
		}
		else if (j > 0 && (i == 0 || dp[i][j - 1] >= dp[i - 1][j])) {
			diffLines.push_back("+" + bLines[j - 1]);
			// b파일에는 있지만 a파일에 없으므로 a파일에서 삭제된 줄
			deleted++;
			--j;
		}
		else {
			diffLines.push_back("-" + aLines[i - 1]);
			// a파일에만 있는 줄 → a파일에서 추가된 줄
			added++;
			--i;
		}
	}
	std::reverse(diffLines.begin(), diffLines.end());
	CString strDiff;
	strDiff += _T("--- b파일 (기준)\n");
	strDiff += _T("+++ a파일 (변경됨)\n");

	for (size_t k = 0; k < diffLines.size(); ++k) {
		strDiff += CString(diffLines[k].c_str()) + _T("\r\n");
	}
	int totalChanged = added + deleted;
//	TRACE(_T("%s"), strDiff);
	TRACE(_T("a파일 : 총 변경 라인수: %4d, 추가 라인수: %4d, 삭제 라인수: %4d\n"), totalChanged, added, deleted);
	TRACE(_T("b파일 : 총 변경 라인수: 0, 추가 라인수: 0, 삭제 라인수: 0 (기준 파일 변경 없음)\n"));

	return totalChanged;
}

// file 디버그용 출력 함수
void CRestGitApi::DownloadGitlabFile(const CString& projectPath, const CString filePath, const CString& branch, const CString& privateToken)
{
	CString rawPath = UrlEncode(filePath);
	CString sDOWNPATH = CString(g_tDOWNPATH.c_str());
	http_client client(g_tHOST_URL);
	http_request request(methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t((LPCTSTR)privateToken));

	client.request(request).then([](http_response response) -> pplx::task<std::vector<unsigned char>>
	{
		if (response.status_code() == status_codes::OK)		{
			std::wcout << L"다운로드 성공" << std::endl;
			return response.extract_vector(); // 바이너리 데이터 추출
		}
		else
		{
			std::wcout << L"다운로드 실패: " << response.status_code() << std::endl;
			return response.extract_vector(); // 바이너리 데이터 추출
		}
	})
	.then([=](pplx::task<std::vector<unsigned char>> previousTask)
	{
		try
		{
			std::vector<unsigned char> fileData = previousTask.get();
			if (!fileData.empty())
			{
				std::ofstream outFile(sDOWNPATH+filePath, std::ios::binary);
				outFile.write((const char*)fileData.data(), fileData.size());
				outFile.close();
				std::wcout << L"파일 저장 완료." << std::endl;
			}
			else
			{
				std::wcout << L"다운로드된 데이터가 비어 있습니다." << std::endl;
			}
		}
		catch (const std::exception& e)
		{
			std::cerr << "예외 발생: " << e.what() << std::endl;
		}
	})
		.wait(); 
}

CString Utf8ToCString(const std::string& utf8Str) {
	int len = MultiByteToWideChar(CP_UTF8, 0, utf8Str.c_str(), utf8Str.length(), NULL, 0);
	CString result;
	if (len > 0) {
		std::wstring wstr(len, 0);
		MultiByteToWideChar(CP_UTF8, 0, utf8Str.c_str(), utf8Str.length(), &wstr[0], len);
		result = wstr.c_str();
	}
	return result;
}
// CString 방식
/*
	**파일에서 읽은 바이트 수(data.size())**가 많고
	**변환된 CString의 문자 수(outContent.GetLength())**가 더 작아 보이는 건
	멀티바이트(UTF-8) → 와이드 문자열(UTF-16) 변환 시 정상입니다.
	✅ 참고
	오히려 길이가 정확히 같다면 오히려 ASCII (단일 바이트) 위주일 가능성이 높습니다.
	한글, 이모지, 특수문자 등이 있을수록 data.size()는 더 커지게 됩니다
*/
//08.02
void CRestGitApi::DownloadGit_CStringBuff(const CString& projectPath, const CString filename,  const CString tag_path ,const CString& commitHash, const CString& branch, const CString& privateToken , CString& outContent)
{
	utility::string_t fullProjectID = g_tPROJECTID;		fullProjectID.append(U("/"));	fullProjectID.append(g_tPROJECTPATH);   //	CString projectEncode;	projectEncode = uri::encode_data_string(fullProjectID).c_str();		
	utility::string_t projEncoded   = utility::conversions::to_string_t(  uri::encode_data_string(fullProjectID).c_str() );
	
	utility::string_t fileEncoded       = utility::conversions::to_string_t((LPCTSTR)UrlEncode(filename));
	utility::string_t branch_commitHash = utility::conversions::to_string_t((LPCTSTR)commitHash);
	http_client client(g_tHOST_URL);  
	uri_builder builder;
	utility::string_t apiPath =U("/api/v4/projects/")+ projEncoded + U("/repository/files/") + fileEncoded +  U("/raw?ref=") + branch_commitHash;
	builder.append_path(apiPath);	

	http_request request(methods::GET);
	request.set_request_uri(builder.to_uri());
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
	http_response response = client.request(request).get();

	TRACE("\r\nCRestGitApi::DownloadGit_CStringBuff()=====================\r\n" );
	TRACE("CRestGitApi::DownloadGit_CStringBuff() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str()) );
	TRACE("%s\r\n", CString(apiPath.c_str()) );

	if (response.status_code() == status_codes::OK)
	{
		auto data = response.extract_vector().get();
		outContent = Utf8ToCString(std::string((char*)data.data(), data.size()));  // CString 방식

		TRACE("CRestGitApi::DownloadGit_CStringBuff()=====================\r\n" );
		TRACE("CRestGitApi::DownloadGit_CStringBuff()= data.size()    [%d]\r\n",data.size() );
		TRACE("CRestGitApi::DownloadGit_CStringBuff()= outContent len [%d]\r\n",outContent.GetLength() );
		TRACE("CRestGitApi::DownloadGit_CStringBuff()=====================\r\n" );

		if(tag_path.GetLength())
		{
			std::ofstream outFile(tag_path+filename , std::ios::binary);
			outFile.write((const char*)data.data(), data.size());
			outFile.close();
		}
	}
	else
	{
		// 1. 응답 상태 문자열 추출
		std::wstring responseBodyW = response.to_string();
		std::string responseBody(responseBodyW.begin(), responseBodyW.end());
		TRACE("CRestGitApi::DownloadGit_CStringBuff()=====================\r\n" );
		TRACE(_T("CRestGitApi::DownloadGit_CStringBuff() [응답 상태] size=%d\n%s\n"), static_cast<int>(responseBody.size()), CString(responseBody.c_str()));

		std::wcout << L"X 실패 코드: " << response.status_code() << std::endl;
	}
}
//string 
/*
		outContent = (char*)data.data();  // X 위험한 방식
		CRestGitApi::DownloadGit_stringBuff()=====================
		CRestGitApi::DownloadGit_stringBuff()= data.size()      [4886]
		CRestGitApi::DownloadGit_stringBuff()= outContent.size()[4904]
		CRestGitApi::DownloadGit_stringBuff()=====================
		이 방식은 널 종료 문자 \0 이전까지만 복사합니다.
		Git에서 내려받은 바이너리 또는 UTF-8 문자열에 \0이 중간에 포함되어 있으면,
		그 뒤의 데이터는 잘려버리거나
		혹은 std::string이 올바르지 않은 길이로 잘못 구성되어서,
		나중에 file.write()로 저장 시 쓰레기 문자가 붙습니다.
/////////////////////////////////////////////
*/
//08.02
void CRestGitApi::DownloadGit_stringBuff(const CString& projectPath, const CString filename,  const CString tag_path ,const CString& commitHash, const CString& branch, const CString& privateToken , string& outContent)
{
	utility::string_t fullProjectID = g_tPROJECTID;		fullProjectID.append(U("/"));	fullProjectID.append(g_tPROJECTPATH);   //	CString projectEncode;	projectEncode = uri::encode_data_string(fullProjectID).c_str();		
	utility::string_t projEncoded   = utility::conversions::to_string_t(  uri::encode_data_string(fullProjectID).c_str() );

	utility::string_t fileEncoded       = utility::conversions::to_string_t((LPCTSTR)UrlEncode(filename));
	utility::string_t branch_commitHash = utility::conversions::to_string_t((LPCTSTR)commitHash);
	http_client client(g_tHOST_URL);  
	uri_builder builder;
	utility::string_t apiPath =U("/api/v4/projects/")+ projEncoded + U("/repository/files/") + fileEncoded +  U("/raw?ref=") + branch_commitHash;
	builder.append_path(apiPath);	

	http_request request(methods::GET);
	request.set_request_uri(builder.to_uri());
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
	http_response response = client.request(request).get();

	TRACE("\r\nCRestGitApi::DownloadGit_stringBuff()=====================\r\n" );
	TRACE("CRestGitApi::DownloadGit_stringBuff() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str()) );
	TRACE("%s\r\n", CString(apiPath.c_str()) );

	if (response.status_code() == status_codes::OK)
	{
		// 1. 응답 상태 문자열 추출
		std::wstring responseBodyW = response.to_string();
		std::string responseBody(responseBodyW.begin(), responseBodyW.end());
		TRACE("CRestGitApi::DownloadGit_stringBuff()=====================\r\n" );
		TRACE(_T("CRestGitApi::DownloadGit_stringBuff() [응답 상태] size=%d\n%s\n"), static_cast<int>(responseBody.size()), CString(responseBody.c_str()));
		TRACE(_T("CRestGitApi::DownloadGit_stringBuff() [다운 buff save] %s\n"), filename);


		auto data = response.extract_vector().get();
		outContent = std::string(reinterpret_cast<const char*>(data.data()), data.size()); //정확한 길이로 문자열 생성

		TRACE("CRestGitApi::DownloadGit_stringBuff()=====================\r\n" );
		TRACE("CRestGitApi::DownloadGit_stringBuff()filename[%s]= data.size()      [%d]\r\n",filename,data.size() );
		TRACE("CRestGitApi::DownloadGit_stringBuff()filename[%s]= outContent.size()[%d]\r\n",filename,outContent.size() );
		TRACE("CRestGitApi::DownloadGit_stringBuff()=====================\r\n" );

		if(tag_path.GetLength())
		{
			std::ofstream outFile(tag_path+filename , std::ios::binary);
			outFile.write((const char*)data.data(), data.size());
			outFile.close();
		}
	}
	else
	{
		// 1. 응답 상태 문자열 추출
		std::wstring responseBodyW = response.to_string();
		std::string responseBody(responseBodyW.begin(), responseBodyW.end());
		TRACE("CRestGitApi::DownloadGit_stringBuff()=====================\r\n" );
		TRACE(_T("CRestGitApi::DownloadGit_stringBuff() [응답 상태] size=%d\n%s\n"), static_cast<int>(responseBody.size()), CString(responseBody.c_str()));

		std::wcout << L"X 실패 코드: " << response.status_code() << std::endl;
	}
}

/*
JSON API 응답을 받고 싶다면 raw 대신 GET /repository/files/:file_path API를 써야 합니다:
GET /projects/:id/repository/files/:file_path?ref=main
{
	"file_name": "CommitDlg.cpp",
		"file_path": "CommitDlg.cpp",
		"size": 4886,
		"encoding": "base64",
		"content": "Q2xhc3MgQ29tbWl0RGxnIHsgfQ==",   //<-----.content를 base64 디코딩 후 저장하셔야 합니다.
}
DownloadFileFromGitLab_JSON(
	L"root",                        // 🔧 프로젝트 경로 또는 ID
	L"CommitDlg.cpp",              // 파일 경로
	L"master",                     // 브랜치명 또는 커밋 SHA
	L"d:\\gittest\\CommitDlg.cpp"               // 저장할 로컬 파일 경로
	);
*/
//Json down base 암호 //08.02
bool CRestGitApi::DownloadFileFromGitLab_JSON(const std::wstring& projectID,const CString filename, const CString& commitHash, const CString&  outFilename)
{
	utility::string_t fullProjectID		= g_tPROJECTID;		fullProjectID.append(U("/"));	fullProjectID.append(g_tPROJECTPATH);   //	CString projectEncode;	projectEncode = uri::encode_data_string(fullProjectID).c_str();		
	utility::string_t projEncoded		= utility::conversions::to_string_t(  uri::encode_data_string(fullProjectID).c_str() );
	utility::string_t fileEncoded       = utility::conversions::to_string_t((LPCTSTR)UrlEncode(filename));
	utility::string_t branch_commitHash = utility::conversions::to_string_t((LPCTSTR)commitHash);
	try {
		// 1. URL 구성
		uri_builder builder(U("/api/v4/projects/"));
		builder.append(projEncoded);
		builder.append(U("/repository/files/"));
		builder.append_path(fileEncoded);
		builder.append_query(U("ref"), branch_commitHash);

		http_client client(g_tHOST_URL);  
		http_request request(methods::GET);
		request.set_request_uri(builder.to_uri());
		request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);  // 🔐 토큰

		TRACE("\r\nCRestGitApi::DownloadFileFromGitLab_JSON()=====================\r\n" );
		TRACE("CRestGitApi::DownloadFileFromGitLab_JSON() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str()) );
		TRACE("%s\r\n", CString(builder.to_string().c_str()) );	
		
		http_response response = client.request(request).get();  // 2. 요청 & 응답		
		if (response.status_code() != status_codes::OK) 
		{
			TRACE("CRestGitApi::DownloadFileFromGitLab_JSON() X 요청 실패: 상태 코드 = %d\n", response.status_code() );
			// 1. 응답 상태 문자열 추출
			std::wstring responseBodyW = response.to_string();
			std::string responseBody(responseBodyW.begin(), responseBodyW.end());
			TRACE("CRestGitApi::DownloadFileFromGitLab_JSON()=====================\r\n" );
			TRACE(_T("CRestGitApi::DownloadFileFromGitLab_JSON() [응답 상태] size=%d\n%s\n"), static_cast<int>(responseBody.size()), CString(responseBody.c_str()));
			return false;
		}


		json::value jsonResp = response.extract_json().get();
		TRACE_JSON("CRestGitApi::DownloadFileFromGitLab_JSON()() commit ", jsonResp);

		auto contentBase64 = jsonResp[U("content")].as_string();	// 3. content (base64 인코딩된 문자열) 추출
		std::string contentA(contentBase64.begin(), contentBase64.end());
		std::vector<unsigned char> decoded_byte = base64_decode(contentA);

		std::ofstream outFile(outFilename, std::ios::binary);
		outFile.write(reinterpret_cast<const char*>(decoded_byte.data()), decoded_byte.size());
		outFile.close();


		TRACE("CRestGitApi::DownloadFileFromGitLab_JSON()=====================\r\n" );
		TRACE("CRestGitApi::DownloadFileFromGitLab_JSON()filename[%s]= contentA.size()  [%d]\r\n",filename,contentA.size() );
		TRACE("CRestGitApi::DownloadFileFromGitLab_JSON()filename[%s]= outContent.size()[%d]\r\n",filename,decoded_byte.size() );
		TRACE("CRestGitApi::DownloadFileFromGitLab_JSON()=====================\r\n" );
		TRACE("CRestGitApi::DownloadFileFromGitLab_JSON() OK 파일 저장 완료: %s\n", outFilename);
		return true;
	} catch (const std::exception& ex) {
		TRACE("CRestGitApi::DownloadFileFromGitLab_JSON() X 예외: %s\n", ex.what());
		return false;
	}
}

//Commit stats 호출 (예: 통계 정보 확인)
//GET http://192.168.0.7/api/v4/projects/{project_id}/repository/commits/bab723ae
//GET /projects/:id/repository/commits/:sha
// GitLab API 호출 및 변경 유형 분석
void CRestGitApi::GetCommitStats(const CString& commitHash,json::value & jsonResult )
{
	utility::string_t projectEncoded = U("root%2Fhtsmts");
	utility::string_t commitSha = utility::conversions::to_string_t((LPCTSTR)commitHash);
	utility::string_t baseUrl = U("http://192.168.0.7/api/v4/projects/");
	utility::string_t url = baseUrl + projectEncoded + U("/repository/commits/") + commitSha;

	http_client_config config;
	http_client client(url, config);
	
	http_request request(methods::GET);		// GET 요청 구성
	request.headers().add(U("Content-Type"), U("application/json"));
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN); // 비공개 토큰 사용

	TRACE("\r\nCRestGitApi::GetCommitStats()=====================\r\n" );
	TRACE("CRestGitApi::GetCommitStats() g_tHOST_URL=%s", CString(url.c_str()) );	
	TRACE("%s\r\n",""); //TRACE("%s\r\n", CString(request.to_string().c_str()) );	

	http_response response = client.request(request).get();		// 요청 실행
	if (response.status_code() == status_codes::OK)
	{
		jsonResult = response.extract_json().get();			// JSON 응답 추출 (단 한 번만 extract_json 호출 가능!)
		TRACE_JSON("CRestGitApi::GetCommitStats()->TRACE_JSON(JSON 전체 출력 )", jsonResult);
	}
	else {
		TRACE("CRestGitApi::GetCommitStats()요청 실패: 상태 코드 %d\n", response.status_code());
	}
}

CString CRestGitApi::GetJsonCheckCommitStats(const json::value & jsonResult)
{
	CString resultType;
	if (jsonResult.has_field(U("stats"))) {
		json::value stats = jsonResult[U("stats")];
		int additions = 0;
		int deletions = 0;
		int total = 0;
		if (stats.has_field(U("additions")))
			additions = stats[U("additions")].as_integer();
		if (stats.has_field(U("deletions")))
			deletions = stats[U("deletions")].as_integer();
		if (stats.has_field(U("total")))
			total = stats[U("total")].as_integer();
		TRACE("CRestGitApi::GetJsonCheckCommitStats() Commit 변경 내용 분석 additions: %d, deletions: %d, total: %d\r\n", additions, deletions, total);
		if (additions > 0 && deletions == 0)
			resultType = _T("추가 (Created)");
		else if (additions == 0 && deletions > 0)
			resultType = _T("삭제 (Delete Only)");
		else if (additions > 0 && deletions > 0)
			resultType = _T("수정 (Modified)");
		else
			resultType = _T("무변경 (No Change)");
	}
	return resultType;

}

//CCommitDlg 작성때 파일 변경 확인용 서버에 저장된것 로칼 비교용
bool CRestGitApi::DownloadGitwrite_0802(const CString& filePath,const CString tag_path , const CString& branch, const CString& privateToken)
{
	utility::string_t fullProjectID = g_tPROJECTID;		fullProjectID.append(U("/"));	fullProjectID.append(g_tPROJECTPATH);   //	CString projectEncode;	projectEncode = uri::encode_data_string(fullProjectID).c_str();		
	utility::string_t projEncoded   = utility::conversions::to_string_t(  uri::encode_data_string(fullProjectID).c_str() );

	utility::string_t fileEncoded   = utility::conversions::to_string_t((LPCTSTR)filePath);
	utility::string_t branchEncoded = utility::conversions::to_string_t((LPCTSTR)branch);
	utility::string_t apiPath = U("/api/v4/projects/") + projEncoded + U("/repository/files/") + fileEncoded + U("/raw?ref=") + branchEncoded;
	http_client client(g_tHOST_URL);

	uri_builder builder;
	builder.append_path(apiPath);		

	TRACE("\r\nCRestGitApi::DownloadGitwrite_0802()=====================\r\n" );
	TRACE("CRestGitApi::DownloadGitwrite_0802() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str()) );
	TRACE("%s\r\n", CString(apiPath.c_str()) );

	http_request request(methods::GET);
	request.set_request_uri(builder.to_uri());
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
	http_response response = client.request(request).get();

	if (response.status_code() == status_codes::OK)
	{
		auto data = response.extract_vector().get();
		std::ofstream outFile(tag_path+filePath , std::ios::binary);
		outFile.write((const char*)data.data(), data.size());
		outFile.close();	

		TRACE("CRestGitApi::DownloadGitwrite_0802()=====================\r\n" );
		TRACE("CRestGitApi::DownloadGitwrite_0802()= data.size()    [%d]\r\n",data.size() );
		TRACE("CRestGitApi::DownloadGitwrite_0802()=====================\r\n" );

		return true;
	}
	else
	{
		std::wcout << L"X 실패 코드: " << response.status_code() << std::endl;
	}
	return false;
}



// commit file push 08/02
// POST /projects/:id/repository/commits
// http://192.168.0.7/api/v4/projects/root%2Fmyproject/repository/commits

/*
action 값	의미
	create	파일을 새로 생성합니다
	update	기존 파일을 수정합니다
	delete	기존 파일을 삭제합니다
	move	파일을 다른 경로로 이동합니다
	chmod	파일 권한을 변경합니다 (+x, -x)
*/
bool CRestGitApi::commitFileToGitLab(const std::string& branch,	const std::string& filePath, const std::string& commitMessage)
{
	CString fullPath = CString(filePath.c_str());
	int pos = fullPath.ReverseFind(_T('\\'));
	if (pos == -1) pos = fullPath.ReverseFind(_T('/'));
	CString filePart;
	CString folder;
	if (pos != -1)
	{
		folder = fullPath.Left(pos + 1);       // 폴더 경로 (슬래시 포함)
		filePart = fullPath.Mid(pos + 1);      // 파일명 + 확장자
	}
	else
	{
		folder = _T("");                       // 폴더 없음
		filePart = fullPath;                  // 전체가 파일명
	}
	CString fname;
	CString ext;
	int dotPos = filePart.ReverseFind(_T('.'));
	if (dotPos != -1)
	{
		fname = filePart.Left(dotPos);      // 확장자 제외한 이름
		ext = filePart.Mid(dotPos);            // 확장자 ('.' 포함)
	}
	else
	{
		fname = filePart;
		ext = _T("");                          // 확장자 없음
	}
	CString filename = fname+ext;

	utility::string_t fullProjectID = g_tPROJECTID;		fullProjectID.append(U("/"));	fullProjectID.append(g_tPROJECTPATH);   //	CString projectEncode;	projectEncode = uri::encode_data_string(fullProjectID).c_str();		
	utility::string_t projEncoded   = utility::conversions::to_string_t(  uri::encode_data_string(fullProjectID).c_str() );

	string_t apiUrl = utility::conversions::to_string_t(g_tHOST_URL+g_tAPI_URL) +  projEncoded + utility::conversions::to_string_t("/repository/commits");
	// base64로 인코딩된 파일 내용
	std::string encodedContent = readBinaryFileBase64(filePath);
	// JSON 요청 구성
	json::value requestBody;
	requestBody[U("branch")] = json::value::string(utility::conversions::to_string_t(branch));
	requestBody[U("commit_message")] = json::value::string(utility::conversions::to_string_t(commitMessage));



	json::value action;
//	action[U("action")] = json::value::string(U("create"));
	action[U("action")] = json::value::string(U("update"));

	action[U("file_path")] = json::value::string(utility::conversions::to_string_t(filename.GetBuffer()));
	action[U("content")] = json::value::string(utility::conversions::to_string_t(encodedContent));
	action[U("encoding")] = json::value::string(U("base64")); // 중요한 부분

	json::value actions = json::value::array();
	actions[0] = action;
	requestBody[U("actions")] = actions;

	// HTTP 요청
	http_client client(utility::conversions::to_string_t(apiUrl));
	http_request request(methods::POST);
	request.headers().add(U("PRIVATE-TOKEN"), utility::conversions::to_string_t(g_tPRIVATE_TOKEN));
	request.headers().add(U("Content-Type"), U("application/json"));
	request.set_body(requestBody);

	TRACE("\r\nCRestGitApi::commitFileToGitLab()=====================\r\n" );
	TRACE("CRestGitApi::commitFileToGitLab() g_tHOST_URL=%s", CString(apiUrl.c_str()) );
	TRACE("		[%s]\r\n", CString(actions.to_string().c_str() ) );


	try 
	{
		client.request(request)
			.then([](http_response response) -> pplx::task<std::vector<unsigned char>> {
				if (response.status_code() == status_codes::OK || response.status_code() == status_codes::Created) {
					TRACE("CRestGitApi::commitFileToGitLab(OK) 커밋이 성공적으로 생성되었습니다. \r\n" );
				} else {
					TRACE("CRestGitApi::commitFileToGitLab() X 커밋 실패. 상태 코드:%d \r\n", response.status_code() );
				}
				return response.extract_vector();
		})
			.then([](std::vector<unsigned char> data) {
				string outContent = std::string(reinterpret_cast<const char*>(data.data()), data.size()); //정확한 길이로 문자열 생성
				TRACE("CRestGitApi::commitFileToGitLab() O 응답 상태:[%s] 크기:%d \r\n",CString(outContent.c_str() ), outContent.size()  );
		})
			.then([](pplx::task<void> t) {
				// 예외를 다시 throw 해서 처리
				try {
					t.get(); // 예외가 여기서 throw 됨
				} catch (const std::exception& e) {
					TRACE("CRestGitApi::commitFileToGitLab() X 예외 발생 :%s \r\n", e.what()  );
				}
		})
			.wait(); // 전체 작업 대기
	}
	catch (const std::exception& e) {
		TRACE("CRestGitApi::commitFileToGitLab() X 요청 실행 중 예외 발생 :%s \r\n", e.what()  );
		std::wcerr << L"CRestGitApi::commitFileToGitLab() X 요청 실행 중 예외 발생: " << e.what() << std::endl;
	}
	return false;
}


void CRestGitApi::GetDiffCompareGitLab(const utility::string_t& oldSha, const utility::string_t& newSha, std::vector<json::value>& oldDiffList , std::vector<json::value> & newDiffList)
{
	web::http::client::http_client client(g_tHOST_URL + g_tAPI_URL);
	utility::string_t path = uri::encode_data_string(g_tPROJECTID + U("/") + g_tPROJECTPATH) +
		U("/repository/compare?from=") + oldSha + U("&to=") + newSha;
	web::http::http_request request(web::http::methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
	request.set_request_uri(path);
	//logHead(client, request);


	TRACE("\r\nCRestGitApi::GetDiffCompareGitLab()=====================\r\n" );
	TRACE("CRestGitApi::GetDiffCompareGitLab() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str())+CString(g_tAPI_URL.c_str()) );
	TRACE("%s\r\n", CString(path.c_str()) );

	http_response diff_response = client.request(request).get();
	if (diff_response.status_code() == status_codes::OK)
	{
		json::value jsonArray = diff_response.extract_json().get();

		TRACE_JSON("CRestGitApi::GetDiffCompareGitLab diff", jsonArray);

		if (jsonArray.has_field(U("commit"))) {
			auto commit = jsonArray[U("commit")]; 	
			TRACE_JSON("CRestGitApi::GetDiffCompareGitLab() commit ", commit);
		}
		if (jsonArray.has_field(U("diffs"))) {
			auto diffs = jsonArray[U("diffs")]; 	
			TRACE("GetDiffCompareGitLab()  변경 파일 내용갯수:[%d]\r\n" , diffs.size() );
			TRACE_JSON("CRestGitApi::GetDiffCompareGitLab() diffs ", diffs);
		}

		size_t diffCount = jsonArray.size();
		const web::json::value& diffs = jsonArray[U("diffs")]; 	

		utility::string_t jsonText= 	jsonArray.to_string(); 
		std::wcout << L"OK 성공적 GetDiffCompareGitLab() " << jsonText.c_str() << std::endl;

		for (size_t i = 0; i < diffs.size(); ++i)
		{
			auto item = diffs[i];
			utility::string_t filepath = item[U("new_path")].as_string(); 
			json::value file = diffs[i];
			if (file.has_field(U("new_path")))	
			{
				utility::string_t file_path = file[U("new_path")].as_string();				
				oldDiffList.push_back(file);

				CString name(file[U("new_path")].as_string().c_str());
				TRACE("GetDiffCompareGitLab(%2d)  new_path  name=[%s] \r\n",i , name );			
			}				
			if (file.has_field(U("old_path")))	
			{
				utility::string_t file_path = file[U("old_path")].as_string();					
				newDiffList.push_back(file);

				CString name(file[U("old_path")].as_string().c_str());
				TRACE("GetDiffCompareGitLab(%2d)  old_path  name=[%s] \r\n",i , name );			
			}
		}
	}
}


void CRestGitApi::GetDiffFromGitLab(const utility::string_t& commitSha, std::vector<json::value>& outDiffList)
{
	web::http::client::http_client client(g_tHOST_URL + g_tAPI_URL);
	utility::string_t path = uri::encode_data_string(g_tPROJECTID + U("/") + g_tPROJECTPATH) + U("/repository/commits/") + commitSha + U("/diff");
	web::http::http_request request(web::http::methods::GET);
	request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
	request.set_request_uri(path);
	//logHead(client, request);

	TRACE("\r\nCRestGitApi::GetDiffFromGitLab()=====================\r\n" );
	TRACE("CRestGitApi::GetDiffFromGitLab() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str())+CString(g_tAPI_URL.c_str()) );
	TRACE("%s\r\n", CString(path.c_str()) );

	http_response diff_response = client.request(request).get();
	if (diff_response.status_code() == status_codes::OK)
	{
		json::value jsonArray = diff_response.extract_json().get();
		size_t diffCount =0;
		if (jsonArray.is_array())
		{
			diffCount = jsonArray.size();
			for (size_t i = 0; i < diffCount; ++i)
			{
				outDiffList.push_back(jsonArray[i]);
			}
		}

		//>>너무 많다 TRACE_JSON("CRestGitApi::GetDiffFromGitLab() diff", jsonArray);

		CString context = "RestGitApi::GetDiffFromGitLab() diff";
		TRACE("%s=====================\r\n", context );
		TRACE("%s= jsonArray.size()    [%d]   record cound : [%d] \r\n"		,context , jsonArray.size() , diffCount);
		TRACE("%s=====================\r\n", context );



	}
}

/*
int wmain() {
std::wstring baseUrl = L"https://127.0.0.1";
std::wstring projectId = L"12345678"; // 실제 프로젝트 ID
std::wstring branch = L"main";
std::wstring commitMsg = L"여러 파일 동시 커밋 예제";
std::wstring token = L"<your_access_token>"; // GitLab Access Token

CommitMultipleFilesToGitLab(baseUrl, projectId, branch, commitMsg, token);
return 0;
}*/

// Git 다중 파일 커밋
bool CommitMultipleFilesToGitLab(
	const std::wstring& apiBaseUrl,
	const std::wstring& projectId,
	const std::wstring& branch,
	const std::wstring& commitMessage,
	const std::wstring& privateToken)
{
	try {
		// HTTP 클라이언트 설정
		std::wstring apiUrl = apiBaseUrl + L"/api/v4/projects/" + projectId + L"/repository/commits";
		http_client client(apiUrl);

		// JSON payload 구성
		json::value root;
		root[L"branch"] = json::value::string(branch);
		root[L"commit_message"] = json::value::string(commitMessage);

		// actions 배열
		json::value actions = json::value::array();

		// 예제 파일 A (수정)
		json::value act1;
		act1[L"action"] = json::value::string(L"update");
		act1[L"file_path"] = json::value::string(L"src/testcode.cpp");
		act1[L"content"] = json::value::string(L"// 수정된 파일 내용 A");
		actions[0] = act1;

		// 예제 파일 B (추가)
		json::value act2;
		act2[L"action"] = json::value::string(L"create");
		act2[L"file_path"] = json::value::string(L"include/newfile.h");
		act2[L"content"] = json::value::string(L"// 새 헤더 파일 내용 B");
		actions[1] = act2;

		// 예제 파일 C (삭제)
		json::value act3;
		act3[L"action"] = json::value::string(L"delete");
		act3[L"file_path"] = json::value::string(L"obsolete/old.cpp");
		actions[2] = act3;
		root[L"actions"] = actions;

		// 요청 생성
		http_request request(methods::POST);
		request.headers().add(L"PRIVATE-TOKEN", privateToken);
		request.headers().add(L"Content-Type", L"application/json");
		request.set_body(root);

		// 요청 전송
		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::Created) {
			std::wcout << L"[성공] 커밋 완료" << std::endl;
			return true;
		} else {
			std::wcout << L"[실패] 상태 코드: " << response.status_code() << std::endl;
			std::wcout << response.to_string() << std::endl;
		}
	} catch (std::exception& ex) {
		std::wcerr << L"예외 발생: " << ex.what() << std::endl;
	}

	return false;
}



//file 목록 조회
std::vector<CString> CRestGitApi::GitLab_GetRepositoryTree2(json::value &Outjson)
{
	std::vector<CString> fileList;
	try
	{
		http_client client( g_tHOST_URL);
		// API 경로 구성: 
		uri_builder builder(g_tAPI_URL);
		utility::string_t path = g_tPROJECTID; path.append(U("/"));	path.append(g_tPROJECTPATH);
		builder.append(uri::encode_data_string(path));
		builder.append_path(U("repository/tree"));
		// 요청 객체 생성
		http_request request(methods::GET);
		request.set_request_uri(builder.to_string()); 
		// 헤더 추가
		request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
		request.headers().add(U("Content-Type") , g_tContent_Type ); // X

		TRACE("\r\nCRestGitApi::GitLab_GetRepositoryTree2()=====================\r\n" );
		TRACE("CRestGitApi::GitLab_GetRepositoryTree2() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str())+CString(path.c_str()) );

		//logHead(client, request);
		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{	
			web::json::value jsonVal = response.extract_json().get();
			Outjson = jsonVal;
			TRACE_JSON("CRestGitApi::GitLab_GetRepositoryTree2() diff_client", jsonVal);
			if (jsonVal.type() == web::json::value::Array) // 구형 버전에서는 type 검사 필요
			{
				size_t len = jsonVal.size();  // 오래된 버전에서는 size() 제공
				for (size_t i = 0; i < len; ++i)
				{
					web::json::value item = jsonVal[i];
					if (item.has_field(U("name")))
					{
						CString name(item[U("name")].as_string().c_str());
						fileList.push_back(name);
						TRACE("GitLab_GetRepositoryTree2(%2d)    name=[%s] \r\n",i , name );
					}
				}
			}
		}
	}
	catch (const std::exception& e)
	{
		AfxMessageBox(CString(L"예외 발생: ") + CString(CA2W(e.what())));
	}	
	return fileList;
}



// 파일 내용을 문자열로 읽어오는 함수
std::string CRestGitApi::readFileContent(const std::string& filePath) {
	std::ifstream fileStream(filePath.c_str(), std::ios::in | std::ios::binary);
	std::ostringstream contentStream;
	contentStream << fileStream.rdbuf();
	return contentStream.str();
}
std::string CRestGitApi::base64_encode(const std::vector<unsigned char>& data) {
	static const char base64_chars[] ="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	std::string result;
	size_t i = 0;
	unsigned char char_array_3[3];
	unsigned char char_array_4[4];

	for (size_t pos = 0; pos < data.size(); ++pos) {
		char_array_3[i++] = data[pos];
		if (i == 3) {
			char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
			char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
			char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
			char_array_4[3] = char_array_3[2] & 0x3f;

			for (i = 0; i < 4; i++)
				result += base64_chars[char_array_4[i]];
			i = 0;
		}
	}

	if (i) {
		for (size_t j = i; j < 3; j++)
			char_array_3[j] = '\0';

		char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
		char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
		char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
		char_array_4[3] = char_array_3[2] & 0x3f;

		for (size_t j = 0; j < i + 1; j++)
			result += base64_chars[char_array_4[j]];

		while (i++ < 3)
			result += '=';
	}

	return result;
}

std::vector<unsigned char> CRestGitApi::base64_decode(const std::string& encoded_string) {
	static const std::string base64_chars =
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz"
		"0123456789+/";

	auto is_base64 = [](unsigned char c) {
		return (isalnum(c) || (c == '+') || (c == '/'));
	};

	int in_len = static_cast<int>(encoded_string.size());
	int i = 0;
	int j = 0;
	int in_ = 0;
	unsigned char char_array_4[4], char_array_3[3];
	std::vector<unsigned char> ret;

	while (in_len-- && (encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
		char_array_4[i++] = encoded_string[in_]; in_++;
		if (i == 4) {
			for (i = 0; i < 4; i++)
				char_array_4[i] = static_cast<unsigned char>(base64_chars.find(char_array_4[i]));

			char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
			char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
			char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

			for (i = 0; i < 3; i++)
				ret.push_back(char_array_3[i]);
			i = 0;
		}
	}

	if (i) {
		for (j = i; j < 4; j++)
			char_array_4[j] = 0;

		for (j = 0; j < 4; j++)
			char_array_4[j] = static_cast<unsigned char>(base64_chars.find(char_array_4[j]));

		char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
		char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
		char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

		for (j = 0; j < i - 1; j++)
			ret.push_back(char_array_3[j]);
	}

	return ret;
}

// 이진 파일 읽기 후 base64 인코딩 //utility::conversions::to_base64(fileStream.rdbuf());
std::string CRestGitApi::readBinaryFileBase64(const std::string& filePath) {
	std::ifstream fileStream(filePath.c_str(), std::ios::in | std::ios::binary);
	std::vector<unsigned char> buffer((std::istreambuf_iterator<char>(fileStream)), std::istreambuf_iterator<char>());
	auto encoded = base64_encode(buffer) ; 
	return utility::conversions::to_utf8string(encoded);
}




/*
	[get_commits_and_files(람다X) diff_client][TRACE_JSON] Record 0:
	{ "diff" : ""@@ -0" }
	{ "new_path" : "CommitDlg.cpp" }
	{ "old_path" : "CommitDlg.cpp" }
	{ "a_mode" : "0" }
	{ "b_mode" : "100644" }
	{ "new_file" : "true" }
	{ "renamed_file" : "false" }
	{ "deleted_file" : "false" }
	{ "generated_file" : "null" }
*/
//commit 최근 목록 조회 const utility::string_t g_BRANCH	          = U("main");
std::vector<CString> CRestGitApi::get_commits_and_files(json::value &Outjson)
{
	std::vector<CString> fileList;
	try
	{
		http_client client(g_tHOST_URL+g_tAPI_URL); 
		uri_builder builder; //2025.06.14 중복 (U("projects/"));
		builder.append(uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH ))
			.append(U("repository/commits"))
			.append_query(U("ref_name"), g_BRANCH)
			.append_query(U("per_page"), U("30"));

		http_request request(methods::GET);
		request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
		request.set_request_uri(builder.to_uri());
		
		TRACE("\r\nCRestGitApi::get_commits_and_files()=====================\r\n" );
		TRACE("CRestGitApi::get_commits_and_files() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str())+CString(g_tAPI_URL.c_str()) );

		//logHead(client, request);

		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{	
			//	logHead(client);
			web::json::value jsonVal = response.extract_json().get();
			Outjson = jsonVal;
			TRACE_JSON("CRestGitApi::get_commits_and_files(람다X)", jsonVal);
			TRACE("get_commits_and_files() get commits jsonVal=[%s] \r\n", jsonVal.to_string().c_str());

			std::vector<utility::string_t> commit_ids;
			std::vector<utility::string_t> commit_tit;
			size_t length = jsonVal.size();
			for (size_t i = 0; i < length; ++i)
			{
				json::value item = jsonVal[i];
				if (item.has_field(U("id")) && item.has_field(U("title")))
				{
					utility::string_t id    = item[U("id")   ].as_string();
					utility::string_t title = item[U("title")].as_string();
					commit_ids.push_back(id);
					commit_tit.push_back(title);
				}
			}
			// commit diff 중첩된 요청들을 순차적으로 처리
			for (size_t i = 0; i < commit_ids.size(); ++i)
			{
				utility::string_t id       = commit_ids[i];
				utility::string_t title    = commit_tit[i];
				utility::string_t diff_url = g_tHOST_URL+g_tAPI_URL + uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH )	+ 
											U("/repository/commits/") + id + U("/diff"); // 2025.06.14 중복  U("projects/")+

				http_client diff_client(diff_url); 
				uri_builder diff_builder;
				diff_builder.append(U(""));

				http_request diff_request(methods::GET);
				diff_request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);	
				diff_request.set_request_uri(diff_builder.to_uri());

//logHead(diff_client, diff_request);

				http_response diff_response = diff_client.request(diff_request).get();

				if (diff_response.status_code() == status_codes::OK)	{
					json::value diff_json = diff_response.extract_json().get();
					TRACE_JSON("CRestGitApi::get_commits_and_files(람다X) diff_client", diff_json);

					if (diff_json.is_array())	{
						size_t diff_len = diff_json.size();
						for (size_t j = 0; j < diff_len; ++j)	{
							json::value file = diff_json[j];
							if (file.has_field(U("new_path")))	{
								utility::string_t file_path = file[U("new_path")].as_string();						//	std::wcout << L"    - " << file_path << std::endl;

								TRACE("get_commits_and_files(%d)  id=[%s]  message=[%s] file_path2[%s] \r\n",
									i, CString(id.c_str()), CString(title.c_str()) ,CString(file_path.c_str()) );
	
									CString name(file[U("new_path")].as_string().c_str());
									fileList.push_back(name);
									TRACE("GitLab_GetRepositoryTree2(%2d)    name=[%s] \r\n",i , name );			

							}
						}
					}
				}
				else	{
					std::wcout << L"[Error] Diff fetch failed for commit: " << id << std::endl;
				}
				TRACE("get_commits_and_files(람다X)  diff_url [%s]\r\n", CString(diff_url.c_str()) );
			}
		}
	}
	catch (const std::exception& e)
	{
		AfxMessageBox(CString(L"예외 발생: ") + CString(CA2W(e.what())));
	}
	return fileList;
}

// 🔹 각 파일의 마지막 커밋 정보 가져오기
json::value CRestGitApi::getcommitLast(TR_LASTcommit& fi, json::value& commit) 
{
	try
	{
		http_client client(g_tHOST_URL+g_tAPI_URL); 

		uri_builder builder; 
		builder.append(uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH ))
			.append(U("repository/commits"))
			.append_query(U("path"), fi.path)
			.append_query(U("ref_name"), g_BRANCH)
			.append_query(U("per_page"), U("1"));

		http_request request(methods::GET);
		request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
		request.set_request_uri(builder.to_uri());

		TRACE("\r\nCRestGitApi::getcommitLast()=====================\r\n" );
		TRACE("CRestGitApi::getcommitLast() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str())+CString(g_tAPI_URL.c_str()) );


		//logHead(client, request);

		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{	
			web::json::value jsonVal = response.extract_json().get();
			commit = jsonVal;
			TRACE_JSON("CRestGitApi::getcommitLast()", commit);
			TRACE("getcommitLast() get commits jsonVal=[%s] \r\n", jsonVal.to_string().c_str());
			size_t length = jsonVal.size();
			for (size_t i = 0; i < length; ++i)
			{
				json::value item = jsonVal[i];
				if (item.has_field(U("id") ))
				{
					fi.id                  = item[U("id")].as_string();
					fi.last_commit_date    = item[U("committed_date")].as_string();
					fi.last_commit_message = item[U("message")].as_string();
					if (item.has_field(U("parent_ids")) ) //&& item.has_field(U("parent_ids")).type() == web::json::value::Array)
					{
						const web::json::value& arrVal = item[U("parent_ids")]; // item.has_field(U("parent_ids"));
						size_t len = arrVal.size();
						for (size_t i = 0; i < len; ++i)
						{
							if (!arrVal[i].is_null() && arrVal[i].type() == web::json::value::String)
							{
								fi.parent_ids = arrVal[i].as_string(); //.push_back(arrVal[i].as_string());/fi.parent_ids = "9baa4cbd3bd5a75f5aa8dcfd3ce8a9caa286597f"
							}
						}
					}
				}
			}

		}
	}
	catch (const std::exception& e)
	{
		AfxMessageBox(CString(L"예외 발생: ") + CString(CA2W(e.what())));
	}
	return commit;

}

/*
[CHistory::HistoryCommits][TRACE_JSON] Record 2:
{ "id" : "8dcf246b5d9bb57d34b421ca62ac551e8a7cdad1" }
{ "short_id" : "8dcf246b" }
{ "created_at" : "2025-06-16T13:04:28.000+00:00" }
{ "parent_ids" : "[]" }
{ "title" : "Initial commit" }
{ "message" : "Initial commit" }
{ "author_name" : "Administrator" }
{ "author_email" : "gitlab_admin_8ea529@example.com" }
{ "authored_date" : "2025-06-16T13:04:28.000+00:00" }
{ "committer_name" : "Administrator" }
{ "committer_email" : "gitlab_admin_8ea529@example.com" }
{ "committed_date" : "2025-06-16T13:04:28.000+00:00" }
{ "trailers" : "{" }
*/
TR_HISTORYcommit CRestGitApi::ParseFullCommitJson(const json::value& jsonCommit, const utility::string_t& filePath )
{
	TR_HISTORYcommit result;
	result.path            = filePath;
	auto pos = filePath.find_last_of(U("/\\"));
	result.name            = (pos != utility::string_t::npos) ? filePath.substr(pos + 1) : filePath;
	auto get_str = [&](const utility::string_t& key) -> utility::string_t {	return jsonCommit.has_field(key) ? jsonCommit[key].as_string() : U("");
	};
	result.id              = get_str(U("id"));
	result.short_id        = get_str(U("short_id"));
	result.created_at      = get_str(U("created_at"));
	result.title           = get_str(U("title"));
	result.message         = get_str(U("message"));
	result.author_name     = get_str(U("author_name"));
	result.author_email    = get_str(U("author_email"));
	result.authored_date   = get_str(U("authored_date"));
	result.committer_name  = get_str(U("committer_name"));
	result.committer_email = get_str(U("committer_email"));
	result.committed_date  = get_str(U("committed_date"));

	if (jsonCommit.has_field(U("parent_ids")) && jsonCommit[U("parent_ids")].is_array()) 
	{ 	
		if (jsonCommit.has_field(U("parent_ids")) && jsonCommit[U("parent_ids")].type() == web::json::value::Array)
		{
			const web::json::value& arrayVal = jsonCommit[U("parent_ids")];
			int len = arrayVal.size(); 
			for (int i = 0; i < len; ++i)
			{
				if (arrayVal[i].is_string())
				{
					result.vParent_ids.push_back(arrayVal[i].as_string()); //0717
				}
			}
		}
	}

	return result;
}

// 전체 커밋 리스트 파싱
std::vector<TR_HISTORYcommit> CRestGitApi::ParseFullCommitList(const web::json::value& commitsJson, const utility::string_t& filePath)
{
	std::vector<TR_HISTORYcommit> commitList;
	if (commitsJson.is_array())
	{
		size_t len = commitsJson.size();
		for (size_t i = 0; i < len; ++i)
		{
			const web::json::value& commitItem = commitsJson[i];
			TR_HISTORYcommit commit = ParseFullCommitJson(commitItem, filePath);
			commitList.push_back(commit);
		}
	}
	return commitList;
}



json::value CRestGitApi::getcommitHistory(utility::string_t filepath, std::vector<TR_HISTORYcommit> &fi, json::value& commit) 
{
	try
	{
		utility::string_t filepathEncode = filepath;
		http_client client(g_tHOST_URL+g_tAPI_URL); 
		uri_builder builder; 
		builder.append(uri::encode_data_string( g_tPROJECTID+U("/")+g_tPROJECTPATH ))
			.append(U("repository/commits"))
			.append_query(U("path"), filepathEncode)
			.append_query(U("ref_name"), g_BRANCH)
			.append_query(U("per_page"), U("25"));




		http_request request(methods::GET);
		request.headers().add(U("PRIVATE-TOKEN"), g_tPRIVATE_TOKEN);
		request.set_request_uri(builder.to_uri());

		TRACE("\r\nCRestGitApi::getcommitHistory()=====================\r\n" );
		TRACE("CRestGitApi::getcommitHistory() g_tHOST_URL=%s", CString(g_tHOST_URL.c_str()) + CString(g_tAPI_URL.c_str()) );
		TRACE("%s\r\n", CString(builder.to_string().c_str()) );

		//logHead(client, request);

		http_response response = client.request(request).get();
		if (response.status_code() == status_codes::OK)
		{	
			web::json::value jsonVal = response.extract_json().get();
			commit = jsonVal;
			fi=	ParseFullCommitList(jsonVal, filepath);
		}
	}
	catch (const std::exception& e)
	{
		AfxMessageBox(CString(L"예외 발생: ") + CString(CA2W(e.what())));
	}
	return commit;

}

