﻿#pragma once

#include <cpprest/http_client.h>
#include <cpprest/filestream.h>
#include <cpprest/json.h>

using namespace std;
using namespace web;
using namespace web::http;
using namespace web::http::client;
using namespace utility;					// string_t 정의
using namespace web::json;					// json::value
using namespace utility;                    // Common utilities like string conversions
using namespace concurrency::streams;       // Asynchronous streams
using namespace pplx;

struct GitDiffLine	{
	CString line;	bool isAddition;	bool isDeletion;
};

struct GitDiffLine2	{
	enum LineType { FileHeader, Index, OldFile, NewFile, HunkHeader, Added, Removed, Context };
	LineType type;	CString content;
};

//Tr Last Commit 정보 
struct TR_LASTcommit {
	utility::string_t path;
	utility::string_t name;
	utility::string_t id;
	utility::string_t last_commit_date;
	utility::string_t last_commit_message;
	utility::string_t parent_ids; //0708
};

struct TR_HISTORYcommit {
	utility::string_t path;
	utility::string_t name;
	utility::string_t id;
	utility::string_t short_id;
	utility::string_t created_at;
	std::vector<utility::string_t> vParent_ids;//		utility::string_t parent_ids; //0708
	utility::string_t title;
	utility::string_t message;
	utility::string_t author_name;
	utility::string_t author_email;
	utility::string_t authored_date;
	utility::string_t committer_name;
	utility::string_t committer_email;
	utility::string_t committed_date;
};

//0706 22:00
const utility::string_t g_tHOST_URL           = U("http://192.168.0.7");
const utility::string_t g_tAPI_URL            = U("/api/v4/projects/");
const utility::string_t g_tPROJECTID          = U("root");
const utility::string_t g_tPROJECTPATH        = U("htsmts");
const utility::string_t g_BRANCH	          = U("main");
const utility::string_t g_tPRIVATE_TOKEN      = U("glpat-NHSAB1BW2uSLeA13iHKy"); //192.168.0.7 htsmts
const utility::string_t g_tContent_Type       = U("application/json");
const utility::string_t g_tDOWNPATH           = U("D:/");

//////////////////////////////////////////////////////
// code 08/01
/////////////////////////////////////////////////////
// 인코딩 유형
enum EncodingType {
	ENCODING_UTF8_BOM,
	ENCODING_UTF8_NO_BOM,
	ENCODING_ASCII,
	ENCODING_ANSI,
	ENCODING_UTF16_LE,
	ENCODING_UTF16_BE,
	ENCODING_UNKNOWN
};

// 변경 유형 열거형
enum FileChangeType 
{
	Unknown,
	Created,
	Updated,
	Deleted
};

/*192.168.0.7 
docker exec -it gitlab bash
# grep 'Password:' /etc/gitlab/initial_root_password
Password: nSNqv4igeSfpRZfCWo1ghg0op9iNE2wy98Wsjzfd8J8=
안나올경우 --> gitlab-ctl reconfigure
*/


extern json::value g_Outjson; // 람다용

class CRestGitApi
{
public:
	CRestGitApi(void);
	~CRestGitApi(void);

	CString UrlEncode(CString str);
	void DownloadGitlabFile     (const CString& projectPath, const CString filePath, const CString& branch, const CString& privateToken);

	std::vector<CString> GitLab_GetRepositoryTree2(json::value &Outjson);
	std::string readFileContent(const std::string& filePath); 

	std::string base64_encode(const std::vector<unsigned char>& data); 
	std::string readBinaryFileBase64(const std::string& filePath); 
	std::vector<unsigned char> base64_decode(const std::string& encoded_string);

	bool commitFileToGitLab(const std::string& branch,	const std::string& filePath, const std::string& commitMessage);
	json::value getcommitHistory(utility::string_t filepath, std::vector<TR_HISTORYcommit> &fi, json::value& commit);
	std::vector<TR_HISTORYcommit> ParseFullCommitList(const web::json::value& commitsJson, const utility::string_t& filePath);
	TR_HISTORYcommit ParseFullCommitJson(const json::value& jsonCommit, const utility::string_t& filePath = U(""));
	void GetDiffCompareGitLab(const utility::string_t& oldSha, const utility::string_t& newSha, std::vector<json::value>& oldDiffList , std::vector<json::value> & newDiffList); //0709
	void GetDiffFromGitLab(const utility::string_t& commitSha, std::vector<json::value>& outDiffList);
	json::value getcommitLast(TR_LASTcommit& fi, json::value& commit);
	std::vector<CString> get_commits_and_files(json::value &Outjson); 
	

	void TRACE_JSON(const char* context, const web::json::value& val, int indent = 0);
		//////////////////////////////////////////////////////
	// code 08/01
	/////////////////////////////////////////////////////
	void DownloadGit_CStringBuff(const CString& projectPath, const CString filename, const CString tag_path,const CString& commitHash, const CString& branch, const CString& privateToken , CString& outContent);
	void DownloadGit_stringBuff(const CString& projectPath, const CString filename, const CString tag_path,const CString& commitHash, const CString& branch, const CString& privateToken , string& outContent);
	bool DownloadFileFromGitLab_JSON(const std::wstring& projectID,const CString filename, const CString& commitHash ,const CString&  outFilename);
	bool DownloadGitwrite_0802( const CString& filePath,const CString tag_path, const CString& branch, const CString& privateToken);
	int CompareFiles(const std::wstring& file1, const std::wstring& file2);
	void GetCommitStats( const CString& commitHash, json::value & jsonResult) ;
	CString GetJsonCheckCommitStats(const json::value & jsonResult);
};

