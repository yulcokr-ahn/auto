const fs = require("fs");
const XLSX = require("xlsx");

// ✅ 테스트 JSON 데이터
const data = {
  info: { code: "DH", target: "S01" },
  record: [
    {
      name: "Real",
      io: 1,
      array: 0,
      arrayInfo: "",
      items: [
        { len: 10, type: 8, item: "RLKEY", key: 1 },
        { len: 15, type: 4, item: "_HIDEKEY", key: 2 } // ⬅ 언더바 시작 → 스킵
      ]
    }
  ]
};

// ✅ 엑셀 데이터 변환
let rows = [];
for (let r = 0; r < data.record.length; r++) {
  const rec = data.record[r];
  for (let i = 0; i < rec.items.length; i++) {
    const it = rec.items[i];

    // ⬅ 첫 문자 "_" 이면 건너뜀
    if (it.item.startsWith("_")) continue;

    rows.push({
      열_키: it.key,
      키명: it.item,
      길이: it.len,
      타입: it.type
    });
  }
}

// ✅ 워크북 & 시트 생성
const wb = XLSX.utils.book_new();
const ws = XLSX.utils.json_to_sheet(rows);

// ✅ 스타일 설정 (셀 배경, 교차행 색상, 그리드 색상)
const range = XLSX.utils.decode_range(ws["!ref"]);
for (let R = range.s.r; R <= range.e.r; ++R) {
  for (let C = range.s.c; C <= range.e.c; ++C) {
    const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
    if (!ws[cell_address]) continue;

    // 기본 흰색
    ws[cell_address].s = {
      fill: { fgColor: { rgb: R % 2 === 0 ? "FFFFFF" : "DDDDDD" } }, // 짝수 행 회색
      border: {
        top: { style: "thin", color: { rgb: "000000" } },
        left: { style: "thin", color: { rgb: "000000" } },
        bottom: { style: "thin", color: { rgb: "000000" } },
        right: { style: "thin", color: { rgb: "000000" } }
      }
    };
  }
}

// ✅ 워크북에 시트 추가
XLSX.utils.book_append_sheet(wb, ws, "Result");

// ✅ 파일 저장
XLSX.writeFile(wb, "output.xlsx");
console.log("✅ Excel 파일 생성 완료 → output.xlsx");
